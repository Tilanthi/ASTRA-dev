#!/usr/bin/env python3
"""
Execute Priority 2 campaigns (HIGH impact)
- P1: Sub-Isothermal EOS Campaign
- P2: Phase Diagram Mapping
"""

import ray
import yaml
import json
import subprocess
import time
from pathlib import Path
from typing import Dict, List
from datetime import datetime

# This script is similar to run_priority1.py but for Priority 2 campaigns
# Key differences:
# - More simulations (P1: 60, P2: 189)
# - All 256³ resolution (faster)
# - Can run more concurrent (12 sims)

def load_config():
    """Load Ray configuration"""
    with open('ray_config.yaml', 'r') as f:
        return yaml.safe_load(f)

def load_campaign_specs():
    """Load campaign specifications"""
    campaigns = {}
    campaigns_dir = Path("campaigns")
    for json_file in campaigns_dir.glob("*.json"):
        with open(json_file, 'r') as f:
            campaign = json.load(f)
            if campaign.get('priority') == 2:
                campaigns[campaign['campaign_name']] = campaign
    return campaigns

def initialize_ray(config: Dict):
    """Initialize Ray cluster"""
    print(f"Initializing Ray with {config['num_cpus']} CPUs...")
    ray.init(
        num_cpus=config['num_cpus'],
        dashboard_port=config.get('dashboard_port', 8265),
        _memory=200 * 1024 * 1024 * 1024  # 200 GB memory
    )
    print(f"Ray dashboard: http://localhost:{config.get('dashboard_port', 8265)}")

def run_athena_simulation(config_file: Path, config: Dict) -> Dict:
    """
    Run a single Athena++ simulation

    Args:
        config_file: Path to .athena config file
        config: Ray configuration dict

    Returns:
        Dictionary with simulation results
    """
    # Parse config filename to extract parameters
    filename = config_file.stem
    parts = filename.split('_')
    campaign_id = parts[0]

    # Priority 2 campaigns use 256³ resolution
    cores = config['cores_per_sim_256']
    timeout = config['walltime_limit_256']

    # Build command
    athena_exe = Path(config['athena_config']['executable'])
    if not athena_exe.exists():
        athena_exe = Path("./athena/bin/athena")

    # Create output directory
    output_dir = Path(config['output_base_dir']) / campaign_id
    output_dir.mkdir(parents=True, exist_ok=True)

    # Run simulation
    start_time = time.time()
    status_file = output_dir / f"{filename}_status.json"

    try:
        # Update status
        with open(status_file, 'w') as f:
            json.dump({
                "sim_id": filename,
                "status": "RUNNING",
                "start_time": datetime.now().isoformat(),
                "config_file": str(config_file)
            }, f)

        # Execute
        result = subprocess.run(
            ["mpirun", "-np", str(cores), str(athena_exe), "-i", str(config_file)],
            capture_output=True,
            text=True,
            timeout=timeout
        )

        elapsed = time.time() - start_time

        if result.returncode == 0:
            with open(status_file, 'w') as f:
                json.dump({
                    "sim_id": filename,
                    "status": "SUCCESS",
                    "start_time": datetime.now().isoformat(),
                    "end_time": datetime.now().isoformat(),
                    "wall_time_seconds": elapsed,
                    "config_file": str(config_file)
                }, f)
            return {"status": "SUCCESS", "wall_time": elapsed}
        else:
            with open(status_file, 'w') as f:
                json.dump({
                    "sim_id": filename,
                    "status": "FAILED",
                    "start_time": datetime.now().isoformat(),
                    "end_time": datetime.now().isoformat(),
                    "wall_time_seconds": elapsed,
                    "error": result.stderr[-500:] if result.stderr else "Unknown error"
                }, f)
            return {"status": "FAILED", "error": result.stderr}

    except subprocess.TimeoutExpired:
        with open(status_file, 'w') as f:
            json.dump({
                "sim_id": filename,
                "status": "TIMEOUT",
                "start_time": datetime.now().isoformat(),
                "end_time": datetime.now().isoformat(),
                "wall_time_seconds": timeout
            }, f)
        return {"status": "TIMEOUT"}

    except Exception as e:
        with open(status_file, 'w') as f:
            json.dump({
                "sim_id": filename,
                "status": "ERROR",
                "start_time": datetime.now().isoformat(),
                "end_time": datetime.now().isoformat(),
                "error": str(e)
            }, f)
        return {"status": "ERROR", "error": str(e)}

@ray.remote
def run_simulation_remote(config_file: Path, ray_config: Dict):
    """Ray remote task for running simulation"""
    return run_athena_simulation(config_file, ray_config)

def run_campaign(campaign_name: str, campaign_spec: Dict, ray_config: Dict):
    """Run a complete campaign"""

    print("=" * 60)
    print(f"Running Campaign: {campaign_name}")
    print("=" * 60)

    # Get config files
    config_dir = Path("./configs") / campaign_name
    config_files = list(config_dir.glob("*.athena"))

    if not config_files:
        print(f"No config files found for {campaign_name}")
        return

    print(f"Found {len(config_files)} simulations to run")

    # Priority 2 uses 256³ resolution - can run more concurrent
    max_concurrent = ray_config['max_concurrent_256']
    print(f"Max concurrent: {max_concurrent}")

    # Run simulations in batches
    results = []
    for i in range(0, len(config_files), max_concurrent):
        batch = config_files[i:i+max_concurrent]
        print(f"\nRunning batch {i//max_concurrent + 1}/{(len(config_files)-1)//max_concurrent + 1}")
        print(f"Simulations: {len(batch)} files")

        # Launch batch
        batch_results = ray.get([
            run_simulation_remote.remote(config_file, ray_config)
            for config_file in batch
        ])

        results.extend(batch_results)

        # Print summary
        success = sum(1 for r in batch_results if r.get('status') == 'SUCCESS')
        print(f"Batch complete: {success}/{len(batch)} succeeded")

    # Campaign summary
    success_count = sum(1 for r in results if r.get('status') == 'SUCCESS')
    failed_count = sum(1 for r in results if r.get('status') in ['FAILED', 'TIMEOUT', 'ERROR'])

    print(f"\nCampaign {campaign_name} Summary:")
    print(f"  Success: {success_count}")
    print(f"  Failed: {failed_count}")
    print(f"  Total: {len(results)}")

    # Save campaign summary
    output_dir = Path(ray_config['output_base_dir']) / campaign_name
    summary_file = output_dir / "campaign_summary.json"
    with open(summary_file, 'w') as f:
        json.dump({
            "campaign": campaign_name,
            "total_simulations": len(results),
            "success": success_count,
            "failed": failed_count,
            "completion_time": datetime.now().isoformat()
        }, f, indent=2)

    return success_count == len(results)

def cleanup_campaign(campaign_name: str, ray_config: Dict):
    """Clean up campaign files after analysis"""

    print(f"\nCleaning up {campaign_name}...")

    output_dir = Path(ray_config['output_base_dir']) / campaign_name

    # Keep essential files
    keep_patterns = ray_config['retention_policy']['keep_files']
    delete_patterns = ray_config['retention_policy']['delete_files']

    # Find and delete HDF5 files
    deleted_count = 0
    for pattern in ['*.hdf5']:
        for file in output_dir.rglob(pattern):
            # Keep files matching keep patterns
            should_delete = True
            for keep_pattern in keep_patterns:
                if keep_pattern in file.name:
                    should_delete = False
                    break

            if should_delete:
                try:
                    file.unlink()
                    deleted_count += 1
                except Exception as e:
                    print(f"Warning: Could not delete {file}: {e}")

    # Also clean up .rst, .log files
    for pattern in ['*.rst', '*.log']:
        for file in output_dir.rglob(pattern):
            try:
                file.unlink()
                deleted_count += 1
            except Exception as e:
                print(f"Warning: Could not delete {file}: {e}")

    print(f"Cleanup complete: {deleted_count} files deleted")

def main():
    """Main execution function"""

    import argparse
    parser = argparse.ArgumentParser(description="Run Priority 2 campaigns")
    parser.add_argument('--campaign', choices=['P1', 'P2', 'all'], default='all',
                       help='Which campaign(s) to run')
    args = parser.parse_args()

    # Load configuration
    config = load_config()
    campaigns = load_campaign_specs()

    # Initialize Ray
    initialize_ray(config)

    # Determine which campaigns to run
    if args.campaign == 'all':
        campaigns_to_run = campaigns.keys()
    elif args.campaign == 'P1':
        campaigns_to_run = ['P1_subisothermal_eos']
    elif args.campaign == 'P2':
        campaigns_to_run = ['P2_phase_diagram']

    # Run campaigns
    print("=" * 60)
    print("Priority 2 Campaigns Execution")
    print("=" * 60)
    print(f"Campaigns to run: {list(campaigns_to_run)}")

    all_success = True
    for campaign_name in campaigns_to_run:
        if campaign_name in campaigns:
            success = run_campaign(campaign_name, campaigns[campaign_name], config)
            if not success:
                print(f"WARNING: {campaign_name} had failures")
                all_success = False

            # Cleanup if enabled
            if config.get('auto_cleanup', False):
                cleanup_campaign(campaign_name, config)
        else:
            print(f"WARNING: Campaign {campaign_name} not found")

    # Shutdown Ray
    ray.shutdown()

    print("\n" + "=" * 60)
    if all_success:
        print("All Priority 2 campaigns completed successfully!")
    else:
        print("Some campaigns had failures - check logs")
    print("=" * 60)

if __name__ == "__main__":
    main()
