# Peer Response Priority Campaigns - May 2026

**Date**: 2026-05-07
**Purpose**: Address critical referee concerns for publication
**Cluster**: 200 CPUs, Ray-based execution (no SLURM)
**Total simulations**: 280 (Priority 1: 36 + Priority 2: 244)

---

## Overview

This package contains specifications for two peer response simulation campaigns:

### Priority 1 - CRITICAL for Publication
1. **C_min-λ/W Resolution Convergence** (12 simulations): Test λ/W numerical convergence
2. **SLW Consistency Test** (24 simulations): Resolve supercritical vs SLW campaign contradiction

### Priority 2 - HIGH Impact
3. **Sub-Isothermal EOS Campaign** (108 simulations): Test realistic γ = 0.7, 0.8
4. **Phase Diagram Mapping** (136 simulations): Define three fragmentation regimes

---

## Quick Start

```bash
# 1. Extract package
tar -xzf peer_response_priority_campaigns_may2026.tar.gz
cd peer_response_priority_campaigns_may2026/

# 2. Compile Athena++
bash compile_athena.sh

# 3. Generate configs
python generate_configs.py

# 4. Run Priority 1 campaigns
python run_priority1.py --campaign all

# 5. After Priority 1 completes, run Priority 2
python run_priority2.py --campaign all

# 6. Analyze results
python analyze_all.py
```

---

## Campaign Specifications

### Campaign C1: Resolution Convergence for λ/W (Priority 1)

**Purpose**: Directly test whether λ/W measurements are numerically converged with resolution

**Referee concern**: "The absence of resolution convergence testing for λ/W is a significant gap" (Rev. B, Moderate #7)

**Parameter Space**:
```
f:      1.1 (fiducial near-critical)
β:      1.0 (fiducial)
θ:      0° (longitudinal)
M:      1.0 (fiducial turbulence)
Seeds:  42, 137, 251 (3 seeds)
Resolutions: 256³, 512³ (factor of 2)
Domain: Lx = 8λJ, Ly = Lz = 1λJ
```

**Total**: 3 seeds × 2 resolutions = 6 simulations

**Key Innovation**: Extract λ/W at BOTH resolutions using identical analysis pipeline

**Success Criteria**:
- λ/W changes by < 10% between 256³ and 512³
- Quantify resolution-dependent bias if present
- Provide convergence statement for referee

**Expected Runtime**: ~6 hours (512³ sims take ~1 hour each)

---

### Campaign C2: SLW Consistency Test (Priority 1)

**Purpose**: Resolve contradiction between 654-simulation supercritical campaign (zero longitudinal fragmentation) and 63-simulation SLW campaign (λ/W = 4-7)

**Referee concern**: "These findings are in direct contradiction... This is the most serious internal inconsistency" (Rev. B, Critical #2)

**Parameter Space**:
```
f:      1.5, 2.0, 2.5, 3.0 (supercritical)
β:      1.0 (fiducial)
θ:      0° (longitudinal)
M:      1.0 (fiducial)
Seeds:  42, 137, 251 (3 seeds)
Resolution: 512³ (matches SLW)
Domain: Lx = 8λJ, Ly = Lz = 1λJ
```

**Total**: 4 f values × 3 seeds = 12 simulations

**Dual Analysis Pipeline**:
Each simulation will be analyzed using BOTH methods:
1. **Supercritical method**: Measure σ(ρ_x1)/⟨ρ_x1⟩ along filament axis
2. **SLW method**: Peak detection on longitudinal column density profile

**Success Criteria**:
- Identify which analysis method detects longitudinal beading
- Quantify detection threshold differences
- Resolve the contradiction

**Expected Runtime**: ~12 hours

---

### Campaign P1: Sub-Isothermal EOS Campaign (Priority 2)

**Purpose**: Test fragmentation behavior for realistic effective γ ≈ 0.7-0.9 (molecular cloud conditions)

**Referee concern**: "Real filaments have effective γ ≈ 0.7-0.9... A more useful framing would compare with γ = 0.7-0.9" (Rev. B, Moderate #6)

**Parameter Space**:
```
f:      1.1, 1.5, 2.0, 2.5, 3.0 (5 values)
β:      0.3, 1.0, 2.0 (3 values)
θ:      0° (longitudinal)
M:      1.0 (fiducial)
γ:      0.7, 0.8 (sub-isothermal effective)
Seeds:  42, 137 (2 seeds)
Resolution: 256³
Domain: Lx = 8λJ, Ly = Lz = 1λJ
```

**Total**: 5 f × 3 β × 2 γ × 2 seeds = 60 simulations

**Physical Motivation**: Real molecular clouds have radiative cooling giving effective γ < 1

**Success Criteria**:
- Map fragmentation behavior vs γ
- Compare sub-isothermal vs isothermal
- Assess whether γ-dependence affects λ/W measurements

**Expected Runtime**: ~15 hours

---

### Campaign P2: Phase Diagram Mapping (Priority 2)

**Purpose**: Explicitly define three fragmentation regimes in (β, f, M) parameter space

**Referee concern**: "These regimes are never explicitly defined, mapped in parameter space, or shown in a figure" (Rev. B, Minor #9)

**Parameter Space**:
```
f:      0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.5, 3.0 (9 values)
β:      0.2, 0.3, 0.5, 1.0, 2.0, 3.0, 5.0 (7 values)
M:      0.5, 1.0, 2.0 (3 values)
θ:      0° (longitudinal)
γ:      1.0 (isothermal)
Seeds:  42 (1 seed for mapping)
Resolution: 256³
Domain: Lx = 8λJ, Ly = Lz = 1λJ
```

**Total**: 9 f × 7 β × 3 M = 189 simulations

**Classification Criteria**:
- **Magnetically Subcritical**: No fragmentation (FLAT)
- **Magnetically Regulated**: Slow beading (t_frag > 1.0 t_J)
- **Thermally Dominated**: Fast beading (t_frag < 0.5 t_J)

**Success Criteria**:
- Create phase diagram in (β, f) space for each M
- Explicitly define regime boundaries
- Publication-ready figure

**Expected Runtime**: ~25 hours

---

## Disk Cleanup Protocol

To keep cluster disks healthy, after EACH sub-campaign completion:

```bash
# After C1 (Resolution Convergence)
python cleanup_campaign.py --campaign C1 --keep_results

# After C2 (Consistency Test)
python cleanup_campaign.py --campaign C2 --keep_results

# After P1 (Sub-Isothermal EOS)
python cleanup_campaign.py --campaign P1 --keep_results

# After P2 (Phase Diagram)
python cleanup_campaign.py --campaign P2 --keep_results
```

**Cleanup strategy**:
- Keep: status.json, lambda_W.json, analysis results
- Delete: HDF5 snapshots (*.hdf5), HST files, restart files
- Archive: Final snapshot only (for verification if needed)

---

## Analysis Protocols

### Campaign C1 Analysis

```python
# analyze_C1.py
- Extract λ/W from 256³ and 512³ simulations
- Compute convergence ratio: λ/W_512 / λ/W_256
- Statistical test: Is convergence < 10%?
- Output: convergence_report.json, convergence_figure.pdf
```

### Campaign C2 Analysis

```python
# analyze_C2.py
- Apply BOTH analysis methods to SAME simulations
- Method 1: Supercritical metric (σ(ρ_x1)/⟨ρ_x1⟩)
- Method 2: SLW peak detection (λ/W extraction)
- Compare: Which method detects beading?
- Output: consistency_report.json, method_comparison.pdf
```

### Campaign P1 Analysis

```python
# analyze_P1.py
- Extract λ/W vs γ for each (f, β)
- Compare γ=0.7, 0.8 vs isothermal γ=1.0
- Test: Does λ/W depend systematically on γ?
- Output: eos_dependence_report.json, gamma_comparison.pdf
```

### Campaign P2 Analysis

```python
# analyze_P2.py
- Classify each simulation into 3 regimes
- Create phase diagram: (β, f) parameter space
- Fit regime boundaries
- Output: phase_diagram.json, phase_diagram_figure.pdf
```

---

## Ray Configuration

**File**: ray_config.yaml

```yaml
num_cpus: 200
max_concurrent_256: 12  # 12 sims × 16 cores = 192 cores
max_concurrent_512: 3   # 3 sims × 64 cores = 192 cores
cores_per_sim_256: 16
cores_per_sim_512: 64
walltime_limit_256: 7200   # 2 hours
walltime_limit_512: 14400  # 4 hours
checkpoint_interval: 0.1   # t_J
output_base_dir: ./outputs
```

---

## Timeline Estimates

| Campaign | Simulations | Wall Time | CPU Hours |
|----------|-------------|-----------|-----------|
| C1 | 6 | 6 hours | 96 |
| C2 | 12 | 12 hours | 192 |
| P1 | 60 | 15 hours | 240 |
| P2 | 189 | 25 hours | 302 |
| **Total** | **267** | **58 hours** | **830** |

**Actual runtime**: ~2-3 days with parallel execution

---

## Expected Deliverables

### For Paper Revision

1. **Resolution Convergence Statement** (C1):
   - "λ/W changes by X% between 256³ and 512³"
   - Figure: λ/W vs resolution bar plot

2. **Contradiction Resolution** (C2):
   - Explanation of supercritical vs SLW discrepancy
   - Figure: Dual analysis method comparison

3. **Sub-Isothermal Results** (P1):
   - "λ/W shows [no/significant] dependence on γ"
   - Figure: λ/W vs γ curves

4. **Phase Diagram** (P2):
   - Explicit regime definitions with boundaries
   - Figure: (β, f) phase diagram

### For Referee Response

- Direct responses to Rev. B Moderate #7 (resolution convergence)
- Direct responses to Rev. B Critical #2 (internal contradiction)
- Direct responses to Rev. B Moderate #6 (sub-isothermal EOS)
- Direct responses to Rev. B Minor #9 (regime definitions)

---

## Verification Checklist

Before deployment:
- [ ] All 4 campaign specifications finalized
- [ ] Ray configuration tested with 200 CPUs
- [ ] Athena++ compiles with filament_fragmentation problem
- [ ] Config generation script produces correct number of files
- [ ] Analysis scripts tested on existing data
- [ ] Cleanup script preserves essential data

During execution:
- [ ] Monitor Ray dashboard (port 8265)
- [ ] Check disk usage every 4 hours
- [ ] Run cleanup after each sub-campaign
- [ ] Verify all simulations complete (SUCCESS status)

After completion:
- [ ] All analysis scripts run without errors
- [ ] All deliverables generated (4 reports + 4 figures)
- [ ] Paper integration text drafted
- [ ] Referee response language drafted

---

## Package Contents

```
peer_response_priority_campaigns_may2026/
├── README.md                              # This file
├── ray_config.yaml                        # Ray cluster configuration
├── compile_athena.sh                      # Athena++ compilation script
├── generate_configs.py                    # Config generation (all campaigns)
├── cleanup_campaign.py                    # Disk cleanup script
├── run_priority1.py                       # Priority 1 execution
├── run_priority2.py                       # Priority 2 execution
├── analyze_all.py                         # Master analysis script
├── campaigns/
│   ├── C1_resolution_convergence.json    # C1 specification
│   ├── C2_consistency_test.json          # C2 specification
│   ├── P1_subisothermal_eos.json         # P1 specification
│   └── P2_phase_diagram.json             # P2 specification
├── analysis/
│   ├── analyze_C1.py                     # C1 analysis
│   ├── analyze_C2.py                     # C2 analysis
│   ├── analyze_P1.py                     # P1 analysis
│   ├── analyze_P2.py                     # P2 analysis
│   └── lambda_W_extraction.py            # Shared λ/W extraction
└── outputs/                               # Created during run (not in package)
```

---

## Contact and Support

**Package created**: 2026-05-07
**ASTRA version**: 4.7
**Target submission**: MNRAS peer response

For questions or issues, refer to:
- Main paper: filament_spacing_streamlined_mnras.tex
- Referee report: See document header
- Previous campaigns: referee_campaigns_may2026/, slw_campaign_may2026/
