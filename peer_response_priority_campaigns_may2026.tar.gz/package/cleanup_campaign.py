#!/usr/bin/env python3
"""
Disk cleanup script for peer response campaigns

Keeps essential files (status.json, analysis results) and deletes
large HDF5 files, logs, and temporary files to maintain disk health.
"""

import json
import sys
from pathlib import Path
from typing import List

# Load retention policy
def load_retention_policy():
    """Load file retention policy from ray_config.yaml"""
    try:
        import yaml
        with open('ray_config.yaml', 'r') as f:
            config = yaml.safe_load(f)
            return config['retention_policy']
    except:
        # Default policy if config not found
        return {
            'keep_files': [
                "status.json",
                "lambda_W.json",
                "*_results.json",
                "*_report.json",
                "final_snapshot.hdf5"
            ],
            'delete_files': [
                "*.hdf5",
                "*.rst",
                "*.log",
                "*.out",
                "*.err"
            ]
        }

def should_keep_file(file: Path, keep_patterns: List[str]) -> bool:
    """Check if file should be kept based on patterns"""
    for pattern in keep_patterns:
        if pattern in file.name:
            return True
    return False

def cleanup_campaign(campaign_name: str, dry_run: bool = False):
    """
    Clean up campaign directory

    Args:
        campaign_name: Name of campaign (e.g., 'C1_resolution_convergence')
        dry_run: If True, only report what would be deleted
    """

    print("=" * 60)
    print(f"Cleaning up {campaign_name}")
    print("=" * 60)

    output_dir = Path("./outputs") / campaign_name

    if not output_dir.exists():
        print(f"Campaign directory not found: {output_dir}")
        return

    # Load retention policy
    policy = load_retention_policy()
    keep_patterns = policy['keep_files']
    delete_patterns = policy['delete_files']

    # Find all files
    all_files = []
    for ext in ['*.hdf5', '*.rst', '*.log', '*.out', '*.err', '*.json']:
        all_files.extend(output_dir.rglob(ext))

    if not all_files:
        print("No files to clean up")
        return

    # Classify files
    keep_files = []
    delete_files = []

    for file in all_files:
        if file.is_dir():
            continue

        if should_keep_file(file, keep_patterns):
            keep_files.append(file)
        else:
            # Check if it matches delete patterns
            for pattern in delete_patterns:
                if file.match(pattern) or pattern in file.suffix:
                    delete_files.append(file)
                    break

    # Report
    print(f"\nTotal files found: {len(all_files)}")
    print(f"Files to keep: {len(keep_files)}")
    print(f"Files to delete: {len(delete_files)}")

    # Calculate space savings
    delete_size = sum(f.stat().st_size for f in delete_files)
    delete_size_mb = delete_size / (1024 * 1024)

    print(f"Space to free: {delete_size_mb:.1f} MB")

    # List files to keep (for verification)
    print(f"\nKeeping (sample):")
    for f in keep_files[:10]:
        print(f"  {f.relative_to(output_dir)}")
    if len(keep_files) > 10:
        print(f"  ... and {len(keep_files) - 10} more")

    # List files to delete (sample)
    print(f"\nDeleting (sample):")
    for f in delete_files[:10]:
        size_mb = f.stat().st_size / (1024 * 1024)
        print(f"  {f.relative_to(output_dir)} ({size_mb:.1f} MB)")
    if len(delete_files) > 10:
        print(f"  ... and {len(delete_files) - 10} more")

    # Delete files
    if not dry_run:
        print(f"\nDeleting files...")
        deleted_count = 0
        for f in delete_files:
            try:
                f.unlink()
                deleted_count += 1
            except Exception as e:
                print(f"  Warning: Could not delete {f}: {e}")

        print(f"Deleted {deleted_count}/{len(delete_files)} files")

        # Save cleanup record
        record = {
            'campaign': campaign_name,
            'cleanup_time': str(Path.cwd()),
            'files_kept': len(keep_files),
            'files_deleted': deleted_count,
            'space_freed_mb': delete_size_mb,
            'kept_files': [str(f.relative_to(output_dir)) for f in keep_files]
        }

        record_file = output_dir / "cleanup_record.json"
        with open(record_file, 'w') as f:
            json.dump(record, f, indent=2)

        print(f"Cleanup record saved to: {record_file}")
    else:
        print("\nDRY RUN - No files deleted")

def cleanup_all(dry_run: bool = False):
    """Clean up all campaigns"""
    campaigns = [
        'C1_resolution_convergence',
        'C2_consistency_test',
        'P1_subisothermal_eos',
        'P2_phase_diagram'
    ]

    for campaign in campaigns:
        cleanup_campaign(campaign, dry_run)

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Clean up campaign files")
    parser.add_argument('--campaign', help='Specific campaign to clean (default: all)')
    parser.add_argument('--dry-run', action='store_true', help='Report only, do not delete')
    args = parser.parse_args()

    if args.campaign:
        cleanup_campaign(args.campaign, args.dry_run)
    else:
        cleanup_all(args.dry_run)

if __name__ == "__main__":
    main()
