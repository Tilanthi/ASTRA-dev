#!/usr/bin/env python3
"""
Generate Athena++ config files for all peer response campaigns
"""

import json
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple

# Load campaign specifications
def load_campaign_specs():
    """Load all campaign JSON specifications"""
    campaigns_dir = Path(__file__).parent / "campaigns"
    campaigns = {}
    for json_file in campaigns_dir.glob("*.json"):
        with open(json_file, 'r') as f:
            campaign = json.load(f)
            campaigns[campaign['campaign_name']] = campaign
    return campaigns

def generate_athena_config(campaign_name: str, params: Dict, output_dir: Path):
    """Generate a single Athena++ config file"""

    # Extract parameters
    f = params['f']
    beta = params['beta']
    theta = params['theta_degrees']
    mach = params.get('mach', 1.0)
    gamma = params.get('gamma', 1.0)
    seed = params['seed']
    resolution = params.get('resolution', '256')
    campaign_id = params.get('campaign_id', 'unknown')

    # Grid configuration
    if resolution == "256":
        nx, ny, nz = 256, 32, 32
    elif resolution == "512":
        nx, ny, nz = 512, 64, 64
    else:
        raise ValueError(f"Unknown resolution: {resolution}")

    # Domain
    Lx = 8.0
    Ly = 1.0
    Lz = 1.0

    # Magnetic field components
    Bx = np.sin(np.radians(theta))
    By = 0.0
    Bz = np.cos(np.radians(theta))

    # t_max
    t_max = params.get('t_max_tJ', 1.0)

    # Output cadence
    output_cadence = params.get('output_cadence_tJ', 0.05)

    # Generate filename
    filename = f"{campaign_id}_f{f}_b{beta}_th{int(theta)}_s{seed}.athena"

    # Generate config content
    config_content = f"""<job>
problemname   filament_fragmentation

<time>
tlim          {t_max}
dt_parabolic  0.0
dt_hydro      0.3
nsmwl         1
start_time    0.0
time          0.0
</time>

<mesh>
nx1           {nx}
nx2           {ny}
nx3           {nz}
x1min         0.0
x1max         {Lx}
x2min         {-Ly/2.0}
x2max         {Ly/2.0}
x3min         {-Lz/2.0}
x3max         {Lz/2.0}
ix1_bc        periodic
ix2_bc        outflow
ix3_bc        outflow
</mesh>

<hydro>
isothermal    true
gamma         {gamma}
</hydro>

<field>
b0x           {Bx}
b0y           {By}
b0z           {Bz}
</field>

<problem>
filament_mass_to_jeans    {f}
plasma_beta               {beta}
mach_number               {mach}
random_seed               {seed}
</problem>

<output>
output      hdf5
file_type   hdf5
dt          {output_cadence}
variables   prim
</output1>

<output1>
out_fmt     hdf5
file_prefix sim
dt          {output_cadence}
variables   prim
</output1>

</job>
"""

    # Write config file
    config_path = output_dir / filename
    with open(config_path, 'w') as f:
        f.write(config_content)

    return config_path

def generate_campaign_configs(campaign_name: str, campaign_spec: Dict):
    """Generate all config files for a campaign"""

    print(f"Generating configs for {campaign_name}...")

    # Create output directory
    output_dir = Path("./configs") / campaign_name
    output_dir.mkdir(parents=True, exist_ok=True)

    # Extract parameter space
    params = campaign_spec['parameter_space']
    domain = campaign_spec['domain']
    temporal = campaign_spec['temporal_settings']
    grid = campaign_spec.get('grid_config', {})

    # Get resolution
    if 'resolutions' in params:
        resolutions = params['resolutions']
    elif 'resolution' in grid:
        resolutions = [grid['resolution']]
    elif 'gamma_vals' in params:
        resolutions = ['256']  # Default for P1, P2
    else:
        resolutions = ['256']

    # Get parameter values
    f_vals = params.get('f_vals', [1.1])
    beta_vals = params.get('beta_vals', [1.0])
    theta_vals = params.get('theta_degrees', [0.0])
    mach_vals = params.get('mach', [1.0])
    if isinstance(mach_vals, (int, float)):
        mach_vals = [mach_vals]

    # Handle gamma
    if 'gamma_vals' in params:
        gamma_vals = params['gamma_vals']
    elif 'gamma' in params:
        gamma_vals = [params['gamma']]
    else:
        gamma_vals = [1.0]

    # Handle seeds
    seeds = params.get('seeds', [42])

    # Generate all combinations
    config_files = []
    count = 0

    for f in f_vals:
        for beta in beta_vals:
            for theta in theta_vals:
                for mach in mach_vals:
                    for gamma in gamma_vals:
                        for seed in seeds:
                            for resolution in resolutions:
                                # Determine if this resolution applies
                                if campaign_name == 'C1_resolution_convergence':
                                    # C1: All resolutions for all seeds
                                    pass
                                elif resolution == '512' and campaign_name != 'C1_resolution_convergence':
                                    # Skip 512 for non-C1 campaigns unless explicitly needed
                                    continue

                                # Create parameter dict
                                sim_params = {
                                    'f': f,
                                    'beta': beta,
                                    'theta_degrees': theta,
                                    'mach': mach,
                                    'gamma': gamma,
                                    'seed': seed,
                                    'resolution': resolution,
                                    't_max_tJ': temporal['t_max_tJ'],
                                    'output_cadence_tJ': temporal['output_cadence_tJ'],
                                    'campaign_id': campaign_name
                                }

                                # Generate config
                                config_path = generate_athena_config(campaign_name, sim_params, output_dir)
                                config_files.append(config_path)
                                count += 1

    print(f"Generated {count} config files for {campaign_name}")
    print(f"Output directory: {output_dir}")

    return count, config_files

def main():
    """Generate all campaign configs"""

    print("=" * 60)
    print("Peer Response Campaign Config Generator")
    print("=" * 60)

    # Load campaign specifications
    campaigns = load_campaign_specs()

    # Generate configs for each campaign
    total_count = 0
    for campaign_name, campaign_spec in campaigns.items():
        count, configs = generate_campaign_configs(campaign_name, campaign_spec)
        total_count += count
        print()

    print("=" * 60)
    print(f"Total config files generated: {total_count}")
    print("=" * 60)

    # Verify count matches expected
    expected_counts = {
        'C1_resolution_convergence': 6,
        'C2_consistency_test': 12,
        'P1_subisothermal_eos': 60,
        'P2_phase_diagram': 189
    }

    print("\nVerification:")
    for campaign_name, expected in expected_counts.items():
        # Count actual files
        config_dir = Path("./configs") / campaign_name
        if config_dir.exists():
            actual = len(list(config_dir.glob("*.athena")))
            status = "✓" if actual == expected else f"✗ (expected {expected})"
            print(f"  {campaign_name}: {actual} files {status}")
        else:
            print(f"  {campaign_name}: NOT FOUND")

if __name__ == "__main__":
    main()
