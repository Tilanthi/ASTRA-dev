#!/usr/bin/env python3
"""
Master analysis script for all peer response campaigns

This script runs all campaign analyses and generates a comprehensive report.
"""

import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime

def run_analysis_script(script_name: str) -> bool:
    """Run an individual analysis script"""
    script_path = Path("analysis") / script_name

    if not script_path.exists():
        print(f"WARNING: {script_name} not found, skipping...")
        return False

    print(f"\nRunning {script_name}...")
    try:
        result = subprocess.run(
            [sys.executable, str(script_path)],
            capture_output=True,
            text=True,
            timeout=300  # 5 minutes max per analysis
        )

        if result.returncode == 0:
            print(result.stdout)
            return True
        else:
            print(f"ERROR in {script_name}:")
            print(result.stderr)
            return False

    except subprocess.TimeoutExpired:
        print(f"ERROR: {script_name} timed out")
        return False
    except Exception as e:
        print(f"ERROR running {script_name}: {e}")
        return False

def generate_master_report():
    """Generate comprehensive report across all campaigns"""

    print("\n" + "=" * 60)
    print("Generating Master Report")
    print("=" * 60)

    campaigns = {
        'C1': 'C1_resolution_convergence',
        'C2': 'C2_consistency_test',
        'P1': 'P1_subisothermal_eos',
        'P2': 'P2_phase_diagram'
    }

    all_reports = {}

    for code, name in campaigns.items():
        report_file = Path(f"./outputs/{name}/{name}_report.json")

        if report_file.exists():
            with open(report_file, 'r') as f:
                all_reports[code] = json.load(f)
                print(f"✓ Loaded {code} report")
        else:
            print(f"✗ {code} report not found")
            all_reports[code] = None

    # Generate summary
    master_report = {
        'generation_date': datetime.now().isoformat(),
        'campaigns': all_reports,
        'summary': {}
    }

    # Count successes
    priority1_complete = all_reports.get('C1') is not None and all_reports.get('C2') is not None
    priority2_complete = all_reports.get('P1') is not None and all_reports.get('P2') is not None

    master_report['summary']['priority1_complete'] = priority1_complete
    master_report['summary']['priority2_complete'] = priority2_complete
    master_report['summary']['all_complete'] = priority1_complete and priority2_complete

    # Save master report
    master_report_file = Path("./master_analysis_report.json")
    with open(master_report_file, 'w') as f:
        json.dump(master_report, f, indent=2)

    print(f"\nMaster report saved to: {master_report_file}")

    # Generate referee response summary
    print("\n" + "=" * 60)
    print("Referee Response Summary")
    print("=" * 60)

    if all_reports['C1']:
        c1 = all_reports['C1']
        print(f"\n[Rev. B, Moderate #7] Resolution Convergence:")
        print(f"  λ/W changes by {c1['mean_pct_change']:.1f}% ± {c1['std_pct_change']:.1f}%")
        print(f"  Status: {c1['conclusion']}")

    if all_reports['C2']:
        c2 = all_reports['C2']
        print(f"\n[Rev. B, Critical #2] SLW Consistency Test:")
        print(f"  Agreement: {c2['agreement_count']}/{c2['total_simulations']}")
        print(f"  Conclusion: {c2['conclusion']}")

    if all_reports['P1']:
        p1 = all_reports['P1']
        print(f"\n[Rev. B, Moderate #6] Sub-Isothermal EOS:")
        print(f"  Status: Analysis complete")

    if all_reports['P2']:
        p2 = all_reports['P2']
        print(f"\n[Rev. B, Minor #9] Phase Diagram:")
        print(f"  Status: Analysis complete")

    return master_report

def main():
    """Main execution"""

    print("=" * 60)
    print("Peer Response Campaign Analysis")
    print("=" * 60)

    # Check which campaigns have completed
    print("\nChecking for completed campaigns...")

    campaigns_to_analyze = []

    # C1
    if (Path("./outputs/C1_resolution_convergence").exists() and
        list(Path("./outputs/C1_resolution_convergence").glob("*.hdf5"))):
        campaigns_to_analyze.append('C1')
        print("  C1: Data available")

    # C2
    if (Path("./outputs/C2_consistency_test").exists() and
        list(Path("./outputs/C2_consistency_test").glob("*.hdf5"))):
        campaigns_to_analyze.append('C2')
        print("  C2: Data available")

    # P1
    if (Path("./outputs/P1_subisothermal_eos").exists() and
        list(Path("./outputs/P1_subisothermal_eos").glob("*.hdf5"))):
        campaigns_to_analyze.append('P1')
        print("  P1: Data available")

    # P2
    if (Path("./outputs/P2_phase_diagram").exists() and
        list(Path("./outputs/P2_phase_diagram").glob("*.hdf5"))):
        campaigns_to_analyze.append('P2')
        print("  P2: Data available")

    if not campaigns_to_analyze:
        print("\nNo campaign data found to analyze.")
        return

    # Run analyses
    success_count = 0

    if 'C1' in campaigns_to_analyze:
        if run_analysis_script('analyze_C1.py'):
            success_count += 1

    if 'C2' in campaigns_to_analyze:
        if run_analysis_script('analyze_C2.py'):
            success_count += 1

    # Note: P1 and P2 analysis scripts would be similar to C1/C2
    # For brevity, we'll just note they need to be created

    print(f"\nAnalysis complete: {success_count}/{len(campaigns_to_analyze)} successful")

    # Generate master report
    generate_master_report()

if __name__ == "__main__":
    main()
