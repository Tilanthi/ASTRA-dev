#!/usr/bin/env python3
"""
Analysis script for Campaign P1: Sub-Isothermal EOS

Tests γ-dependence of fragmentation behavior for realistic molecular cloud conditions.
"""

import json
import h5py
import numpy as np
from pathlib import Path
from scipy.signal import find_peaks
from typing import Dict, List

def extract_lambda_W_and_tfrag(hdf5_file: Path) -> Dict:
    """Extract λ/W and t_frag from HDF5 file"""
    try:
        with h5py.File(hdf5_file, 'r') as f:
            rho = f['dens'][:]

            # Get time from file attributes or structure
            # This is simplified - actual implementation depends on HDF5 structure

            # Extract λ/W (same method as C1)
            sigma_yz = np.mean(rho, axis=2)
            profile_z = np.mean(sigma_yz, axis=0)

            background = np.median(np.concatenate([profile_z[:10], profile_z[-10:]]))
            profile_sub = profile_z - background

            peaks, properties = find_peaks(
                profile_sub,
                height=0.1 * np.std(profile_sub),
                distance=4,
                prominence=0.1 * np.std(profile_sub)
            )

            if len(peaks) >= 3:
                peak_spacing = np.diff(peaks)
                lambda_cells = np.mean(peak_spacing)

                center_idx = rho.shape[2] // 2
                transverse_profile = sigma_yz[:, center_idx]
                transverse_profile = transverse_profile / np.max(transverse_profile)

                half_max = 0.5
                above_half = transverse_profile > half_max
                fwhm_cells = np.sum(above_half)

                nz, ny, nx = rho.shape
                Lx_lambdaJ = 8.0
                cells_per_lambdaJ = nx / Lx_lambdaJ

                lambda_lambdaJ = lambda_cells / cells_per_lambdaJ
                W_lambdaJ = fwhm_cells / cells_per_lambdaJ

                lambda_over_W = lambda_lambdaJ / W_lambdaJ

                return {
                    'classification': 'GOOD',
                    'n_peaks': len(peaks),
                    'lambda_over_W': lambda_over_W,
                    'lambda_per_lambdaJ': lambda_lambdaJ,
                    'W_per_lambdaJ': W_lambdaJ
                }
            else:
                return {
                    'classification': 'FLAT',
                    'n_peaks': len(peaks),
                    'lambda_over_W': np.nan
                }

    except Exception as e:
        return {
            'classification': 'ERROR',
            'error': str(e),
            'lambda_over_W': np.nan
        }

def analyze_P1_results():
    """Analyze P1 campaign results"""
    print("=" * 60)
    print("Campaign P1 Analysis: Sub-Isothermal EOS")
    print("=" * 60)

    output_dir = Path("./outputs/P1_subisothermal_eos")

    # Load campaign spec
    with open("campaigns/P1_subisothermal_eos.json", 'r') as f:
        campaign_spec = json.load(f)

    f_vals = campaign_spec['parameter_space']['f_vals']
    beta_vals = campaign_spec['parameter_space']['beta_vals']
    gamma_vals = campaign_spec['parameter_space']['gamma_vals']
    seeds = campaign_spec['parameter_space']['seeds']

    results = []

    for gamma in gamma_vals:
        print(f"\nAnalyzing γ = {gamma}:")

        for f in f_vals:
            for beta in beta_vals:
                # Aggregate over seeds
                lw_values = []

                for seed in seeds:
                    sim_id = f"P1_subisothermal_eos_f{f}_b{beta}_g{gamma}_s{seed}"
                    hdf5_files = list(output_dir.glob(f"{sim_id}/sim.*.hdf5"))

                    if not hdf5_files:
                        continue

                    final_hdf5 = sorted(hdf5_files)[-1]
                    measurement = extract_lambda_W_and_tfrag(final_hdf5)

                    if measurement['classification'] == 'GOOD':
                        lw_values.append(measurement['lambda_over_W'])

                if lw_values:
                    mean_lw = np.mean(lw_values)
                    std_lw = np.std(lw_values)

                    results.append({
                        'gamma': gamma,
                        'f': f,
                        'beta': beta,
                        'lambda_over_W_mean': mean_lw,
                        'lambda_over_W_std': std_lw,
                        'n_measurements': len(lw_values)
                    })

    # Analyze γ-dependence
    print("\n" + "=" * 60)
    print("γ-Dependence Analysis:")
    print("=" * 60)

    for f in f_vals:
        for beta in beta_vals:
            print(f"\nf = {f}, β = {beta}:")

            for gamma in gamma_vals:
                matches = [r for r in results if r['f'] == f and r['beta'] == beta and r['gamma'] == gamma]

                if matches:
                    lw = matches[0]['lambda_over_W_mean']
                    err = matches[0]['lambda_over_W_std']
                    print(f"  γ = {gamma}: λ/W = {lw:.2f} ± {err:.2f}")

    # Overall assessment
    print("\n" + "=" * 60)
    print("Overall Assessment:")
    print("=" * 60)

    # Compare γ=0.7, 0.8 vs baseline γ=1.0
    baseline_results = [r for r in results if r['gamma'] == 1.0]
    gamma07_results = [r for r in results if r['gamma'] == 0.7]
    gamma08_results = [r for r in results if r['gamma'] == 0.8]

    if baseline_results and gamma07_results:
        baseline_mean = np.mean([r['lambda_over_W_mean'] for r in baseline_results])
        gamma07_mean = np.mean([r['lambda_over_W_mean'] for r in gamma07_results])

        pct_change = abs(gamma07_mean - baseline_mean) / baseline_mean * 100

        print(f"Baseline (γ=1.0): {baseline_mean:.2f}")
        print(f"Sub-isothermal (γ=0.7): {gamma07_mean:.2f}")
        print(f"Difference: {pct_change:.1f}%")

        if pct_change < 10:
            conclusion = "λ/W independent of γ (within 10%)"
        elif pct_change < 20:
            conclusion = "λ/W shows moderate γ-dependence"
        else:
            conclusion = "λ/W strongly γ-dependent"

        print(f"\nConclusion: {conclusion}")

    # Save report
    report = {
        'campaign': 'P1_subisothermal_eos',
        'conclusion': conclusion if 'conclusion' in locals() else "Insufficient data",
        'all_results': results
    }

    report_file = output_dir / "P1_eos_dependence_report.json"
    with open(report_file, 'w') as f:
        json.dump(report, f, indent=2)

    print(f"\nReport saved to: {report_file}")

    # Referee response language
    print("\n" + "=" * 60)
    print("Referee Response Language:")
    print("=" * 60)
    print(f"Sub-isothermal EOS simulations (γ = 0.7, 0.8) show {conclusion.lower()}")
    print(f"compared to the isothermal baseline (γ = 1.0). This addresses the")
    print(f"concern that real molecular cloud filaments have effective γ ≈ 0.7-0.9")
    print(f"due to radiative cooling. The λ/W measurements are {('robust' if pct_change < 10 else 'sensitive')} to")
    print(f"the choice of effective equation of state.")

    return report

if __name__ == "__main__":
    analyze_P1_results()
