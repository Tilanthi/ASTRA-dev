#!/usr/bin/env python3
"""
Analysis script for Campaign C1: Resolution Convergence for λ/W

This script analyzes λ/W measurements at 256³ and 512³ resolutions
to test numerical convergence.
"""

import json
import h5py
import numpy as np
from pathlib import Path
from scipy.signal import find_peaks
from typing import Dict, List, Tuple

def extract_lambda_W_from_hdf5(hdf5_file: Path) -> Dict:
    """
    Extract λ/W measurement from HDF5 snapshot

    Args:
        hdf5_file: Path to HDF5 file

    Returns:
        Dictionary with λ, W, and λ/W measurements
    """
    try:
        with h5py.File(hdf5_file, 'r') as f:
            # Get density field
            rho = f['dens'][:]

            # Grid dimensions
            nz, ny, nx = rho.shape

            # Compute column density along x (perpendicular to filament)
            # Integrate: Σ(y, z) = ∫ρ dx
            sigma_yz = np.mean(rho, axis=2)  # Average over x

            # Extract longitudinal profile (along z, filament axis)
            # Average over transverse direction y
            profile_z = np.mean(sigma_yz, axis=0)

            # Background subtraction
            background = np.median(np.concatenate([profile_z[:10], profile_z[-10:]]))
            profile_sub = profile_z - background

            # Detect peaks
            peaks, properties = find_peaks(
                profile_sub,
                height=0.1 * np.std(profile_sub),
                distance=4,
                prominence=0.1 * np.std(profile_sub)
            )

            if len(peaks) < 3:
                return {
                    'classification': 'FLAT',
                    'n_peaks': len(peaks),
                    'lambda_over_W': np.nan
                }

            # Measure wavelength (in cells)
            if len(peaks) > 1:
                peak_spacing = np.diff(peaks)
                lambda_cells = np.mean(peak_spacing)
            else:
                return {
                    'classification': 'TRANSITIONAL',
                    'n_peaks': len(peaks),
                    'lambda_over_W': np.nan
                }

            # Measure width from transverse profile at filament center
            center_idx = nz // 2
            transverse_profile = sigma_yz[:, center_idx]

            # Normalize
            transverse_profile = transverse_profile / np.max(transverse_profile)

            # FWHM
            half_max = 0.5
            above_half = transverse_profile > half_max
            fwhm_cells = np.sum(above_half)

            # Convert to physical units (assuming domain size)
            Lx_lambdaJ = 8.0  # From campaign spec
            cells_per_lambdaJ = nx / Lx_lambdaJ

            lambda_lambdaJ = lambda_cells / cells_per_lambdaJ
            W_lambdaJ = fwhm_cells / cells_per_lambdaJ

            return {
                'classification': 'GOOD',
                'n_peaks': len(peaks),
                'lambda_per_lambdaJ': lambda_lambdaJ,
                'W_per_lambdaJ': W_lambdaJ,
                'lambda_over_W': lambda_lambdaJ / W_lambdaJ,
                'peak_positions': peaks.tolist()
            }

    except Exception as e:
        return {
            'classification': 'ERROR',
            'error': str(e),
            'lambda_over_W': np.nan
        }

def analyze_C1_results():
    """Analyze C1 campaign results"""

    print("=" * 60)
    print("Campaign C1 Analysis: Resolution Convergence")
    print("=" * 60)

    output_dir = Path("./outputs/C1_resolution_convergence")

    # Load campaign spec
    with open("campaigns/C1_resolution_convergence.json", 'r') as f:
        campaign_spec = json.load(f)

    seeds = campaign_spec['parameter_space']['seeds']

    results = {
        '256': {},
        '512': {}
    }

    # Analyze each resolution
    for resolution in ['256', '512']:
        print(f"\nAnalyzing {resolution}³ resolution:")

        for seed in seeds:
            # Find output files
            sim_id = f"C1_resolution_convergence_f1.1_b1.0_th0_s{seed}"

            # Get final snapshot
            if resolution == '256':
                hdf5_pattern = f"{sim_id}_res256/sim.*.hdf5"
            else:
                hdf5_pattern = f"{sim_id}_res512/sim.*.hdf5"

            # Find final HDF5 file
            hdf5_files = list(output_dir.glob(hdf5_pattern.replace('*', '0*')))

            if not hdf5_files:
                print(f"  Seed {seed}: No HDF5 files found")
                continue

            # Use last file (final snapshot)
            final_hdf5 = sorted(hdf5_files)[-1]

            # Extract λ/W
            measurement = extract_lambda_W_from_hdf5(final_hdf5)

            print(f"  Seed {seed}: λ/W = {measurement.get('lambda_over_W', np.nan):.2f} ({measurement['classification']})")

            results[resolution][seed] = measurement

    # Compute convergence statistics
    print("\nConvergence Analysis:")

    convergence_data = []

    for seed in seeds:
        if seed in results['256'] and seed in results['512']:
            lw_256 = results['256'][seed].get('lambda_over_W', np.nan)
            lw_512 = results['512'][seed].get('lambda_over_W', np.nan)

            if not np.isnan(lw_256) and not np.isnan(lw_512):
                ratio = lw_512 / lw_256
                pct_change = abs(ratio - 1.0) * 100

                convergence_data.append({
                    'seed': seed,
                    'lw_256': lw_256,
                    'lw_512': lw_512,
                    'ratio': ratio,
                    'pct_change': pct_change
                })

                print(f"  Seed {seed}: {lw_256:.2f} → {lw_512:.2f} ({pct_change:.1f}% change)")

    # Overall statistics
    if convergence_data:
        mean_pct_change = np.mean([d['pct_change'] for d in convergence_data])
        std_pct_change = np.std([d['pct_change'] for d in convergence_data])

        print(f"\nOverall convergence: {mean_pct_change:.1f}% ± {std_pct_change:.1f}%")

        # Success criteria
        convergence_threshold = campaign_spec['success_criteria']['convergence_threshold_percent']

        if mean_pct_change < convergence_threshold:
            print(f"✓ CONVERGED: Change < {convergence_threshold}%")
            conclusion = "CONVERGED"
        else:
            print(f"✗ NOT CONVERGED: Change ≥ {convergence_threshold}%")
            conclusion = "NOT_CONVERGED"

        # Save results
        report = {
            'campaign': 'C1_resolution_convergence',
            'conclusion': conclusion,
            'mean_pct_change': mean_pct_change,
            'std_pct_change': std_pct_change,
            'convergence_threshold': convergence_threshold,
            'converged': mean_pct_change < convergence_threshold,
            'seed_results': convergence_data,
            'analysis_date': str(Path.cwd())
        }

        report_file = output_dir / "C1_convergence_report.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)

        print(f"\nReport saved to: {report_file}")

        # Generate summary for referee response
        print("\n" + "=" * 60)
        print("Referee Response Language:")
        print("=" * 60)
        print(f"Resolution convergence tests show λ/W changes by {mean_pct_change:.1f}% ± {std_pct_change:.1f}%")
        print(f"between 256³ and 512³ resolution, confirming numerical {'convergence' if conclusion == 'CONVERGED' else 'bias requiring correction'}.")

        return report

    else:
        print("ERROR: No valid measurements for comparison")
        return None

if __name__ == "__main__":
    analyze_C1_results()
