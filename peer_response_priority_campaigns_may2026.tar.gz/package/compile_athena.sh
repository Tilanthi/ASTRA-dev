#!/bin/bash
# Compile Athena++ for filament fragmentation simulations
# Target problem: filament_fragmentation
# Required physics: MHD, isothermal, 3D

set -e  # Exit on error

echo "=================================="
echo "Athena++ Compilation Script"
echo "=================================="

# Check if Athena++ directory exists
if [ ! -d "athena" ]; then
    echo "Athena++ directory not found. Cloning..."
    git clone https://github.com/PrincetonUniversity/athena-public-version.git athena
    cd athena
    git checkout v1.1.1
    cd ..
else
    echo "Athena++ directory found"
fi

cd athena

echo ""
echo "Configuring Athena++..."
echo "  Problem: filament_fragmentation"
echo "  Physics: MHD, isothermal"
echo "  Geometry: 3D"
echo "  Coordinates: Cartesian"
echo "  Flux: HLLD"
echo "  ODE: 2nd order"
echo "  MPI: enabled"
echo "  HDF5: enabled"

# Configure Athena++
./configure \
    --prob=filament_fragmentation \
    --flux=hlld \
    --ode=2n \
    --mpi \
    --hdf5 \
    --coord=cartesian

echo ""
echo "Compiling Athena++..."
echo "This may take several minutes..."

# Compile
make all

# Check if executable was created
if [ -f "bin/athena" ]; then
    echo ""
    echo "=================================="
    echo "SUCCESS: Athena++ compiled"
    echo "=================================="
    echo "Executable: athena/bin/athena"
    echo ""
    echo "Testing executable..."
    ./bin/athena -h | head -5
    echo ""
else
    echo ""
    echo "=================================="
    echo "ERROR: Compilation failed"
    echo "=================================="
    echo "Please check the output above for errors"
    exit 1
fi
