#!/usr/bin/env python3
"""
Generate Athena++ Configuration Files for Referee Campaigns

Generates all config files for the three minimum viable campaigns.

Author: ASTRA
Date: 2026-05-06
"""

import numpy as np
from pathlib import Path
from typing import Dict, List


def generate_athena_config(
    sim_id: str,
    theta_degrees: float,
    f: float,
    beta: float,
    mach: float,
    seed: int,
    Lx_lambdaJ: float,
    nx: int,
    ny: int,
    nz: int,
    output_cadence_tJ: float,
    max_tJ: float
) -> str:
    """
    Generate Athena++ config file for λ/W measurement simulation.

    Parameters
    ----------
    sim_id : str
        Simulation identifier
    theta_degrees : float
        Magnetic field inclination angle (degrees)
    f : float
        Line-mass fraction (M_line/M_J)
    beta : float
        Plasma beta
    mach : float
        Mach number
    seed : int
        Random seed for perturbations
    Lx_lambdaJ : float
        Domain length in units of Jeans length
    nx, ny, nz : int
        Grid resolution
    output_cadence_tJ : float
        HDF5 output cadence in units of t_J
    max_tJ : float
        Maximum simulation time in units of t_J

    Returns
    -------
    str
        Athena++ configuration file content
    """

    # Convert angle to radians
    theta_rad = np.deg2rad(theta_degrees)

    # Magnetic field orientation (B in x-z plane, filament along z)
    # theta = 0: B parallel to filament (B_z)
    # theta = 90: B perpendicular to filament (B_x)
    Bx = np.sin(theta_rad)
    By = 0.0
    Bz = np.cos(theta_rad)

    # Domain dimensions
    Lx = Lx_lambdaJ
    Ly = 1.0
    Lz = 1.0

    # Config template
    config = f"""<job>
problemname   filament_fragmentation

<time>
tlim          {max_tJ}
dt_parabolic  0.0
dt_hydro      0.3
nsmwl         1
start_time    0.0
time          0.0
</time>

<mesh>
nx1           {nx}
nx2           {ny}
nx3           {nz}
x1min         0.0
x1max         {Lx}
x2min         {Ly/2.0}
x2max         {-Ly/2.0}
x3min         {-0.5}
x3max         0.5
ix1_bc        periodic
ix2_bc        outflow
ix3_bc        outflow
</mesh>

<hydro>
isothermal    true
gamma         1.0
</hydro>

<field>
b0x           {Bx:.6f}
b0y           {By:.6f}
b0z           {Bz:.6f}
</field>

<problem>
filament_mass_to_jeans    {f}
plasma_beta               {beta}
mach_number               {mach}
random_seed               {seed}
</problem>

<output>
output      hdf5
file_type   hdf5
dt          {output_cadence_tJ}
variables   prim
</output>

<output1>
out_fmt     hdf5
file_prefix sim
dt          {output_cadence_tJ}
variables   prim
</output1>
</job>
"""

    return config


def write_config(config_content: str, output_path: Path):
    """Write config file to disk."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w') as f:
        f.write(config_content)


def generate_campaign_b_min():
    """Generate Campaign B-min configs: Oblique λ/W(θ) calibration."""
    print("Generating Campaign B-min configs...")

    configs = []

    theta_vals = [0, 15, 30, 45, 60, 75, 90]
    f_vals = [1.1]
    beta_vals = [1.0, 2.0]
    seeds = [42, 137]

    for theta in theta_vals:
        for f in f_vals:
            for beta in beta_vals:
                for seed in seeds:
                    sim_id = f"B_f{f}_b{beta}_th{theta}_s{seed}"

                    config = generate_athena_config(
                        sim_id=sim_id,
                        theta_degrees=float(theta),
                        f=f,
                        beta=beta,
                        mach=1.0,
                        seed=seed,
                        Lx_lambdaJ=8.0,
                        nx=256,
                        ny=64,
                        nz=64,
                        output_cadence_tJ=0.05,
                        max_tJ=1.0
                    )

                    output_path = Path(f"configs/B_min/{sim_id}.athena")
                    write_config(config, output_path)
                    configs.append(sim_id)

    print(f"  Generated {len(configs)} configs")
    return configs


def generate_campaign_a_min():
    """Generate Campaign A-min configs: Perpendicular λ/W statistics."""
    print("Generating Campaign A-min configs...")

    configs = []

    f_vals = [1.1, 1.2]
    beta_vals = [1.0, 1.5, 2.0, 3.0]
    seeds = [42, 137, 251]

    for f in f_vals:
        for beta in beta_vals:
            for seed in seeds:
                sim_id = f"A_f{f}_b{beta}_th90_s{seed}"

                config = generate_athena_config(
                    sim_id=sim_id,
                    theta_degrees=90.0,
                    f=f,
                    beta=beta,
                    mach=1.0,
                    seed=seed,
                    Lx_lambdaJ=16.0,
                    nx=512,
                    ny=64,
                    nz=64,
                    output_cadence_tJ=0.02,
                    max_tJ=0.8
                )

                output_path = Path(f"configs/A_min/{sim_id}.athena")
                write_config(config, output_path)
                configs.append(sim_id)

    print(f"  Generated {len(configs)} configs")
    return configs


def generate_campaign_c_min():
    """Generate Campaign C-min configs: Resolution convergence check."""
    print("Generating Campaign C-min configs...")

    configs = []
    seeds = [42, 137, 251]

    # Low resolution (256x64x64)
    for seed in seeds:
        sim_id = f"C_low_f1p1_b1p0_th0_s{seed}"

        config = generate_athena_config(
            sim_id=sim_id,
            theta_degrees=0.0,
            f=1.1,
            beta=1.0,
            mach=1.0,
            seed=seed,
            Lx_lambdaJ=8.0,
            nx=256,
            ny=64,
            nz=64,
            output_cadence_tJ=0.05,
            max_tJ=1.0
        )

        output_path = Path(f"configs/C_min/{sim_id}.athena")
        write_config(config, output_path)
        configs.append(sim_id)

    # High resolution (512x128x128)
    for seed in seeds:
        sim_id = f"C_high_f1p1_b1p0_th0_s{seed}"

        config = generate_athena_config(
            sim_id=sim_id,
            theta_degrees=0.0,
            f=1.1,
            beta=1.0,
            mach=1.0,
            seed=seed,
            Lx_lambdaJ=8.0,
            nx=512,
            ny=128,
            nz=128,
            output_cadence_tJ=0.05,
            max_tJ=1.0
        )

        output_path = Path(f"configs/C_min/{sim_id}.athena")
        write_config(config, output_path)
        configs.append(sim_id)

    print(f"  Generated {len(configs)} configs")
    return configs


def generate_test_configs():
    """Generate test configs (1 from each campaign)."""
    print("Generating TEST configs (1 per campaign)...")

    configs = []

    # Campaign B test
    sim_id = "B_test_f1p1_b1p0_th45_s42"
    config = generate_athena_config(
        sim_id=sim_id,
        theta_degrees=45.0,
        f=1.1,
        beta=1.0,
        mach=1.0,
        seed=42,
        Lx_lambdaJ=8.0,
        nx=256,
        ny=64,
        nz=64,
        output_cadence_tJ=0.05,
        max_tJ=1.0
    )
    write_config(config, Path(f"configs/B_min/{sim_id}.athena"))
    configs.append(sim_id)

    # Campaign A test
    sim_id = "A_test_f1p1_b2p0_th90_s42"
    config = generate_athena_config(
        sim_id=sim_id,
        theta_degrees=90.0,
        f=1.1,
        beta=2.0,
        mach=1.0,
        seed=42,
        Lx_lambdaJ=16.0,
        nx=512,
        ny=64,
        nz=64,
        output_cadence_tJ=0.02,
        max_tJ=0.8
    )
    write_config(config, Path(f"configs/A_min/{sim_id}.athena"))
    configs.append(sim_id)

    # Campaign C test
    sim_id = "C_test_f1p1_b1p0_th0_s42"
    config = generate_athena_config(
        sim_id=sim_id,
        theta_degrees=0.0,
        f=1.1,
        beta=1.0,
        mach=1.0,
        seed=42,
        Lx_lambdaJ=8.0,
        nx=256,
        ny=64,
        nz=64,
        output_cadence_tJ=0.05,
        max_tJ=1.0
    )
    write_config(config, Path(f"configs/C_min/{sim_id}.athena"))
    configs.append(sim_id)

    print(f"  Generated {len(configs)} test configs")
    return configs


def generate_all_configs():
    """Generate all config files for all campaigns."""
    print("\n" + "="*60)
    print("GENERATING ALL CONFIGURATION FILES")
    print("="*60 + "\n")

    all_configs = []

    all_configs.extend(generate_campaign_b_min())
    all_configs.extend(generate_campaign_a_min())
    all_configs.extend(generate_campaign_c_min())

    print(f"\nTotal configs generated: {len(all_configs)}")
    print("Config files written to configs/ directory")

    return all_configs


def main():
    """Main execution function."""
    import argparse

    parser = argparse.ArgumentParser(description='Generate Athena++ configs for referee campaigns')
    parser.add_argument('--campaign', type=str, default='all',
                       choices=['all', 'B', 'A', 'C', 'test'],
                       help='Which campaign to generate configs for')

    args = parser.parse_args()

    if args.campaign == 'all':
        generate_all_configs()
    elif args.campaign == 'B':
        generate_campaign_b_min()
    elif args.campaign == 'A':
        generate_campaign_a_min()
    elif args.campaign == 'C':
        generate_campaign_c_min()
    elif args.campaign == 'test':
        generate_test_configs()


if __name__ == '__main__':
    main()
