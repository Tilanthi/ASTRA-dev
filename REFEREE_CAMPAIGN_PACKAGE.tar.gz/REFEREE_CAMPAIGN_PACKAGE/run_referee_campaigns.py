#!/usr/bin/env python3
"""
Run Referee-Driven λ/W Measurement Campaigns

This script executes the minimum viable simulation campaign to address all
referee concerns about λ/W measurements.

Author: ASTRA
Date: 2026-05-06
"""

import os
import sys
import ray
import yaml
import subprocess
import time
from pathlib import Path
from typing import Dict, List, Any
from dataclasses import dataclass

# Load Ray configuration
with open('ray_config.yaml', 'r') as f:
    RAY_CONFIG = yaml.safe_load(f)


@dataclass
class SimulationConfig:
    """Configuration for a single simulation."""
    sim_id: str
    campaign: str
    theta_degrees: float
    f: float
    beta: float
    mach: float
    seed: int
    Lx_lambdaJ: float
    nx: int
    ny: int
    nz: int
    output_cadence_tJ: float
    max_tJ: float
    cores: int
    timeout: int


@ray.remote
def run_simulation(config: SimulationConfig) -> Dict[str, Any]:
    """Run a single Athena++ simulation via Ray."""
    import subprocess
    import json
    from pathlib import Path
    import time

    start_time = time.time()

    # Create output directory
    output_dir = Path(f"outputs/{config.campaign}/{config.sim_id}")
    output_dir.mkdir(parents=True, exist_ok=True)

    # Copy config file
    config_src = Path(f"configs/{config.campaign}/{config.sim_id}.athena")
    config_dst = output_dir / "filament_fragmentation.att"

    if not config_src.exists():
        return {
            'sim_id': config.sim_id,
            'status': 'FAILED',
            'error': f'Config file not found: {config_src}',
            'wall_time_hours': 0
        }

    with open(config_src, 'r') as f:
        config_content = f.read()
    with open(config_dst, 'w') as f:
        f.write(config_content)

    # Run Athena++
    try:
        result = subprocess.run(
            [
                'mpirun', '-np', str(config.cores),
                './athena', '-i', 'filament_fragmentation.att',
                '-d', str(output_dir)
            ],
            cwd=str(output_dir),
            capture_output=True,
            text=True,
            timeout=config.timeout
        )

        wall_time = (time.time() - start_time) / 3600

        # Check for outputs
        hdf5_files = list(output_dir.glob('*.hdf5'))

        if result.returncode == 0 and len(hdf5_files) > 0:
            return {
                'sim_id': config.sim_id,
                'status': 'SUCCESS',
                'n_outputs': len(hdf5_files),
                'wall_time_hours': wall_time,
                'output_dir': str(output_dir)
            }
        else:
            return {
                'sim_id': config.sim_id,
                'status': 'FAILED',
                'error': result.stderr[-500:] if result.stderr else 'Unknown error',
                'returncode': result.returncode,
                'wall_time_hours': wall_time
            }

    except subprocess.TimeoutExpired:
        wall_time = (time.time() - start_time) / 3600
        return {
            'sim_id': config.sim_id,
            'status': 'TIMEOUT',
            'wall_time_hours': wall_time
        }
    except Exception as e:
        wall_time = (time.time() - start_time) / 3600
        return {
            'sim_id': config.sim_id,
            'status': 'ERROR',
            'error': str(e),
            'wall_time_hours': wall_time
        }


def generate_campaign_configs():
    """Generate all simulation configs for the three campaigns."""
    from generate_configs import generate_all_configs

    print("Generating simulation configurations...")
    generate_all_configs()
    print("Configuration files generated.")


def run_campaign_b_min():
    """Run Campaign B-min: Oblique λ/W(θ) calibration."""
    print("\n" + "="*60)
    print("CAMPAIGN B-MIN: Oblique λ/W(θ) Calibration")
    print("="*60)

    configs = []

    theta_vals = [0, 15, 30, 45, 60, 75, 90]
    f_vals = [1.1]
    beta_vals = [1.0, 2.0]
    seeds = [42, 137]

    for theta in theta_vals:
        for f in f_vals:
            for beta in beta_vals:
                for seed in seeds:
                    sim_id = f"B_f{f}_b{beta}_th{theta}_s{seed}"

                    config = SimulationConfig(
                        sim_id=sim_id,
                        campaign='B_min',
                        theta_degrees=float(theta),
                        f=f,
                        beta=beta,
                        mach=1.0,
                        seed=seed,
                        Lx_lambdaJ=8.0,
                        nx=256,
                        ny=64,
                        nz=64,
                        output_cadence_tJ=0.05,
                        max_tJ=1.0,
                        cores=16,
                        timeout=7200  # 2 hours
                    )
                    configs.append(config)

    print(f"Generated {len(configs)} simulations for Campaign B-min")
    return configs


def run_campaign_a_min():
    """Run Campaign A-min: Perpendicular λ/W statistics."""
    print("\n" + "="*60)
    print("CAMPAIGN A-MIN: Perpendicular λ/W Statistics")
    print("="*60)

    configs = []

    f_vals = [1.1, 1.2]
    beta_vals = [1.0, 1.5, 2.0, 3.0]
    seeds = [42, 137, 251]

    for f in f_vals:
        for beta in beta_vals:
            for seed in seeds:
                sim_id = f"A_f{f}_b{beta}_th90_s{seed}"

                config = SimulationConfig(
                    sim_id=sim_id,
                    campaign='A_min',
                    theta_degrees=90.0,
                    f=f,
                    beta=beta,
                    mach=1.0,
                    seed=seed,
                    Lx_lambdaJ=16.0,
                    nx=512,
                    ny=64,
                    nz=64,
                    output_cadence_tJ=0.02,
                    max_tJ=0.8,
                    cores=16,
                    timeout=14400  # 4 hours
                )
                configs.append(config)

    print(f"Generated {len(configs)} simulations for Campaign A-min")
    return configs


def run_campaign_c_min():
    """Run Campaign C-min: Resolution convergence check."""
    print("\n" + "="*60)
    print("CAMPAIGN C-MIN: Resolution Convergence")
    print("="*60)

    configs = []
    seeds = [42, 137, 251]

    # Low resolution (256x64x64)
    for seed in seeds:
        sim_id = f"C_low_f1p1_b1p0_th0_s{seed}"

        config = SimulationConfig(
            sim_id=sim_id,
            campaign='C_min',
            theta_degrees=0.0,
            f=1.1,
            beta=1.0,
            mach=1.0,
            seed=seed,
            Lx_lambdaJ=8.0,
            nx=256,
            ny=64,
            nz=64,
            output_cadence_tJ=0.05,
            max_tJ=1.0,
            cores=16,
            timeout=7200  # 2 hours
        )
        configs.append(config)

    # High resolution (512x128x128)
    for seed in seeds:
        sim_id = f"C_high_f1p1_b1p0_th0_s{seed}"

        config = SimulationConfig(
            sim_id=sim_id,
            campaign='C_min',
            theta_degrees=0.0,
            f=1.1,
            beta=1.0,
            mach=1.0,
            seed=seed,
            Lx_lambdaJ=8.0,
            nx=512,
            ny=128,
            nz=128,
            output_cadence_tJ=0.05,
            max_tJ=1.0,
            cores=64,
            timeout=36000  # 10 hours
        )
        configs.append(config)

    print(f"Generated {len(configs)} simulations for Campaign C-min")
    return configs


def monitor_progress(results: List[Dict[str, Any]]):
    """Monitor and display simulation progress."""
    from collections import Counter

    while True:
        completed = [r for r in results if r is not None]
        pending = len(results) - len(completed)

        if pending == 0:
            break

        status_counts = Counter([r.get('status', 'PENDING') for r in completed if r])

        print(f"\rProgress: {len(completed)}/{len(results)} complete | "
              f"Status: {dict(status_counts)} | Pending: {pending}", end='')

        time.sleep(10)


def main():
    """Main execution function."""
    import argparse

    parser = argparse.ArgumentParser(description='Run referee-driven λ/W campaigns')
    parser.add_argument('--phase', type=str, default='all',
                       choices=['all', '1', '2', 'B', 'A', 'C'],
                       help='Which phase/campaign to run')
    parser.add_argument('--test', action='store_true',
                       help='Run test simulations only (1 from each campaign)')
    parser.add_argument('--no-generate', action='store_true',
                       help='Skip config generation')

    args = parser.parse_args()

    # Initialize Ray
    print(f"Initializing Ray with {RAY_CONFIG['ray']['num_cpus']} CPUs...")
    ray.init(
        num_cpus=RAY_CONFIG['ray']['num_cpus'],
        object_store_memory=RAY_CONFIG['ray']['object_store_memory'],
        dashboard_port=RAY_CONFIG['ray']['dashboard_port']
    )
    print(f"Ray dashboard: http://localhost:{RAY_CONFIG['ray']['dashboard_port']}")

    # Generate configs
    if not args.no_generate:
        generate_campaign_configs()

    all_configs = []

    # Phase 1: Campaigns B-min and A-min (can run concurrently)
    if args.phase in ['all', '1', 'B']:
        all_configs.extend(run_campaign_b_min())

    if args.phase in ['all', '1', 'A']:
        all_configs.extend(run_campaign_a_min())

    # Phase 2: Campaign C-min (run after Phase 1)
    if args.phase in ['all', '2', 'C']:
        all_configs.extend(run_campaign_c_min())

    if args.test:
        # Run only first config from each campaign
        test_configs = []
        campaigns_seen = set()
        for config in all_configs:
            if config.campaign not in campaigns_seen:
                test_configs.append(config)
                campaigns_seen.add(config.campaign)
        all_configs = test_configs
        print(f"\nTEST MODE: Running {len(all_configs)} test simulations")

    print(f"\nTotal simulations to run: {len(all_configs)}")

    # Launch simulations
    print("\nLaunching simulations...")
    results = [run_simulation.remote(config) for config in all_configs]

    # Monitor progress
    print("\nSimulation progress:")
    monitor_progress(results)

    # Collect results
    print("\n\nCollecting results...")
    final_results = ray.get(results)

    # Summary
    print("\n" + "="*60)
    print("SIMULATION SUMMARY")
    print("="*60)

    from collections import Counter
    status_counts = Counter([r.get('status', 'UNKNOWN') for r in final_results])

    for status, count in status_counts.items():
        print(f"  {status}: {count}")

    # Save results
    results_file = 'outputs/simulation_results.json'
    with open(results_file, 'w') as f:
        import json
        json.dump(final_results, f, indent=2)

    print(f"\nResults saved to {results_file}")

    # Analyze results
    print("\nRunning λ/W analysis...")
    from analyze_lambda_W import analyze_all_campaigns
    analyze_all_campaigns('outputs/')

    # Shutdown Ray
    ray.shutdown()

    print("\nCampaign execution complete!")


if __name__ == '__main__':
    main()
