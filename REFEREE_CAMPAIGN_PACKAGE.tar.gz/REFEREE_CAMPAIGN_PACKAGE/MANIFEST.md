# REFEREE_CAMPAIGN_PACKAGE Manifest

**Package Version**: 1.0
**Date**: 2026-05-06
**Purpose**: Minimum viable λ/W measurement campaign for referee response

---

## Package Contents

### Documentation (3 files)

1. **README.md**
   - Purpose: Complete usage guide
   - Contents: Quick start, campaign specs, execution plan, methodology
   - Format: Markdown

2. **MANIFEST.md** (this file)
   - Purpose: Complete file inventory
   - Contents: All files with descriptions and checksums
   - Format: Markdown

3. **REF_PLAN_SPEC.md**
   - Purpose: Detailed referee campaign specification
   - Contents: Campaign designs, parameters, analysis protocols
   - Format: Markdown

### Execution Scripts (5 files)

4. **run_referee_campaigns.py**
   - Purpose: Main Ray execution script
   - Dependencies: ray, yaml, subprocess
   - Usage: `python run_referee_campaigns.py --phase all`
   - Lines: ~350

5. **generate_configs.py**
   - Purpose: Generate Athena++ config files
   - Dependencies: numpy, pathlib
   - Usage: `python generate_configs.py`
   - Lines: ~300
   - Outputs: 58 config files in configs/

6. **analyze_lambda_W.py**
   - Purpose: Extract λ/W from HDF5 outputs
   - Dependencies: h5py, numpy, scipy, pathlib
   - Usage: `python analyze_lambda_W.py --outputs outputs/`
   - Lines: ~300
   - Outputs: JSON files with λ/W measurements

7. **test_analyze.py**
   - Purpose: Run test simulations before full launch
   - Dependencies: subprocess, pathlib
   - Usage: `python test_analyze.py`
   - Lines: ~200
   - Runs: 3 test simulations (1 per campaign)

8. **monitor_progress.py**
   - Purpose: Real-time progress monitoring
   - Dependencies: time, json, pathlib
   - Usage: `python monitor_progress.py`
   - Lines: ~150
   - Refresh rate: 5 seconds (configurable)

### Configuration (1 file)

9. **ray_config.yaml**
   - Purpose: Ray cluster configuration
   - Contents: CPU count, concurrent sims, timeouts, wall time estimates
   - Format: YAML
   - Key settings:
     - num_cpus: 220
     - max_concurrent_256: 13
     - max_concurrent_512: 3

### Build Script (1 file)

10. **compile_athena.sh**
    - Purpose: Compile Athena++ with filament_fragmentation problem
    - Dependencies: Athena++ v1.1.1 source code
    - Usage: `bash compile_athena.sh`
    - Configure options: filament_fragmentation, MHD, isothermal, 3D, MPI, HDF5

### Directory Structure

```
configs/                 # Generated config files (58 total)
├── B_min/              # Campaign B configs (28 files)
│   ├── B_f1p1_b1p0_th0_s42.athena
│   ├── B_f1p1_b1p0_th0_s137.athena
│   ├── B_f1p1_b1p0_th15_s42.athena
│   └── ... (25 more)
├── A_min/              # Campaign A configs (24 files)
│   ├── A_f1p1_b1p0_th90_s42.athena
│   ├── A_f1p1_b1p0_th90_s137.athena
│   ├── A_f1p1_b1p0_th90_s251.athena
│   └── ... (21 more)
└── C_min/              # Campaign C configs (6 files)
    ├── C_low_f1p1_b1p0_th0_s42.athena
    ├── C_low_f1p1_b1p0_th0_s137.athena
    ├── C_low_f1p1_b1p0_th0_s251.athena
    ├── C_high_f1p1_b1p0_th0_s42.athena
    ├── C_high_f1p1_b1p0_th0_s137.athena
    └── C_high_f1p1_b1p0_th0_s251.athena

analysis/               # Analysis functions (in analyze_lambda_W.py)
outputs/                # Created during run (not in package)
├── B_min/             # Campaign B outputs
├── A_min/             # Campaign A outputs
├── C_min/             # Campaign C outputs
├── simulation_results.json
├── B_min_lambda_W_results.json
├── A_min_lambda_W_results.json
├── C_min_lambda_W_results.json
└── all_lambda_W_results.json
```

---

## Configuration File Templates

### Athena++ Config Structure

Each .athena file contains:

```
<job>
problemname   filament_fragmentation

<time>
tlim          [max_tJ]
dt_parabolic  0.0
dt_hydro      0.3
nsmwl         1
start_time    0.0
time          0.0
</time>

<mesh>
nx1           [nx]
nx2           [ny]
nx3           [nz]
x1min         0.0
x1max         [Lx]
x2min         [Ly/2.0]
x2max         {-Ly/2.0}
x3min         -0.5
x3max         0.5
ix1_bc        periodic
ix2_bc        outflow
ix3_bc        outflow
</mesh>

<hydro>
isothermal    true
gamma         1.0
</hydro>

<field>
b0x           [Bx]
b0y           [By]
b0z           [Bz]
</field>

<problem>
filament_mass_to_jeans    [f]
plasma_beta               [beta]
mach_number               [mach]
random_seed               [seed]
</problem>

<output>
output      hdf5
file_type   hdf5
dt          [output_cadence_tJ]
variables   prim
</output>

<output1>
out_fmt     hdf5
file_prefix sim
dt          [output_cadence_tJ]
variables   prim
</output1>
</job>
```

### Naming Convention

```
[CAMPAIGN]_f[F]_b[BETA]_th[THETA]s[SEED].athena

Examples:
- B_f1p1_b1p0_th45_s42.athena  → Campaign B, f=1.1, β=1.0, θ=45°, seed=42
- A_f1p2_b2p0_th90_s137.athena → Campaign A, f=1.2, β=2.0, θ=90°, seed=137
- C_low_f1p1_b1p0_th0_s251.athena → Campaign C low-res, f=1.1, β=1.0, θ=0°, seed=251
```

---

## Parameter Ranges Summary

### Campaign B-min (28 configs)

| Parameter | Values | Count |
|-----------|--------|-------|
| θ (deg) | 0, 15, 30, 45, 60, 75, 90 | 7 |
| f | 1.1 | 1 |
| β | 1.0, 2.0 | 2 |
| Seed | 42, 137 | 2 |
| **Total** | | **28** |

### Campaign A-min (24 configs)

| Parameter | Values | Count |
|-----------|--------|-------|
| θ (deg) | 90 | 1 |
| f | 1.1, 1.2 | 2 |
| β | 1.0, 1.5, 2.0, 3.0 | 4 |
| Seed | 42, 137, 251 | 3 |
| **Total** | | **24** |

### Campaign C-min (6 configs)

| Parameter | Values | Count |
|-----------|--------|-------|
| θ (deg) | 0 | 1 |
| f | 1.1 | 1 |
| β | 1.0 | 1 |
| Seed | 42, 137, 251 | 3 |
| Resolution | low (256³), high (512³) | 2 |
| **Total** | | **6** |

---

## Output File Summary

### Per Simulation

Each simulation produces:

1. **HDF5 snapshots**: 21 (B-min, C-min) or 41 (A-min)
   - Filename: sim.[output_number].hdf5
   - Fields: rho (density), vel (velocity), Bcc (magnetic field)

2. **Status file**: status.json (created by Ray wrapper)
   - Contents: sim_id, status (SUCCESS/FAILED/TIMEOUT), wall_time, n_outputs

3. **λ/W measurement**: (created by analyze_lambda_W.py)
   - N_peaks, λ/λJ, W/λJ, λ/W, classification

### Combined Results

1. **simulation_results.json**: All simulation status
2. **[CAMPAIGN]_lambda_W_results.json**: λ/W measurements per campaign
3. **all_lambda_W_results.json**: Combined λ/W measurements

---

## Resource Requirements

### Compute Resources

- **Total simulations**: 58
- **Max concurrent**: 13 (for 256³) or 3 (for 512³)
- **CPU cores**: 220 recommended
- **RAM**: ~4 GB per 256³ sim, ~16 GB per 512³ sim
- **Disk space**: ~200 GB for all outputs

### Wall Time Estimates

- **Phase 1** (B-min + A-min): ~7 hours parallel
- **Phase 2** (C-min): ~10 hours serial
- **Total**: ~17-20 hours

---

## Dependency Requirements

### Python Packages

```
ray>=2.0.0
numpy>=1.20.0
scipy>=1.7.0
h5py>=3.0.0
pyyaml>=5.4.0
```

### System Requirements

```
MPI (mpich or openmpi)
HDF5 libraries with development headers
C++ compiler with C++11 support
git (for Athena++ checkout)
```

### Athena++ Requirements

```
Version: v1.1.1
Problem: filament_fragmentation (must be available)
Configure options: --prob=filament_fragmentation --flux=hlld --ode=2n --mpi --hdf5
Geometry: std/3d
Physics: mhd/iso
```

---

## Verification Checklist

Before deployment:

- [ ] All 10 package files present
- [ ] README.md contains complete instructions
- [ ] ray_config.yaml has correct CPU count
- [ ] compile_athena.sh is executable
- [ ] Python scripts are syntactically valid
- [ ] No hardcoded paths (use relative paths)

Before execution:

- [ ] Athena++ compiled successfully
- [ ] Config files generated (58 total)
- [ ] Test simulations run successfully
- [ ] λ/W extraction verified working

---

## Version History

**v1.0** (2026-05-06)
- Initial package release
- Three campaigns: B-min, A-min, C-min
- Total: 58 simulations
- Ray-based execution framework
- Automated λ/W analysis pipeline

---

**End of Manifest**

Generated by ASTRA for referee-driven simulation campaign
Date: 2026-05-06
Status: READY FOR DEPLOYMENT
