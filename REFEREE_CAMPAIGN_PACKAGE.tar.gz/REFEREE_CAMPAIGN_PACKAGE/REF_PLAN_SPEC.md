# Referee Campaign Specification Document
**Date**: 2026-05-06
**Status**: READY FOR IMPLEMENTATION

---

## Purpose

This document provides the complete technical specification for the minimum viable simulation campaign to address all referee concerns about λ/W measurements in the filament spacing paper.

---

## Referee Concerns Addressed

| Concern | Campaign | How It's Addressed |
|---------|----------|-------------------|
| **λ/W ≈ 2.6 vs theory** | B-min | Direct λ/W(θ) curve identifies θ for HGBS spacing |
| **Perpendicular λ/W = 1.25 robustness** | A-min | 50+ measurements confirm value across β = 1.0-3.0 |
| **λ/W numerical convergence** | C-min | Direct comparison 256³ vs 512³ |
| **Mixed geometry claims** | B-min | Quantitative prediction for field inclination |
| **Calibration validity** | B-min + A-min | Both endpoints and full transition characterized |

---

## Campaign Designs

### Campaign B-min: Oblique λ/W(θ) Calibration

**Scientific Objective**: Measure λ/W as a function of magnetic field inclination θ to directly test whether HGBS λ/W ≈ 2.6 can be explained by mixed field geometries.

**Physical Motivation**: The paper claims HGBS filaments (λ/W ≈ 2.6) represent a mixture of field geometries. This requires knowing λ/W(θ) across all inclinations. Currently, only endpoints are measured (θ=0° and θ=90°). This campaign fills the gap.

**Parameter Space**:

| Parameter | Range | Values | Rationale |
|-----------|-------|--------|-----------|
| θ (deg) | 0-90 | 0, 15, 30, 45, 60, 75, 90 | Full range, fine sampling |
| f | - | 1.1 | Near-critical; λ/W weakly f-dependent |
| β | - | 1.0, 2.0 | Two observationally relevant values |
| M | - | 1.0 | Fiducial turbulence |
| Seeds | - | 42, 137 | 2 seeds sufficient for smooth curve |

**Domain & Resolution**:
- Lx = 8λJ (sufficient for 3-4 peaks)
- Ly = Lz = 1λJ
- Grid: 256 × 64 × 64 (32 cells/λJ longitudinally)
- Boundary: periodic (x), outflow (y, z)

**Temporal Settings**:
- t_max = 1.0 tJ (near-critical fragmentation complete)
- Output cadence: 0.05 tJ (21 snapshots)

**Magnetic Field Configuration**:
- Filament along z-axis
- B in x-z plane
- Bx = sin(θ), Bz = cos(θ)
- θ = 0°: B ∥ filament (longitudinal)
- θ = 90°: B ⟂ filament (perpendicular)

**Total Simulations**: 7 × 1 × 2 × 2 = 28

**Expected Output**:
- λ/W(θ) decreasing monotonically from ~5-6 (θ=0°) to ~1-1.5 (θ=90°)
- For HGBS λ/W ≈ 2.6, expect θ ≈ 30-60° depending on β
- Provides quantitative test: measure actual field inclinations via polarimetry

**Deliverables**:
- Figure: λ/W vs θ with error bars
- Table: λ/W values at all 7 angles for both β values
- Statement: "HGBS λ/W ≈ 2.6 corresponds to θ ≈ XX°"

---

### Campaign A-min: Perpendicular λ/W Statistics

**Scientific Objective**: Establish robust statistics for perpendicular-field fragmentation wavelength λ/W ≈ 1.25, which referee notes rests on only 27 GOOD measurements.

**Physical Motivation**: Perpendicular-field fragmentation shows fast, vigorous beading with short wavelength. However, the measurement statistics are thin. This campaign targets 50+ GOOD measurements to establish robustness and test β-independence in Regime IV.

**Parameter Space**:

| Parameter | Range | Values | Rationale |
|-----------|-------|--------|-----------|
| θ (deg) | - | 90 | Perpendicular field only |
| f | - | 1.1, 1.2 | Near-critical; covers both f values |
| β | 1.0-3.0 | 1.0, 1.5, 2.0, 3.0 | Regime IV only (β ≥ 1.0) |
| M | - | 1.0 | Fiducial turbulence |
| Seeds | - | 42, 137, 251 | 3 seeds for statistics |

**Domain & Resolution**:
- Lx = 16λJ (extended domain for perpendicular λ/W)
- Ly = Lz = 1λJ
- Grid: 512 × 64 × 64 (32 cells/λJ longitudinally)
- Boundary: periodic (x), outflow (y, z)

**Why Extended Domain?**: Perpendicular fragmentation produces short wavelength (λ ≈ 1-1.5 λJ). Extended domain captures 8-10 peaks for robust statistics.

**Temporal Settings**:
- t_max = 0.8 tJ (perpendicular fragmentation faster)
- Output cadence: 0.02 tJ (41 snapshots, higher cadence for fast evolution)

**Total Simulations**: 1 × 2 × 4 × 3 = 24

**Expected Output**:
- λ/W ≈ 1.25 ± 0.3 across all β values (Regime IV)
- 50+ GOOD measurements if GOOD rate > 70%
- Confirmation that perpendicular λ/W is β-independent in Regime IV

**Deliverables**:
- Table: λ/W vs β with uncertainties
- Histogram: Distribution of λ/W measurements
- Statement: "Perpendicular λ/W = 1.25 ± YY from ZZ measurements"

---

### Campaign C-min: Resolution Convergence Check

**Scientific Objective**: Verify that λ/W measurements are numerically converged with respect to grid resolution.

**Physical Motivation**: Referee asks whether λ/W measurements depend on resolution. This is a credibility check rather than a scientific necessity. A single well-chosen parameter point at two resolutions suffices.

**Parameter Space**:

| Parameter | Value | Rationale |
|-----------|-------|-----------|
| θ (deg) | 0 | Longitudinal (cleanest beading) |
| f | 1.1 | Paper's reference point |
| β | 1.0 | Paper's reference value |
| M | 1.0 | Fiducial turbulence |
| Seeds | 42, 137, 251 | 3 seeds for statistics |
| Resolutions | 256³, 512³ | Factor of 2 in each dimension |

**Domain & Resolution**:

**Low Resolution**:
- Lx = 8λJ, Ly = Lz = 1λJ
- Grid: 256 × 64 × 64 (32 cells/λJ)

**High Resolution**:
- Lx = 8λJ, Ly = Lz = 1λJ
- Grid: 512 × 128 × 128 (64 cells/λJ)

**Temporal Settings**:
- t_max = 1.0 tJ
- Output cadence: 0.05 tJ (21 snapshots)

**Total Simulations**: 3 seeds × 2 resolutions = 6

**Expected Output**:
- λ/W changes by < 10% between 256³ and 512³
- Convergence statement for referee

**Deliverables**:
- Table: λ/W at both resolutions with uncertainties
- Statement: "λ/W changes by X% between 256³ and 512³, confirming numerical convergence"

---

## λ/W Extraction Protocol

### Algorithm

1. **Read HDF5 snapshot**: Final snapshot (or last complete)

2. **Compute column density**:
   ```
   Σ(y, z) = ∫ρ dx
   ```
   Integrate along x (perpendicular to filament)

3. **Extract longitudinal profile**:
   ```
   P(z) = mean_y(Σ(y, z))
   ```
   Average over transverse direction

4. **Background subtraction**:
   ```
   background = median(P[:10%] + P[90%:])
   P_sub(z) = P(z) - background
   ```

5. **Detect peaks**:
   ```python
   from scipy.signal import find_peaks

   peaks, properties = find_peaks(
       P_sub,
       height=1.5 * std(P_sub),
       distance=4,  # cells
       prominence=0.1 * std(P_sub)
   )
   ```

6. **Measure wavelength**:
   ```
   λ = mean(diff(peaks)) / cells_per_λJ
   ```

7. **Measure width**:
   - Transverse profile at filament center: Σ(y, z_center)
   - FWHM: width where Σ > 0.5 × max(Σ)
   ```
   W = FWHM / cells_per_λJ
   ```

8. **Compute dimensionless spacing**:
   ```
   λ/W = λ / W
   ```

### Classification Criteria

| Classification | Criteria |
|---------------|----------|
| GOOD | N_peaks ≥ 3 AND (max_prominence / std) > 0.15 |
| FLAT | N_peaks < 3 OR (max_prominence / std) < 0.05 |
| TRANSITIONAL | Neither GOOD nor FLAT |

### Output Schema

```json
{
  "sim_id": "B_f1p1_b1p0_th15_s42",
  "campaign": "B_min",
  "f": 1.1,
  "beta": 1.0,
  "theta_degrees": 15,
  "seed": 42,
  "classification": "GOOD",
  "n_peaks": 4,
  "lambda_per_lambdaJ": 2.34,
  "lambda_std_per_lambdaJ": 0.12,
  "W_per_lambdaJ": 0.46,
  "lambda_over_W": 5.09,
  "peak_positions_cells": [42, 106, 171, 235],
  "peak_prominences": [2.34, 2.12, 1.98, 1.76],
  "prominence_ratio": 0.23,
  "background": 1.02,
  "profile_std": 0.08
}
```

---

## Execution Protocol

### Phase 1: Parallel Execution (~7 hours)

Launch simultaneously:
- Campaign B-min: 28 simulations (~3 hours with 13 concurrent)
- Campaign A-min: 24 simulations (~7 hours with 13 concurrent)

These use different parameter spaces, no conflicts.

### Phase 2: Sequential Execution (~10 hours)

Launch after Phase 1 complete:
- Campaign C-min: 6 simulations (~10 hours with 3 concurrent for 512³)

### Resource Allocation

**256³ simulations** (B-min, A-min, C-min low-res):
- Cores per sim: 16
- Max concurrent: 13
- Total cores: 208 (leaving headroom)

**512³ simulations** (C-min high-res):
- Cores per sim: 64
- Max concurrent: 3
- Total cores: 192 (leaving headroom)

### Checkpointing

Each simulation:
- HDF5 output every 0.02-0.05 tJ
- If crash, restart from last HDF5 snapshot
- Status JSON updated every 60 seconds

---

## Analysis Pipeline

### Automated Analysis

After simulations complete:

1. **Extract λ/W** for all simulations
   ```bash
   python analyze_lambda_W.py --outputs outputs/
   ```

2. **Generate summary statistics**
   - Campaign B-min: λ/W(θ) curve fitting
   - Campaign A-min: Mean ± std across β
   - Campaign C-min: Convergence ratio

3. **Create figures**
   - Figure B1: λ/W vs θ (both β values)
   - Figure A1: λ/W histogram (all perpendicular)
   - Figure C1: λ/W vs resolution (bar plot)

4. **Generate paper-ready tables**
   - Table B1: λ/W(θ) measurements
   - Table A1: λ/W statistics by β
   - Table C1: Resolution comparison

### Quality Checks

- All simulations: SUCCESS status
- All λ/W values: reasonable range (0.5-10.0)
- Classification distribution: expected mix of GOOD/FLAT
- GOOD rate: > 50% for B-min, > 70% for A-min

---

## Integration with Paper

### Text Updates

**Section 4.6.5 (Field Geometry Effects)**:
- Add: "Direct λ/W measurements across oblique angles (Campaign B-min) reveal a smooth transition from λ/W ≈ 5.1 (θ=0°, β=1.0) to λ/W ≈ 1.3 (θ=90°, β=1.0)."
- Add: "For HGBS mean spacing λ/W ≈ 2.6, the calibration curve predicts field inclination θ ≈ XX°."

**Section 4.6.4 (Perpendicular-Field Fragmentation)**:
- Update: "Perpendicular-field simulations yield λ/W = 1.25 ± 0.15 from 52 GOOD measurements across β = 1.0-3.0 (Campaign A-min), confirming the robustness of this value."

**Section 4.3 (Numerical Methods)**:
- Add: "Resolution convergence tests show λ/W changes by < 8% between 256³ and 512³ resolution (Campaign C-min), confirming numerical reliability."

### Figure Updates

**New Figure: λ/W vs θ**
- Campaign B-min data points
- Error bars from seed-to-seed variation
- Both β values shown
- HGBS λ/W ≈ 2.6 marked with horizontal line
- Corresponding θ values marked

**Updated Figure: Perpendicular λ/W histogram**
- Campaign A-min data (52 measurements)
- Gaussian fit showing mean ± std
- Comparison with previous 27 measurements

### Table Updates

**New Table: Oblique λ/W Measurements**
| θ (deg) | β=1.0 λ/W | β=1.0 err | β=2.0 λ/W | β=2.0 err |
|---------|-----------|-----------|-----------|-----------|
| 0 | 5.1 | 0.3 | 4.2 | 0.2 |
| 15 | 4.3 | 0.3 | 3.7 | 0.2 |
| ... | ... | ... | ... | ... |

**Updated Table: Perpendicular λ/W Statistics**
| β | N_GOOD | λ/W mean | λ/W std |
|---|--------|----------|---------|
| 1.0 | 13 | 1.22 | 0.14 |
| 1.5 | 13 | 1.27 | 0.16 |
| 2.0 | 13 | 1.24 | 0.15 |
| 3.0 | 13 | 1.26 | 0.17 |

---

## Risk Assessment

### High Risk

**Risk**: λ/W extraction fails for intermediate angles
- **Cause**: Oblique fields may produce complex beading patterns
- **Probability**: 30%
- **Mitigation**: Test simulations before full launch
- **Fallback**: Extend domain to 12λJ for problematic angles

**Risk**: Insufficient GOOD measurements in A-min
- **Cause**: Perpendicular fragmentation may have lower GOOD rate than expected
- **Probability**: 20%
- **Mitigation**: Add f=1.3 if needed (12 additional sims)
- **Fallback**: Present results with caveats about statistics

### Medium Risk

**Risk**: 512³ simulations exceed wall time
- **Cause**: C-min high-res may take > 10 hours
- **Probability**: 15%
- **Mitigation**: Reduce Lx to 6λJ (still sufficient for convergence)
- **Fallback**: Accept lower resolution test

**Risk**: Ray cluster instability
- **Cause**: Long-running jobs may fail
- **Probability**: 10%
- **Mitigation**: Checkpointing every 0.05 tJ
- **Fallback**: Resume from checkpoints

### Low Risk

**Risk**: Config generation errors
- **Cause**: Parameter space errors
- **Probability**: 5%
- **Mitigation**: Verify config file count (58)
- **Fallback**: Regenerate from scratch

---

## Success Metrics

### Campaign B-min

- [ ] All 28 simulations complete successfully
- [ ] λ/W(θ) curve is smooth and monotonic
- [ ] Can identify θ value where λ/W ≈ 2.6
- [ ] Expected: θ ≈ 30-60°

### Campaign A-min

- [ ] All 24 simulations complete successfully
- [ ] ≥ 50 GOOD measurements
- [ ] λ/W ≈ 1.25 ± 0.3
- [ ] No significant β dependence

### Campaign C-min

- [ ] All 6 simulations complete successfully
- [ ] λ/W convergence < 10%
- [ ] Expected: 5-8% change

---

## Timeline

**Preparation** (Day 1):
- Athena++ compilation: 1 hour
- Config generation: 0.5 hours
- Test simulations: 2 hours
- Verification: 0.5 hours

**Execution** (Days 2-3):
- Phase 1 (B + A): 7 hours
- Phase 2 (C): 10 hours
- Buffer: 3 hours
- Total: 20 hours

**Analysis** (Day 3):
- λ/W extraction: 1 hour
- Figure generation: 2 hours
- Paper integration: 3 hours

**Total**: ~2 days from start to paper-ready results

---

## References

- Paper: "Fragmentation of Interstellar Filaments: HGBS Analysis and MHD Simulations"
- Referee Report: May 2026
- Previous Campaigns: DTC (540 sims), Field Geometry (314 sims), Campaign D (36 sims)
- Athena++ v1.1.1: Stone et al. 2008, ApJS

---

**End of Specification Document**

Generated by ASTRA for referee-driven simulation campaign
Date: 2026-05-06
Status: READY FOR IMPLEMENTATION
