#!/usr/bin/env python3
"""
Extract λ/W Measurements from Simulation HDF5 Outputs

This script extracts fragmentation wavelength (λ) and filament width (W)
from completed simulations, then computes the dimensionless spacing λ/W.

CRITICAL: This measures λ/W, NOT t_frag. Previous campaign failure was
measuring the wrong observable.

Author: ASTRA
Date: 2026-05-06
"""

import h5py
import numpy as np
from scipy.signal import find_peaks
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import json


def extract_lambda_W(
    hdf5_path: str,
    snapshot_idx: int = -1,
    cells_per_lambdaJ: float = 32.0
) -> Dict[str, any]:
    """
    Extract λ/W measurement from simulation HDF5 output.

    Parameters
    ----------
    hdf5_path : str
        Path to HDF5 file
    snapshot_idx : int
        Which snapshot to analyze (-1 for last)
    cells_per_lambdaJ : float
        Grid cells per Jeans length (32 for 256x64x64, 64 for 512x128x128)

    Returns
    -------
    dict
        Dictionary with λ/W measurement and classification
    """

    if not Path(hdf5_path).exists():
        return {
            'status': 'ERROR',
            'error': f'HDF5 file not found: {hdf5_path}'
        }

    try:
        with h5py.File(hdf5_path, 'r') as f:
            # Get density grid
            # Shape expected: (time, x, y, z) or (x, y, z)
            rho = f['rho'][...]

            # If 4D, extract requested snapshot
            if rho.ndim == 4:
                rho = rho[snapshot_idx]

    except Exception as e:
        return {
            'status': 'ERROR',
            'error': f'Failed to read HDF5: {e}'
        }

    # Grid dimensions
    nx, ny, nz = rho.shape

    # Compute column density (integrate along x, perpendicular to filament)
    # Filament is along z, so we integrate along x (and average over y)
    Sigma = np.mean(rho, axis=0)  # Shape: (ny, nz)

    # Extract longitudinal profile (average over transverse direction y)
    profile = np.mean(Sigma, axis=0)  # Shape: (nz,)

    # Background subtraction (use outer 10% on each end)
    n_outer = max(10, nz // 10)
    background = np.median(np.concatenate([profile[:n_outer], profile[-n_outer:]]))
    profile_subtracted = profile - background
    profile_std = np.std(profile_subtracted)

    # Detect peaks
    peaks, properties = find_peaks(
        profile_subtracted,
        height=1.5 * profile_std,  # Minimum peak height
        distance=4,  # Minimum distance between peaks (in cells)
        prominence=0.1 * profile_std  # Minimum prominence
    )

    # Classification
    n_peaks = len(peaks)

    peak_prominences = properties.get('prominences', [])
    max_prominence = np.max(peak_prominences) if len(peak_prominences) > 0 else 0
    prominence_ratio = max_prominence / profile_std if profile_std > 0 else 0

    if n_peaks >= 3 and prominence_ratio > 0.15:
        classification = "GOOD"
    elif n_peaks < 2 or prominence_ratio < 0.05:
        classification = "FLAT"
    else:
        classification = "TRANSITIONAL"

    # Measure wavelength (peak spacing)
    if n_peaks >= 2:
        peak_diffs = np.diff(peaks)
        lambda_cells = np.mean(peak_diffs)
        lambda_std_cells = np.std(peak_diffs)
        lambda_lambdaJ = lambda_cells / cells_per_lambdaJ
    else:
        lambda_cells = np.nan
        lambda_std_cells = np.nan
        lambda_lambdaJ = np.nan

    # Measure width (transverse FWHM at filament center)
    center_z = nz // 2
    transverse_profile = Sigma[:, center_z]

    # FWHM calculation
    peak_value = np.max(transverse_profile)
    half_max = background + 0.5 * (peak_value - background)
    above_half = transverse_profile > half_max
    fwhm_cells = np.sum(above_half)

    if fwhm_cells > 0:
        W_lambdaJ = fwhm_cells / cells_per_lambdaJ
    else:
        W_lambdaJ = np.nan

    # Compute λ/W
    if not np.isnan(lambda_lambdaJ) and not np.isnan(W_lambdaJ) and W_lambdaJ > 0:
        lambda_over_W = lambda_lambdaJ / W_lambdaJ
    else:
        lambda_over_W = np.nan

    return {
        'status': 'SUCCESS',
        'n_peaks': n_peaks,
        'lambda_per_lambdaJ': lambda_lambdaJ,
        'lambda_std_per_lambdaJ': lambda_std_cells / cells_per_lambdaJ,
        'W_per_lambdaJ': W_lambdaJ,
        'lambda_over_W': lambda_over_W,
        'classification': classification,
        'peak_positions_cells': peaks.tolist(),
        'peak_prominences': peak_prominences.tolist() if len(peak_prominences) > 0 else [],
        'prominence_ratio': prominence_ratio,
        'background': float(background),
        'profile_std': float(profile_std)
    }


def parse_sim_id(sim_id: str) -> Dict[str, any]:
    """
    Parse simulation ID to extract parameters.

    Examples:
        B_f1p1_b1p0_th45_s42 -> campaign=B, f=1.1, beta=1.0, theta=45, seed=42
        A_f1p2_b2p0_th90_s137 -> campaign=A, f=1.2, beta=2.0, theta=90, seed=137
    """
    params = {'sim_id': sim_id}

    # Campaign
    if sim_id.startswith('B_'):
        params['campaign'] = 'B_min'
    elif sim_id.startswith('A_'):
        params['campaign'] = 'A_min'
    elif sim_id.startswith('C_'):
        params['campaign'] = 'C_min'
    else:
        params['campaign'] = 'unknown'

    # Parse parameters
    parts = sim_id.split('_')

    for part in parts:
        if part.startswith('f'):
            params['f'] = float(part[1:].replace('p', '.'))
        elif part.startswith('b'):
            params['beta'] = float(part[1:].replace('p', '.'))
        elif part.startswith('th'):
            params['theta_degrees'] = float(part[2:])
        elif part.startswith('s'):
            params['seed'] = int(part[1:])

    return params


def get_cells_per_lambdaJ(sim_id: str) -> float:
    """Get grid cells per Jeans length based on resolution."""
    if 'high' in sim_id or '512' in sim_id:
        return 64.0
    else:
        return 32.0


def analyze_simulation(sim_dir: Path) -> Optional[Dict]:
    """Analyze a single simulation directory."""
    sim_id = sim_dir.name

    # Find HDF5 file
    hdf5_files = list(sim_dir.glob('*.hdf5'))

    if len(hdf5_files) == 0:
        return {
            'sim_id': sim_id,
            'status': 'NO_DATA',
            'error': 'No HDF5 files found'
        }

    # Use the last HDF5 file (most complete)
    hdf5_file = sorted(hdf5_files)[-1]

    # Parse simulation ID
    params = parse_sim_id(sim_id)
    cells_per_lambdaJ = get_cells_per_lambdaJ(sim_id)

    # Extract λ/W
    result = extract_lambda_W(str(hdf5_file), cells_per_lambdaJ=cells_per_lambdaJ)

    # Combine with parameters
    result.update(params)

    return result


def analyze_campaign(campaign_dir: str) -> List[Dict]:
    """Analyze all simulations in a campaign."""
    campaign_path = Path(campaign_dir)

    if not campaign_path.exists():
        print(f"Warning: Campaign directory not found: {campaign_dir}")
        return []

    results = []
    sim_dirs = [d for d in campaign_path.iterdir() if d.is_dir() and not d.name.startswith('.')]

    for sim_dir in sim_dirs:
        result = analyze_simulation(sim_dir)
        if result is not None:
            results.append(result)

    return results


def analyze_all_campaigns(outputs_dir: str):
    """Analyze all campaigns and save results."""
    outputs_path = Path(outputs_dir)

    all_results = {}

    for campaign in ['B_min', 'A_min', 'C_min']:
        campaign_dir = outputs_path / campaign

        if not campaign_dir.exists():
            print(f"Skipping {campaign}: directory not found")
            continue

        print(f"\nAnalyzing {campaign}...")
        results = analyze_campaign(str(campaign_dir))
        all_results[campaign] = results

        print(f"  Analyzed {len(results)} simulations")

        # Save campaign-specific results
        campaign_results_file = outputs_path / f"{campaign}_lambda_W_results.json"
        with open(campaign_results_file, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"  Saved to {campaign_results_file}")

    # Save combined results
    combined_file = outputs_path / "all_lambda_W_results.json"
    with open(combined_file, 'w') as f:
        json.dump(all_results, f, indent=2)
    print(f"\nCombined results saved to {combined_file}")

    # Print summary
    print("\n" + "="*60)
    print("λ/W MEASUREMENT SUMMARY")
    print("="*60)

    for campaign, results in all_results.items():
        if len(results) == 0:
            continue

        good_results = [r for r in results if r.get('classification') == 'GOOD']
        flat_results = [r for r in results if r.get('classification') == 'FLAT']

        lambda_W_values = [r['lambda_over_W'] for r in good_results
                          if not np.isnan(r.get('lambda_over_W', np.nan))]

        print(f"\n{campaign}:")
        print(f"  Total: {len(results)}")
        print(f"  GOOD: {len(good_results)}")
        print(f"  FLAT: {len(flat_results)}")
        if len(lambda_W_values) > 0:
            print(f"  λ/W range: {np.min(lambda_W_values):.2f} - {np.max(lambda_W_values):.2f}")
            print(f"  λ/W mean: {np.mean(lambda_W_values):.2f} ± {np.std(lambda_W_values):.2f}")


def main():
    """Main execution function."""
    import argparse

    parser = argparse.ArgumentParser(description='Extract λ/W from simulations')
    parser.add_argument('--outputs', type=str, default='outputs',
                       help='Outputs directory')

    args = parser.parse_args()

    analyze_all_campaigns(args.outputs)


if __name__ == '__main__':
    main()
