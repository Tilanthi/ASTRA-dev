#!/usr/bin/env python3
"""
Monitor Referee Campaign Progress

Display real-time progress of simulation campaigns.

Author: ASTRA
Date: 2026-05-06
"""

import time
import json
from pathlib import Path
from collections import Counter


def load_simulation_results(outputs_dir='outputs'):
    """Load simulation results JSON."""
    results_file = Path(outputs_dir) / 'simulation_results.json'

    if not results_file.exists():
        return []

    with open(results_file, 'r') as f:
        return json.load(f)


def load_lambda_W_results(outputs_dir='outputs'):
    """Load λ/W analysis results."""
    all_results_file = Path(outputs_dir) / 'all_lambda_W_results.json'

    if not all_results_file.exists():
        return {}

    with open(all_results_file, 'r') as f:
        return json.load(f)


def count_hdf5_files(campaign_dir):
    """Count HDF5 files in campaign directory."""
    if not campaign_dir.exists():
        return 0

    hdf5_files = list(campaign_dir.glob('**/*.hdf5'))
    return len(hdf5_files)


def print_status_bar(results, lambda_W_results):
    """Print status bar."""
    if not results:
        print("Waiting for simulations to start...")
        return

    status_counts = Counter([r.get('status', 'PENDING') for r in results])

    total = len(results)
    complete = status_counts.get('SUCCESS', 0)
    failed = status_counts.get('FAILED', 0) + status_counts.get('ERROR', 0)
    timeout = status_counts.get('TIMEOUT', 0)
    running = total - complete - failed - timeout

    # Progress bar
    bar_width = 50
    progress = complete / total
    filled = int(bar_width * progress)
    bar = '=' * filled + '-' * (bar_width - filled)

    print(f"\r[{bar}] {complete}/{total} ({progress*100:.1f}%) | "
          f"Running: {running} | Failed: {failed} | Timeout: {timeout}", end='')

    # λ/W analysis status
    if lambda_W_results:
        total_analyzed = sum(len(v) if isinstance(v, list) else 0 for v in lambda_W_results.values())
        print(f" | Analyzed: {total_analyzed}", end='')


def print_detailed_status(results, lambda_W_results):
    """Print detailed campaign status."""
    print("\n" + "="*60)
    print("CAMPAIGN STATUS")
    print("="*60)

    # Group by campaign
    campaigns = {}
    for result in results:
        sim_id = result.get('sim_id', 'unknown')
        if sim_id.startswith('B_'):
            campaign = 'B_min'
        elif sim_id.startswith('A_'):
            campaign = 'A_min'
        elif sim_id.startswith('C_'):
            campaign = 'C_min'
        else:
            campaign = 'unknown'

        if campaign not in campaigns:
            campaigns[campaign] = []
        campaigns[campaign].append(result)

    for campaign, sims in sorted(campaigns.items()):
        status_counts = Counter([s.get('status', 'PENDING') for s in sims])
        total = len(sims)
        complete = status_counts.get('SUCCESS', 0)

        print(f"\n{campaign}:")
        print(f"  Total: {total}")
        print(f"  Complete: {complete}")
        print(f"  Status: {dict(status_counts)}")

        # λ/W statistics
        if campaign in lambda_W_results:
            lambda_W_data = lambda_W_results[campaign]
            if isinstance(lambda_W_data, list):
                good = [r for r in lambda_W_data if r.get('classification') == 'GOOD']
                lambda_W_values = [r.get('lambda_over_W') for r in good
                                  if not r.get('lambda_over_W', None) is None]

                if len(lambda_W_values) > 0:
                    import numpy as np
                    print(f"  λ/W measurements: {len(lambda_W_values)}")
                    print(f"  λ/W mean: {np.mean(lambda_W_values):.2f} ± {np.std(lambda_W_values):.2f}")


def monitor(refresh_rate=5, outputs_dir='outputs'):
    """Monitor campaign progress."""
    print("\n" + "="*60)
    print("MONITORING REFEREE CAMPAIGN PROGRESS")
    print("="*60)
    print(f"\nOutputs directory: {outputs_dir}")
    print(f"Refresh rate: {refresh_rate} seconds")
    print("\nPress Ctrl+C to stop monitoring and see detailed status.\n")

    try:
        while True:
            results = load_simulation_results(outputs_dir)
            lambda_W_results = load_lambda_W_results(outputs_dir)

            print_status_bar(results, lambda_W_results)

            time.sleep(refresh_rate)

    except KeyboardInterrupt:
        print("\n\nMonitoring stopped.")

        # Print detailed status
        results = load_simulation_results(outputs_dir)
        lambda_W_results = load_lambda_W_results(outputs_dir)
        print_detailed_status(results, lambda_W_results)


def main():
    """Main execution function."""
    import argparse

    parser = argparse.ArgumentParser(description='Monitor referee campaign progress')
    parser.add_argument('--refresh', type=int, default=5,
                       help='Refresh rate in seconds')
    parser.add_argument('--outputs', type=str, default='outputs',
                       help='Outputs directory')

    args = parser.parse_args()

    monitor(refresh_rate=args.refresh, outputs_dir=args.outputs)


if __name__ == '__main__':
    main()
