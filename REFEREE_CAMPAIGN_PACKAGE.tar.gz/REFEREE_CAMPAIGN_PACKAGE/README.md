# Referee Campaign Package: Minimum Viable λ/W Measurements

**Date**: 2026-05-06
**Priority**: HIGH - Addresses all referee concerns for paper acceptance
**Total Simulations**: 58
**Estimated Wall Time**: ~17-20 hours on 220-core cluster

---

## Executive Summary

This package implements the **minimum viable simulation campaign** to address all referee concerns about λ/W measurements in the filament spacing paper. Three focused campaigns target:

1. **Campaign B-min**: λ/W vs θ (28 sims) - Mixed geometry calibration curve
2. **Campaign A-min**: Perpendicular λ/W statistics (24 sims) - Robustness of λ/W ≈ 1.25
3. **Campaign C-min**: Resolution convergence (6 sims) - Numerical verification

---

## CRITICAL: What This Campaign Measures

**This campaign measures λ/W (fragmentation wavelength), NOT t_frag (fragmentation timescale).**

The previous campaign failure was measuring t_frag only because λ/W extraction was not configured.

**λ/W extraction methodology**:
- Extract longitudinal density profile from column density map
- Detect peaks using scipy.signal.find_peaks
- Measure wavelength (peak spacing) and width (FWHM)
- Compute dimensionless spacing λ/W

---

## Quick Start

### Prerequisites

1. **Athena++ v1.1.1** with filament_fragmentation problem
2. **Ray** for distributed execution
3. **Python 3.8+** with numpy, scipy, h5py
4. **220 CPU cores** available (or adjust ray_config.yaml)
5. **~200 GB disk space** for simulation outputs

### Installation

```bash
# 1. Extract this package
tar -xzf REFEREE_CAMPAIGN_PACKAGE.tar.gz
cd REFEREE_CAMPAIGN_PACKAGE/

# 2. Clone and compile Athena++
git clone https://github.com/PrincetonUniversity/athena.git
cd athena
git checkout v1.1.1
cd ..

bash compile_athena.sh

# 3. Generate config files
python generate_configs.py

# 4. Run TEST simulations (MANDATORY)
python test_analyze.py

# 5. If all tests pass, launch full campaign
python run_referee_campaigns.py --phase all
```

### Monitoring Progress

```bash
# In a separate terminal
python monitor_progress.py
```

Ray dashboard: http://localhost:8265

---

## Campaign Specifications

### Campaign B-min: Oblique λ/W(θ) - THE ESSENTIAL RUN

**Purpose**: Directly measure λ/W at intermediate field inclinations. This calibration curve transforms the paper's weakest claim into a testable prediction.

**Configuration**:
- θ = 0°, 15°, 30°, 45°, 60°, 75°, 90° (7 values)
- f = 1.1 only (near-critical)
- β = 1.0, 2.0 (two observationally relevant values)
- M = 1.0 (fiducial turbulence)
- 2 seeds per point
- Domain: 8λJ × λJ × λJ
- Resolution: 256 × 64 × 64
- HDF5 output: Every 0.05 tJ

**Total**: 28 simulations
**Wall time**: ~3 hours (with 13 concurrent)

**Expected Output**: λ/W(θ) calibration curve. Can directly read off θ value where λ/W ≈ 2.6 (HGBS mean).

---

### Campaign A-min: Perpendicular λ/W Statistics - TARGETED IMPROVEMENT

**Purpose**: Referee notes λ/W ≈ 1.25 rests on only 27 GOOD measurements. Targeting 50+ measurements establishes robustness.

**Configuration**:
- θ = 90° (perpendicular field only)
- f = 1.1, 1.2 (two near-critical values)
- β = 1.0, 1.5, 2.0, 3.0 (Regime IV only)
- M = 1.0 (fiducial turbulence)
- 3 seeds per point
- Domain: 16λJ × λJ × λJ (extended for perpendicular λ/W)
- Resolution: 512 × 64 × 64
- HDF5 output: Every 0.02 tJ (higher cadence for fast fragmentation)

**Total**: 24 simulations
**Wall time**: ~7 hours (with 13 concurrent)

**Expected Output**: 50+ GOOD λ/W measurements confirming λ/W ≈ 1.25 with robust statistics.

---

### Campaign C-min: Resolution Convergence - SINGLE SPOT CHECK

**Purpose**: Credibility check for λ/W numerical convergence. Single well-chosen parameter point at two resolutions.

**Configuration**:
- θ = 0° (longitudinal, cleanest beading)
- f = 1.1, β = 1.0, M = 1.0 (paper's reference point)
- 3 seeds per point
- Two resolutions: 256×64×64 and 512×128×128
- Domain: 8λJ × λJ × λJ
- HDF5 output: Every 0.05 tJ

**Total**: 6 simulations (3 at each resolution)
**Wall time**: ~10 hours (512³ runs are bottleneck)

**Expected Output**: "λ/W changes by X% between 256³ and 512³, confirming numerical convergence."

---

## Execution Plan

### Phase 1: Launch Simultaneously (~7 hours)

- Campaign B-min: All 28 simulations (~3 hours with 13 concurrent)
- Campaign A-min: All 24 simulations (~7 hours with 13 concurrent)

These use different parameter spaces and can run in parallel with no conflicts.

### Phase 2: After Phase 1 Completes (~10 hours)

- Campaign C-min: All 6 simulations (~10 hours with 3 concurrent for 512³)

### Total Elapsed Time: ~17-20 hours

---

## File Structure

```
REFEREE_CAMPAIGN_PACKAGE/
├── README.md                          # This file
├── MANIFEST.md                        # Complete file list
├── run_referee_campaigns.py           # Main Ray execution script
├── generate_configs.py                # Config generation
├── monitor_progress.py                # Progress monitoring
├── analyze_lambda_W.py                # λ/W extraction
├── test_analyze.py                    # Test simulation + analysis
├── compile_athena.sh                  # Athena++ compilation
├── ray_config.yaml                    # Ray configuration
├── configs/                           # Generated config files
│   ├── B_min/                         # Campaign B configs
│   ├── A_min/                         # Campaign A configs
│   └── C_min/                         # Campaign C configs
├── analysis/
│   └── (analysis functions in analyze_lambda_W.py)
└── outputs/                           # Created during run (not in package)
    ├── B_min/
    ├── A_min/
    └── C_min/
```

---

## λ/W Analysis Methodology

### Extraction Process

For each simulation:

1. **Read final HDF5 snapshot**
2. **Compute column density**: Σ(x, y) = ∫ρ dx
3. **Extract longitudinal profile**: Average along transverse direction
4. **Background subtraction**: Median of outer 10% of domain
5. **Detect peaks**: scipy.signal.find_peaks with thresholds
6. **Measure wavelength**: Mean peak spacing
7. **Measure width**: FWHM of transverse profile
8. **Compute λ/W**: Dimensionless spacing

### Classification Criteria

- **GOOD**: N_peaks ≥ 3 AND peak_prominence/background > 0.15
- **FLAT**: N_peaks < 3 OR peak_prominence/background < 0.05
- **TRANSITIONAL**: Intermediate cases

### Output Format

```json
{
  "sim_id": "B_f1p1_b1p0_th15_s42",
  "campaign": "B_min",
  "f": 1.1,
  "beta": 1.0,
  "theta_degrees": 15,
  "classification": "GOOD",
  "n_peaks": 4,
  "lambda_per_lambdaJ": 2.34,
  "W_per_lambdaJ": 0.46,
  "lambda_over_W": 5.09
}
```

---

## Verification Checklist

Before launching full campaign, verify:

- [ ] Athena++ compiles successfully
- [ ] Config files generated (28 + 24 + 6 = 58 files)
- [ ] Test simulations run successfully
- [ ] λ/W extraction produces reasonable values (0.5-10.0)
- [ ] Classification (GOOD/FLAT) is sensible
- [ ] HDF5 snapshots are being written

**ONLY after all tests pass, launch full campaign.**

---

## Risk Mitigation

### Risk 1: λ/W extraction fails
**Mitigation**: MANDATORY test simulations before full launch.

### Risk 2: Insufficient GOOD measurements in A-min
**Mitigation**: If GOOD rate < 50%, add f=1.3 to parameter space.

### Risk 3: Oblique angles show FLAT behavior
**Mitigation**: If intermediate angles fail to fragment, extend domain to Lx=12λJ.

### Risk 4: 512³ resolution takes too long
**Mitigation**: If 10 hours per sim is too long, reduce to Lx=6λJ.

---

## Success Criteria

### Campaign B-min
- All 28 simulations complete
- λ/W(θ) curve is smooth and monotonic
- Can identify θ value where λ/W ≈ 2.6

### Campaign A-min
- All 24 simulations complete
- ≥ 50 GOOD measurements
- λ/W ≈ 1.25 ± 0.3

### Campaign C-min
- All 6 simulations complete
- λ/W convergence < 10% between resolutions

---

## Integration with Paper

After campaigns complete:

1. **Update Figure**: λ/W vs θ curve (Campaign B-min)
2. **Update Text**: "Direct λ/W measurements confirm HGBS λ/W ≈ 2.6 corresponds to θ ≈ XX°"
3. **Update Statistics**: "Perpendicular λ/W = 1.25 ± YY from ZZ measurements"
4. **Add Statement**: "Numerical convergence verified: λ/W changes by < 10% between 256³ and 512³"

---

## Troubleshooting

### Athena++ fails to compile

Ensure you have:
- MPI libraries (mpich, openmpi, or equivalent)
- HDF5 libraries with development headers
- C++ compiler with C++11 support

### Ray initialization fails

Check that:
- No other Ray instance is running (port 8265 available)
- Sufficient memory available (200 GB for object store)
- Correct number of CPUs in ray_config.yaml

### Simulations timeout

Increase timeout in ray_config.yaml for affected campaign.

### λ/W extraction fails

Check that:
- HDF5 files exist in output directories
- HDF5 files contain 'rho' field
- Grid dimensions are as expected

---

## Contact and Support

For questions or issues:
1. Check the ASTRA documentation
2. Review analysis code in analyze_lambda_W.py
3. Verify Athena++ problem source code

---

## License

This campaign package is part of the ASTRA project and follows the same license terms.

---

**Generated by ASTRA for referee-driven simulation campaign**
**Date**: 2026-05-06
**Status**: READY FOR DEPLOYMENT
