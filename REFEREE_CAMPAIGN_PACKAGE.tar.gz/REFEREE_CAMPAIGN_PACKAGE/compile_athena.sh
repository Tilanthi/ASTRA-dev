#!/bin/bash
# Compile Athena++ for Referee Campaigns
# Author: ASTRA
# Date: 2026-05-06

set -e  # Exit on error

echo "=========================================="
echo "Compiling Athena++ for Referee Campaigns"
echo "=========================================="
echo ""

# Check if Athena++ directory exists
if [ ! -d "athena" ]; then
    echo "ERROR: Athena++ directory not found"
    echo "Please clone Athena++:"
    echo "  git clone https://github.com/PrincetonUniversity/athena.git"
    echo "  cd athena"
    echo "  git checkout v1.1.1"
    exit 1
fi

cd athena

echo "Configuring Athena++..."
echo "  Problem: filament_fragmentation"
echo "  Physics: MHD with isothermal EOS"
echo "  Geometry: 3D Cartesian"
echo ""

# Configure Athena++
./configure \
    --prob=filament_fragmentation \
    --flux=hlld \
    --ode=2n \
    --mpi \
    --hdf5 \
    <<EOF
13
std
3d
mhd
iso
EOF

echo ""
echo "Building Athena++..."
echo "This may take several minutes..."
echo ""

# Build with 4 parallel jobs (adjust based on your system)
make -j4

echo ""
echo "=========================================="
echo "Athena++ compilation complete!"
echo "=========================================="
echo ""
echo "Executable: bin/athena"
echo ""
echo "You can now run the referee campaigns:"
echo "  cd .."
echo "  python test_analyze.py          # Run test simulations first"
echo "  python run_referee_campaigns.py  # Then launch full campaign"
