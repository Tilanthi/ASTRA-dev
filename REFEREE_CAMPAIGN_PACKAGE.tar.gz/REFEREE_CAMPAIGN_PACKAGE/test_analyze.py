#!/usr/bin/env python3
"""
Test Simulation + λ/W Analysis

Run one test simulation from each campaign to verify λ/W extraction works
before launching the full campaign.

CRITICAL: This must pass before full campaign launch.

Author: ASTRA
Date: 2026-05-06
"""

import subprocess
import sys
from pathlib import Path
import time

# Test configurations
TEST_CONFIGS = [
    {
        'name': 'Campaign B-min Test',
        'campaign': 'B_min',
        'config': 'B_test_f1p1_b1p0_th45_s42.athena',
        'expected_peaks': '3-5',
        'expected_lambda_W': '3-6',
        'timeout': 7200
    },
    {
        'name': 'Campaign A-min Test',
        'campaign': 'A_min',
        'config': 'A_test_f1p1_b2p0_th90_s42.athena',
        'expected_peaks': '5-10',
        'expected_lambda_W': '1-2',
        'timeout': 14400
    },
    {
        'name': 'Campaign C-min Test',
        'campaign': 'C_min',
        'config': 'C_test_f1p1_b1p0_th0_s42.athena',
        'expected_peaks': '3-5',
        'expected_lambda_W': '4-7',
        'timeout': 7200
    }
]


def run_test_simulation(test_config):
    """Run a single test simulation."""
    print(f"\n{'='*60}")
    print(f"TEST: {test_config['name']}")
    print(f"{'='*60}")

    config_path = Path(f"configs/{test_config['campaign']}/{test_config['config']}")

    if not config_path.exists():
        print(f"ERROR: Config file not found: {config_path}")
        return False

    # Create output directory
    output_dir = Path(f"outputs/test_{test_config['campaign']}")
    output_dir.mkdir(parents=True, exist_ok=True)

    # Copy config
    import shutil
    shutil.copy(config_path, output_dir / "filament_fragmentation.att")

    print(f"\nRunning simulation...")
    print(f"  Config: {test_config['config']}")
    print(f"  Output: {output_dir}")
    print(f"  Timeout: {test_config['timeout']} seconds")

    start_time = time.time()

    try:
        # Run Athena++
        result = subprocess.run(
            ['mpirun', '-np', '16', './athena', '-i', 'filament_fragmentation.att'],
            cwd=str(output_dir),
            capture_output=True,
            text=True,
            timeout=test_config['timeout']
        )

        wall_time = (time.time() - start_time) / 60  # minutes

        if result.returncode != 0:
            print(f"\nERROR: Athena++ failed with return code {result.returncode}")
            print(f"STDERR:\n{result.stderr[-1000:]}")
            return False

        print(f"\nSimulation completed in {wall_time:.1f} minutes")

        # Check for HDF5 outputs
        hdf5_files = list(output_dir.glob('*.hdf5'))

        if len(hdf5_files) == 0:
            print("\nERROR: No HDF5 output files found")
            return False

        print(f"Found {len(hdf5_files)} HDF5 snapshots")

        # Analyze λ/W
        print(f"\nAnalyzing λ/W...")

        from analyze_lambda_W import extract_lambda_W, get_cells_per_lambdaJ

        sim_id = output_dir.name
        cells_per_lambdaJ = get_cells_per_lambdaJ(sim_id)

        # Use last HDF5 file
        hdf5_file = sorted(hdf5_files)[-1]
        result = extract_lambda_W(str(hdf5_file), cells_per_lambdaJ=cells_per_lambdaJ)

        if result['status'] != 'SUCCESS':
            print(f"\nERROR: λ/W extraction failed: {result.get('error', 'Unknown')}")
            return False

        # Display results
        print(f"\nλ/W Analysis Results:")
        print(f"  Classification: {result['classification']}")
        print(f"  N_peaks: {result['n_peaks']}")
        print(f"  λ/λ_J: {result.get('lambda_per_lambdaJ', 'N/A')}")
        print(f"  W/λ_J: {result.get('W_per_lambdaJ', 'N/A')}")
        print(f"  λ/W: {result.get('lambda_over_W', 'N/A')}")

        # Check if results are reasonable
        lambda_W = result.get('lambda_over_W', np.nan)

        if np.isnan(lambda_W):
            print("\nWARNING: λ/W is NaN - this may indicate a problem")
            return False

        if result['classification'] not in ['GOOD', 'TRANSITIONAL']:
            print(f"\nWARNING: Classification is {result['classification']}, expected GOOD or TRANSITIONAL")

        # Check expected range
        expected_min, expected_max = map(float, test_config['expected_lambda_W'].split('-'))
        if not (expected_min <= lambda_W <= expected_max):
            print(f"\nWARNING: λ/W = {lambda_W:.2f} is outside expected range {test_config['expected_lambda_W']}")
            print("This may be OK, but verify the simulation is behaving correctly")

        print(f"\n✓ TEST PASSED")

        return True

    except subprocess.TimeoutExpired:
        print(f"\nERROR: Simulation timed out after {test_config['timeout']} seconds")
        return False
    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all test simulations."""
    print("\n" + "="*60)
    print("REFREE CAMPAIGN TEST SIMULATIONS")
    print("="*60)
    print("\nThis will run ONE test simulation from each campaign")
    print("to verify λ/W extraction is working correctly.")
    print("\nAll tests MUST pass before launching the full campaign.")

    results = {}

    for test_config in TEST_CONFIGS:
        success = run_test_simulation(test_config)
        results[test_config['name']] = success

        if not success:
            print(f"\n{'='*60}")
            print("TEST FAILED - DO NOT PROCEED WITH FULL CAMPAIGN")
            print(f"{'='*60}")
            return 1

    # All tests passed
    print(f"\n{'='*60}")
    print("ALL TESTS PASSED - READY FOR FULL CAMPAIGN")
    print(f"{'='*60}")

    print("\nTest Summary:")
    for name, success in results.items():
        status = "✓ PASS" if success else "✗ FAIL"
        print(f"  {status}: {name}")

    print("\nYou can now launch the full campaign with:")
    print("  python run_referee_campaigns.py --phase all")

    return 0


if __name__ == '__main__':
    sys.exit(main())
