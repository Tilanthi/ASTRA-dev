#!/bin/bash
###############################################################################
# submit_turbulent_campaign.sh
# SLURM batch submission script for Turbulent Amplitude Gap Campaign
#
# Usage: sbatch --array=1-800 submit_turbulent_campaign.sh
###############################################################################

#SBATCH --job-name=turb_gap
#SBATCH --output=turb_gap_%A_%a.out
#SBATCH --error=turb_gap_%A_%a.err
#SBATCH --time=06:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem-per-cpu=2G
#SBATCH --partition=compute

###############################################################################
# Configuration
###############################################################################

# Athena++ installation path
ATHENA_INSTALL="/path/to/athena/bin/athena"

# Campaign root directory
CAMPAIGN_ROOT="/path/to/turbulent_amplitude_gap_campaign"

# Simulation list file
SIM_LIST="${CAMPAIGN_ROOT}/simulation_list.txt"

# Get simulation directory for this array job
SIM_DIR=$(sed -n "${SLURM_ARRAY_TASK_ID}p" "${SIM_LIST}")

# Output directory for this simulation
OUTPUT_DIR="${SIM_DIR}"
INPUT_FILE="${SIM_DIR}/athena_input.txt"

###############################################################################
# Functions
###############################################################################

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

check_prerequisites() {
    if [ ! -f "${ATHENA_INSTALL}" ]; then
        log_message "ERROR: Athena++ executable not found: ${ATHENA_INSTALL}"
        exit 1
    fi

    if [ ! -f "${INPUT_FILE}" ]; then
        log_message "ERROR: Input file not found: ${INPUT_FILE}"
        exit 1
    fi

    if [ ! -d "${OUTPUT_DIR}" ]; then
        log_message "ERROR: Output directory not found: ${OUTPUT_DIR}"
        exit 1
    fi
}

run_simulation() {
    log_message "Starting simulation: ${SIM_DIR}"
    log_message "Input file: ${INPUT_FILE}"
    log_message "Output directory: ${OUTPUT_DIR}"

    # Create output subdirectories
    mkdir -p "${OUTPUT_DIR}/hst"
    mkdir -p "${OUTPUT_DIR}/tab"
    mkdir -p "${OUTPUT_DIR}/hdf5"

    # Record simulation metadata
    cat > "${OUTPUT_DIR}/simulation_metadata.txt" <<EOF
Simulation started: $(date)
Job ID: ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}
Node: ${SLURM_NODELIST}
Athena++ executable: ${ATHENA_INSTALL}
Input file: ${INPUT_FILE}
EOF

    # Run Athena++
    log_message "Executing Athena++..."
    "${ATHENA_INSTALL}" -i "${INPUT_FILE}" \
        -d "${OUTPUT_DIR}" \
        > "${OUTPUT_DIR}/athena_stdout.log" \
        2> "${OUTPUT_DIR}/athena_stderr.log"

    exit_code=$?

    # Record completion status
    cat >> "${OUTPUT_DIR}/simulation_metadata.txt" <<EOF
Simulation completed: $(date)
Exit code: ${exit_code}
EOF

    if [ ${exit_code} -eq 0 ]; then
        log_message "Simulation completed successfully"
    else
        log_message "WARNING: Simulation exited with code ${exit_code}"
    fi
}

###############################################################################
# Main execution
###############################################################################

log_message "================================================"
log_message "Turbulent Amplitude Gap Campaign"
log_message "================================================"
log_message "Job ID: ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}"
log_message "Node: ${SLURM_NODELIST}"
log_message "Simulation directory: ${SIM_DIR}"

check_prerequisites
run_simulation

log_message "Job finished"

exit 0
