# Turbulent Amplitude Gap Campaign - README

## Quick Start

1. **Generate configuration files**:
   ```bash
   python generate_turbulent_campaign.py /path/to/campaign/directory
   ```

2. **Submit simulations to cluster**:
   ```bash
   sbatch --array=1-800 submit_turbulent_campaign.sh
   ```

3. **Analyze results**:
   ```bash
   python turbulent_gap_analysis.py /path/to/campaign/directory
   ```

## Directory Structure

```
turbulent_amplitude_gap_campaign/
├── TURBULENT_AMPLITUDE_GAP_CAMPAIGN.md  # Full specification
├── README_TURBULENT_CAMPAIGN.md         # This file
├── generate_turbulent_campaign.py       # Config generator
├── submit_turbulent_campaign.sh         # SLURM submission script
├── turbulent_gap_analysis.py            # Analysis pipeline
├── campaign_metadata.json               # Auto-generated metadata
├── simulation_list.txt                 # Auto-generated sim list
└── f{f}_b{beta}_t{theta}_s{seed}/     # Simulation directories (800)
    ├── athena_input.txt                # Athena++ config
    ├── hst/                           # History files
    ├── tab/                           # Tab files
    ├── hdf5/                          # HDF5 snapshots
    └── simulation_metadata.txt        # Run metadata
```

## Campaign Statistics

- **Total simulations**: 800
- **Parameter space**: 5 amplitudes × 4 f values × 4 β values × 2 geometries × 5 seeds
- **Expected runtime**: ~1 week (800 sims × 4 hours ÷ 20 concurrent)
- **Storage required**: ~1.6 TB raw data

## Key Parameters

| Parameter | Values | Physical Meaning |
|-----------|--------|------------------|
| Turbulent amplitude (δv/cs) | 1.0, 1.5, 2.0, 2.5, 3.0 | HGBS range |
| Line-mass fraction (f) | 1.0, 1.2, 1.5, 2.0 | Near-critical to supercritical |
| Plasma β (longitudinal) | 0.3, 0.5, 1.0, 2.0 | Weak to strong field |
| Field geometry (θ) | 0°, 90° | Longitudinal, perpendicular |
| Random seeds | 1-5 | Statistical robustness |

## Expected Outcomes

This campaign will definitively answer:

1. **Does field geometry dependence survive at realistic turbulence amplitudes?**
   - Laminar: Perpendicular fields give λ/W ≈ 1.25 vs longitudinal ≈ 2.8-4.7
   - Realistic: Does this 2-4× factor persist at δv/cs = 2-3?

2. **Does β-dependence remain valid under turbulent conditions?**
   - Laminar: Longitudinal λ/W decreases from 4.74 (β=0.3) to 2.80 (β=2.0)
   - Realistic: Is this trend preserved?

3. **Does fragmentation morphology change?**
   - Laminar: Sharp transition between FULL, PARTIAL, RADIAL_ONLY
   - Realistic: Does turbulence broaden these categories?

## Integration with Paper

Results will be integrated into Section 4.6 as a new subsection:

**"Realistic-Turbulence Validation Campaign"**

After completion, update `filament_spacing_streamlined_mnras_v2.tex` with:

1. Simulation count in Section 4 (add to total)
2. New subsection in Section 4.6 describing campaign
3. Updated discussion in Section 5.3 reflecting realistic-turbulence results
4. Modified conclusions acknowledging regime tested

## Contact

- **Campaign PI**: G. J. White (g.j.white@open.ac.uk)
- **GitHub**: https://github.com/Tilanthi/ASTRA-dev
- **Issue tracker**: For questions or problems

---

**Version**: 1.0
**Last updated**: 2026-05-28
