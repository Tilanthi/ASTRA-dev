#!/usr/bin/env python3
"""
Analysis script for peer review campaign results

This script processes the output from the filament MHD campaign and generates
the figures and tables needed for the MNRAS paper revision.

Input: status/*.json files from completed simulations
Output:
    - CSV catalog of all simulation results
    - Analysis figures (PDF/PNG)
    - Summary report (Markdown)
"""

import json
import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats, signal
from typing import Dict, List
import h5py

# =============================================================================
# CONFIGURATION
# =============================================================================

BASE_DIR = Path.cwd()
STATUS_DIR = BASE_DIR / "status"
RUNS_DIR = BASE_DIR / "runs"
OUTPUT_DIR = BASE_DIR / "analysis_output"
OUTPUT_DIR.mkdir(exist_ok=True)

# =============================================================================
# DATA LOADING
# =============================================================================

def load_all_results() -> pd.DataFrame:
    """Load all simulation status files into a DataFrame."""

    results = []
    for status_file in STATUS_DIR.glob("*.json"):
        with open(status_file) as f:
            data = json.load(f)
            results.append(data)

    df = pd.DataFrame(results)
    return df

def parse_sim_id(sim_id: str) -> Dict:
    """Extract parameters from simulation ID."""
    params = {}

    # Parse line mass fraction
    if 'f1.00' in sim_id:
        params['f'] = 1.00
    elif 'f1.05' in sim_id:
        params['f'] = 1.05
    elif 'f1.10' in sim_id:
        params['f'] = 1.10
    elif 'f1.15' in sim_id:
        params['f'] = 1.15
    elif 'f1.20' in sim_id:
        params['f'] = 1.20
    elif 'f1.5' in sim_id:
        params['f'] = 1.5
    elif 'f2.0' in sim_id:
        params['f'] = 2.0
    elif 'f2.5' in sim_id:
        params['f'] = 2.5
    elif 'f3.0' in sim_id:
        params['f'] = 3.0

    # Parse plasma beta
    if 'b0.3' in sim_id:
        params['beta'] = 0.3
    elif 'b0.5' in sim_id:
        params['beta'] = 0.5
    elif 'b0.7' in sim_id:
        params['beta'] = 0.7
    elif 'b1.0' in sim_id:
        params['beta'] = 1.0
    elif 'b1.5' in sim_id:
        params['beta'] = 1.5
    elif 'b2.0' in sim_id:
        params['beta'] = 2.0

    # Parse Mach number
    if 'M0.5' in sim_id:
        params['mach'] = 0.5
    elif 'M1' in sim_id:
        params['mach'] = 1.0
    elif 'M2' in sim_id:
        params['mach'] = 2.0
    elif 'M3' in sim_id:
        params['mach'] = 3.0

    # Parse field geometry
    if 'perp' in sim_id:
        params['bfield'] = 'perpendicular'
    elif 'oblique' in sim_id:
        params['bfield'] = 'oblique'
    else:
        params['bfield'] = 'longitudinal'

    # Parse EOS
    if 'adiabatic' in sim_id:
        params['eos'] = 'adiabatic'
    else:
        params['eos'] = 'isothermal'

    # Parse profile
    if 'uniform' in sim_id:
        params['profile'] = 'uniform'
    else:
        params['profile'] = 'king'

    return params

def enrich_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Add parsed parameters to DataFrame."""

    # Parse sim_id to extract parameters
    param_dicts = df['sim_id'].apply(parse_sim_id).tolist()

    for key in param_dicts[0].keys():
        df[key] = [p[key] for p in param_dicts]

    return df

# =============================================================================
# PEAK DETECTION FROM HDF5
# =============================================================================

def detect_longitudinal_peaks(sim_id: str) -> Dict:
    """
    Analyze HDF5 output to detect longitudinal fragmentation structure.

    Returns:
        dict with keys: n_peaks, lambda_frag, quality_metric
    """

    # Find simulation directory
    sim_dir = None
    for campaign_dir in RUNS_DIR.iterdir():
        if campaign_dir.is_dir():
            potential_dir = campaign_dir / sim_id
            if potential_dir.exists():
                sim_dir = potential_dir
                break

    if sim_dir is None:
        return {"n_peaks": 0, "lambda_frag": None, "quality": "no_data"}

    # Find HDF5 files
    hdf5_files = sorted(sim_dir.glob("*.athdf"))

    if len(hdf5_files) == 0:
        return {"n_peaks": 0, "lambda_frag": None, "quality": "no_hdf5"}

    # Analyze last few snapshots
    results = []
    for hdf5_file in hdf5_files[-3:]:  # Last 3 snapshots
        try:
            with h5py.File(hdf5_file, 'r') as f:
                rho = f['density'][:]

                # Extract longitudinal spine density
                ny, nz = rho.shape[1], rho.shape[2]
                spine_rho = rho[:, ny//2, nz//2]

                # Normalize
                spine_rho = spine_rho / np.mean(spine_rho)

                # Peak detection
                peaks, properties = signal.find_peaks(
                    spine_rho,
                    height=1.1,  # 10% above mean
                    distance=10   # Minimum separation
                )

                n_peaks = len(peaks)

                if n_peaks >= 2:
                    # Calculate spacing
                    spacings = np.diff(peaks)
                    lambda_frag = np.mean(spacings)

                    # Quality metric based on peak prominence
                    prom = properties.get('prominence', np.zeros(n_peaks))
                    quality = np.mean(prom) / np.mean(spine_rho[peaks])
                else:
                    lambda_frag = None
                    quality = 0.0

                results.append({
                    "n_peaks": n_peaks,
                    "lambda_frag": lambda_frag,
                    "quality": quality
                })
        except Exception as e:
            continue

    if not results:
        return {"n_peaks": 0, "lambda_frag": None, "quality": "error"}

    # Return best result (most peaks)
    best = max(results, key=lambda x: x['n_peaks'])

    # Classify quality
    if best['n_peaks'] >= 3:
        quality_label = "excellent"
    elif best['n_peaks'] == 2:
        quality_label = "good" if best['quality'] > 0.2 else "marginal"
    elif best['n_peaks'] == 1:
        quality_label = "weak"
    else:
        quality_label = "none"

    return {
        "n_peaks": best['n_peaks'],
        "lambda_frag": best['lambda_frag'],
        "quality_metric": best['quality'],
        "quality_label": quality_label
    }

# =============================================================================
# ANALYSIS FUNCTIONS
# =============================================================================

def analyze_near_critical_regime(df: pd.DataFrame):
    """Address T1, T2: At what f does longitudinal beading emerge?"""

    # Filter near-critical simulations
    nearcrit = df[(df['f'] <= 1.20) & (df['bfield'] == 'longitudinal') & (df['eos'] == 'isothermal')]

    # Group by f and count beading events
    beading_stats = nearcrit.groupby('f').agg({
        'longitudinal_peaks': ['mean', 'count'],
        'lambda_frag': ['mean', 'std'],
        't_frag': ['mean', 'std']
    })

    return beading_stats

def analyze_perpendicular_fields(df: pd.DataFrame):
    """Address T3, T9: Fragmentation for perpendicular B-fields."""

    perp = df[df['bfield'] == 'perpendicular']

    # Compare λ/W between field geometries
    comparison = df.groupby('bfield').agg({
        'longitudinal_peaks': 'mean',
        'lambda_frag': 'mean',
        't_frag': 'mean'
    })

    return comparison

def analyze_power_law(df: pd.DataFrame):
    """Address T5: Power-law exponent across different conditions."""

    results = {}

    # Overall power law
    for eos in ['isothermal', 'adiabatic']:
        for profile in ['king', 'uniform']:
            subset = df[(df['eos'] == eos) & (df['profile'] == profile) & (df['t_frag'] > 0)]

            if len(subset) > 10:
                # Fit power law: 1/t_frag ∝ f^α
                log_t = np.log(subset['t_frag'])
                log_f = np.log(subset['f'])

                slope, intercept, r_value, p_value, std_err = stats.linregress(log_f, log_t)

                key = f"{eos}_{profile}"
                results[key] = {
                    'exponent': -slope,
                    'r_squared': r_value**2,
                    'n_sims': len(subset)
                }

    return results

def analyze_regime_boundaries(df: pd.DataFrame):
    """Address T4: Compare regime boundaries to theory."""

    # Find transition β values
    transitions = []

    for f in df['f'].unique():
        subset = df[df['f'] == f]

        # Find where longitudinal peaks emerge
        for beta in sorted(subset['beta'].unique()):
            beta_subset = subset[subset['beta'] == beta]
            mean_peaks = beta_subset['longitudinal_peaks'].mean()

            if mean_peaks > 0.5:  # Significant beading
                transitions.append({'f': f, 'beta_transition': beta, 'mean_peaks': mean_peaks})

    return pd.DataFrame(transitions)

# =============================================================================
# FIGURE GENERATION
# =============================================================================

def make_figure_1_beading_regime(df: pd.DataFrame):
    """Figure 1: Regime map showing where longitudinal beading emerges."""

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Left: Longitudinal fields
    long_data = df[df['bfield'] == 'longitudinal'].copy()

    # Create pivot table for heatmap
    pivot = long_data.pivot_table(
        values='longitudinal_peaks',
        index='beta',
        columns='f',
        aggfunc='mean'
    )

    sns.heatmap(pivot, annot=True, fmt='.1f', cmap='RdYlGn',
                vmin=0, vmax=3, ax=axes[0], cbar_kws={'label': 'N_peaks'})
    axes[0].set_title('Longitudinal B-Field')
    axes[0].set_xlabel('Line mass fraction f')
    axes[0].set_ylabel('Plasma β')

    # Right: Perpendicular fields
    perp_data = df[df['bfield'] == 'perpendicular'].copy()

    pivot_perp = perp_data.pivot_table(
        values='longitudinal_peaks',
        index='beta',
        columns='f',
        aggfunc='mean'
    )

    sns.heatmap(pivot_perp, annot=True, fmt='.1f', cmap='RdYlGn',
                vmin=0, vmax=3, ax=axes[1], cbar_kws={'label': 'N_peaks'})
    axes[1].set_title('Perpendicular B-Field')
    axes[1].set_xlabel('Line mass fraction f')
    axes[1].set_ylabel('Plasma β')

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'fig1_beading_regime.pdf')
    plt.savefig(OUTPUT_DIR / 'fig1_beading_regime.png', dpi=300)
    plt.close()

def make_figure_2_lambda_W(df: pd.DataFrame):
    """Figure 2: λ/W comparison across field geometries."""

    fig, ax = plt.subplots(figsize=(8, 6))

    for bfield in ['longitudinal', 'perpendicular']:
        subset = df[(df['bfield'] == bfield) & (df['lambda_frag'].notna())]

        # Plot λ/W vs f
        for beta in [0.5, 1.0, 2.0]:
            beta_subset = subset[subset['beta'] == beta]

            if len(beta_subset) > 0:
                ax.scatter(beta_subset['f'], beta_subset['lambda_frag'],
                          label=f'{bfield}, β={beta}', alpha=0.7)

    # HGBS reference
    ax.axhline(y=2.1, color='red', linestyle='--', label='HGBS (λ/W=2.1)')

    ax.set_xlabel('Line mass fraction f')
    ax.set_ylabel('Fragmentation spacing λ/W_core')
    ax.set_title('Fragmentation Spacing Comparison')
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'fig2_lambda_W_comparison.pdf')
    plt.savefig(OUTPUT_DIR / 'fig2_lambda_W_comparison.png', dpi=300)
    plt.close()

def make_figure_3_power_law(df: pd.DataFrame):
    """Figure 3: Power-law comparison across EOS and profiles."""

    fig, ax = plt.subplots(figsize=(8, 6))

    colors = {'isothermal': 'blue', 'adiabatic': 'red'}
    markers = {'king': 'o', 'uniform': 's'}

    for eos in ['isothermal', 'adiabatic']:
        for profile in ['king', 'uniform']:
            subset = df[(df['eos'] == eos) & (df['profile'] == profile) & (df['t_frag'] > 0)]

            if len(subset) > 10:
                ax.scatter(subset['f'], subset['t_frag'],
                          c=colors[eos], marker=markers[profile],
                          label=f'{eos}, {profile}', alpha=0.6)

    # Power law fits
    f_fit = np.linspace(1.0, 3.0, 50)

    # Original fit
    t_fit_orig = f_fit ** (-0.39)  # Normalized
    ax.plot(f_fit, t_fit_orig, 'k--', label='f^(-0.39) (original)', alpha=0.5)

    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel('Line mass fraction f')
    ax.set_ylabel('Fragmentation time t_frag [t_J]')
    ax.set_title('Power-Law Scaling Comparison')
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'fig3_power_law_comparison.pdf')
    plt.savefig(OUTPUT_DIR / 'fig3_power_law_comparison.png', dpi=300)
    plt.close()

def make_figure_4_resolution_convergence(df: pd.DataFrame):
    """Figure 4: Resolution convergence comparison."""

    # This would require 128³ vs 256³ comparison data
    # For now, create placeholder
    fig, ax = plt.subplots(figsize=(8, 6))

    ax.text(0.5, 0.5, 'Resolution convergence figure\nrequires 128³ vs 256³ comparison',
            ha='center', va='center', fontsize=14)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'fig4_resolution_convergence.pdf')
    plt.close()

# =============================================================================
# REPORT GENERATION
# =============================================================================

def generate_summary_report(df: pd.DataFrame, analyses: Dict):
    """Generate comprehensive summary report."""

    report = []

    # Title
    report.append("# Filament Spacing MHD Campaign - Peer Review Response")
    report.append(f"Generated: {pd.Timestamp.now()}\n")

    # Executive Summary
    report.append("## Executive Summary\n")
    report.append(f"Total simulations completed: {len(df)}")

    frag_count = (df['status'] == 'FRAG').sum()
    beading_count = (df['longitudinal_peaks'] >= 2).sum()

    report.append(f"Fragmentation rate: {frag_count/len(df)*100:.1f}%")
    report.append(f"Longitudinal beading detected: {beading_count} simulations")
    report.append("")

    # Response to each concern
    report.append("## Peer Review Concern Responses\n")

    # T1 & T2: Negative result and fragmentation detection
    report.append("### T1/T2: Longitudinal Fragmentation Detection")
    report.append(f"Simulations with ≥2 longitudinal peaks: {beading_count}")

    beading_by_f = df[df['longitudinal_peaks'] >= 2].groupby('f').size()
    report.append("\nBy line-mass fraction:")
    for f, count in beading_by_f.items():
        report.append(f"  f={f}: {count} simulations with beading")

    report.append(f"\n**Key finding**: Beading emerges at f ≤ {df[df['longitudinal_peaks'] >= 2]['f'].max():.2f}")
    report.append("")

    # T3: Field geometry
    report.append("### T3: Realistic Field Geometry")
    perp_beading = df[df['bfield'] == 'perpendicular']['longitudinal_peaks'].mean()
    long_beading = df[df['bfield'] == 'longitudinal']['longitudinal_peaks'].mean()

    report.append(f"Mean longitudinal peaks (perpendicular B): {perp_beading:.2f}")
    report.append(f"Mean longitudinal peaks (longitudinal B): {long_beading:.2f}")
    report.append("")

    # T4: Regime boundaries
    report.append("### T4: Regime Boundaries")
    boundaries = analyses['regime_boundaries']
    report.append("Transition β values by f:")
    for _, row in boundaries.iterrows():
        report.append(f"  f={row['f']}: β_transition ≈ {row['beta_transition']:.2f}")
    report.append("")

    # T5: Power law
    report.append("### T5: Power-Law Exponent")
    power_law = analyses['power_law']
    for key, result in power_law.items():
        report.append(f"{key}: α = {result['exponent']:.3f} (R² = {result['r_squared']:.3f})")
    report.append("")

    # T8: Turbulence amplitude
    report.append("### T8: Turbulence Amplitude Effect")
    if 'turb_amp' in df.columns:
        real_turb = df[df['turb_amp'] == 'realistic']
        weak_turb = df[df['turb_amp'] != 'realistic']

        report.append(f"Realistic turbulence: {len(real_turb)} simulations")
        report.append(f"Weak turbulence: {len(weak_turb)} simulations")
        report.append("")

    # T10: Domain size
    report.append("### T10: Domain Size Effects")
    if 'Lx' in df.columns:
        domain_8 = df[df['Lx'] == 8]
        domain_12 = df[df['Lx'] == 12]

        report.append(f"Lx=8λJ: {len(domain_8)} simulations")
        report.append(f"Lx=12λJ: {len(domain_12)} simulations")

        if len(domain_8) > 0 and len(domain_12) > 0:
            report.append(f"\nPeak count comparison:")
            report.append(f"  Lx=8: {domain_8['longitudinal_peaks'].mean():.2f} peaks")
            report.append(f"  Lx=12: {domain_12['longitudinal_peaks'].mean():.2f} peaks")
    report.append("")

    # Save report
    report_text = "\n".join(report)

    with open(OUTPUT_DIR / "SUMMARY_REPORT.md", 'w') as f:
        f.write(report_text)

    return report_text

# =============================================================================
# MAIN
# =============================================================================

def main():
    """Run complete analysis pipeline."""

    print("Loading simulation results...")
    df = load_all_results()

    if len(df) == 0:
        print("No results found. Check that simulations have completed.")
        return

    print(f"Loaded {len(df)} simulation results")

    print("Enriching with parsed parameters...")
    df = enrich_dataframe(df)

    print("Running analyses...")
    analyses = {
        'near_critical': analyze_near_critical_regime(df),
        'perpendicular_fields': analyze_perpendicular_fields(df),
        'power_law': analyze_power_law(df),
        'regime_boundaries': analyze_regime_boundaries(df)
    }

    print("Generating figures...")
    make_figure_1_beading_regime(df)
    make_figure_2_lambda_W(df)
    make_figure_3_power_law(df)
    make_figure_4_resolution_convergence(df)

    print("Generating summary report...")
    report = generate_summary_report(df, analyses)

    print("\n" + "="*70)
    print("ANALYSIS COMPLETE")
    print("="*70)
    print(f"\nOutput directory: {OUTPUT_DIR}")
    print("Files generated:")
    print("  - SUMMARY_REPORT.md")
    print("  - fig1_beading_regime.pdf/png")
    print("  - fig2_lambda_W_comparison.pdf/png")
    print("  - fig3_power_law_comparison.pdf/png")
    print("  - fig4_resolution_convergence.pdf")

if __name__ == "__main__":
    main()
