#!/bin/bash
# Athena++ compilation script for peer review campaign
# Compiles with all required modules for filament simulations

set -e  # Exit on error

echo "======================================================================"
echo "Athena++ Compilation for Filament Spacing Peer Review Campaign"
echo "======================================================================"

# Configuration options
CONFIG_OPTIONS="--with-gas=hydro"
CONFIG_OPTIONS="$CONFIG_OPTIONS --with-mhd"
CONFIG_OPTIONS="$CONFIG_OPTIONS --with-self-gravity=fft"
CONFIG_OPTIONS="$CONFIG_OPTIONS --with-hdf5"
CONFIG_OPTIONS="$CONFIG_OPTIONS --with-mpi"

# Problem generator
CONFIG_OPTIONS="$CONFIG_OPTIONS --prob=filament_spacing_pr"

echo ""
echo "Configuration options:"
echo "  $CONFIG_OPTIONS"
echo ""

# Check for required modules
echo "Checking required tools..."

# MPI
if ! command -v mpicc &> /dev/null; then
    echo "ERROR: mpicc not found. Please install MPI."
    exit 1
fi
echo "  ✓ mpicc found"

# HDF5
if ! pkg-config --exists hdf5; then
    echo "ERROR: HDF5 development libraries not found."
    echo "Install with: apt-get install libhdf5-dev (Ubuntu/Debian)"
    exit 1
fi
echo "  ✓ HDF5 found"

# FFTW3 (for FFT gravity solver)
if ! pkg-config --exists fftw3; then
    echo "ERROR: FFTW3 not found."
    echo "Install with: apt-get install libfftw3-dev (Ubuntu/Debian)"
    exit 1
fi
echo "  ✓ FFTW3 found"

echo ""
echo "Configuring Athena++..."

# Configure
./configure $CONFIG_OPTIONS

echo ""
echo "Compiling Athena++..."

# Compile with 13 jobs (appropriate for typical configuration)
make -j 13

# Check if binary was created
if [ -f bin/athena ]; then
    echo ""
    echo "======================================================================"
    echo "SUCCESS: Athena++ binary compiled"
    echo "Location: bin/athena"
    echo ""
    echo "Creating symlink for campaign..."

    # Copy to campaign directory
    cp bin/athena athena_filament_peer_review

    echo "Created: athena_filament_peer_review"
    echo "======================================================================"

    # Test run
    echo ""
    echo "Running test compilation check..."
    ./athena_filament_peer_review --help 2>&1 | head -5

    echo ""
    echo "Athena++ is ready for the campaign!"
else
    echo ""
    echo "======================================================================"
    echo "ERROR: Compilation failed"
    echo "Check the output above for errors"
    echo "======================================================================"
    exit 1
fi
