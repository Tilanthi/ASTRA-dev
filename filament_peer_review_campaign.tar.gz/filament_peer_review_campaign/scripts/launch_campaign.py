#!/usr/bin/env python3
"""
Ray-based Athena++ filament simulation launcher
Peer Review Response Campaign - April 2026

Usage:
    python launch_campaign.py --tier 1
    python launch_campaign.py --priority 1
    python launch_campaign.py --sim nearcrit_f1.00_b0.3_M1_s1_king_iso

This script manages the parallel execution of Athena++ MHD simulations
using Ray for distributed computing on 220 CPU systems.
"""

import ray
import os
import subprocess
import json
import time
import argparse
from pathlib import Path
from typing import Dict, List, Optional
import signal

# =============================================================================
# CONFIGURATION
# =============================================================================

# Ray settings
RAY_NUM_CPUS = 208  # 13 sims × 16 MPI ranks, leaving 12 CPUs overhead
MAX_CONCURRENT = 13
MPI_RANKS_PER_SIM = 16

# Simulation settings
TIMEOUT_SECONDS = 7200  # 2 hours per simulation
WATCHDOG_POLL_INTERVAL = 15  # seconds

# Athena++ binary
ATHENA_BIN = "./athena_filament_peer_review"

# Directory structure
BASE_DIR = Path.cwd()
RUNS_DIR = BASE_DIR / "runs"
STATUS_DIR = BASE_DIR / "status"
HDF5_DIR = BASE_DIR / "hdf5_output"

# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def setup_directories():
    """Create required directory structure."""
    RUNS_DIR.mkdir(exist_ok=True)
    STATUS_DIR.mkdir(exist_ok=True)
    HDF5_DIR.mkdir(exist_ok=True)

def load_simulation_manifest() -> List[Dict]:
    """Load simulation configuration from manifest file."""
    manifest_file = BASE_DIR / "config" / "simulation_manifest.json"
    with open(manifest_file) as f:
        return json.load(f)

def get_sim_dir(sim_config: Dict) -> Path:
    """Generate simulation directory name from configuration."""
    campaign = sim_config.get("campaign", "unknown")

    if "bfield" in sim_config:
        bfield = sim_config["bfield"]
        sim_dir = RUNS_DIR / f"{bfield}_{sim_config['sim_id']}"
    else:
        sim_dir = RUNS_DIR / sim_config['sim_id']

    return sim_dir

def generate_athena_input(sim_config: Dict, sim_dir: Path):
    """Generate Athena++ input file from simulation configuration."""

    # Map configuration to Athena++ parameters
    f = sim_config['f']
    beta = sim_config['beta']
    mach = sim_config['mach']
    seed = sim_config['seed']

    # Calculate derived parameters
    if f == 1.00:
        rho_0 = 1.0  # Critical density
    else:
        rho_0 = f  # Supercritical: scale density

    # Magnetic field strength from plasma beta
    # beta = 2*c_s^2*rho_0 / B_0^2, with c_s = 1
    B_0 = (2 * rho_0 / beta) ** 0.5

    # Turbulence amplitude
    if sim_config.get("turb_amp") == "realistic":
        turb_amplitude = mach * 1.0e-1  # Realistic: 10% of sound speed
    else:
        turb_amplitude = mach * 1.0e-4  # Original weak seeding

    # Domain size
    Lx = sim_config.get("Lx", 8)  # Default 8 lambda_J
    Ly, Lz = 2.0, 2.0

    # Boundary conditions
    if sim_config.get("bc_x1") == "outflow":
        bc_x1 = "outflow"
    else:
        bc_x1 = "periodic"
    bc_x2 = "periodic"
    bc_x3 = "periodic"

    # EOS
    if sim_config.get("eos") == "adiabatic":
        gamma = 1.67  # 5/3 for monatomic gas
    else:
        gamma = 1.001  # Approximately isothermal

    # Field geometry
    if sim_config.get("bfield") == "perpendicular":
        Bx_0, By_0, Bz_0 = 0.0, B_0, 0.0
    elif sim_config.get("bfield") == "oblique":
        theta_deg = sim_config.get("theta_deg", 45)
        theta_rad = theta_deg * 3.14159 / 180.0
        Bx_0 = B_0 * np.cos(theta_rad)
        By_0 = B_0 * np.sin(theta_rad)
        Bz_0 = 0.0
    else:  # longitudinal (default)
        Bx_0, By_0, Bz_0 = B_0, 0.0, 0.0

    # Density profile
    if sim_config.get("profile") == "uniform":
        density_profile = "uniform"
    else:  # King profile (default)
        density_profile = "king"

    input_content = f"""<job>
================================================================================
Athena++ Filament Simulation - Peer Review Response Campaign
Simulation: {sim_config['sim_id']}
================================================================================

<time>
tcfl = 0.3
nlim = -1
restart = 0
tlim = {TIMEOUT_SECONDS / 100.0}  # Safety limit
output_dt = 0.05  # HDF5 output every 0.05 t_J
dt = 1.0e-4
<nb>
dust = 0
fargo = 0
  <cfl>
cfl_fluid = 0.3
cfl_number = 1.0e-8  # Fragmentation detection threshold
  </cfl>
<integrator>
integrator = vl2
third_order = true
ltt_correct = false
xorder = 2
    <mesh>
nx1 = {256 * (Lx // 8)}
nx2 = 64
nx3 = 64
fblock = 32
x1min = 0.0
x1max = {Lx}
x2min = -1.0
x2max = 1.0
x3min = -1.0
x3max = 1.0
    <meshblock>
     <boundary>
ix1_bc = {bc_x1}
ox1_bc = {bc_x1}
ix2_bc = {bc_x2}
ox2_bc = {bc_x2}
ix3_bc = {bc_x3}
ox3_bc = {bc_x3}
    <hydro>
iso_sound_speed = 1.0
gamma = {gamma}
    <mhd>
    <gravity>
gravity = fft
grav_mean_rho = {rho_0}
four_pi_G = 39.47841760435743  # 4*pi^2
    <problem>
problem = filament_spacing_pr
{f}  # Line mass fraction
rho0 = {rho_0}
rc = 0.3  # Core radius in units of lambda_J
Bx0 = {Bx_0}
By0 = {By_0}
Bz0 = {Bz_0}
mach_number = {mach}
seed = {seed}
turb_amplitude = {turb_amplitude}
density_profile = {density_profile}
    <output>
output = hdf5
dt = {TIMEOUT_SECONDS / 100.0}
variables = all
file_type = single
       hdf5
    <output>
output = rst
dt = {TIMEOUT_SECONDS / 20.0}
file_type = master
        rst>
"""

    input_file = sim_dir / "athena_input"
    with open(input_file, 'w') as f:
        f.write(input_content)

    return input_file

# =============================================================================
# SIMULATION EXECUTION
# =============================================================================

@ray.remote(num_cpus=MPI_RANKS_PER_SIM)
def run_simulation(sim_config: Dict, sim_dir: Path):
    """
    Execute a single Athena++ simulation with watchdog monitoring.

    Returns:
        dict: Simulation status and results
    """
    import numpy as np

    sim_id = sim_config['sim_id']
    status_file = STATUS_DIR / f"{sim_id}.json"

    # Check if already completed
    if status_file.exists():
        with open(status_file) as f:
            return json.load(f)

    print(f"[{sim_id}] Starting simulation...")

    # Generate input file
    input_file = generate_athena_input(sim_config, sim_dir)
    sim_dir.mkdir(exist_ok=True)

    # Prepare MPI command
    mpi_cmd = [
        "mpirun",
        "-np", str(MPI_RANKS_PER_SIM),
        str(ATHENA_BIN),
        "-i", str(input_file),
        "-d", str(sim_dir)
    ]

    # Launch simulation
    proc = subprocess.Popen(
        mpi_cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=sim_dir
    )

    # Watchdog monitoring
    start_time = time.time()
    last_dt = 1.0
    t_frag = None
    rho_c_max = 0.0
    status = "RUNNING"

    try:
        while True:
            # Check timeout
            elapsed = time.time() - start_time
            if elapsed > TIMEOUT_SECONDS:
                proc.terminate()
                status = "TIMEOUT"
                break

            # Check if process completed
            if proc.poll() is not None:
                if proc.returncode == 0:
                    status = "COMPLETED"
                else:
                    status = "ERROR"
                break

            # Watchdog: monitor HST file for timestep and density
            hst_file = sim_dir / "*.hst"
            if hst_file.exists():
                try:
                    import re
                    with open(hst_file) as f:
                        lines = f.readlines()
                    if len(lines) > 1:
                        # Parse last data line
                        last_line = lines[-1].split()
                        if len(last_line) > 3:
                            try:
                                current_dt = float(last_line[3])  # Column 4 is dt
                                current_time = float(last_line[0])  # Column 1 is time
                                rho_c = float(last_line[1])  # Column 2 is max density

                                rho_c_max = max(rho_c_max, rho_c)

                                # Fragmentation detection: dt < 1e-8
                                if current_dt < 1.0e-8:
                                    t_frag = current_time
                                    status = "FRAG"
                                    proc.terminate()
                                    break

                                last_dt = current_dt
                            except (ValueError, IndexError):
                                pass
                except:
                    pass

            # Sleep before next check
            time.sleep(WATCHDOG_POLL_INTERVAL)

    except Exception as e:
        status = f"EXCEPTION: {str(e)}"
        proc.terminate()

    # Wait for process to finish
    try:
        proc.wait(timeout=30)
    except:
        proc.kill()

    elapsed = time.time() - start_time

    # Post-process HDF5 outputs for longitudinal peaks
    longitudinal_peaks = 0
    lambda_frag = None
    frag_quality = "none"

    hdf5_files = sorted(sim_dir.glob("*.athdf"))
    if len(hdf5_files) > 0:
        try:
            import h5py
            last_hdf5 = h5py.File(hdf5_files[-1], 'r')
            rho = last_hdf5['density'][:]

            # Analyze longitudinal density profile
            # Extract spine density (middle of y-z plane)
            ny, nz = rho.shape[1], rho.shape[2]
            spine_rho = rho[:, ny//2, nz//2]

            # Simple peak detection
            from scipy import signal
            peaks, properties = signal.find_peaks(spine_rho, height=np.mean(spine_rho) * 1.1)
            longitudinal_peaks = len(peaks)

            if longitudinal_peaks >= 2:
                # Measure spacing
                peak_positions = peaks
                spacings = np.diff(peak_positions)
                if len(spacings) > 0:
                    lambda_frag = float(np.mean(spacings))
                    frag_quality = "excellent" if longitudinal_peaks >= 3 else "good"
                    if longitudinal_peaks == 2:
                        frag_quality = "marginal"
        except Exception as e:
            pass

    # Compile results
    result = {
        "sim_id": sim_id,
        "status": status,
        "t_frag": t_frag if t_frag else 0.0,
        "dt_min": last_dt,
        "rho_c_max": rho_c_max,
        "wall_time_seconds": elapsed,
        "longitudinal_peaks": longitudinal_peaks,
        "lambda_frag": lambda_frag,
        "fragmentation_quality": frag_quality,
        "hdf5_outputs": len(hdf5_files)
    }

    # Save status
    with open(status_file, 'w') as f:
        json.dump(result, f, indent=2)

    print(f"[{sim_id}] Completed: {status} (t_frag={t_frag}, peaks={longitudinal_peaks})")

    return result

# =============================================================================
# CAMPAIGN MANAGEMENT
# =============================================================================

def run_tier(tier: int, manifest: List[Dict]):
    """Run all simulations of a given priority tier."""
    tier_sims = [s for s in manifest if s.get('priority', 999) == tier]

    print(f"\n{'='*70}")
    print(f"TIER {tier}: {len(tier_sims)} simulations")
    print(f"{'='*70}\n")

    if not tier_sims:
        print(f"No simulations found for tier {tier}")
        return []

    return run_batch(tier_sims)

def run_batch(sim_list: List[Dict]):
    """Run a batch of simulations in parallel."""

    # Initialize Ray
    ray.init(num_cpus=RAY_NUM_CPUS, ignore_reinit_error=True)

    print(f"Ray initialized: {RAY_NUM_CPUS} CPUs available")
    print(f"Max concurrent simulations: {MAX_CONCURRENT}")
    print(f"MPI ranks per simulation: {MPI_RANKS_PER_SIM}\n")

    results = []
    completed = 0
    total = len(sim_list)

    # Process in batches
    for i in range(0, total, MAX_CONCURRENT):
        batch = sim_list[i:i+MAX_CONCURRENT]

        print(f"\n--- Batch {i//MAX_CONCURRENT + 1}/{(total + MAX_CONCURRENT - 1)//MAX_CONCURRENT} ---")
        print(f"Simulations: {[s['sim_id'] for s in batch]}\n")

        # Generate simulation directories and input files
        futures = []
        for sim_config in batch:
            sim_dir = get_sim_dir(sim_config)
            future = run_simulation.remote(sim_config, sim_dir)
            futures.append(future)

        # Wait for batch completion
        batch_results = ray.get(futures)
        results.extend(batch_results)
        completed += len(batch)

        print(f"\nProgress: {completed}/{total} simulations completed\n")

    # Shutdown Ray
    ray.shutdown()

    return results

# =============================================================================
# MAIN ENTRY POINT
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description="Launch Athena++ filament campaign")
    parser.add_argument('--tier', type=int, help='Run specific priority tier (1-4)')
    parser.add_argument('--priority', type=int, help='Alias for --tier')
    parser.add_argument('--sim', type=str, help='Run specific simulation by ID')
    parser.add_argument('--list', action='store_true', help='List all simulations')
    parser.add_argument('--all', action='store_true', help='Run all simulations')

    args = parser.parse_args()

    # Setup
    setup_directories()
    manifest = load_simulation_manifest()

    if args.list:
        print("\nSimulation Manifest:")
        print("-" * 80)
        for sim in manifest:
            print(f"{sim['sim_id']:50s} | Priority: {sim.get('priority', 999)}")
        return

    if args.sim:
        # Run single simulation
        sim_config = next((s for s in manifest if s['sim_id'] == args.sim), None)
        if sim_config:
            print(f"Running single simulation: {args.sim}")
            ray.init(num_cpus=MPI_RANKS_PER_SIM)
            sim_dir = get_sim_dir(sim_config)
            result = ray.get(run_simulation.remote(sim_config, sim_dir))
            ray.shutdown()
            print(f"\nResult: {json.dumps(result, indent=2)}")
        else:
            print(f"Simulation {args.sim} not found in manifest")
        return

    if args.tier or args.priority:
        tier = args.tier or args.priority
        print(f"Running Tier {tier} simulations...")
        results = run_tier(tier, manifest)

    elif args.all:
        print("Running all simulations by priority tier...")
        all_results = []
        for tier in range(1, 5):
            tier_results = run_tier(tier, manifest)
            all_results.extend(tier_results)

        # Save summary
        summary_file = BASE_DIR / "campaign_summary.json"
        with open(summary_file, 'w') as f:
            json.dump(all_results, f, indent=2)
        print(f"\nCampaign summary saved to {summary_file}")

    else:
        parser.print_help()

if __name__ == "__main__":
    main()
