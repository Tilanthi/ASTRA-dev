#!/bin/bash
# Master launch script for peer review campaign
# This script manages the complete campaign execution

set -e

echo "======================================================================"
echo "Filament Spacing Peer Review Response Campaign"
echo "Master Launch Script"
echo "======================================================================"

# Check prerequisites
echo "Checking prerequisites..."

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "ERROR: python3 not found"
    exit 1
fi

# Check required Python packages
python3 -c "import ray, numpy, pandas, matplotlib, h5py" 2>/dev/null || {
    echo "ERROR: Missing required Python packages"
    echo "Install with: pip install ray numpy pandas matplotlib seaborn scipy h5py"
    exit 1
}

# Check Ray availability
python3 -c "import ray; ray.init(num_cpus=208, ignore_reinit_error=True); ray.shutdown()" || {
    echo "ERROR: Ray cannot initialize with 208 CPUs"
    echo "Check: ray start --head"
    exit 1
}

echo "✓ Prerequisites satisfied"
echo ""

# Check Athena++ binary
if [ ! -f "./athena_filament_peer_review" ]; then
    echo "WARNING: athena_filament_peer_review not found"
    echo ""
    echo "Would you like to compile Athena++ now? (y/n)"
    read -r response
    if [[ $response =~ ^[Yy]$ ]]; then
        bash scripts/compile_athena.sh
    else
        echo "Cannot proceed without Athena++ binary"
        exit 1
    fi
fi

echo "✓ Athena++ binary found"
echo ""

# Check configuration
if [ ! -f "config/simulation_manifest.json" ]; then
    echo "ERROR: simulation_manifest.json not found"
    exit 1
fi

echo "✓ Configuration found"
echo ""

# Show campaign summary
echo "Campaign Summary:"
echo "------------------"
python3 << 'EOF'
import json
with open('config/simulation_manifest.json') as f:
    manifest = json.load(f)

by_priority = {}
for sim in manifest:
    p = sim.get('priority', 999)
    by_priority[p] = by_priority.get(p, 0) + 1

print(f"Total simulations: {len(manifest)}")
for p in sorted(by_priority.keys()):
    print(f"  Tier {p}: {by_priority[p]} simulations")

# Field geometry breakdown
bfield_count = {}
for sim in manifest:
    b = sim.get('bfield', 'longitudinal')
    bfield_count[b] = bfield_count.get(b, 0) + 1

print(f"\nBy field geometry:")
for b, count in bfield_count.items():
    print(f"  {b}: {count} simulations")

# EOS breakdown
eos_count = {}
for sim in manifest:
    e = sim.get('eos', 'isothermal')
    eos_count[e] = eos_count.get(e, 0) + 1

print(f"\nBy equation of state:")
for e, count in eos_count.items():
    print(f"  {e}: {count} simulations")
EOF

echo ""
echo "======================================================================"

# Ask what to run
echo ""
echo "Select execution mode:"
echo "  1) Tier 1 only (Essential - 180 sims, ~8 hours)"
echo "  2) Tier 1 + 2 (High Priority - 366 sims, ~16 hours)"
echo "  3) Tier 1 + 2 + 3 (All priority - 522 sims, ~24 hours)"
echo "  4) Full campaign (All tiers - 624 sims, ~30-50 hours)"
echo "  5) Single simulation (for testing)"
echo "  6) Analysis only (skip simulation)"
echo "  q) Quit"
echo ""
read -p "Enter choice [1-6 or q]: " choice

case $choice in
    1)
        echo "Launching Tier 1 (Essential)..."
        python3 scripts/launch_campaign.py --tier 1
        ;;
    2)
        echo "Launching Tiers 1 + 2 (High Priority)..."
        python3 scripts/launch_campaign.py --tier 1
        python3 scripts/launch_campaign.py --tier 2
        ;;
    3)
        echo "Launching Tiers 1 + 2 + 3 (All Priority)..."
        python3 scripts/launch_campaign.py --tier 1
        python3 scripts/launch_campaign.py --tier 2
        python3 scripts/launch_campaign.py --tier 3
        ;;
    4)
        echo "Launching Full Campaign (All Tiers)..."
        python3 scripts/launch_campaign.py --all
        ;;
    5)
        echo "Enter simulation ID:"
        read sim_id
        python3 scripts/launch_campaign.py --sim "$sim_id"
        ;;
    6)
        echo "Running analysis only..."
        python3 scripts/analyze_campaign.py
        ;;
    q|Q)
        echo "Exiting"
        exit 0
        ;;
    *)
        echo "Invalid choice"
        exit 1
        ;;
esac

echo ""
echo "======================================================================"
echo "Campaign execution complete!"
echo ""
echo "Next steps:"
echo "  1. Check results: ls status/*.json | wc -l"
echo "  2. Generate analysis: python3 scripts/analyze_campaign.py"
echo "  3. Review outputs: ls analysis_output/"
echo "  4. Return to paper integration (see docs/DATA_RETURN_SPEC.md)"
echo "======================================================================"
