# FILAMENT SPACING PEER REVIEW CAMPAIGN
# Complete Package Contents

## QUICK NAVIGATION

- **START HERE**: `QUICKSTART.md` - Essential reading before running anything
- **FULL DOCUMENTATION**: `docs/README.md` - Complete campaign specification
- **DATA RETURN SPEC**: `docs/DATA_RETURN_SPEC.md` - What data is needed for paper integration
- **RUN**: `run_campaign.sh` - Master launch script (or use `scripts/launch_campaign.py`)

## PACKAGE STRUCTURE

```
filament_peer_review_campaign/
├── README.html (this file)
├── QUICKSTART.md
├── run_campaign.sh                    # Master launch script
│
├── config/
│   ├── campaign_specification.json    # Campaign metadata and objectives
│   └── simulation_manifest.json       # Complete simulation parameter list
│
├── scripts/
│   ├── launch_campaign.py             # Ray-based parallel execution
│   ├── analyze_campaign.py            # Analysis and figure generation
│   └── compile_athena.sh              # Athena++ compilation script
│
├── docs/
│   ├── README.md                       # Complete documentation
│   ├── QUICKSTART.md                   # Quick start guide
│   └── DATA_RETURN_SPEC.md            # Required outputs for paper integration
│
└── templates/
    ├── athena_input_template.dat      # Athena++ input file template
    └── filamen_spacing_pr.cpp         # Problem generator source code
```

## EXECUTION FLOW

1. **PREPARATION** (First time only):
   ```bash
   # Extract package
   tar -xzf filament_peer_review_campaign.tar.gz
   cd filament_peer_review_campaign

   # Compile Athena++
   bash scripts/compile_athena.sh
   ```

2. **EXECUTION** (Choose mode):
   ```bash
   # Interactive mode (recommended)
   bash run_campaign.sh

   # Direct Python
   python3 scripts/launch_campaign.py --tier 1      # Essential only
   python3 scripts/launch_campaign.py --tier 1-2    # High priority
   python3 scripts/launch_campaign.py --all        # Full campaign
   ```

3. **ANALYSIS** (After simulations complete):
   ```bash
   python3 scripts/analyze_campaign.py
   ```

4. **INTEGRATION** (Return to paper):
   - Copy `analysis_output/*` to paper figures directory
   - Review `analysis_output/SUMMARY_REPORT.md`
   - Update paper with new evidence

## CAMPAIGN SPECIFICATIONS

### Simulation Count by Tier
- **Tier 1 (Essential)**: 180 simulations - Address T1, T2, T3, T5
- **Tier 2 (High Priority)**: 186 simulations - Address T7, T8, T9
- **Tier 3 (Important)**: 258 simulations - Address T4, T10
- **Total**: 624 simulations

### Computational Requirements
- **CPUs**: 208 (13 concurrent × 16 MPI ranks)
- **RAM**: ~2 GB per simulation (16 MPI ranks)
- **Disk**: ~500 GB for HDF5 outputs
- **Time**: 8-50 hours depending on tier selection

### Key Parameters

| Parameter | Values | Purpose |
|-----------|--------|---------|
| Line mass (f) | 1.00, 1.05, 1.10, 1.15, 1.20, 1.5, 2.0, 2.5, 3.0 | Near-critical to supercritical |
| Plasma β | 0.3, 0.5, 0.7, 1.0, 1.5, 2.0 | Strong to weak magnetic field |
| Mach (M) | 0.5, 1.0, 2.0 | Subsonic to supersonic turbulence |
| Seeds | 1, 2, 3 | Random seed variations |
| EOS | isothermal, adiabatic | Test EOS dependence |
| B-field | longitudinal, perpendicular, oblique | Test realistic geometries |
| Profile | King, uniform | Test IC dependence |

## PEER REVIEW CONCERNS ADDRESSED

| **Concern** | **Remedy** | **Tier** | **Sims** |
|-------------|------------|----------|---------|
| **T1**: Negative result under-analyzed | Near-critical simulations (f≤1.20) | 1 | 180 |
| **T2**: Fragmentation detection criterion | Peak detection from HDF5 | 1 | Built-in |
| **T3**: Longitudinal B unrealistic | Perpendicular field campaign | 1 | 96 |
| **T4**: Regime boundaries lack theory | Boundary analysis | 3 | 0 |
| **T5**: Power-law unexplained | EOS/profile variations | 1 | 144 |
| **T6**: DTC unexplained | Documentation only | N/A | 0 |
| **T7**: Resolution incomplete | Extended 256³ runtime | 2 | 12 |
| **T8**: Turbulence too weak | Realistic amplitudes | 2 | 54 |
| **T9**: Calibration inadequate | Oblique field calibration | 2 | 90 |
| **T10**: Domain BC issues | Larger domain, outflow BC | 3 | 48 |

## OUTPUT REQUIREMENTS

After campaign completion, the following are required for paper integration:

### Critical Deliverables

1. **simulation_catalog.csv** - Master catalog of all 624 simulations
2. **fig1_beading_regime.pdf** - Where longitudinal beading emerges
3. **fig2_lambda_W_comparison.pdf** - Field geometry comparison
4. **fig3_power_law_comparison.pdf** - EOS/profile validation
5. **fig4_resolution_convergence.pdf** - 128³ vs 256³ comparison
6. **SUMMARY_REPORT.md** - Response to each concern with evidence

### Analysis Products

For each simulation:
- Status (FRAG/STABLE/TIMEOUT)
- Fragmentation time (t_frag)
- Number of longitudinal peaks (n_peaks)
- Fragmentation spacing (λ_frag) if applicable
- Quality metric (excellent/good/marginal/none)

### Success Criteria

Campaign is successful if:
1. At least one regime shows ≥2 longitudinal peaks
2. Perpendicular fields produce measurable λ/W
3. Power-law exponent validated across conditions
4. Resolution convergence demonstrated

## TROUBLESHOOTING

**Ray initialization fails**:
```bash
ray stop
ray start --head
```

**Simulations timeout frequently**:
```bash
# Increase TIMEOUT_SECONDS in scripts/launch_campaign.py
# From 7200 to 14400 (4 hours)
```

**Memory issues**:
```bash
# Reduce concurrency in scripts/launch_campaign.py
# MAX_CONCURRENT = 13 → MAX_CONCURRENT = 8
```

**Athena++ compilation fails**:
- Check HDF5, FFTW3, MPI are installed
- Verify problem generator is in src/prob/
- Review compile_athena.sh output for errors

## INTEGRATION WITH PAPER

After successful campaign completion:

1. **Copy analysis outputs**:
   ```bash
   cp analysis_output/fig*.pdf /path/to/paper/figures/
   cp analysis_output/SUMMARY_REPORT.md /path/to/paper/
   ```

2. **Update paper sections**:
   - Abstract: Mention new simulations addressing concerns
   - Section 4: Add near-critical and perpendicular field results
   - Section 5: Update discussion with new evidence
   - Conclusions: Revise with new findings

3. **Generate response to reviewer**:
   - Document how each concern was addressed
   - Cite specific simulations showing beading
   - Include figures demonstrating perpendicular field fragmentation

## SUPPORT

For technical issues:
1. Check docs/README.md for detailed documentation
2. Review docs/QUICKSTART.md for common problems
3. Examine logs in status/ directory for simulation details

For scientific questions:
- Consult campaign_specification.json for scientific rationale
- Review peer review concerns in docs/README.md
- Refer to original filament_spacing paper for context

## VERSION HISTORY

- **v1.0** (2026-04-22): Initial campaign specification
  - Addresses all 10 peer review concerns
  - 624 simulations across 3 priority tiers
  - Estimated 30-50 hours wall time

---

**Campaign prepared by**: ASTRA autonomous system
**Date**: 22 April 2026
**Purpose**: Peer review response for MNRAS filament spacing paper
