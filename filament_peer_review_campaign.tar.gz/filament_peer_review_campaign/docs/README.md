# Filament Spacing MHD Campaign
# Addressing Peer Review Concerns - April 2026

## Campaign Overview

This campaign of 400 new Athena++ MHD simulations is designed to address the 10 major concerns raised by the peer reviewer regarding the filament spacing paper. The campaign is organized into three phases with specific scientific objectives.

## Phase 1: Near-Critical & Adiabatic Campaign (Primary Priority)

**Objective**: Address T1 (negative result) and T5 (power-law exponent) by testing conditions where longitudinal fragmentation should occur before radial collapse.

**Parameter space**:
- f = 1.00, 1.05, 1.10, 1.15, 1.20 (near-critical to marginally supercritical)
- β = 0.3, 0.5, 0.7, 1.0, 1.5, 2.0
- M = 1.0, 2.0
- Seeds = {1, 2, 3}
- EOS = isothermal, adiabatic (γ = 1.67, 5/3 for monatomic)
- Density profiles = King, uniform

**Key tests**:
1. At what f does longitudinal beading emerge before radial collapse?
2. Does the power-law exponent change for adiabatic EOS?
3. How does initial density profile affect the threshold?

**Total simulations**: 720 (comprehensive near-critical grid)

## Phase 2: Perpendicular Field Campaign (Primary Priority)

**Objective**: Address T3 (unrealistic field geometry) and T9 (calibration) by testing the magnetic geometry that applies to 90% of HGBS filaments.

**Parameter space**:
- f = 1.5, 2.0, 2.5, 3.0
- β = 0.3, 0.5, 0.7, 1.0, 1.5, 2.0
- M = 1.0, 2.0
- Seeds = {1, 2}
- B_field = perpendicular (θ = 90° to filament axis)

**Key tests**:
1. Does perpendicular B suppress radial collapse and allow longitudinal beading?
2. What is the fragmentation spacing for perpendicular fields?
3. Does λ/W match HGBS observations better for perpendicular fields?

**Total simulations**: 96

## Phase 3: Oblique Field & Extended Campaigns (Secondary Priority)

**Objective**: Address remaining concerns with targeted simulations.

### 3a. Oblique Field Calibration (T9)
- θ = 30°, 45°, 60°
- f = 1.5, 2.0, 2.5
- β = 0.5, 1.0, 2.0
- M = 1.0
- Seeds = {1, 2}
**Total**: 90

### 3b. Realistic Turbulence (T8)
- Realistic turbulent amplitudes: δv = M × cs (not × 10⁻⁴)
- f = 1.5, 2.0, 2.5
- β = 0.5, 1.0, 2.0
- M = 0.5, 1.0, 2.0
- Seeds = {1, 2}
**Total**: 54

### 3c. Domain Size Test (T10)
- Lx = 12, 16 λJ (vs 8 baseline)
- f = 2.0
- β = 0.5, 1.0, 2.0
- M = 1.0
- Seeds = {1, 2}
**Total**: 36

### 3d. Boundary Condition Test (T10)
- Outflow BC on x1 (periodic on x2, x3)
- f = 2.0
- β = 0.5, 1.0, 2.0
- M = 1.0
- Seeds = {1, 2}
**Total**: 12

## Computational Requirements

**Total simulations**: 1008

**Resource allocation**:
- Platform: 220 CPU system (AMD EPYC 7B13 recommended)
- Ray parallelism: 13 concurrent simulations × 16 MPI ranks = 208 CPUs
- Per-simulation wall time: 2-4 hours (adiabatic runs longer)
- Estimated total wall time: 200-400 hours
- Timeout setting: 7200 seconds (2 hours) per simulation

**Ray configuration**:
```python
ray.init(num_cpus=208)
max_concurrent = 13
mpi_ranks_per_sim = 16
```

## Success Criteria

The campaign will be considered successful if it demonstrates:

1. **Longitudinal beading emergence**: At least one simulation regime shows clear longitudinal fragmentation structure (λ/W directly measurable)

2. **Perpendicular field fragmentation**: Direct measurement of λ/W for perpendicular B-fields showing whether this matches HGBS observations better

3. **Power-law validation**: Confirmation that the f^(-0.39) scaling holds across different EOS and initial conditions, or identification of systematic variations

4. **Resolution convergence**: 256³ simulations reaching fragmentation with extended timeout

5. **Realistic turbulence effect**: Demonstration of whether realistic turbulent amplitudes change the fragmentation dynamics

## Output Requirements

Each simulation must produce:

1. **HDF5 snapshots**: Minimum 10 snapshots at Δt = 0.05 tJ
   - Must capture the transition from uniform to beaded structure
   - Snapshots at: t = 0, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50 tJ

2. **Status file**: JSON file with:
   ```json
   {
     "sim_id": "filament_f1.05_b0.5_M1_s1_king_adiabatic",
     "status": "FRAG" | "STABLE" | "TIMEOUT",
     "t_frag": 0.35,
     "dt_min": 1.2e-8,
     "rho_c_max": 245.3,
     "longitudinal_peaks": 3,
     "lambda_frag_measured": 1.23,
     "fragmentation_quality": "excellent" | "good" | "marginal" | "none"
   }
   ```

3. **Peak detection analysis**: Automated measurement of:
   - Number of density peaks along filament axis
   - Peak-to-peak spacing (λ_frag)
   - Amplitude of longitudinal density contrast
   - Quality metric (σ(ρ_x1)/⟨ρ_x1⟩)

## Data Return Format

For integration into the MNRAS paper, the following data products are required:

1. **Complete simulation catalog**: CSV file listing all 1008 simulations with:
   - Simulation ID
   - All parameters (f, β, M, seed, EOS, profile, B-geometry, etc.)
   - Status (FRAG/STABLE/TIMEOUT)
   - t_frag
   - Longitudinal peaks detected (yes/no)
   - λ_frag (if measured)
   - Fragmentation quality metric

2. **Analysis scripts**: Python scripts for:
   - Automated peak detection from HDF5 files
   - λ_frag measurement with uncertainty estimates
   - Power-law fitting across parameter space
   - Comparison with HGBS observations

3. **Key figures**: PDF/PNG figures showing:
   - Regime map showing where longitudinal beading emerges
   - λ/W vs f, β for perpendicular fields
   - Power-law comparison across EOS and initial conditions
   - Resolution convergence comparison
   - Realistic vs weak turbulence comparison

4. **Summary report**: Markdown report addressing each peer review concern with specific simulation evidence

## Priority Ranking

If computational resources are limited, execute in this order:

**Tier 1 (Essential)**:
- Phase 1: f ≤ 1.15, isothermal, King profile (180 sims)
- Phase 2: Full perpendicular field grid (96 sims)

**Tier 2 (High Priority)**:
- Phase 1: f = 1.20, adiabatic runs (144 sims)
- Phase 3a: Oblique field calibration (90 sims)

**Tier 3 (Important)**:
- Phase 3b: Realistic turbulence (54 sims)
- Phase 3c: Domain size test (36 sims)

**Tier 4 (Optional)**:
- Phase 3d: Boundary conditions (12 sims)
- Extended near-critical grid (remaining 432 sims)

## Notes

- All simulations use Athena++ with isothermal/adiabatic MHD + FFT self-gravity
- Resolution: 256³ (or 128³ for faster exploration)
- Domain: 8 × 2 × 2 λJ baseline (12 × 2 × 2 for domain tests)
- Boundary conditions: Periodic all faces (except BC tests)
- Fragmentation detection: CFL watchdog (Δt < 10⁻⁸) + longitudinal peak detection
- Timeout: 7200 seconds (2 hours) per simulation
- HDF5 output: Every 0.05 tJ until fragmentation
