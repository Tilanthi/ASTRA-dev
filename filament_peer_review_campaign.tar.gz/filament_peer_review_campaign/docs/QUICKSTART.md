# Peer Review Campaign - Quick Start Guide

## 1. Setup (First Time Only)

```bash
# Extract the campaign package
tar -xzf filament_peer_review_campaign.tar.gz
cd filament_peer_review_campaign

# Verify directory structure
ls -la
# Should see: config/ docs/ scripts/ templates/

# Make scripts executable
chmod +x scripts/*.py
```

## 2. System Requirements

- 220 CPU system (AMD EPYC 7B13 recommended)
- Ray 2.55.0+ installed
- MPI (mpirun) available
- Athena++ compiled with required modules
- ~500 GB disk space for outputs
- Python 3.8+ with: numpy, pandas, matplotlib, seaborn, scipy, h5py, ray

## 3. Quick Start (Tier 1 - Essential)

```bash
# Run Tier 1 simulations (180 simulations)
# These address the most critical peer review concerns
python scripts/launch_campaign.py --tier 1

# Monitor progress in another terminal
watch -n 30 'ls status/*.json | wc -l'
```

**Expected runtime**: 6-10 hours for Tier 1

## 4. Check Progress

```bash
# View completed simulations
ls status/*.json | wc -l

# Check status of specific simulation
cat status/nearcrit_f1.00_b0.3_M1_s1_king_iso.json | jq '.status, .t_frag, .longitudinal_peaks'

# Generate intermediate analysis
python scripts/analyze_campaign.py
```

## 5. Full Campaign (All Tiers)

```bash
# Run all simulations in priority order
python scripts/launch_campaign.py --all
```

**Expected runtime**: 30-50 hours for full campaign

## 6. Post-Processing

After simulations complete:

```bash
# Generate all figures and analysis
python scripts/analyze_campaign.py

# Results will be in analysis_output/
# - SUMMARY_REPORT.md
# - fig1_beading_regime.pdf/png
# - fig2_lambda_W_comparison.pdf/png
# - fig3_power_law_comparison.pdf/png
# - fig4_resolution_convergence.pdf
```

## 7. Return to Paper

To integrate results into the MNRAS paper:

1. **Copy analysis outputs**:
   - `analysis_output/SUMMARY_REPORT.md` → Review
   - `analysis_output/fig*.pdf` → `W3_HGBS_filaments/final_merged_paper/figures/`

2. **Update paper** with evidence from:
   - Longitudinal beading detection (addresses T1/T2)
   - Perpendicular field fragmentation (addresses T3)
   - Power-law validation (addresses T5)
   - Regime boundaries (addresses T4)

3. **Revise abstract and conclusions** with new findings

## Troubleshooting

**Ray initialization fails**:
```bash
# Stop existing Ray
ray stop

# Restart
ray start --head

# Then retry launch script
```

**Simulations timing out**:
```bash
# Increase timeout in scripts/launch_campaign.py
# Change: TIMEOUT_SECONDS = 7200  # 2 hours
# To: TIMEOUT_SECONDS = 14400  # 4 hours
```

**Out of memory**:
```bash
# Reduce concurrency
# In scripts/launch_campaign.py, change:
MAX_CONCURRENT = 13  # Reduce to 8 or 10
```

## Contact

For issues or questions, refer to the full documentation in `docs/README.md`.
