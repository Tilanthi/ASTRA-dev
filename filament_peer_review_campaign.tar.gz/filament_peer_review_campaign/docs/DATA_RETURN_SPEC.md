# DATA RETURN SPECIFICATION
## For Integration into MNRAS Filament Spacing Paper

After completing the peer review campaign, the following data products are required for paper integration.

---

## CRITICAL DATA PRODUCTS

### 1. Simulation Catalog (CSV)

**File**: `simulation_catalog.csv`

**Required columns**:
- sim_id: Unique simulation identifier
- f: Line mass fraction
- beta: Plasma beta
- mach: Mach number
- seed: Random seed
- eos: Equation of state (isothermal/adiabatic)
- profile: Density profile (king/uniform)
- bfield: Magnetic field geometry (longitudinal/perpendicular/oblique)
- status: FRAG/STABLE/TIMEOUT/ERROR
- t_frag: Fragmentation time (t_J)
- dt_min: Minimum timestep reached
- rho_c_max: Maximum central density
- longitudinal_peaks: Number of density peaks along filament axis
- lambda_frag: Measured fragmentation spacing (if peaks ≥ 2)
- fragmentation_quality: excellent/good/marginal/none
- wall_time_seconds: Wall-clock time
- hdf5_outputs: Number of HDF5 snapshots

### 2. Analysis Figures (PDF)

**Figure 1**: Regime Map - `fig1_beading_regime.pdf`
- Left: Longitudinal B-field (heatmap of n_peaks vs f, β)
- Right: Perpendicular B-field (heatmap of n_peaks vs f, β)
- Shows: Where longitudinal beading emerges (addresses T1/T2, T3)

**Figure 2**: λ/W Comparison - `fig2_lambda_W_comparison.pdf`
- Plot: λ/W vs f for different field geometries and β values
- Shows: Perpendicular vs longitudinal field fragmentation spacing
- Includes: HGBS reference line (λ/W = 2.1)

**Figure 3**: Power-Law Validation - `fig3_power_law_comparison.pdf`
- Plot: t_frag vs f for different EOS and initial profiles
- Shows: Whether f^(-0.39) exponent is universal (addresses T5)

**Figure 4**: Resolution Convergence - `fig4_resolution_convergence.pdf`
- Plot: t_frag vs resolution for test cases
- Shows: 128³ vs 256³ comparison (addresses T7)

### 3. Summary Report (Markdown)

**File**: `SUMMARY_REPORT.md`

**Required sections**:

```markdown
# Peer Review Response Campaign - Summary

## Executive Summary
- Total simulations completed
- Fragmentation rate
- Longitudinal beading detection rate

## Response by Concern

### T1/T2: Longitudinal Fragmentation Detection
- Simulations with ≥2 peaks: [count]
- Threshold f for beading: [value]
- Sample snapshot showing beading: [image]

### T3: Realistic Field Geometry
- Perpendicular field beading rate: [value]
- λ/W for perpendicular fields: [mean ± std]
- Comparison with HGBS: [statement]

### T4: Regime Boundaries
- Theoretical β_transition: [value]
- Simulated β_transition: [value]
- Agreement assessment: [statement]

### T5: Power-Law Exponent
- Isothermal, King profile: α = [value], R² = [value]
- Adiabatic, King profile: α = [value], R² = [value]
- Universal exponent assessment: [statement]

### T7: Resolution Convergence
- 128³ t_frag: [value]
- 256³ t_frag: [value] (if completed)
- Convergence assessment: [statement]

### T8: Turbulence Amplitude
- Weak turbulence beading: [value]
- Realistic turbulence beading: [value]
- Effect assessment: [statement]

### T9: Field-Geometry Calibration
- Oblique field calibration: λ_frag = [coefficient] × λ_MJ
- Statistical basis: [n_sims] simulations
- Comparison to previous: [statement]

### T10: Domain Size Effects
- Lx=8 beading: [value]
- Lx=12 beading: [value]
- Boundary condition effect: [statement]

## Conclusions
- Which concerns are fully addressed
- Which concerns are partially addressed
- Recommended additional work (if any)
```

### 4. Sample Snapshots

**Required**: 3-5 representative HDF5 snapshots showing:
1. Pure radial collapse (no beading) - typical of original campaign
2. Weak longitudinal beading (2-3 peaks) - threshold case
3. Strong longitudinal beading (4+ peaks) - ideal case
4. Perpendicular field beading - if different from longitudinal

**Format**: PNG/PDF with density profiles along filament spine

---

## DERIVED DATA PRODUCTS

### Peak Detection Analysis

For each simulation with ≥2 longitudinal peaks, provide:

```json
{
  "sim_id": "example_sim",
  "n_peaks": 3,
  "peak_positions": [128, 256, 384],
  "peak_amplitudes": [2.34, 2.56, 2.12],
  "peak_spacings": [128, 128],
  "lambda_frag": 128.0,
  "lambda_frag_uncertainty": 8.5,
  "quality_metric": 0.45,
  "quality_label": "excellent"
}
```

### Power-Law Fits

For each EOS × profile combination, provide:

```json
{
  "group": "isothermal_king",
  "exponent": 0.39,
  "exponent_uncertainty": 0.02,
  "r_squared": 0.998,
  "n_sims": 180,
  "f_range": [1.0, 3.0],
  "comparison_to_freefall": "0.39 vs 0.50 expected"
}
```

### Regime Boundaries

For each f value, provide:

```json
{
  "f": 1.5,
  "beta_transition_sim": 1.2,
  "beta_transition_theory": 1.1,
  "agreement": "good (within 10%)"
}
```

---

## FILE ORGANIZATION

```
filament_peer_review_campaign/
├── status/
│   ├── *.json                    # Individual simulation status files
│   └── simulation_catalog.csv    # Master catalog (REQUIRED)
├── runs/
│   └── [campaign]/
│       └── [sim_id]/
│           ├── *.athdf           # HDF5 snapshots
│           └── *.hst            # History files
├── analysis_output/
│   ├── SUMMARY_REPORT.md         # Required
│   ├── fig1_beading_regime.pdf  # Required
│   ├── fig2_lambda_W_comparison.pdf  # Required
│   ├── fig3_power_law_comparison.pdf  # Required
│   └── fig4_resolution_convergence.pdf  # Required
└── sample_snapshots/
    ├── radial_collapse_only.png   # Required
    ├── weak_beading.png           # Required
    ├── strong_beading.png          # Required
    └── perpendicular_beading.png   # Required
```

---

## VALIDATION CHECKLIST

Before returning data, verify:

- [ ] All simulations in manifest have corresponding status files
- [ ] CSV catalog has no missing values (use NA or -1 for inapplicable)
- [ ] All 4 required figures are present and valid PDFs
- [ ] Summary report addresses all 10 peer review concerns
- [ ] Sample snapshots clearly show beading vs no-beading
- [ ] HDF5 files are accessible and readable
- [ ] Peak detection analysis is reproducible from code
- [ ] Power-law fits include R² values and uncertainties

---

## DELIVERY FORMAT

Package as:
```
filament_peer_review_campaign_results.tar.gz

Contents:
- status/simulation_catalog.csv
- analysis_output/*
- sample_snapshots/*
- scripts/analyze_campaign.py  # For reproducibility
- README_RESULTS.txt           # This file
```

Upload to GitHub and provide location for integration.

---

## CONTACT FOR CLARIFICATION

If any requirements are unclear, or if simulation results don't match expected formats, contact before running full campaign to avoid wasted computational effort.

**Key questions to resolve before starting**:
1. Can your Athena++ version compile with both isothermal AND adiabatic EOS?
2. Can you generate HDF5 outputs at Δt = 0.05 t_J without I/O issues?
3. Do you have sufficient disk space (~500 GB) for all HDF5 outputs?
4. Can Ray handle 208 CPUs on your system (13 × 16)?

If any answer is NO, adjust specifications before starting.
