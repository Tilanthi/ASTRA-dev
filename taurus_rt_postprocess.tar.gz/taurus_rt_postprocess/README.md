# RT Post-Processing for M-T Spatial Variation Test

## Science case
We have detected (z=3.76 sigma, Fisher-combined) that the core mass-temperature
(M-T) relation varies SPATIALLY within active star-forming clouds (IC5146
F=6.78 p=0.002; Orion A F=5.76 p=0.004), but NOT in quiescent Taurus L1495
(F=1.26 p=0.28). The Athena++ simulations are isothermal (eos=isothermal) and
thus cannot model this dimension. This package post-processes the simulation
density outputs to predict the dust temperature field the sims WOULD produce
if non-isothermal physics were included, enabling a direct sim-observation
comparison.

## What this package does
1. rt_postprocess.py: reads Athena++ athdf density snapshot, computes dust
   temperature via ray-tracing (ISRF attenuated through density field), outputs
   T_dust cube. Uses Ray for parallelism (NOT SLURM).
2. analyze_mt_slope.py: extracts synthetic cores from the density+T cube,
   computes the M-T slope, and tests for spatial variation (F-test).
3. Compares to observed targets (IC5146 F=6.78; Taurus F=1.26).

## How to run
```bash
# 1. Setup
pip install ray astropy numpy scipy
# Ensure Athena++ Python reader is available (athdf reader)

# 2. Run RT post-processing (Ray, 200 vCPUs)
python rt_postprocess.py --athdf /path/to/final_snapshot.athdf \
    --output rt_output.npz --ncpu 200 --kappa 0.1 --T_isrf 15.0

# 3. Analyze M-T slope
python analyze_mt_slope.py --input rt_output.npz --output mt_results.json

# 4. Return results
# Send mt_results.json + this README back for comparison with observations.
```

## Data to return
Send back: mt_results.json (the F-statistic, p-value, z-score, and per-region
M-T slopes from the synthetic cores). This is compared to:
- IC5146 observed: F=6.78, p=0.002, slope range [-12.4, +1.1] K/dex
- Taurus L1495 observed: F=1.26, p=0.28, slope ~constant
- The KEY question: does the RT-processed sim reproduce the ACTIVE vs
  QUIESCENT differential? (Spatial variation in active sims, uniform in
  quiescent?)
