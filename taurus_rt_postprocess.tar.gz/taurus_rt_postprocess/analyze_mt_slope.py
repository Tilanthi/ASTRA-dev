#!/usr/bin/env python3
"""
Analyze the M-T slope from RT-processed simulation output.

Extracts synthetic "cores" (density peaks above a threshold), computes their
mass and RT-dust-temperature, fits the M-T relation, and tests for SPATIAL
variation (the F-test that gave F=6.78 in IC5146).

Usage:
  python analyze_mt_slope.py --input rt_output.npz --output mt_results.json
"""
import argparse, json
import numpy as np
from scipy import stats
from numpy.linalg import lstsq

def extract_cores(rho, T_dust, threshold_factor=0.1):
    """Extract synthetic cores as local density maxima above a threshold."""
    threshold = threshold_factor * rho.max()
    # Find local maxima (simple: cell above threshold AND above all 6 neighbors)
    from scipy.ndimage import maximum_filter
    local_max = (rho == maximum_filter(rho, size=3)) & (rho > threshold)
    indices = np.argwhere(local_max)
    
    cores = []
    for idx in indices:
        i, j, k = idx
        # Estimate core mass: sum density in a 5x5x5 cube around the peak
        i0, i1 = max(0, i-2), min(rho.shape[0], i+3)
        j0, j1 = max(0, j-2), min(rho.shape[1], j+3)
        k0, k1 = max(0, k-2), min(rho.shape[2], k+3)
        mass = rho[i0:i1, j0:j1, k0:k1].sum()
        T = T_dust[i, j]
        x, y, z = float(i), float(j), float(k)
        cores.append({"mass": float(mass), "Tdust": float(T), "x": x, "y": y, "z": z})
    
    return cores

def mt_spatial_test(cores):
    """Run the M-T x position F-test."""
    valid = [c for c in cores if c["mass"] > 0 and c["Tdust"] > 0]
    n = len(valid)
    if n < 30:
        return {"n": n, "error": "too few cores"}
    
    M = np.log10(np.array([c["mass"] for c in valid]))
    T = np.array([c["Tdust"] for c in valid])
    x = np.array([c["x"] for c in valid])
    y = np.array([c["y"] for c in valid])
    
    # Global M-T slope
    s_global = np.polyfit(M, T, 1)[0]
    r_global = np.corrcoef(M, T)[0, 1]
    
    # F-test for M x position interaction
    X0 = np.column_stack([np.ones(n), M, x, y])
    X1 = np.column_stack([np.ones(n), M, x, y, M*x, M*y])
    b0, _, _, _ = lstsq(X0, T, rcond=None)
    b1, _, _, _ = lstsq(X1, T, rcond=None)
    SSR0 = float(((T - X0 @ b0) ** 2).sum())
    SSR1 = float(((T - X1 @ b1) ** 2).sum())
    df_num, df_den = 2, max(n - 6, 1)
    F = ((SSR0 - SSR1) / df_num) / (SSR1 / df_den) if SSR1 > 0 else 0
    p = float(stats.f.sf(F, df_num, df_den))
    z = float(stats.norm.isf(max(p, 1e-300))) if p > 0 else 10
    
    return {
        "n_cores": n, "F": F, "p_value": p, "z_score": z,
        "global_mt_slope": float(s_global), "global_r": float(r_global),
        "spatial_variation_significant": bool(p < 0.05),
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', default='mt_results.json')
    parser.add_argument('--threshold', type=float, default=0.1)
    args = parser.parse_args()
    
    data = np.load(args.input)
    rho = data['density']
    T_dust = data['T_dust']
    
    print(f"Loaded: rho shape {rho.shape}, T_dust range [{T_dust.min():.2f}, {T_dust.max():.2f}] K")
    
    # Extract synthetic cores
    cores = extract_cores(rho, T_dust, args.threshold)
    print(f"Extracted {len(cores)} synthetic cores")
    
    # Run M-T spatial test
    result = mt_spatial_test(cores)
    
    # Add comparison targets
    result["observed_targets"] = {
        "IC5146_active": {"F": 6.78, "p": 0.002, "slope_range": [-12.4, 1.1]},
        "Orion_A_active": {"F": 5.76, "p": 0.004, "slope_range": "similar"},
        "Taurus_L1495_quiescent": {"F": 1.26, "p": 0.283, "note": "NO spatial variation"},
    }
    result["key_question"] = (
        "Does the RT-processed sim show spatial M-T variation? "
        "If yes for active-cloud parameters (high ISRF, structured density): "
        "the RT captures the missing physics. If no: the sim still misses something."
    )
    
    with open(args.output, 'w') as f:
        json.dump(result, f, indent=2)
    
    print(f"\nResults saved to {args.output}")
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
