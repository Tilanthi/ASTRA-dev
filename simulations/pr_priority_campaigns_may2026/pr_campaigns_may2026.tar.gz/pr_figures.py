#!/usr/bin/env python3
"""
Figure Generation: C1/C2/P1/P2 Referee Response Campaigns — May 2026
Generates 4 publication-quality figures
"""
import json, os, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import LinearSegmentedColormap
from pathlib import Path

BASE = Path("/data/pr_campaigns")
SIM_DIR = BASE / "sims"
P1_RERUN_DIR = BASE / "P1_rerun"
FIG_DIR = BASE / "figures"
FIG_DIR.mkdir(exist_ok=True)
ANA_DIR = BASE / "analysis"

plt.rcParams.update({
    'font.size': 11, 'axes.titlesize': 12, 'axes.labelsize': 11,
    'xtick.labelsize': 10, 'ytick.labelsize': 10,
    'legend.fontsize': 9, 'figure.dpi': 150,
})

# ─── Load data ───────────────────────────────────────────────────────────────
c1_ana = json.loads((ANA_DIR / "C1_analysis.json").read_text())
c2_ana = json.loads((ANA_DIR / "C2_analysis.json").read_text())
p1_ana = json.loads((ANA_DIR / "P1_analysis.json").read_text())
p2_ana = json.loads((ANA_DIR / "P2_analysis.json").read_text())
print("Loaded analysis files")

# ─── Figure 1: C1 Resolution Convergence ─────────────────────────────────────
fig, ax = plt.subplots(figsize=(7, 5))

seeds = ['42', '137', '251']
colors_256 = ['#1f77b4', '#1f77b4', '#1f77b4']
colors_512 = ['#ff7f0e', '#ff7f0e', '#ff7f0e']

t256 = c1_ana['res256']['values']
t512 = c1_ana['res512']['values']

x_256 = np.array([0.85, 1.0, 1.15])
x_512 = np.array([1.85, 2.0, 2.15])

ax.scatter(x_256, t256, c='#1f77b4', s=80, zorder=5, label='256×32×32 (standard)')
ax.scatter(x_512, t512, c='#ff7f0e', s=80, marker='s', zorder=5, label='512×64×64 (high-res)')

# Mean lines
ax.axhline(c1_ana['res256']['mean'], color='#1f77b4', linestyle='--', alpha=0.7, linewidth=1.5)
ax.axhline(c1_ana['res512']['mean'], color='#ff7f0e', linestyle='--', alpha=0.7, linewidth=1.5)

# Shaded bands (mean ± std)
for m, s, c in [(c1_ana['res256']['mean'], c1_ana['res256']['std'], '#1f77b4'),
                (c1_ana['res512']['mean'], c1_ana['res512']['std'], '#ff7f0e')]:
    ax.axhspan(m-s, m+s, alpha=0.1, color=c)

# Annotate means
ax.annotate(f"Mean={c1_ana['res256']['mean']:.4f} t_J", xy=(1.0, c1_ana['res256']['mean']),
           xytext=(1.6, c1_ana['res256']['mean']+0.02), fontsize=9, color='#1f77b4')
ax.annotate(f"Mean={c1_ana['res512']['mean']:.4f} t_J", xy=(2.0, c1_ana['res512']['mean']),
           xytext=(1.6, c1_ana['res512']['mean']-0.04), fontsize=9, color='#ff7f0e')

conv = c1_ana['convergence_pct']
ax.set_title(f'C1: Resolution Convergence Test\n'
             f'f=1.1, β=1.0, θ=0°, seeds=[42,137,251] | Convergence={conv:.2f}%', fontsize=11)
ax.set_ylabel('$t_{\\rm frag}$ / $t_J$')
ax.set_xlim(0.5, 2.5)
ax.set_xticks([1.0, 2.0])
ax.set_xticklabels(['256×32×32\n(standard)', '512×64×64\n(high-res)'])
ax.set_ylim(1.35, 1.75)
ax.legend(loc='upper right')
ax.text(0.05, 0.05, f'Convergence: {conv:.2f}% < 10% threshold\nRef: Rev. B Moderate #7',
        transform=ax.transAxes, fontsize=9, verticalalignment='bottom',
        bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.8))
ax.grid(True, alpha=0.3)
plt.tight_layout()
fname = FIG_DIR / "Fig1_C1_resolution_convergence.pdf"
plt.savefig(fname, bbox_inches='tight')
plt.savefig(str(fname).replace('.pdf','.png'), bbox_inches='tight', dpi=150)
plt.close()
print(f"Fig 1 saved: {fname}")

# ─── Figure 2: C2 Consistency Test ───────────────────────────────────────────
fig, ax = plt.subplots(figsize=(7, 5))

f_vals = [float(k) for k in c2_ana['by_f'].keys()]
means = [c2_ana['by_f'][k]['mean'] for k in c2_ana['by_f']]
stds = [c2_ana['by_f'][k]['std'] for k in c2_ana['by_f']]
values_all = [c2_ana['by_f'][k]['values'] for k in c2_ana['by_f']]

# Individual seeds
colors_seeds = ['#e41a1c', '#377eb8', '#4daf4a']
seed_labels = ['seed=42', 'seed=137', 'seed=251']
for i_s in range(3):
    t_s = [v[i_s] if i_s < len(v) else None for v in values_all]
    t_s_valid = [(f, t) for f, t in zip(f_vals, t_s) if t is not None]
    if t_s_valid:
        ax.scatter([x[0] for x in t_s_valid], [x[1] for x in t_s_valid],
                   c=colors_seeds[i_s], s=60, zorder=5, label=seed_labels[i_s])

# Mean with errorbars
ax.errorbar(f_vals, means, yerr=stds, fmt='ko', markersize=8, linewidth=1.5,
            capsize=4, label='Mean ± σ', zorder=6)

# Linear fit
f_fine = np.linspace(1.3, 3.2, 100)
slope = c2_ana['slope_per_unit_f']
intercept = np.mean(means) - slope * np.mean(f_vals)
ax.plot(f_fine, slope * f_fine + intercept, 'k--', linewidth=1.5, alpha=0.7,
        label=f'Linear fit: slope={slope:.3f} t_J/unit f')

ax.set_title('C2: Fragmentation Timescale Consistency Test\n'
             '512×64×64, β=1.0, θ=0°, seeds=[42,137,251]', fontsize=11)
ax.set_xlabel('$f$ (mass-to-flux ratio)')
ax.set_ylabel('$t_{\\rm frag}$ / $t_J$')
ax.set_xlim(1.3, 3.2)
ax.set_ylim(0.55, 1.55)
ax.legend(loc='upper right', fontsize=8)
ax.text(0.05, 0.05, 'Ref: Rev. B Critical #2',
        transform=ax.transAxes, fontsize=9, verticalalignment='bottom',
        bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.8))
ax.grid(True, alpha=0.3)
plt.tight_layout()
fname = FIG_DIR / "Fig2_C2_consistency_test.pdf"
plt.savefig(fname, bbox_inches='tight')
plt.savefig(str(fname).replace('.pdf','.png'), bbox_inches='tight', dpi=150)
plt.close()
print(f"Fig 2 saved: {fname}")

# ─── Figure 3: P1 Sub-Isothermal EOS ─────────────────────────────────────────
fig, ax = plt.subplots(figsize=(7, 5))

f_orig_vals = sorted([float(k) for k in p1_ana['by_f_orig'].keys()])
t_g07 = []
t_g08 = []

# Get means by (f_orig, gamma) from raw data
p1_results = json.loads((BASE / "P1_rerun_results.json").read_text())
p1_frag = [s for s in p1_results if s.get('class') == 'FRAG' and s.get('t_frag')]

for f in f_orig_vals:
    g07_t = [s['t_frag'] for s in p1_frag if abs(s.get('f_orig',0)-f)<0.01 and abs(s.get('gamma',0)-0.7)<0.01]
    g08_t = [s['t_frag'] for s in p1_frag if abs(s.get('f_orig',0)-f)<0.01 and abs(s.get('gamma',0)-0.8)<0.01]
    t_g07.append((np.mean(g07_t), np.std(g07_t)) if g07_t else (None, None))
    t_g08.append((np.mean(g08_t), np.std(g08_t)) if g08_t else (None, None))

m07 = [t[0] for t in t_g07 if t[0]]
s07 = [t[1] for t in t_g07 if t[0]]
f07 = [f for f, t in zip(f_orig_vals, t_g07) if t[0]]

m08 = [t[0] for t in t_g08 if t[0]]
s08 = [t[1] for t in t_g08 if t[0]]
f08 = [f for f, t in zip(f_orig_vals, t_g08) if t[0]]

ax.errorbar(f07, m07, yerr=s07, fmt='b-o', markersize=7, linewidth=1.5,
            capsize=4, label='γ=0.7 (sub-isothermal)', color='#e41a1c')
ax.errorbar(f08, m08, yerr=s08, fmt='r--s', markersize=7, linewidth=1.5,
            capsize=4, label='γ=0.8 (sub-isothermal)', color='#ff7f0e')

# Add isothermal reference (γ=1.0) from C2 data (β=1.0 only)
# C2 data: f=1.5/2.0/2.5/3.0 at β=1.0 — closest comparison
c2_f = [float(k) for k in c2_ana['by_f'].keys()]
c2_t = [c2_ana['by_f'][k]['mean'] for k in c2_ana['by_f']]
ax.plot(c2_f, c2_t, 'g:^', markersize=7, linewidth=1.5, label='γ=1.0 (isothermal, C2 β=1.0)', color='#2ca02c')

speedup = p1_ana.get('gamma_speedup_pct', 0) or 0
ax.set_title(f'P1: Sub-Isothermal EOS Effect on Fragmentation\n'
             f'f_eff = f/√γ approximation | γ speedup = {speedup:.1f}%', fontsize=11)
ax.set_xlabel('$f$ (mass-to-flux ratio, original)')
ax.set_ylabel('$t_{\\rm frag}$ / $t_J$')
ax.set_xlim(0.9, 3.2)
ax.legend(loc='upper right')
ax.text(0.05, 0.05, 'Ref: Rev. B Moderate #6',
        transform=ax.transAxes, fontsize=9, verticalalignment='bottom',
        bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.8))
ax.grid(True, alpha=0.3)
plt.tight_layout()
fname = FIG_DIR / "Fig3_P1_subisothermal_eos.pdf"
plt.savefig(fname, bbox_inches='tight')
plt.savefig(str(fname).replace('.pdf','.png'), bbox_inches='tight', dpi=150)
plt.close()
print(f"Fig 3 saved: {fname}")

# ─── Figure 4: P2 Phase Diagram ───────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

f_vals = p2_ana['f_vals']
b_vals = p2_ana['beta_vals']

# Left panel: FRAG fraction heatmap
frac_matrix = np.zeros((len(f_vals), len(b_vals)))
for i, f in enumerate(f_vals):
    for j, b in enumerate(b_vals):
        key = f"{f}_{b}"
        d = p2_ana['phase_data'].get(key, {})
        frac_matrix[i, j] = d.get('frac_frag', 0)

cmap = plt.cm.RdYlGn
im1 = axes[0].imshow(frac_matrix, cmap=cmap, vmin=0, vmax=1,
                      aspect='auto', origin='lower')
axes[0].set_xticks(range(len(b_vals)))
axes[0].set_xticklabels([f'β={b:.1f}' for b in b_vals], rotation=45, ha='right', fontsize=9)
axes[0].set_yticks(range(len(f_vals)))
axes[0].set_yticklabels([f'f={f:.1f}' for f in f_vals])
axes[0].set_title('FRAG Fraction (0=TOUT, 1=FRAG)\n3 M values per cell', fontsize=11)
axes[0].set_xlabel('Plasma beta β')
axes[0].set_ylabel('Mass-to-flux ratio f')

# Add text annotations
for i in range(len(f_vals)):
    for j in range(len(b_vals)):
        frac = frac_matrix[i, j]
        axes[0].text(j, i, f'{frac:.0%}', ha='center', va='center',
                    fontsize=7, color='black' if 0.2 < frac < 0.8 else 'white')

cb1 = plt.colorbar(im1, ax=axes[0])
cb1.set_label('FRAG fraction')

# Right panel: mean t_frag heatmap (FRAG only)
tfrag_matrix = np.full((len(f_vals), len(b_vals)), np.nan)
for i, f in enumerate(f_vals):
    for j, b in enumerate(b_vals):
        key = f"{f}_{b}"
        val = p2_ana['tfrag_matrix'].get(key)
        if val: tfrag_matrix[i, j] = val

cmap2 = plt.cm.viridis_r
masked = np.ma.masked_invalid(tfrag_matrix)
im2 = axes[1].imshow(masked, cmap=cmap2, vmin=0.6, vmax=1.5,
                      aspect='auto', origin='lower')
axes[1].set_xticks(range(len(b_vals)))
axes[1].set_xticklabels([f'β={b:.1f}' for b in b_vals], rotation=45, ha='right', fontsize=9)
axes[1].set_yticks(range(len(f_vals)))
axes[1].set_yticklabels([f'f={f:.1f}' for f in f_vals])
axes[1].set_title('Mean t_frag / t_J (FRAG only)\n(grey = all TIMEOUT)', fontsize=11)
axes[1].set_xlabel('Plasma beta β')
axes[1].set_ylabel('Mass-to-flux ratio f')

for i in range(len(f_vals)):
    for j in range(len(b_vals)):
        val = tfrag_matrix[i, j]
        if not np.isnan(val):
            axes[1].text(j, i, f'{val:.2f}', ha='center', va='center',
                        fontsize=7, color='white' if val < 1.0 else 'black')

cb2 = plt.colorbar(im2, ax=axes[1])
cb2.set_label('$t_{\\rm frag}$ / $t_J$')

# Add regime boundary line (approximate)
# Transition between mostly-FRAG and mostly-TOUT
# Based on data: roughly f~1.2-1.6 boundary
from matplotlib.lines import Line2D
legend_elements = [
    mpatches.Patch(facecolor='#2ca02c', label='Freely Fragmenting (f≥2.5)'),
    mpatches.Patch(facecolor='#ff7f0e', label='Transition (f=1.2–2.0)'),
    mpatches.Patch(facecolor='#1f77b4', label='Magnetically Dominated (f≤1.0)'),
    mpatches.Patch(facecolor='gray', alpha=0.5, label='β=5.0: TLIM artefact'),
]
axes[0].legend(handles=legend_elements, loc='upper left', fontsize=7, framealpha=0.9)

fig.suptitle('P2: 3D Phase Diagram f × β × M (Rev. B Minor #9)\n'
             '189 sims, TLIM=1.5 t_J, seed=42', fontsize=12, y=1.01)
plt.tight_layout()
fname = FIG_DIR / "Fig4_P2_phase_diagram.pdf"
plt.savefig(fname, bbox_inches='tight')
plt.savefig(str(fname).replace('.pdf','.png'), bbox_inches='tight', dpi=150)
plt.close()
print(f"Fig 4 saved: {fname}")

print(f"\nAll figures saved to {FIG_DIR}")
print(f"Files: {sorted(os.listdir(FIG_DIR))}")
