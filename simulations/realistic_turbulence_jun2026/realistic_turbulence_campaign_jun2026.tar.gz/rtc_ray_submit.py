#!/usr/bin/env python3
"""
Realistic Turbulence Campaign Ray Submission Script
Submits RTC-1200 campaign to 200 vCPU cluster using Ray
"""

import ray
import subprocess
import os
import pandas as pd
from pathlib import Path
from datetime import datetime
import time
import json

# Ray configuration
RAY_HEAD_IP = "34.143.130.135"  # Cluster IP
RAY_NUM_CPUS = 200  # Available vCPUs
SIM_CPUS = 32  # CPUs per simulation (8 MPI ranks × 4 threads)
CONCURRENCY = 6  # Number of simultaneous simulations (6 × 32 = 192 vCPUs)

# Campaign parameters
CAMPAIGN_DIR = "/Users/gjw255/astrodata/SWARM/ASTRA-dev-main/simulations/realistic_turbulence_jun2026"
CONFIG_DIR = os.path.join(CAMPAIGN_DIR, "configs")
RESULTS_DIR = os.path.join(CAMPAIGN_DIR, "results")
ATHENA_BINARY = "/path/to/athena++/bin/athena"  # UPDATE THIS PATH

@ray.remote(num_cpus=SIM_CPUS, memory=20_000_000_000)
def run_simulation(sim_dir, campaign_dir):
    """
    Run single Athena++ simulation with Ray

    Parameters:
    -----------
    sim_dir : str
        Simulation configuration directory
    campaign_dir : str
        Campaign base directory

    Returns:
    --------
    dict : Simulation results
    """
    import re
    from pathlib import Path

    sim_path = Path(sim_dir)
    sim_name = sim_path.name

    print(f"[{datetime.now()}] Starting: {sim_name}")

    try:
        # Change to simulation directory
        os.chdir(sim_path)

        # Run Athena++ with MPI
        cmd = [
            "mpirun",
            "-n", "8",  # 8 MPI ranks (512/64 × 64/32 × 64/32 = 8 meshblocks)
            ATHENA_BINARY,
            "-i", "athena_input.txt"
        ]

        start_time = time.time()
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=7200  # 2 hour timeout per simulation
        )
        elapsed = time.time() - start_time

        # Parse output for fragmentation data
        results = {
            "sim_name": sim_name,
            "status": "completed" if result.returncode == 0 else "failed",
            "runtime_seconds": elapsed,
            "returncode": result.returncode,
            "stdout_tail": result.stdout[-1000:] if result.stdout else "",
        }

        # Extract simulation parameters from directory name
        # Format: f{f}_b{beta}_m{mturb}_t{theta}_s{seed}
        match = re.match(r"f(\d+\.\d+)_b(\d+\.\d+)_m(\d+\.\d+)_t(\d+)_s(\d+)", sim_name)
        if match:
            results["f"] = float(match.group(1))
            results["beta"] = float(match.group(2))
            results["mturb"] = float(match.group(3))
            results["theta"] = int(match.group(4))
            results["seed"] = int(match.group(5))

        # Extract fragmentation data from output
        if result.returncode == 0:
            # Parse HDF5 or history files for fragmentation metrics
            frag_data = extract_fragmentation_data(sim_path)
            results.update(frag_data)

        # Cleanup HDF5 files to save space
        hdf5_dir = sim_path / "hdf5"
        if hdf5_dir.exists():
            subprocess.run(["rm", "-rf", str(hdf5_dir)], capture_output=True)

        print(f"[{datetime.now()}] Completed: {sim_name} ({elapsed:.1f}s)")
        return results

    except subprocess.TimeoutExpired:
        print(f"[{datetime.now()}] TIMEOUT: {sim_name}")
        return {
            "sim_name": sim_name,
            "status": "timeout",
            "runtime_seconds": 7200,
            "error": "Simulation exceeded 2 hour timeout"
        }
    except Exception as e:
        print(f"[{datetime.now()}] ERROR: {sim_name} - {str(e)}")
        return {
            "sim_name": sim_name,
            "status": "error",
            "error": str(e)
        }

def extract_fragmentation_data(sim_path):
    """
    Extract fragmentation metrics from simulation output

    Parameters:
    -----------
    sim_path : Path
        Simulation directory path

    Returns:
    --------
    dict : Fragmentation metrics
    """
    import h5py
    import numpy as np

    results = {}

    try:
        # Read HDF5 snapshots
        hdf5_dir = sim_path / "hdf5"
        if not hdf5_dir.exists():
            return {"lW": "N/A", "t_frag": "N/A", "morphology": "NO_HDF5"}

        hdf5_files = sorted(hdf5_dir.glob("*.hdf5"))
        if len(hdf5_files) < 2:
            return {"lW": "N/A", "t_frag": "N/A", "morphology": "INSUFFICIENT_SNAPSHOTS"}

        # Read first and last snapshots
        with h5py.File(hdf5_files[0], 'r') as f:
            rho_initial = f['rho'][:]

        with h5py.File(hdf5_files[-1], 'r') as f:
            rho_final = f['rho'][:]

        # Calculate axial density profile
        rho_axial_final = np.mean(rho_final, axis=(1, 2))  # Average over y,z

        # Find density peaks
        from scipy.signal import find_peaks
        peaks, properties = find_peaks(rho_axial_final, prominence=0.5, distance=20)

        if len(peaks) >= 2:
            # Calculate wavelengths between adjacent peaks
            wavelengths = np.diff(peaks)
            lW = np.mean(wavelengths) * (16.0 / 512)  # Convert to physical units
            results["lW"] = lW
            results["n_peaks"] = len(peaks)
            results["morphology"] = "FULL" if len(peaks) >= 3 else "PARTIAL"
        else:
            results["lW"] = "NO_BEADING"
            results["n_peaks"] = len(peaks)
            results["morphology"] = "RADIAL_ONLY"

        # Estimate fragmentation time from last snapshot time
        # Extract from filename: usually something like 0.00000.hdf5
        t_str = hdf5_files[-1].stem
        results["t_frag"] = float(t_str) if t_str.replace('.', '').isdigit() else "N/A"

        # Transient peak survival analysis (CRITICAL for Referee Concern #1)
        if len(hdf5_files) >= 10:  # Need sufficient temporal resolution
            peak_lifetimes = []
            for i in range(len(hdf5_files) - 1):
                with h5py.File(hdf5_files[i], 'r') as f:
                    rho_i = np.mean(f['rho'][:], axis=(1, 2))
                peaks_i, _ = find_peaks(rho_i, prominence=0.5, distance=20)

                with h5py.File(hdf5_files[i+1], 'r') as f:
                    rho_j = np.mean(f['rho'][:], axis=(1, 2))
                peaks_j, _ = find_peaks(rho_j, prominence=0.5, distance=20)

                # Track which peaks survive
                for peak in peaks_i:
                    # Find if peak persists in next snapshot
                    if len(peaks_j) > 0 and any(abs(peak - pj) < 5 for pj in peaks_j):
                        peak_lifetimes.append(0.01)  # dt = 0.01 tJ
                    else:
                        break

            if peak_lifetimes:
                results["tau_peak"] = np.sum(peak_lifetimes)
                results["survives_to_bound"] = results["tau_peak"] >= 0.1

    except Exception as e:
        results["extraction_error"] = str(e)
        results["lW"] = "ERROR"
        results["morphology"] = "ERROR"

    return results

def main():
    """
    Main: Submit RTC campaign to Ray cluster
    """
    print("="*80)
    print("Realistic Turbulence Campaign - Ray Submission")
    print("="*80)
    print(f"Started: {datetime.now()}")
    print(f"Cluster: {RAY_HEAD_IP}")
    print(f"Available CPUs: {RAY_NUM_CPUS}")
    print(f"CPUs per simulation: {SIM_CPUS}")
    print(f"Concurrency: {CONCURRENCY}")
    print("="*80)

    # Initialize Ray
    print(f"\n[{datetime.now()}] Connecting to Ray cluster at {RAY_HEAD_IP}...")
    try:
        ray.init(address=f"ray://{RAY_HEAD_IP}:6379", num_cpus=RAY_NUM_CPUS)
        print(f"[{datetime.now()}] Connected to Ray cluster successfully")
    except Exception as e:
        print(f"[{datetime.now()}] ERROR connecting to Ray: {e}")
        print("Make sure Ray cluster is running at specified address")
        return

    # Read simulation list
    sim_list_file = os.path.join(CONFIG_DIR, "simulation_list.txt")
    if not os.path.exists(sim_list_file):
        print(f"[{datetime.now()}] ERROR: Simulation list not found: {sim_list_file}")
        print("Run rtc_config_generator.py first to generate configurations")
        return

    with open(sim_list_file, 'r') as f:
        sim_dirs = [line.strip() for line in f if line.strip()]

    print(f"\n[{datetime.now()}] Found {len(sim_dirs)} simulations to run")
    print(f"Estimated wall time: {len(sim_dirs) * 45 / 3600:.1f} hours (assuming 45 min/sim)")
    print(f"Estimated completion: {datetime.fromtimestamp(time.time() + len(sim_dirs) * 45 * 60)}")

    # Create results directory
    os.makedirs(RESULTS_DIR, exist_ok=True)

    # Initialize results tracking
    results_file = os.path.join(RESULTS_DIR, "RTC_results_progress.csv")
    if os.path.exists(results_file):
        results_df = pd.read_csv(results_file)
        completed = set(results_df['sim_name'].values)
        print(f"\n[{datetime.now()}] Resuming from {len(completed)} completed simulations")
        sim_dirs = [s for s in sim_dirs if Path(s).name not in completed]
    else:
        results_df = pd.DataFrame()
        completed = set()

    # Submit simulations with limited concurrency
    print(f"\n[{datetime.now()}] Starting simulation execution...")
    all_results = []
    futures = []

    for i, sim_dir in enumerate(sim_dirs):
        # Submit to Ray
        future = run_simulation.remote(sim_dir, CAMPAIGN_DIR)
        futures.append(future)

        # Wait for completion if we've reached concurrency limit
        if len(futures) >= CONCURRENCY or i == len(sim_dirs) - 1:
            print(f"\n[{datetime.now()}] Batch of {len(futures)} submitted, waiting for completion...")

            # Wait for at least one to complete
            ready, futures = ray.wait(futures, num_returns=1, timeout=7200)
            result = ray.get(ready[0])

            # Save result
            all_results.append(result)
            results_df = pd.concat([results_df, pd.DataFrame([result])], ignore_index=True)
            results_df.to_csv(results_file, index=False)

            # Progress update
            completed_count = len(all_results)
            total_count = len(sim_dirs)
            progress = completed_count / total_count * 100
            print(f"[{datetime.now()}] Progress: {completed_count}/{total_count} ({progress:.1f}%)")

            # Estimate remaining time
            avg_runtime = np.mean([r.get('runtime_seconds', 2700) for r in all_results])
            remaining_sims = total_count - completed_count
            eta_seconds = remaining_sims * avg_runtime / CONCURRENCY
            eta_hours = eta_seconds / 3600
            print(f"[{datetime.now()}] ETA: {eta_hours:.1f} hours")

    # Final save
    results_df.to_csv(results_file, index=False)

    print(f"\n{'='*80}")
    print(f"Campaign Complete!")
    print(f"Total simulations: {len(results_df)}")
    print(f"Successful: {len(results_df[results_df['status'] == 'completed'])}")
    print(f"Failed: {len(results_df[results_df['status'] == 'failed'])}")
    print(f"Timeout: {len(results_df[results_df['status'] == 'timeout'])}")
    print(f"Results file: {results_file}")
    print(f"{'='*80}")

if __name__ == "__main__":
    main()
