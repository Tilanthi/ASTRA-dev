#!/usr/bin/env python3
import glob, os, re, json
import numpy as np, h5py
from scipy.signal import find_peaks
W=0.3

def parse(pid):
 def g(p,cast=str,default=None):
  m=re.search(p,pid); return cast(m.group(1)) if m else default
 return {'pid':pid,'f':g(r'_f([0-9.]+)',float),'beta':g(r'_b([0-9.]+)',float),'theta':g(r'_th([0-9.]+)',float),'Lx':g(r'_Lx([0-9]+)',int),'seed':g(r'_s([0-9]+)',int)}

def choose_density(f):
 keys=[]
 def rec(g,path=''):
  for k,v in g.items():
   p=path+'/'+k
   if isinstance(v,h5py.Dataset): keys.append((p,v))
   elif isinstance(v,h5py.Group): rec(v,p)
 rec(f)
 # prefer dataset shaped like (nz,ny,nx) with max dimension substantially largest
 best=None
 for p,d in keys:
  sh=d.shape
  if len(sh)<3: continue
  score=max(sh)/(min(sh)+1e-9)
  if best is None or score>best[0]: best=(score,p,d)
 if best is None: return None,None
 return best[1],best[2][:]

def analyze_file(fn,pid):
 with h5py.File(fn,'r') as f:
  path,a=choose_density(f)
  if a is None: return {'file':os.path.basename(fn),'error':'no density'}
  a=np.array(a).squeeze()
  while a.ndim>3: a=a[0]
  if a.ndim!=3: return {'file':os.path.basename(fn),'error':'density not 3D','shape':a.shape,'dataset':path}
  # Longitudinal x1 in Athena++ is last axis for (z,y,x) layout. Require longest dimension axis.
  axis=int(np.argmax(a.shape))
  axes=tuple(i for i in range(3) if i!=axis)
  prof=a.mean(axis=axes)
  n=len(prof); L=parse(pid)['Lx'] or 24; dx=L/n
  mean=np.mean(prof); mx=np.max(prof); med=np.median(prof)
  peaks,props=find_peaks(prof,prominence=max(1e-6,0.05*mean),distance=max(4,int(0.1*n)))
  # Filter edge peaks caused by periodic wrap of one structure: require interior peaks for physical beading
  interior=[int(p) for p in peaks if 0.05*n < p < 0.95*n]
  # physical spacing from interior peaks only
  spacing=np.diff(interior)*dx
  lam=float(np.median(spacing)/W) if len(spacing) else None
  # conservative classification
  beading=len(interior)>=2 and mx/mean>1.5
  return {'file':os.path.basename(fn),'dataset':path,'shape':list(a.shape),'axis':axis,'n':n,'mean':float(mean),'max':float(mx),'contrast':float(mx/mean),'peaks':[int(p) for p in peaks],'interior_peaks':interior,'n_interior':len(interior),'lambda_W':lam,'beading':bool(beading)}

def main():
 pids=sorted(set(re.sub(r'\.prim\..*','',os.path.basename(x)) for x in glob.glob('*.athdf')))
 out={}
 for pid in pids:
  rec=parse(pid); ss=[]
  for fn in sorted(glob.glob(pid+'*.athdf')):
   try:ss.append(analyze_file(fn,pid))
   except Exception as e:ss.append({'file':os.path.basename(fn),'error':str(e)})
  rec['snapshots']=ss; rec['any_physical_beading']=any(s.get('beading') for s in ss)
  rec['max_interior_peaks']=max([s.get('n_interior',0) for s in ss],default=0)
  rec['physical_lambdaW_values']=[s.get('lambda_W') for s in ss if s.get('beading') and s.get('lambda_W')]
  out[pid]=rec
 open('hdf5_physical_beading_analysis.json','w').write(json.dumps(out,indent=2))
 print('pids',len(out),'physical_beading',sum(r['any_physical_beading'] for r in out.values()))
 for pid,r in out.items():
  if r['any_physical_beading']: print('BEADING',pid,r['max_interior_peaks'],r['physical_lambdaW_values'])
if __name__=='__main__':main()
