#!/usr/bin/env python3
"""Generate targeted referee-response validation suite.

Suites:
A seeding_sensitivity: perturb_ampl 1.0/0.1/0.01 at 4 parameter points × 3 seeds = 36
B fiducial_replication: f=1.5 β=1 θ=0 Lx=24, five seeds at low perturb_ampl=1e-4 = 5
C kill_threshold_robustness: 3 fiducial seeds × 3 monitor thresholds = 9
D t1_resolution_convergence: β=1, f={1.0,1.5,2.0}, cells/lambda={32,64,128}, seeds={42,137} = 18
E stability_probe: low-amplitude seeding, f=1.5, β=1, θ={0,45,90}, Lx={24,48}, seeds={42,137} = 12
Total = 80 simulations.
"""
import json, math
from pathlib import Path
SEEDS=[42,137,251]
FOUR_PI_G=39.4784176044
W_CORE=0.3

def nx_for(Lx, cells_per_lambda=64):
    return int(Lx*cells_per_lambda)

def make_cfg(pid,f,beta,theta,Lx,seed,perturb=1.0,cells_per_lambda=64,tlim=0.08,hdt=0.002,odt=0.02,dt_kill=2e-5):
    nx=nx_for(Lx,cells_per_lambda)
    return f"""<comment>
problem   = {pid}
f={f} beta={beta} theta={theta} Lx={Lx} seed={seed} perturb_ampl={perturb} cells_per_lambda={cells_per_lambda}

<job>
problem_id      = {pid}
max_runtime     = 21600
num_cores       = 16
restart_file    =

<output1>
file_type   = hdf5
variable    = prim
dt          = {odt}
id          = prim
data_dir    = ./{pid}/

<output2>
file_type   = hst
dt          = {hdt}
id          = hst
data_dir    = ./{pid}/

<time>
cfl_number  = 0.3
tlim        = {tlim}
nlim        = -1

<mesh>
nx1         = {nx}
x1min       = 0.0
x1max       = {Lx}
ix1_bc      = periodic
ox1_bc      = periodic
nx2         = 64
x2min       = -0.5
x2max       = 0.5
ix2_bc      = user
ox2_bc      = user
nx3         = 64
x3min       = -0.5
x3max       = 0.5
ix3_bc      = user
ox3_bc      = user

<meshblock>
nx1 = 32
nx2 = 64
nx3 = 64

<hydro>
gamma           = 1.0
iso_sound_speed  = 1.0

<gravity>
grav_mean_rho   = 1.0

<problem>
four_pi_G       = {FOUR_PI_G}
f_line_mass     = {f}
plasma_beta     = {beta}
theta_deg       = {theta}
mach_number     = 1.0
perturb_ampl    = {perturb}
random_seed     = {seed}
W_core          = {W_CORE}
"""

def add(files,manifest,suite,pid,**kw):
    d=Path('configs')/suite; d.mkdir(parents=True,exist_ok=True)
    p=d/(pid+'.athinput')
    p.write_text(make_cfg(pid,**kw))
    files.append(str(p)); manifest['suites'].setdefault(suite,[]).append({'pid':pid,'config':str(p),**kw})

def main():
    root=Path('.'); Path('configs').mkdir(exist_ok=True)
    manifest={'generated_utc':'2026-07-19','suites':{},'notes':{
        'purpose':'Referee-response validation suite for extended-domain audit, seeding, kill-threshold, and T1 convergence.',
        'boundary_conditions':'x1 periodic; x2/x3 user (required by current compiled Athena++ binary)',
        'default_tlim':0.08,
        'default_hdt':0.002,
        'default_odt':0.02
    }}
    files=[]
    # A. Seeding sensitivity: 3 amplitudes × 4 points × 3 seeds
    pts=[(1.0,1.0,0.0),(1.5,1.0,0.0),(2.0,1.0,0.0),(2.0,1.0,90.0)]
    for amp in [1.0,0.1,0.01]:
        for f,beta,theta in pts:
            for s in SEEDS:
                ampstr=('1e0' if amp==1.0 else ('1em1' if amp==0.1 else '1em2'))
                pid=f'VAL_seed{ampstr}_f{f:.1f}_b{beta:.1f}_th{theta:.0f}_Lx24_s{s}'
                add(files,manifest,'A_seeding_sensitivity',pid,f=f,beta=beta,theta=theta,Lx=24,seed=s,perturb=amp)
    # B. Exact-ish fiducial replication at 5 seeds, low perturb_ampl, longer tlim
    for s in [42,137,251,7,11]:
        pid=f'VAL_rep_f1.5_b1.0_th0_Lx24_s{s}_p1em4'
        add(files,manifest,'B_fiducial_replication',pid,f=1.5,beta=1.0,theta=0.0,Lx=24,seed=s,perturb=1e-4,tlim=0.20,hdt=0.001,odt=0.01)
    # C. kill-threshold robustness on fiducial seeds, grouped by threshold but same cfg physics
    for thr in [2e-5,1e-5,5e-6]:
        tstr=str(thr).replace('e-','em').replace('.','p')
        for s in SEEDS:
            pid=f'VAL_kthr{tstr}_f1.5_b1.0_th0_Lx24_s{s}'
            add(files,manifest,'C_kill_threshold_robustness',pid,f=1.5,beta=1.0,theta=0.0,Lx=24,seed=s,perturb=1.0,dt_kill=thr)
    # D. T1 resolution convergence: lower amplitude, resolution ladder
    for f in [1.0,1.5,2.0]:
        for cpl in [32,64,128]:
            for s in [42,137]:
                pid=f'VAL_t1res{cpl}_f{f:.1f}_b1.0_th0_Lx24_s{s}'
                add(files,manifest,'D_t1_resolution_convergence',pid,f=f,beta=1.0,theta=0.0,Lx=24,seed=s,perturb=1e-2,cells_per_lambda=cpl,tlim=0.12,hdt=0.001,odt=0.01)
    # E. Stability probes with low amplitude across θ and Lx
    for Lx in [24,48]:
        for theta in [0.0,45.0,90.0]:
            for s in [42,137]:
                pid=f'VAL_stab_f1.5_b1.0_th{theta:.0f}_Lx{Lx}_s{s}_p1em4'
                add(files,manifest,'E_stability_probe',pid,f=1.5,beta=1.0,theta=theta,Lx=Lx,seed=s,perturb=1e-4,tlim=0.25,hdt=0.001,odt=0.01)
    manifest['total_sims']=len(files)
    Path('configs/manifest.json').write_text(json.dumps(manifest,indent=2))
    # threshold-specific run batches
    Path('config_groups.json').write_text(json.dumps({
        'threshold_2em5': [str(p) for p in files if '/A_' in str(p) or '/B_' in str(p) or '/D_' in str(p) or '/E_' in str(p) or 'kthr2p0em5' in str(p)],
        'threshold_1em5': [str(p) for p in files if 'kthr1p0em5' in str(p)],
        'threshold_5em6': [str(p) for p in files if 'kthr5p0em6' in str(p)],
    },indent=2))
    print('generated',len(files),'configs')
    for suite,items in manifest['suites'].items(): print(suite,len(items))
if __name__=='__main__': main()
