#!/usr/bin/env python3
"""Validation runner with per-config MPI ranks and early-collapse termination."""
import argparse, concurrent.futures as cf, json, os, re, subprocess, time
from pathlib import Path

def nproc_for(cfg):
 s=Path(cfg).read_text(); m=re.search(r'num_cores\s*=\s*(\d+)',s); return int(m.group(1)) if m else 16

def discover(config_dir): return [str(p) for p in sorted(Path(config_dir).glob('**/*.athinput'))]
def latest_dt(hst):
 try:
  for line in reversed(Path(hst).read_text(errors='ignore').splitlines()):
   if line and not line.startswith('#'):
    p=line.split()
    if len(p)>=2: return float(p[0]),float(p[1])
 except Exception: pass
 return None,None
def stop(proc):
 try: proc.terminate()
 except: pass
 time.sleep(3)
 if proc.poll() is None:
  try: proc.kill()
  except: pass
def run_one(cfg,athena,root,timeout,dt_kill,kill_checks,poll):
 cfg=str(Path(cfg).resolve()); pid=Path(cfg).stem; nproc=nproc_for(cfg)
 for pat in [pid+'.hst',pid+'*.athdf',pid+'*.xdmf']:
  for f in Path(root).glob(pat):
   try:f.unlink()
   except:pass
 cmd=['mpirun','-np',str(nproc),athena,'-i',cfg]
 env=os.environ.copy(); env['OMP_NUM_THREADS']='1'; env.setdefault('OMPI_MCA_btl_vader_single_copy_mechanism','none')
 t0=time.time(); hits=0
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  while p.poll() is None:
   if time.time()-t0>timeout:
    stop(p); return {'pid':pid,'status':'TIMEOUT','wall_s':round(time.time()-t0,1),'returncode':-1,'nproc':nproc,'config':cfg}
   t,dt=latest_dt(Path(root)/(pid+'.hst'))
   if dt is not None and dt<=dt_kill:
    hits+=1
    if hits>=kill_checks:
     stop(p); return {'pid':pid,'status':'COLLAPSE_EARLY','wall_s':round(time.time()-t0,1),'returncode':p.poll(),'nproc':nproc,'config':cfg,'collapse_t':t,'collapse_dt':dt,'dt_kill':dt_kill}
   else: hits=0
   time.sleep(poll)
 except Exception as e:
  stop(p); return {'pid':pid,'status':f'ERROR:{e}','wall_s':round(time.time()-t0,1),'returncode':-2,'nproc':nproc,'config':cfg}
 rc=p.wait(); out,err=p.communicate()
 return {'pid':pid,'status':'OK' if rc==0 else f'FAIL({rc})','wall_s':round(time.time()-t0,1),'returncode':rc,'nproc':nproc,'config':cfg,'stdout_tail':(out or '')[-1000:],'stderr_tail':(err or '')[-1000:]}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--athena_path',default='/home/fetch-agi/athena/bin/athena');ap.add_argument('--config_dir',default='configs');ap.add_argument('--max_concurrent',type=int,default=12);ap.add_argument('--timeout',type=int,default=21600);ap.add_argument('--dt_kill',type=float,default=2e-5);ap.add_argument('--kill_checks',type=int,default=3);ap.add_argument('--poll',type=float,default=20);a=ap.parse_args();root=str(Path.cwd().resolve());cs=discover(a.config_dir)
 print('='*60,flush=True);print('DEFINITIVE VALIDATION RUNNER — VARIABLE RANKS',flush=True);print('='*60,flush=True);print(f'Root: {root}',flush=True);print(f'Configs: {len(cs)}',flush=True);print(f'Max concurrent: {a.max_concurrent}',flush=True);print(f'dt_kill={a.dt_kill:g}, poll={a.poll}s',flush=True)
 results=[]
 with cf.ThreadPoolExecutor(max_workers=a.max_concurrent) as ex:
  futs={ex.submit(run_one,c,a.athena_path,root,a.timeout,a.dt_kill,a.kill_checks,a.poll):c for c in cs}
  for i,f in enumerate(cf.as_completed(futs),1):
   r=f.result();results.append(r);print(f'[{i}/{len(cs)}] {r["pid"]}: {r["status"]} ({r["wall_s"]}s)',flush=True);Path('definitive_results_partial.json').write_text(json.dumps(results,indent=2))
 Path('definitive_results.json').write_text(json.dumps(results,indent=2));from collections import Counter;print('COMPLETE',len(results),dict(Counter(r['status'] for r in results)),flush=True)
if __name__=='__main__':main()
