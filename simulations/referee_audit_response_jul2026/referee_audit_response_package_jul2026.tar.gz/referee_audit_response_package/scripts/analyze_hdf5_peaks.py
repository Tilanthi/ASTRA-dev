#!/usr/bin/env python3
import glob, os, re, json
import numpy as np
try:
 import h5py
except Exception as e:
 print('NO_H5PY',e); raise SystemExit
try:
 from scipy.signal import find_peaks
except Exception:
 find_peaks=None

def parse(pid):
 def g(p,cast=str,default=None):
  m=re.search(p,pid); return cast(m.group(1)) if m else default
 return {'pid':pid,'f':g(r'_f([0-9.]+)',float),'beta':g(r'_b([0-9.]+)',float),'theta':g(r'_th([0-9.]+)',float),'Lx':g(r'_Lx([0-9]+)',int),'seed':g(r'_s([0-9]+)',int)}

def get_density(f):
 for key in ['rho','dens','density','prim']:
  if key in f:
   a=f[key][:]
   return a
 # search first 3D+ float dataset
 def walk(g):
  for k,v in g.items():
   if hasattr(v,'shape') and len(v.shape)>=3:
    return v[:]
   if isinstance(v,h5py.Group):
    r=walk(v)
    if r is not None: return r
 return walk(f)

def profile_for(arr):
 # Athena data often (nz,ny,nx) or (nvar,nz,ny,nx) or meshblocks; squeeze/average transverse
 a=np.array(arr).squeeze()
 while a.ndim>3: a=a[0]
 if a.ndim!=3: return None
 means=a.mean(axis=(0,1,2))
 # try axes with largest positive variance as longitudinal; average other two
 best=None
 for axis in range(3):
  axes=tuple(i for i in range(3) if i!=axis)
  prof=a.mean(axis=axes)
  score=np.nanstd(prof)/(np.nanmean(prof)+1e-30)
  if best is None or score>best[0]: best=(score,axis,prof)
 return best[1],best[2]

def analyze(pid):
 files=sorted(glob.glob(pid+'*.athdf'))
 out=[]
 for fn in files:
  try:
   with h5py.File(fn,'r') as f:
    a=get_density(f)
    if a is None: continue
    axis,prof=profile_for(a)
    if prof is None or len(prof)<8: continue
    n=len(prof); mx=np.nanmax(prof); mn=np.nanmin(prof); mean=np.nanmean(prof)
    peaks=[]
    if find_peaks is not None:
     distance=max(3,n//20); height=mean+(mx-mean)*0.05
     peaks,_=find_peaks(prof,height=height,distance=distance)
    # periodic peak count incl wrap
    npeaks=len(peaks)
    spacing=np.diff(peaks)* (parse(pid)['Lx'] or 24)/n if npeaks>=2 else []
    out.append({'file':os.path.basename(fn),'n':int(n),'axis':axis,'mean':float(mean),'max':float(mx),'contrast':float(mx/mean) if mean else None,'npeaks':int(npeaks),'peaks':[int(x) for x in peaks],'median_spacing_lambdaJ':float(np.median(spacing)) if len(spacing) else None,'lambda_over_W':float(np.median(spacing)/0.3) if len(spacing) else None})
  except Exception as e: out.append({'file':os.path.basename(fn),'error':str(e)})
 return out

def main():
 pids=sorted(set(re.sub(r'\.prim\..*','',os.path.basename(x)) for x in glob.glob('*.athdf')))
 res={}
 for pid in pids:
  rec=parse(pid); rec['snapshots']=analyze(pid); res[pid]=rec
  valid=[s for s in rec['snapshots'] if 'error' not in s]
  rec['max_npeaks']=max([s['npeaks'] for s in valid],default=0)
  rec['any_beading']=bool(valid and max(s['npeaks'] for s in valid)>=2)
  lams=[s['lambda_over_W'] for s in valid if s.get('lambda_over_W') is not None]
  rec['lambda_W_candidates']=lams[-5:]
 open('hdf5_peak_analysis.json','w').write(json.dumps(res,indent=2))
 print('pids',len(res))
 print('any_beading',sum(1 for r in res.values() if r['any_beading']))
 for pid,r in sorted(res.items()):
  if r['any_beading']: print('BEAD',pid,r['max_npeaks'],r['lambda_W_candidates'])
if __name__=='__main__': main()
