#!/usr/bin/env python3
import json, re, csv
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'; FIGS=ROOT/'figures'; FIGS.mkdir(exist_ok=True)
files={'original_audit66':'original_audit66_results.json','referee_validation_main71':'referee_validation_main71_results.json','referee_validation_kthr1em5':'referee_validation_kthr1em5_results.json','referee_validation_kthr5em6':'referee_validation_kthr5em6_results.json','definitive67':'definitive67_results.json'}
allr=[]
for src,fn in files.items():
 p=DATA/fn
 for r in json.load(open(p)):
  r=dict(r);r['source']=src;allr.append(r)

def parse(pid):
 def g(pat,cast=str,default=None):
  m=re.search(pat,pid); return cast(m.group(1)) if m else default
 suite='other'
 if pid.startswith('AUDIT_Lx'): suite='original_domain'
 elif pid.startswith('AUDIT_f2th') or re.match(r'AUDIT_f[0-9.]+_f',pid): suite='original_audit'
 elif pid.startswith('AUDIT_'): suite='original_audit'
 elif pid.startswith('VAL_seed'): suite='seeding'
 elif pid.startswith('VAL_rep'): suite='fiducial_replication'
 elif pid.startswith('VAL_kthr'): suite='kill_threshold'
 elif pid.startswith('VAL_t1res'): suite='t1_resolution'
 elif pid.startswith('VAL_stab'): suite='stability'
 elif pid.startswith('DEF_seed'): suite='def_seed_ladder'
 elif pid.startswith('DEF_rep'): suite='def_fiducial_replication'
 elif pid.startswith('DEF_long'): suite='def_long_survival'
 elif pid.startswith('DEF_t1res'): suite='def_t1res32'
 elif pid.startswith('DEF_grid'): suite='def_geometry_beta'
 elif pid.startswith('DEF_domain'): suite='def_domain_lowseed'
 amp=None
 for token,val in [('seed1e0',1.0),('seed1em1',0.1),('seed1em2',0.01),('seed1em3',1e-3),('seed1em4',1e-4),('rep1em3',1e-3),('rep1em4',1e-4)]:
  if token in pid: amp=val
 if 'p1em4' in pid: amp=1e-4
 if pid.startswith('VAL_t1res'): amp=0.01
 if pid.startswith('DEF_t1res'): amp=0.01
 if pid.startswith('DEF_grid'): amp=1e-3
 if pid.startswith('DEF_long') or pid.startswith('DEF_domain'): amp=1e-4
 kthr=None
 for token,val in [('kthr2em05',2e-5),('kthr1em05',1e-5),('kthr5em06',5e-6)]:
  if token in pid:kthr=val
 return {'f':g(r'_f([0-9.]+)',float),'beta':g(r'_b([0-9.]+)',float),'theta':g(r'_th([0-9.]+)',float),'Lx':g(r'_Lx([0-9]+)',int),'seed':g(r'_s([0-9]+)',int),'suite':suite,'amp':amp,'kthr':kthr}
rows=[]
for r in allr:
 p=parse(r['pid']);p.update(r);rows.append(p)
# identify invalid T1res32 first-pass fake OKs
for r in rows:
 r['valid_physical']=not (r['suite']=='t1_resolution' and r['status']=='OK')
# per-run CSV
with open(DATA/'all_runs_combined.csv','w',newline='') as f:
 fields=['source','suite','pid','status','valid_physical','f','beta','theta','Lx','seed','amp','kthr','wall_s','collapse_t','collapse_dt','dt_kill','nproc','returncode']
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
# summary tables
valid=[r for r in rows if r['valid_physical']]
summary={'total_results_records':len(rows),'valid_physical_runs':len(valid),'invalid_excluded_runs':len(rows)-len(valid),'status_counts':dict(Counter(r['status'] for r in valid)),'suite_counts':dict(Counter(r['suite'] for r in valid)),'key_tables':{}}
# seed ladder combined
seed=[r for r in valid if r['suite'] in ('seeding','def_seed_ladder') and r['amp'] is not None and r.get('collapse_t') is not None]
by=defaultdict(list)
for r in seed:by[(r['amp'],r['f'],r['theta'])].append(r['collapse_t'])
seed_table=[{'amp':k[0],'f':k[1],'theta':k[2],'n':len(v),'collapse_t_mean':float(np.mean(v)),'collapse_t_std':float(np.std(v)),'collapse_t_median':float(np.median(v))} for k,v in sorted(by.items())]
summary['key_tables']['seeding_ladder']=seed_table
# domain
dom=[r for r in valid if r['suite']=='def_domain_lowseed' and r.get('collapse_t') is not None]
summary['key_tables']['domain_lowseed']=[{'Lx':r['Lx'],'collapse_t':r['collapse_t'],'collapse_dt':r['collapse_dt'],'wall_s':r['wall_s']} for r in sorted(dom,key=lambda x:x['Lx'])]
# fiducial
fid=[r for r in valid if r['suite'] in ('fiducial_replication','def_fiducial_replication') and r.get('collapse_t') is not None]
by=defaultdict(list)
for r in fid:by[(r['amp'],r['source'])].append(r['collapse_t'])
summary['key_tables']['fiducial_replication']=[{'amp':k[0],'source':k[1],'n':len(v),'collapse_t_mean':float(np.mean(v)),'collapse_t_std':float(np.std(v))} for k,v in sorted(by.items(),key=lambda x:(x[0][0],x[0][1]))]
# geometry beta
geo=[r for r in valid if r['suite']=='def_geometry_beta' and r.get('collapse_t') is not None]
by=defaultdict(list)
for r in geo:by[(r['f'],r['beta'],r['theta'])].append(r['collapse_t'])
summary['key_tables']['geometry_beta']=[{'f':k[0],'beta':k[1],'theta':k[2],'n':len(v),'collapse_t_mean':float(np.mean(v)),'collapse_t_std':float(np.std(v))} for k,v in sorted(by.items())]
# kill threshold
kt=[r for r in valid if r['suite']=='kill_threshold' and r.get('collapse_t') is not None]
by=defaultdict(list)
for r in kt:by[(r['kthr'] or r.get('dt_kill'))].append(r['collapse_t'])
summary['key_tables']['kill_threshold']=[{'dt_kill':k,'n':len(v),'collapse_t_mean':float(np.mean(v)),'collapse_t_std':float(np.std(v))} for k,v in sorted(by.items() if not isinstance(by,defaultdict) else by.items())]
# HDF5 physical beading
h5=json.load(open(DATA/'hdf5_physical_beading_analysis.json'))
summary['hdf5_physical_beading']={'n_pids':len(h5),'n_any_physical_beading':sum(1 for r in h5.values() if r.get('any_physical_beading')),'max_interior_peaks_max':max(r.get('max_interior_peaks',0) for r in h5.values())}
# T1 existing
summary['t1_plummer_existing']=json.load(open(DATA/'t1_plummer_existing_results.json'))
(DATA/'combined_summary.json').write_text(json.dumps(summary,indent=2))
# figures
plt.figure(figsize=(8,5))
for fval in sorted(set(r['f'] for r in seed if r['f'] is not None)):
 xs=[];ys=[]
 for amp in sorted(set(r['amp'] for r in seed)):
  vals=[r['collapse_t'] for r in seed if r['amp']==amp and r['f']==fval]
  if vals: xs.append(amp);ys.append(np.mean(vals))
 if xs: plt.plot(xs,ys,'o-',label=f'f={fval:g}')
plt.xscale('log');plt.xlabel('perturbation amplitude');plt.ylabel('collapse time');plt.title('Radial collapse time vs seed amplitude');plt.legend();plt.tight_layout();plt.savefig(FIGS/'seeding_ladder_collapse_time.png',dpi=180);plt.close()
plt.figure(figsize=(7,5))
xs=[r['Lx'] for r in dom];ys=[r['collapse_t'] for r in dom]
plt.plot(xs,ys,'o-',color='darkred');plt.xlabel('domain length Lx (lambda_J)');plt.ylabel('collapse time');plt.title('Low-seed domain-size collapse trend');plt.grid(True,alpha=.3);plt.tight_layout();plt.savefig(FIGS/'domain_lowseed_collapse_time.png',dpi=180);plt.close()
# status bar
plt.figure(figsize=(7,4))
c=Counter(r['status'] for r in valid);plt.bar(c.keys(),c.values(),color=['#c44e52','#55a868','#8172b2'][:len(c)]);plt.ylabel('runs');plt.title('Valid run classifications');plt.xticks(rotation=20);plt.tight_layout();plt.savefig(FIGS/'run_status_counts.png',dpi=180);plt.close()
print('wrote',DATA/'combined_summary.json',FIGS)
