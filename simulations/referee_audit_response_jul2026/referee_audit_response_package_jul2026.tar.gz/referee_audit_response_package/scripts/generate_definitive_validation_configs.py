#!/usr/bin/env python3
"""Generate overnight definitive validation suite (v3).
Adds lower seeding amplitudes, original-seed fiducial replication, long survival probes,
corrected T1res32 MPI-rank configurations, and expanded near-critical geometry/beta coverage.
"""
import json
from pathlib import Path
FOUR_PI_G=39.4784176044; W_CORE=0.3

def fmt_amp(a):
    return {1.0:'1e0',0.1:'1em1',0.01:'1em2',1e-3:'1em3',1e-4:'1em4'}[a]

def make_cfg(pid,f,beta,theta,Lx,seed,perturb=1e-4,cells_per_lambda=64,nproc=16,tlim=0.12,hdt=0.001,odt=0.01):
    nx=int(Lx*cells_per_lambda); ny=64; nz=64
    # make x1 meshblocks as small as possible while ensuring nx/mb_x1 == nproc
    mbx=32
    while mbx < nx and (nx % mbx or nx//mbx != nproc):
        mbx += 32
    if nx//mbx != nproc:
        # fallback: request nproc=1 style serial-safe decomposition
        mbx=nx; nproc=1
    return f"""<comment>
problem   = {pid}
f={f} beta={beta} theta={theta} Lx={Lx} seed={seed} perturb_ampl={perturb} cells_per_lambda={cells_per_lambda} nproc={nproc}

<job>
problem_id      = {pid}
max_runtime     = 21600
num_cores       = {nproc}
restart_file    =

<output1>
file_type   = hdf5
variable    = prim
dt          = {odt}
id          = prim
data_dir    = ./{pid}/

<output2>
file_type   = hst
dt          = {hdt}
id          = hst
data_dir    = ./{pid}/

<time>
cfl_number  = 0.3
tlim        = {tlim}
nlim        = -1

<mesh>
nx1         = {nx}
x1min       = 0.0
x1max       = {Lx}
ix1_bc      = periodic
ox1_bc      = periodic
nx2         = {ny}
x2min       = -0.5
x2max       = 0.5
ix2_bc      = user
ox2_bc      = user
nx3         = {nz}
x3min       = -0.5
x3max       = 0.5
ix3_bc      = user
ox3_bc      = user

<meshblock>
nx1 = {mbx}
nx2 = {ny}
nx3 = {nz}

<hydro>
gamma           = 1.0
iso_sound_speed  = 1.0

<gravity>
grav_mean_rho   = 1.0

<problem>
four_pi_G       = {FOUR_PI_G}
f_line_mass     = {f}
plasma_beta     = {beta}
theta_deg       = {theta}
mach_number     = 1.0
perturb_ampl    = {perturb}
random_seed     = {seed}
W_core          = {W_CORE}
"""

def add(manifest,suite,pid,**kw):
    d=Path('configs')/suite; d.mkdir(parents=True,exist_ok=True)
    p=d/(pid+'.athinput'); p.write_text(make_cfg(pid,**kw))
    manifest['suites'].setdefault(suite,[]).append({'pid':pid,'config':str(p),**kw})

def main():
    manifest={'purpose':'Overnight definitive referee-response validation suite','suites':{},'total_sims':0}
    # A2: extend seeding ladder downward
    pts=[(1.0,1.0,0.0),(1.5,1.0,0.0),(2.0,1.0,0.0),(2.0,1.0,90.0)]
    for amp in [1e-3,1e-4]:
      for f,beta,theta in pts:
       for s in [42,137,251]:
        pid=f'DEF_seed{fmt_amp(amp)}_f{f:.1f}_b{beta:.1f}_th{theta:.0f}_Lx24_s{s}'
        add(manifest,'A2_seed_ladder',pid,f=f,beta=beta,theta=theta,Lx=24,seed=s,perturb=amp,tlim=0.16)
    # B2: fiducial replication with original campaign seed convention, low amplitudes
    for amp in [1e-3,1e-4]:
      for s in [1,2,3]:
        pid=f'DEF_rep{fmt_amp(amp)}_f1.5_b1.0_th0_Lx24_s{s}'
        add(manifest,'B2_fiducial_original_seeds',pid,f=1.5,beta=1.0,theta=0.0,Lx=24,seed=s,perturb=amp,tlim=0.30)
    # C2: long survival probes at low amplitude; allow enough t to detect beading if present
    for Lx in [24,48]:
      for th in [0.0,90.0]:
        for s in [42,137]:
          pid=f'DEF_long_f1.5_b1.0_th{th:.0f}_Lx{Lx}_s{s}'
          add(manifest,'C2_long_survival',pid,f=1.5,beta=1.0,theta=th,Lx=Lx,seed=s,perturb=1e-4,tlim=0.50)
    # D2: corrected T1res32 (nproc=24 because nx=768/mbx=32 -> 24 x1 blocks)
    for f in [1.0,1.5,2.0]:
      for s in [42,137]:
        pid=f'DEF_t1res32np24_f{f:.1f}_b1.0_th0_Lx24_s{s}'
        add(manifest,'D2_t1res32_corrected',pid,f=f,beta=1.0,theta=0.0,Lx=24,seed=s,perturb=1e-2,cells_per_lambda=32,nproc=24,tlim=0.16)
    # E2: broader near-critical geometry and beta coverage at low seed
    for f in [1.0,1.2,1.5]:
      for beta in [0.3,1.0,2.0]:
        for th in [0.0,90.0]:
          pid=f'DEF_grid_f{f:.1f}_b{beta:.1f}_th{th:.0f}_Lx24_s42'
          add(manifest,'E2_nearcritical_geometry_beta',pid,f=f,beta=beta,theta=th,Lx=24,seed=42,perturb=1e-3,tlim=0.20)
    # F2: domain dependence at low seed, original critical f=1.5
    for Lx in [8,16,24,32,48]:
      pid=f'DEF_domain_f1.5_b1.0_th0_Lx{Lx}_s42'
      add(manifest,'F2_domain_lowseed',pid,f=1.5,beta=1.0,theta=0.0,Lx=Lx,seed=42,perturb=1e-4,tlim=0.30)
    manifest['total_sims']=sum(len(v) for v in manifest['suites'].values())
    Path('configs').mkdir(exist_ok=True)
    Path('configs/manifest_definitive.json').write_text(json.dumps(manifest,indent=2))
    print('total',manifest['total_sims'])
    for k,v in manifest['suites'].items(): print(k,len(v))
if __name__=='__main__': main()
