#!/usr/bin/env python3
"""Generate T1-exploration configs (Jul 2026, astra-pa).

Suite E_equil : subcritical f = {0.5, 0.7, 0.9}, seeds {42,137} -- filaments
                that never radially collapse, giving the cleanest possible
                intrinsic-width measurement for the T1 forward model.
Suite E_hires : transverse-resolution convergence (ny=nz=128 vs 64) at
                f=0.7 (equilibrium) and f=1.5 (collapsing), seed 42.
"""
from pathlib import Path

FOUR_PI_G = 39.4784176044
W_CORE = 0.3


def make_cfg(pid, f, beta, theta, Lx, seed, ny=64, nproc=16, tlim=0.5,
             hdt=0.001, odt=0.01, perturb=1e-2):
    nx = int(Lx * 64)
    mbx = nx // nproc
    assert nx % nproc == 0 and mbx >= 32
    return f"""<comment>
problem   = {pid}
f={f} beta={beta} theta={theta} Lx={Lx} seed={seed} ny={ny} nproc={nproc} odt={odt}

<job>
problem_id      = {pid}
max_runtime     = 21600
num_cores       = {nproc}
restart_file    =

<output1>
file_type   = hdf5
variable    = prim
dt          = {odt}
id          = prim
data_dir    = ./{pid}/

<output2>
file_type   = hst
dt          = {hdt}
id          = hst
data_dir    = ./{pid}/

<time>
cfl_number  = 0.3
tlim        = {tlim}
nlim        = -1

<mesh>
nx1         = {nx}
x1min       = 0.0
x1max       = {Lx}
ix1_bc      = periodic
ox1_bc      = periodic
nx2         = {ny}
x2min       = -0.5
x2max       = 0.5
ix2_bc      = user
ox2_bc      = user
nx3         = {ny}
x3min       = -0.5
x3max       = 0.5
ix3_bc      = user
ox3_bc      = user

<meshblock>
nx1 = {mbx}
nx2 = {ny}
nx3 = {ny}

<hydro>
gamma           = 1.0
iso_sound_speed  = 1.0

<gravity>
grav_mean_rho   = 1.0

<problem>
four_pi_G       = {FOUR_PI_G}
f_line_mass     = {f}
plasma_beta     = {beta}
theta_deg       = {theta}
mach_number     = 1.0
perturb_ampl    = {perturb}
random_seed     = {seed}
W_core          = {W_CORE}
"""


out = Path('configs')
n = 0
for f in (0.5, 0.7, 0.9):
    for seed in (42, 137):
        pid = f'E_f{f}_b1.0_th0_Lx8_s{seed}'
        (out / 'E_equil').mkdir(parents=True, exist_ok=True)
        (out / 'E_equil' / f'{pid}.athinput').write_text(
            make_cfg(pid, f, 1.0, 0.0, 8, seed, nproc=8, tlim=0.5))
        n += 1
# hi-res convergence pair (ny=nz=128)
(out / 'E_hires').mkdir(parents=True, exist_ok=True)
(out / 'E_hires' / 'E_f0.7_b1.0_th0_Lx8_s42_hr.athinput').write_text(
    make_cfg('E_f0.7_b1.0_th0_Lx8_s42_hr', 0.7, 1.0, 0.0, 8, 42,
             ny=128, nproc=16, tlim=0.5))
(out / 'E_hires' / 'E_f1.5_b1.0_th0_Lx8_s42_hr.athinput').write_text(
    make_cfg('E_f1.5_b1.0_th0_Lx8_s42_hr', 1.5, 1.0, 0.0, 8, 42,
             ny=128, nproc=16, tlim=0.3))
n += 2
print(f'wrote {n} configs')
