#!/usr/bin/env python3
"""Campaign A analysis v2 -- density-contrast validation of 1/t_frag ~ f^0.39.

Fixes the per-meshblock misread in analyze_campaignA_density_contrast.py
(which measured contrast inside meshblock 0 only; the collapse clump is
generally elsewhere, so crossings were missed -> 'insufficient data').

For each run:
  * assemble the GLOBAL density grid from per-block athdf (ordered by
    LogicalLocations);
  * vol contrast(t)   = rho_max / rho_mean          (global);
  * trans contrast(t) = max/mean of the spine-averaged transverse column;
  * crossing times for thresholds {10, 100, 1000} (linear interpolation);
  * CFL-trigger times from the .hst at dt <= {1e-6, 1e-7}
    (dt = 1e-8 was not reached before early termination; these are the
    CFL-family proxies, same diagnostic family as the paper's trigger);
  * fit log(1/t) = a + alpha log(f) per diagnostic; compare to paper 0.39.

Run from the campaign directory:
  python3 analyze_campaignA_v2.py --out campaignA_density_contrast_timing_v2.json
"""
import argparse
import glob
import json
import re
from pathlib import Path

import h5py
import numpy as np

THRESHOLDS = [10.0, 100.0, 1000.0]
CFL_DTS = [1e-6, 1e-7]
PAPER_ALPHA = 0.39


def parse(pid):
    def g(p, cast, default=None):
        m = re.search(p, pid)
        return cast(m.group(1)) if m else default
    return {'pid': pid, 'f': g(r'_f([0-9.]+)', float),
            'beta': g(r'_b([0-9.]+)', float),
            'seed': g(r'_s([0-9.]+)', int)}


def global_rho(fn):
    with h5py.File(fn, 'r') as h5:
        prim = np.array(h5['prim'][0])          # (nb, nz, ny, nxb)
        loc = np.array(h5['LogicalLocations'])
    order = np.argsort(loc[:, 0])
    return np.concatenate([prim[i] for i in order], axis=2)  # (nz, ny, nx)


def contrasts(rho):
    vol = float(rho.max() / (rho.mean() + 1e-30))
    axis = int(np.argmax(rho.shape))            # longitudinal
    trans = rho.mean(axis=axis)
    tr = float(trans.max() / (trans.mean() + 1e-30))
    return vol, tr


def first_crossing(ts, vs, thr):
    ts = np.asarray(ts); vs = np.asarray(vs)
    o = np.argsort(ts); ts, vs = ts[o], vs[o]
    for i in range(1, len(ts)):
        if vs[i] >= thr:
            v0, v1, t0, t1 = vs[i - 1], vs[i], ts[i - 1], ts[i]
            if v1 == v0:
                return float(t1)
            return float(t0 + (t1 - t0) * (thr - v0) / (v1 - v0))
    return None


def cfl_time(hst, thr):
    try:
        d = np.loadtxt(hst, comments='#')
    except Exception:
        return None
    if d.ndim == 1:
        d = d[None, :]
    if d.shape[1] < 2:
        return None
    idx = np.where(d[:, 1] <= thr)[0]
    return float(d[idx[0], 0]) if len(idx) else None


def fit_alpha(fs, ts):
    fs = np.asarray(fs, float); ts = np.asarray(ts, float)
    m = np.isfinite(ts) & (ts > 0) & np.isfinite(fs) & (fs > 0)
    fs, ts = fs[m], ts[m]
    if len(fs) < 3:
        return None
    x, y = np.log(fs), np.log(1.0 / ts)
    a, b = np.polyfit(x, y, 1)
    ss_res = np.sum((y - (a * x + b)) ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    return {'alpha': float(a),
            'r2': float(1 - ss_res / ss_tot) if ss_tot > 0 else None,
            'n': int(len(fs))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--include', default='A_*')
    ap.add_argument('--odt', type=float, default=0.005)
    ap.add_argument('--out', default='campaignA_density_contrast_timing_v2.json')
    a = ap.parse_args()

    pids = sorted(set(re.sub(r'\.prim\..*$', '', Path(x).stem)
                      for x in glob.glob(f'{a.include}.prim.*.athdf')))
    print(f'{len(pids)} runs', flush=True)
    runs = []
    for pid in pids:
        rec = dict(parse(pid))
        snaps = sorted(glob.glob(f'{pid}.prim.*.athdf'),
                       key=lambda s: int(re.search(r'\.(\d+)\.athdf$', s).group(1)))
        ts, vols, trs = [], [], []
        for fn in snaps:
            ix = int(re.search(r'\.(\d+)\.athdf$', fn).group(1))
            try:
                rho = global_rho(fn)
            except Exception:
                continue
            v, tr = contrasts(rho)
            ts.append(ix * a.odt); vols.append(v); trs.append(tr)
        rec['n_snapshots'] = len(ts)
        rec['vol_contrast_max'] = max(vols) if vols else None
        for thr in THRESHOLDS:
            rec[f't_vol_{thr:g}'] = first_crossing(ts, vols, thr)
            rec[f't_trans_{thr:g}'] = first_crossing(ts, trs, thr)
        hst = f'{pid}.hst'
        for d in CFL_DTS:
            rec[f't_cfl_{d:g}'] = cfl_time(hst, d)
        runs.append(rec)
        print(f"{pid}: volmax={rec['vol_contrast_max']:.0f} "
              f"t100={rec['t_vol_100']} t1000={rec['t_vol_1000']}", flush=True)

    fits = {}
    for thr in THRESHOLDS:
        fits[f't_vol_{thr:g}'] = fit_alpha([r['f'] for r in runs],
                                           [r[f't_vol_{thr:g}'] for r in runs])
        fits[f't_trans_{thr:g}'] = fit_alpha([r['f'] for r in runs],
                                             [r[f't_trans_{thr:g}'] for r in runs])
    for d in CFL_DTS:
        fits[f't_cfl_{d:g}'] = fit_alpha([r['f'] for r in runs],
                                         [r[f't_cfl_{d:g}'] for r in runs])

    out = {'paper_alpha': PAPER_ALPHA, 'fits': fits, 'per_run': runs}
    Path(a.out).write_text(json.dumps(out, indent=2))
    print('\n=== exponent fits: log(1/t) = a + alpha log(f) ===')
    print(f'(paper CFL-trigger alpha = {PAPER_ALPHA})')
    for k, v in fits.items():
        if v:
            print(f'{k:>16}: alpha={v["alpha"]:.3f} r2={v["r2"]:.3f} n={v["n"]}')
        else:
            print(f'{k:>16}: insufficient data')


if __name__ == '__main__':
    main()
