#!/usr/bin/env python3
"""Synthesis figures for the referee follow-up report (Jul 2026)."""
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

A = json.load(open('campaignA_density_contrast_timing_v2.json'))
V3 = json.load(open('t1_forward_model_v3.json'))
EQ = json.load(open('t1_v3_equil_hires.json'))

# ---------- Fig A1: crossing times vs f ----------
runs = A['per_run']
fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
ax = axes[0]
for key, lab, mk in [('t_vol_10', 'contrast 10', 'o'),
                     ('t_vol_100', 'contrast 100', 's'),
                     ('t_vol_1000', 'contrast 1000', '^'),
                     ('t_cfl_1e-06', 'CFL dt≤1e-6', 'd')]:
    fs = [r['f'] for r in runs if r.get(key)]
    ts = [r[key] for r in runs if r.get(key)]
    ax.plot(fs, ts, mk, label=lab, ms=6, alpha=0.8)
ax.set_xlabel('f (line mass / critical)')
ax.set_ylabel('crossing time  t  [t_J]')
ax.set_title('Campaign A: collapse-time diagnostics vs f\n(all nearly f-independent)')
ax.legend(fontsize=8)
ax.grid(alpha=0.3)

ax = axes[1]
fits = A['fits']
names, alphas, labels = [], [], []
for k, v in fits.items():
    if v:
        names.append(k.replace('t_', '').replace('_', ' '))
        alphas.append(v['alpha'])
        labels.append(f"r²={v['r2']:.2f}, n={v['n']}")
ypos = np.arange(len(names))
ax.barh(ypos, alphas, color='steelblue', alpha=0.8)
for i, (a, l) in enumerate(zip(alphas, labels)):
    ax.text(a + 0.002 * np.sign(a + 1e-9), i, f'{a:+.3f}  ({l})',
            va='center', fontsize=8)
ax.axvline(0.39, color='r', ls='--', lw=1.5, label="paper CFL α=0.39 (MHD)")
ax.axvline(0, color='k', lw=0.5)
ax.set_yticks(ypos); ax.set_yticklabels(names, fontsize=8)
ax.set_xlabel('fitted exponent α in  1/t ∝ f^α')
ax.set_title('Exponent per diagnostic (hydro config)')
ax.legend(fontsize=8, loc='lower right')
ax.set_xlim(-0.15, 0.45)
ax.grid(alpha=0.3, axis='x')
plt.tight_layout()
plt.savefig('figA_crossing_times_and_exponents.png', dpi=150)
plt.close()

# ---------- Fig B1: W_form robustness ----------
fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
ax = axes[0]
# E-equilibrium set at t=0.04
xs, ys, cs = [], [], []
for r in EQ['runs']:
    ep = r['epochs'].get('t=0.040')
    if not ep:
        continue
    w = ep['raw'].get('W_gauss')
    if not w:
        continue
    xs.append(r['f']); ys.append(w)
    cs.append('crimson' if r['pid'].endswith('_hr') else 'steelblue')
ax.scatter(xs, ys, c=cs, s=60, zorder=3)
ax.axhline(np.mean(ys), color='k', ls='-', lw=1,
           label=f'mean = {np.mean(ys):.3f} ± {np.std(ys):.3f}')
ax.axhline(np.mean(ys) + np.std(ys), color='k', ls=':', lw=0.8)
ax.axhline(np.mean(ys) - np.std(ys), color='k', ls=':', lw=0.8)
ax.set_xlabel('f'); ax.set_ylabel('W_form (Gaussian FWHM)  [λ_J]')
ax.set_title('Equilibrium (relaxed) width, t=0.04\nred = hires 128 cells/λ_J (converged to 0.9%)')
ax.legend(fontsize=8); ax.grid(alpha=0.3)

# Fig B2: eta_plum vs epoch, both sets, with paper band
ax = axes[1]
for data, lab, c in [(V3, 'collapsing set (f=1.0–3.0)', 'steelblue'),
                     (EQ, 'equilibrium set (f=0.5–0.9)', 'darkgreen')]:
    eps, mus, sds = [], [], []
    for ep, agg in sorted(data['aggregates'].items()):
        v = agg.get('eta_plum')
        if v and v[2] >= 3:
            eps.append(float(ep.split('=')[1])); mus.append(v[0]); sds.append(v[1])
    if eps:
        ax.errorbar(eps, mus, yerr=sds, fmt='o-', color=c, label=lab,
                    ms=5, capsize=3)
ax.axhspan(0.606 - 0.072, 0.606 + 0.072, color='orange', alpha=0.25,
           label='paper η_W = 0.606 ± 0.072')
ax.axhspan(0.707 - 0.087, 0.707 + 0.087, color='red', alpha=0.18,
           label='paper η_W,P = 0.707 ± 0.087')
ax.axhline(0.606, color='orange', ls='--', lw=1)
ax.axhline(0.707, color='red', ls='--', lw=1)
ax.set_xlabel('epoch t [t_J]'); ax.set_ylabel('η_W = W_form / W_Plum(beam-conv)')
ax.set_title('Forward-modelled η_W vs epoch (mid beam 0.08 λ_J)\nvs paper values')
ax.legend(fontsize=7.5); ax.grid(alpha=0.3); ax.set_ylim(0.3, 1.1)
plt.tight_layout()
plt.savefig('figB_eta_W_forward_model.png', dpi=150)
plt.close()
print('figures written')
