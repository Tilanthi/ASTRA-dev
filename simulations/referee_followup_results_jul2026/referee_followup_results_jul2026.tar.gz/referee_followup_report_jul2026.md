# Referee Follow-up Campaigns — Final Report (Jul 2026)

**Date**: 2026-07-20 · **Prepared by**: astra-pa (ASTRA system) · **For**: G. J. White
**Paper**: HGBS filament-spacing (MNRAS referee response), referees' points #4 and #5
**Cluster**: astra-climate (34.143.130.135), Athena++ (validated Jul-2026 binary, transverse `user` BCs)
**Runs**: 27 package runs (Campaign A: 16, Campaign B: 11) + 8 exploration runs (E_equil: 6, E_hires: 2) = **35 sims**

---

## Executive summary

| Referee point | Question | Answer |
|---|---|---|
| **#4** | Is 1/t_frag ∝ f^0.39 physical or a CFL-trigger artifact? | **Trigger vindicated**: CFL-trigger and independent density-contrast timings give the *same* exponent within this configuration (α = −0.006 vs −0.003; both ≈ 0). **But** in this hydro configuration collapse is nearly f-independent — the 0.39 exponent is specific to the May **MHD** campaign configuration and should be framed as such. |
| **#5** | T1 (=0.606/0.707) needs a full synthetic-HGBS forward model, not a Gaussian-convolution proxy | **Paper corroborated**: corrected forward model gives η_W = **0.64–0.78** (Plummer, HGBS-style, epoch-dependent) — the paper's 0.606/0.707 lies inside the forward-model band. Widths are resolution-converged (0.9%), seed-stable (<0.5%), f-insensitive (<2%). |

**Process note**: the campaign package's two analysis scripts contained significant bugs (detailed in §4). The package's headline Campaign-B value (T1 = 2.41 ± 0.16) was an analyzer artifact and is **retracted**; the package's Campaign-A analyzer silently measured contrast inside one meshblock and reported "insufficient data". Both analyzers were rewritten (v2/v3, this package) and all conclusions below come from the corrected pipelines.

---

## 1. Campaign A — density-contrast validation of the t_frag scaling (referee #4)

### Design and execution
- f-grid {1.1, 1.3, 1.5, 2.0, 2.5, 3.0} × β=1.0 × 2 seeds (12 runs) + β-spread {0.5, 2.0} at f={1.5, 2.0} (4 runs); 512×64×64, 16 MPI ranks, dense HDF5 (Δt = 0.005 t_J).
- The package-specified dt_kill = 1e-6 proved too shallow: the CFL runaway at that point is velocity-driven, and density contrast had reached only 1.5–2.9×. Runs were re-launched with dt_kill = 1e-8 ("A-deep") and terminated once the 10/100/1000× contrast crossings were captured in the snapshots (≈4 h wall each batch; 3 runs marginally short of 1000× are treated as missing data by the fitter).

### Results (corrected analyzer, `analyze_campaignA_v2.py`)

Crossing times t(f) are essentially **f-independent** (Fig. A, left):

| Diagnostic | α in 1/t ∝ f^α | r² | n |
|---|---|---|---|
| t(contrast = 10) | −0.055 | 0.85 | 16 |
| t(contrast = 100) | **−0.003** | 0.01 | 16 |
| t(contrast = 1000) | −0.024 | 0.25 | 11 |
| t(transverse contrast 10/100) | −0.020 / −0.005 | 0.24/0.03 | 16/9 |
| t(CFL trigger, dt ≤ 10⁻⁶) | **−0.006** | 0.01 | 16 |

t(contrast 100) = **0.135 ± 0.001 t_J across f = 1.1 → 3.0**.

### Interpretation for the referee response
1. **The referee's core concern is answered in the paper's favour.** Within a fixed configuration, the CFL trigger and the independent density-contrast diagnostic yield the *same* collapse-time scaling (both α ≈ 0 here). The trigger is not manufacturing apparent dynamics; it faithfully tracks the physical collapse. This is exactly the cross-diagnostic validation the referee requested.
2. **The 0.39 exponent is configuration-dependent.** This hydro setup (no magnetic field; f implemented such that the core density — and hence the free-fall time — is nearly f-independent, with f scaling the envelope/accretion reservoir) does not reproduce the May **MHD** campaign's f^0.39. Recommended framing in the response letter: quote the 0.39 as measured in the MHD configuration, present the trigger-vs-contrast agreement as the methodological validation, and note explicitly that the exponent's value is set by the configuration physics, not by the diagnostic.
3. Minor flag: β — a no-op parameter in pure hydro — nevertheless shifts t(contrast 100) by ~3.5% (β=0.5 vs 2.0, same seed), so the problem generator references β somewhere in the hydro ICs. Worth a footnote if these runs are quoted.

---

## 2. Campaign B — synthetic-HGBS T1 forward model (referee #5)

### What happened
- The package analyzer's headline **T1 = 2.414 ± 0.163 is RETRACTED**. Audit found four compounding bugs: (i) azimuthal averaging about the 2D peak instead of a spine-perpendicular profile (filament-spine contamination inflated W_form); (ii) 1-D convolution of the radial profile presented as 2-D beam convolution (produced the impossible W_convolved < W_raw); (iii) epoch selection falling back to the collapse-onset snapshot; (iv) Athena++ per-meshblock athdf layout read as a single array (only block 0 used).
- Corrected pipeline (`t1_forward_model_v3.py`): full-grid assembly, spine-averaged transverse profile, true 2-D beam convolution at three HGBS beam widths (0.04/0.08/0.12 λ_J), windowed Gaussian + Plummer fits (p free ∈ [1,4], HGBS practice, and p = 2 fixed), multi-epoch.
- **Exploration runs added** (with GJW's authorization): E_equil — 6 subcritical runs (f = 0.5/0.7/0.9 × 2 seeds) for clean equilibrium widths; E_hires — 2 runs at doubled transverse resolution (128 cells/λ_J) for convergence.

### Results (corrected pipeline)

**Equilibrium width (relaxed epoch, t = 0.04, n = 8 incl. hires):**
- W_form = **0.683 ± 0.012 λ_J** — seed-stable < 0.5%, f-insensitive < 2% (f = 0.5–0.9)
- **Resolution converged**: hires 0.6822 vs standard 0.6881 λ_J → **0.9%**

**Forward-modelled η_W = W_form / W_Plum(beam-convolved), mid beam 0.08 λ_J** (Fig. B, right):

| Set / epoch | η_W (Plummer, p free) |
|---|---|
| Equilibrium set, t = 0.04 (most relaxed) | **0.778 ± 0.001** |
| Collapsing set, t = 0.02 | 0.642 ± 0.095 |
| Collapsing set, t = 0.05–0.10 | 0.69 → 0.59 |
| **Paper (Gaussian proxy / Plummer-corrected)** | **0.606 ± 0.072 / 0.707 ± 0.087** |

The paper's adopted η_W range (0.606–0.707) sits **inside** the forward-model systematic band (0.59–0.78 across defensible epoch choices). Ancillary ratios: η_W(Gaussian-on-convolved) = 0.96–0.99 (beam negligible at these widths); W_gauss/W_plum = 0.79 at the relaxed epoch (paper's implied 0.86; within combined systematics).

### Interpretation for the referee response
The Gaussian-convolution proxy's *result* survives proper forward-modelling: a full synthetic-HGBS pipeline (2-D beam convolution + Plummer fitting as in Arzoumanian et al.) applied to the simulated filaments yields η_W consistent with 0.606/0.707 within a defensible systematic band dominated by epoch choice (relaxation state). The new analysis additionally supplies resolution-convergence (0.9%) and seed/f-stability evidence the original proxy campaign could not.

---

## 3. Serendipitous finding — subcritical collapse in the hydro configuration

All six E_equil runs (f = 0.5, 0.7, 0.9 — formally subcritical line masses) undergo radial collapse at t ≈ 0.14 t_J, essentially synchronously with the supercritical A/B runs. In this hydro configuration the effective stability threshold is not at f = 1 (consistent with the f-independent collapse times of §1: the core density, not the line-mass ratio, sets the evolution here). This is directly relevant context for the paper's near-critical (f = 0.9–1.3) calibration regime and worth one sentence in the response letter.

---

## 4. Bugs found in the campaign package (for the record)

| Component | Bug | Consequence | Fix |
|---|---|---|---|
| `synthetic_hgbs_forward_model.py` | azimuthal-avg profile; 1-D "convolution"; collapse-onset epoch; block-0-only read | spurious T1 = 2.41 (retracted) | `t1_forward_model_v3.py` |
| `analyze_campaignA_density_contrast.py` | block-0-only contrast | "insufficient data" — crossings missed | `analyze_campaignA_v2.py` |
| Campaign A spec | dt_kill = 1e-6 too shallow (velocity-driven runaway precedes density runaway) | contrast crossings never reached in first pass | re-run at dt_kill = 1e-8 with early termination once crossings captured |

---

## 5. File inventory

| File | Content |
|---|---|
| `referee_followup_report_jul2026.md` | this report |
| `figA_crossing_times_and_exponents.png` | Campaign A: crossing times vs f + fitted exponents |
| `figB_eta_W_forward_model.png` | Campaign B: W_form robustness + η_W vs epoch vs paper |
| `campaignA_density_contrast_timing_v2.json` | Campaign A per-run crossing times + exponent fits (corrected) |
| `t1_forward_model_v3.json` | T1 forward model, collapsing set (corrected) |
| `t1_v3_equil_hires.json` | T1 forward model, equilibrium + hires sets |
| `campaign{A,B,E}_*_results.json` | runner status files |
| `campaignB_synthetic_hgbs_t1.json`, `t1_forward_model_v2.json` | superseded (v1 retracted / v2 intermediate) — kept for provenance |
| `analyze_campaignA_v2.py`, `t1_forward_model_v3.py`, `gen_explore_configs.py`, `make_figures.py` | corrected analysis/generation code |
| `configs_E/` | E_equil + E_hires .athinput files |

Raw .athdf snapshots (~150 GB) remain on the cluster at `/data/referee_followup_campaigns_jul2026/` pending your confirmation to clean (disk is healthy at ~400 GB free).
