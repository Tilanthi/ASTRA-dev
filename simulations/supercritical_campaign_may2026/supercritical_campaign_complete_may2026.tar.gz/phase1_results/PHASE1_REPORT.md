# SUPERCRITICAL FILAMENT FRAGMENTATION — PHASE 1 ANALYSIS REPORT

**Date**: 2026-05-24
**Framework**: Semi-analytical MHD, calibrated against 600+ Athena++ runs
**Total simulations**: 192

---

## 1. Campaign Overview

### Scientific Question
Can λ/W (fragmentation spacing / filament width) be measured in the
supercritical regime (f > 1.5) where radial collapse dominates?
HGBS filaments occupy f ≈ 1.5–3.0 (supercritical regime), but
current measurements are only possible for f ≲ 1.3.

### Parameter Space Explored
| Parameter | Values | Count |
|-----------|--------|-------|
| f (line-mass) | [1.3, 1.4, 1.5, 2.0, 2.5, 3.0] | 6 |
| β (plasma beta) | [0.1, 0.3, 1.0, 3.0] | 4 |
| M (Mach number) | [0.5, 1.0, 3.0] | 3 |
| θ (field angle) | [0.0, 45.0, 90.0] | 3 |
| Seeds | [1, 2] | 2 |

---

## 2. Classification Results

### Overall (all 192 simulations)
| Category | Count | Fraction |
|----------|-------|----------|
| MEASURABLE | 50 | 26.0% |
| PARTIAL | 109 | 56.8% |
| COLLAPSED | 33 | 17.2% |
| STABLE | 0 | 0.0% |

### Supercritical only (f ≥ 1.5, 156 sims)
| Category | Count | Fraction |
|----------|-------|----------|
| MEASURABLE | 30 | 19.2% |
| PARTIAL | 93 | 59.6% |
| COLLAPSED | 33 | 21.2% |
| STABLE | 0 | 0.0% |

---

## 3. Transition Boundary Analysis

### Theoretical f_trans(β, M, θ)
| β | M | θ | f_trans (theory) | f_trans (empirical) | MEASURABLE? |
|---|---|---|------------------|--------------------|--------------|
| 0.1 | 1.0 | 0° | 3.300 | 2.00 | YES |
| 0.1 | 1.0 | 90° | 4.800 | 2.00 | YES |
| 0.3 | 1.0 | 0° | 1.967 | 1.50 | YES |
| 0.3 | 1.0 | 45° | 2.217 | 2.00 | YES |
| 0.3 | 1.0 | 90° | 2.467 | 2.00 | YES |
| 0.3 | 3.0 | 0° | 1.807 | 1.50 | YES |
| 0.3 | 3.0 | 45° | 2.057 | 2.00 | YES |
| 0.3 | 3.0 | 90° | 2.307 | 2.00 | YES |
| 1.0 | 0.5 | 0° | 1.500 | — | NO |
| 1.0 | 1.0 | 0° | 1.500 | 1.40 | YES |
| 1.0 | 1.0 | 45° | 1.575 | 1.50 | YES |
| 1.0 | 1.0 | 90° | 1.650 | 1.50 | YES |
| 1.0 | 3.0 | 0° | 1.340 | — | NO |
| 1.0 | 3.0 | 45° | 1.415 | 1.50 | YES |
| 1.0 | 3.0 | 90° | 1.490 | — | NO |
| 3.0 | 1.0 | 0° | 1.367 | — | NO |
| 3.0 | 1.0 | 45° | 1.392 | — | NO |
| 3.0 | 1.0 | 90° | 1.417 | 1.40 | YES |
| 3.0 | 3.0 | 0° | 1.207 | — | NO |
| 3.0 | 3.0 | 45° | 1.232 | — | NO |
| 3.0 | 3.0 | 90° | 1.257 | — | NO |

---

## 4. λ/W Results

### MEASURABLE cases
- Count: 50
- λ/W = 1.152 ± 0.693
- Range: [0.50, 3.58]
- f range: [1.30, 2.00]

### HGBS Matches (λ/W ≈ 2.8 ± 10%)
- 1 matches found
  - f=1.5, β=0.3, θ=0°, M=1.0: λ/W=2.834

### PARTIAL cases
- Count: 109
- λ/W (estimated) = 1.901 ± 0.885

---

## 5. Physical Interpretation

### Why radial collapse dominates in the supercritical regime
1. **Timescale competition**: For f > f_trans, the radial collapse
   timescale t_rad becomes shorter than the fragmentation timescale t_frag.
   Density peaks cannot grow to measurable amplitudes before the filament
   collapses radially.

2. **Magnetic support**: Strong magnetic fields (low β) extend the beading
   regime by braking radial collapse. The strongest effect occurs for
   longitudinal fields (θ ≈ 0°) where flux-freezing directly opposes
   radial contraction.

3. **Perpendicular fields**: θ ≈ 90° provides magnetic pressure support
   against radial collapse but simultaneously suppresses longitudinal
   perturbation growth. The net effect is ambiguous.

4. **Mach number**: Supersonic motions (M > 1) compress the filament,
   accelerating radial collapse and reducing f_trans.

### Beading conditions summary
- 30 MEASURABLE cases found for f ≥ 1.5
- Best conditions:
  - f=1.5, β=0.3, θ=0°, M=1.0: λ/W=2.364
  - f=1.5, β=0.3, θ=0°, M=1.0: λ/W=2.834
  - f=1.5, β=0.3, θ=45°, M=1.0: λ/W=0.814
  - f=1.5, β=0.3, θ=45°, M=1.0: λ/W=0.932
  - f=1.5, β=0.3, θ=90°, M=1.0: λ/W=0.647
  - f=1.5, β=0.3, θ=90°, M=1.0: λ/W=0.640
  - f=1.5, β=0.3, θ=0°, M=3.0: λ/W=2.356
  - f=1.5, β=0.3, θ=45°, M=3.0: λ/W=0.779
  - f=1.5, β=0.3, θ=45°, M=3.0: λ/W=0.737
  - f=1.5, β=0.3, θ=90°, M=3.0: λ/W=0.550
  - f=1.5, β=0.3, θ=90°, M=3.0: λ/W=0.555
  - f=1.5, β=1.0, θ=45°, M=1.0: λ/W=1.450
  - f=1.5, β=1.0, θ=90°, M=1.0: λ/W=1.122
  - f=1.5, β=1.0, θ=90°, M=1.0: λ/W=1.030
  - f=1.5, β=1.0, θ=45°, M=3.0: λ/W=1.296
  - f=2.0, β=0.3, θ=45°, M=1.0: λ/W=0.731
  - f=2.0, β=0.3, θ=45°, M=1.0: λ/W=0.817
  - f=2.0, β=0.3, θ=90°, M=1.0: λ/W=0.584
  - f=2.0, β=0.3, θ=90°, M=1.0: λ/W=0.593
  - f=2.0, β=0.3, θ=45°, M=3.0: λ/W=0.711
  - f=2.0, β=0.3, θ=45°, M=3.0: λ/W=0.729
  - f=2.0, β=0.3, θ=90°, M=3.0: λ/W=0.537
  - f=2.0, β=0.3, θ=90°, M=3.0: λ/W=0.510
  - f=1.5, β=0.1, θ=0°, M=1.0: λ/W=2.273
  - f=1.5, β=0.1, θ=90°, M=1.0: λ/W=0.500
  - f=1.5, β=0.1, θ=90°, M=1.0: λ/W=0.500
  - f=2.0, β=0.1, θ=0°, M=1.0: λ/W=2.282
  - f=2.0, β=0.1, θ=0°, M=1.0: λ/W=2.164
  - f=2.0, β=0.1, θ=90°, M=1.0: λ/W=0.500
  - f=2.0, β=0.1, θ=90°, M=1.0: λ/W=0.500

- 20 MEASURABLE cases at f = 1.3–1.4 (near transition)

---

## 6. Scientific Conclusion

**POSITIVE: Measurable λ/W found in supercritical regime**

### Recommendation
Proceed to Phase 2 for precise boundary calibration

### Implications for HGBS Paper

POSITIVE RESULT: Some parameter combinations allow measurable λ/W
in the supercritical regime. This opens the possibility of direct
comparison between simulations and HGBS observations at the same f values.
Phase 2 should precisely calibrate the boundary and characterize
the viable parameter region.

---

## 7. Output Files

| File | Description |
|------|-------------|
| phase1_all_results.csv | All 192 simulation results |
| phase1_transition_map.csv | Transition boundary mapping |
| phase1_summary.json | Comprehensive JSON summary |
| SC-1_regime_map_M*.png | Regime maps (f vs β, by θ) |
| SC-2_lambda_W_vs_f.png | λ/W for measurable/partial cases |
| SC-3_transition_boundary.png | f_trans boundary mapping |
| SC-4_parameter_coverage.png | Parameter space coverage |
| SC-5_timescale_competition.png | t_frag vs t_radial |
| SC-6_quality_metrics.png | σ_λ/λ, peak significance |
| PHASE1_REPORT.md | This report |

---

*Generated by ASTRA Supercritical Filament Fragmentation Campaign*
*Semi-analytical MHD framework calibrated against 600+ Athena++ runs*
