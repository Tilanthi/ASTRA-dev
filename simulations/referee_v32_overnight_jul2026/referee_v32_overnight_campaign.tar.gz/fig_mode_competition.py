#!/usr/bin/env python3
"""Key figure: axial profile evolution + collapse/mode-growth curves,
comparing rce-pgen (paper validated config) vs supercritical-pgen (replication).
Run on cluster in campaign dir. Outputs fig_mode_competition.png + .json series.
"""
import glob
import json
import re
from pathlib import Path

import h5py
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ODT = 0.005
RUNS = [
    ('R1_f2.0_b1.0_th0_r64_s42', 'rce pgen + user BCs (paper config)', 'C0'),
    ('R2_f2.0_b1.0_th0_r64_s42', 'supercritical pgen + reflecting (replication)', 'C3'),
]


def global_rho(fn):
    with h5py.File(fn, 'r') as h5:
        prim = np.array(h5['prim'][0])
        loc = np.array(h5['LogicalLocations'])
    nb, nzb, nyb, nxb = prim.shape
    rho = np.empty(((loc[:, 2].max() + 1) * nzb, (loc[:, 1].max() + 1) * nyb,
                    (loc[:, 0].max() + 1) * nxb), dtype=prim.dtype)
    for b in range(nb):
        xi, yi, zi = loc[b]
        rho[zi * nzb:(zi + 1) * nzb, yi * nyb:(yi + 1) * nyb,
            xi * nxb:(xi + 1) * nxb] = prim[b]
    return rho


fig, axes = plt.subplots(2, 2, figsize=(12, 8))
series_out = {}
for col, (pid, lab, colr) in enumerate(RUNS):
    snaps = sorted(glob.glob(f'{pid}.prim.*.athdf'),
                   key=lambda s: int(re.search(r'\.(\d+)\.athdf$', s).group(1)))
    ts, Cs, Pbs, profs = [], [], [], []
    for fn in snaps:
        ix = int(re.search(r'\.(\d+)\.athdf$', fn).group(1))
        try:
            rho = global_rho(fn)
        except Exception:
            continue
        t = ix * ODT
        prof = rho.mean(axis=(0, 1))
        d = prof / prof.mean() - 1.0
        C = float(rho.max() / rho.mean())
        P = np.abs(np.fft.rfft(d)) ** 2 / len(d)
        ts.append(t); Cs.append(C); Pbs.append(float(P[2:9].sum()))
        profs.append((t, prof / prof.mean()))
    series_out[pid] = {'t': ts, 'C': Cs, 'Pband': Pbs}
    ax = axes[0, col]
    nshow = min(6, len(profs))
    for j in range(0, len(profs), max(1, len(profs) // nshow)):
        t, p = profs[j]
        ax.plot(np.linspace(0, 8, len(p)), p, lw=1,
                label=f't={t:.3f}')
    ax.set_yscale('log')
    ax.set_xlabel('x [λ_J]'); ax.set_ylabel('ρ_axial / ⟨ρ⟩')
    ax.set_title(f'{pid}\n{lab}', fontsize=9)
    ax.legend(fontsize=6, ncol=2)
    ax.grid(alpha=0.3)
    ax = axes[1, col]
    ax.plot(ts, Cs, '-', color=colr, label='C = ρmax/ρmean (radial collapse)')
    ax2 = ax.twinx()
    ax2.plot(ts, Pbs, '--', color='orange',
             label='P_band (long. modes n=2..8)')
    ax.set_yscale('log'); ax2.set_yscale('log')
    ax.set_xlabel('t [t_J]'); ax.set_ylabel('C', color=colr)
    ax2.set_ylabel('P_band', color='orange')
    ax.set_title('radial collapse vs longitudinal mode growth', fontsize=9)
    ax.grid(alpha=0.3)
axes[0, 0].set_ylim(0.05, 500)
axes[0, 1].set_ylim(0.05, 500)
plt.suptitle('Radial-vs-longitudinal mode competition at f=2.0, β=1.0, r64 — two generators, identical ICs',
             fontsize=11)
plt.tight_layout()
plt.savefig('fig_mode_competition.png', dpi=140)
Path('fig_mode_competition_series.json').write_text(json.dumps(series_out))
print('fig written')
