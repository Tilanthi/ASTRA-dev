#!/usr/bin/env python3
"""R1 mode-competition resolution study configs (referee v32 point 1/3).

Resolution ladder at f=2.0, beta=1.0, ampl=1e-2, MHD+user BCs:
  RES64 : 512x64x64   (16 ranks) theta={0,90} x seeds {42,137}
  RES128: 512x128x128 (32 ranks) theta={0,90} x seeds {42,137}
  RES256: 512x256x256 (64 ranks) theta={0,90} x seed {42}
Dense snapshots (odt=0.005) for longitudinal-mode growth tracking.
"""
from pathlib import Path

FOUR_PI_G = 39.4784176044
W_CORE = 0.3


def make_cfg(pid, theta, seed, ny, nproc, mb, tlim=0.4, odt=0.005):
    nx = 512
    mb1, mb2, mb3 = mb
    return f"""<comment>
problem   = {pid}
f=2.0 beta=1.0 theta={theta} Lx=8 seed={seed} ampl=1e-2 res={ny}

<job>
problem_id      = {pid}
max_runtime     = 21600
num_cores       = {nproc}
restart_file    =

<output1>
file_type   = hdf5
variable    = prim
dt          = {odt}
id          = prim
data_dir    = ./{pid}/

<output2>
file_type   = hst
dt          = 0.001
id          = hst
data_dir    = ./{pid}/

<time>
cfl_number  = 0.3
tlim        = {tlim}
nlim        = -1

<mesh>
nx1         = {nx}
x1min       = 0.0
x1max       = 8
ix1_bc      = periodic
ox1_bc      = periodic
nx2         = {ny}
x2min       = -0.5
x2max       = 0.5
ix2_bc      = user
ox2_bc      = user
nx3         = {ny}
x3min       = -0.5
x3max       = 0.5
ix3_bc      = user
ox3_bc      = user

<meshblock>
nx1 = {mb1}
nx2 = {mb2}
nx3 = {mb3}

<mhd>
b_flag        = true
</mhd>

<hydro>
gamma           = 1.0
iso_sound_speed  = 1.0

<gravity>
grav_mean_rho   = 1.0

<problem>
four_pi_G       = {FOUR_PI_G}
f_line_mass     = 2.0
plasma_beta     = 1.0
theta_deg       = {theta}
mach_number     = 1.0
perturb_ampl    = 1e-2
random_seed     = {seed}
W_core          = {W_CORE}
"""


out = Path('configs')
n = 0
for theta in (0, 90):
    for seed in (42, 137):
        pid = f'R1_f2.0_b1.0_th{theta}_r64_s{seed}'
        d = out / 'R1_res64'
        d.mkdir(parents=True, exist_ok=True)
        (d / f'{pid}.athinput').write_text(
            make_cfg(pid, theta, seed, 64, 16, (32, 64, 64)))
        n += 1
        pid = f'R1_f2.0_b1.0_th{theta}_r128_s{seed}'
        d = out / 'R1_res128'
        d.mkdir(parents=True, exist_ok=True)
        (d / f'{pid}.athinput').write_text(
            make_cfg(pid, theta, seed, 128, 32, (32, 64, 128)))
        n += 1
    pid = f'R1_f2.0_b1.0_th{theta}_r256_s42'
    d = out / 'R1_res256'
    d.mkdir(parents=True, exist_ok=True)
    (d / f'{pid}.athinput').write_text(
        make_cfg(pid, theta, 42, 256, 64, (32, 64, 128)))
    n += 1
print(f'wrote {n} R1 configs')
