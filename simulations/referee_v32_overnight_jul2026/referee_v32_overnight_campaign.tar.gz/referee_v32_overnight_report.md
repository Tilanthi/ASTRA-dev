# Overnight Simulation Campaign — Referee Report v32 Response (Jul 2026)

**Date**: 2026-07-21 · **Prepared by**: astra-pa (cluster-side ASTRA) · **For**: G. J. White's external ASTRA (paper revision)
**Trigger**: referee report on `filament_spacing_streamlined_mnras_v32.pdf` — major concerns 1–3 (simulation-based)
**New simulations**: 24 runs overnight (R1: 12, R2: 12 incl. replications), 2 Athena++ binaries, ~15 kCPU-h
**Headline**: the supercritical negative result is **resolution-robust within the paper's own configuration** (referee pt 1), but it **fails independent replication with a different problem generator** (referee pt 2) — with the replication generator, supercritical filaments **bead longitudinally** (3–4 peaks, λ/W ≈ 0.7–1.6), and the difference traces to the boundary-condition/equilibrium implementation, not to resolution or to physics parameters.

---

## 1. Campaign design

| Campaign | Referee point | Design | Runs |
|---|---|---|---|
| **R1** — mode-competition resolution ladder | #1 (and #3 for θ=90°) | Paper's validated config (`filament_rce` pgen, transverse `user` BCs, MHD, f=2.0, β=1.0, ampl=10⁻²), transverse resolution 64→128→256 cells/λ_J, θ={0°,90°}, dense HDF5 | 12 |
| **R2** — independent replication | #2 (and #3) | NEW binary compiled with `filament_supercritical` pgen (the May-campaign generator) + reflecting transverse BCs; **identical initial conditions and physics parameters**; ampl={10⁻²,10⁻⁴}, r64+r128, θ={0°,90°} | 12 |

Custom analysis (`analyze_mode_competition.py`, full 3-D meshblock assembly): per snapshot, axial profile ρ̄(x), fragmentation-band mode power (n=2–8, λ≈1–4 λ_J), radial contrast C(t), and interior-peak counts (beading discriminant) — measuring the *mode competition itself*, exactly what the referee asked for ("not global fragmentation timing").

---

## 2. Results

### 2.1 R1 — the negative result is resolution-robust in the paper's configuration

| Run | C_final | axial rms_final | **interior peaks** | Γ_mode (dex/t_J) |
|---|---|---|---|---|
| r64 θ=0° (2 seeds) | 676–1009 | 1.3–1.6 | **0 / 0** | 50–56 |
| r128 θ=0° (2 seeds) | 461–1409 | 1.2–1.2 | **0 / 0** | 76–78 |
| r256 θ=0° (1 seed) | 317 | 1.09 | **0** | 90.0 |
| r64 θ=90° (2 seeds) | 7022–14423 | 1.4–1.4 | **0 / 0** | 49–55 |
| r128 θ=90° (2 seeds) | 15905–59339 | 1.3–1.4 | **0 / 0** | 73–75 |
| r256 θ=90° (1 seed) | 861 | 1.13 | **0** | 82.8 |

- **Zero interior axial peaks at every resolution, both field geometries** — the supercritical radial-collapse negative result does not weaken as transverse resolution quadruples.
- Longitudinal-mode growth *is* faster at higher resolution (Γ_mode +45% from r64→r128), directly confirming the referee's intuition that resolution matters for mode growth — but radial collapse still outruns it by the same large margin (Fig. `fig_mode_competition.png`, left panels: the axial profile stays uniform until a broad n=1 swell, never fragmentation-scale peaks).
- The large final axial rms (~1.3–1.6) is **not** beading: it is a smooth n=1 asymmetry (gas sloshing) with zero interior maxima — important nuance for how the paper quotes its "<0.02% axial variance" metric (see §4, item 6).

### 2.2 R2 — the negative result FAILS independent replication

With the `filament_supercritical` generator (reflecting transverse BCs) and **byte-identical initial density profiles, line masses, β, and Kolmogorov velocity seeding** (verified in source: same ρ = 1 + ρ_amp e^{−r²/2W²}, same ρ_amp formula, same 12-mode k^{-11/6} seeding):

| Run | collapse time | **interior peaks** | axial rms_final | bead spacing |
|---|---|---|---|---|
| R2 θ=0° r64, ampl=10⁻² (2 seeds) | 0.632 / 0.669 t_J | **3 / 3** | 1.08–1.82 | n\*=8 → λ=1.00 λ_J = 1.46 W |
| R2 θ=0° r128, ampl=10⁻² | 0.620 t_J | **3** | 0.82 | n\*=8 (same), peaks converged to 0.01–0.03 λ_J |
| R2 θ=0° r64, ampl=10⁻⁴ | 0.958 t_J | **4** | 1.04 | n\*=10 → λ=0.80 λ_J = 1.17 W |
| R2 θ=90° r64 (2 seeds) | 0.418 t_J | 1 / 4 | 0.025 | weak structure |
| R2 θ=90° r128 | 0.430 t_J | **16** | 0.76 | strong multi-bead fragmentation at deep collapse (C≈6×10⁴) |

**Supercritical filaments DO fragment longitudinally** in the replication configuration — 3–4 beads, axial density variation ~100–180%, vs the paper's "<0.02% at all snapshots". The beading is resolution-converged (same n\*, same peak positions at r64 and r128) and amplitude-robust (10⁻² and 10⁻⁴).

**Why the difference?** Not the ICs (identical), not the physics parameters (identical), not resolution (both ladders self-consistent). The remaining differences: transverse **boundary-condition implementation** (rce pgen's enrolled "external-pressure" user BCs vs reflecting) and the resulting **radial-collapse timescale**: the paper's configuration collapses at t≈0.14 t_J (near-immediate radial free-fall — the ICs are out of radial equilibrium), while the replication collapses at t≈0.63–0.96 t_J (quasi-static evolution that gives longitudinal modes time to grow to nonlinearity). This is precisely the radial-collapse-vs-fragmentation **timescale competition** the referee pointed to (Inutsuka & Miyama's later work; also Pon, Johnstone & Heitsch 2011–2012 on supercritical cylinders collapsing to spindles before fragmenting). The paper's campaigns sit deep in the fast-collapse corner of that competition; the replication sits in the competing corner.

### 2.3 Consequences for each referee point

1. **Point 1 (resolution study of mode competition)**: done — R1 answers it *within the paper's config* (negative result resolution-robust at 64→256). **But** R2 shows the deeper issue is not resolution — it is that the fast-collapse regime itself is implementation-dependent. The paper should engage the spindle-collapse literature explicitly (Pon et al. 2011, 2012; Inutsuka & Miyama 1997) and reframe: "in our configuration radial collapse outruns longitudinal mode growth" — not "supercritical filaments undergo radial collapse" as a general truth.
2. **Point 2 (independent replication)**: the honest outcome is that replication **fails** — and that is the most valuable finding of this campaign. The negative result must be presented as configuration/generator-dependent, and the May-campaign beading measurements (same generator as R2!) should be revisited rather than treated as superseded: the two generator families give systematically different regimes (fast radial collapse vs quasi-static beading). Recommend: acknowledge openly that which regime applies to real filaments is currently **not determined** by these simulations; add IC-equilibration tests as future work.
3. **Point 3 (perpendicular-field tension)**: R2-θ90 collapses faster (t≈0.42) with weak axial structure (rms 2.5%, 1–4 marginal peaks); R1-θ90 shows no beading at any resolution; R2-θ90 at r128 fragments into ~16 beads at deep collapse. The perpendicular λ/W ≈ 0.8 prediction thus also inherits the implementation dependence; the "unresolved tension" framing should extend to "unresolved at the level of simulation implementation, not only field topology".
4. **Points 4–6**: no new sims needed (presentation). For point 5, note our forward-model η_W band (0.59–0.78, yesterday's package) already provides the width-systematic to fold into the region-specific-width sensitivity check the referee suggests.

---

## 3. Additional findings from reading v32 + referee report (for the external ASTRA)

1. **Generator reads `bfield_geometry`, not `theta_deg`** (`filament_rce.cpp`): any configs in the paper's archive that varied θ via `theta_deg` alone under this generator were actually all-longitudinal duplicates. (I hit this myself overnight and re-ran the θ=90° suite correctly.) The external ASTRA should audit every θ≠0 run in its campaign records for which parameter was set.
2. **The "<0.02% axial variance" metric** needs careful definition: late in collapse our no-beading runs show axial rms ~1.3 from n=1 sloshing. If the paper's 0.02% was measured pre-collapse, say so explicitly and give the epoch; consider adding a peak-count metric (interior maxima above 3σ) as the robust beading discriminant.
3. **Referee's "two seeds identical at low amplitude"**: at ampl=10⁻⁴ the velocity seeding is so weak that different random seeds produce identical trajectories — seed statistics quoted at that amplitude are effectively single-realization. (My own a4 pair hit this; disclosed.)
4. Literature to engage for point 1: Pon, Johnstone & Heitsch (2011, 2012, spindle collapse vs fragmentation); Inutsuka & Miyama (1997); Heigl, Burkert & Hacar? — the referee's suggestion is well-matched to the Pon et al. sequence.
5. The paper's recommended reframe (option (a) vs (b) in the referee's recommendation): our results support **(b) with caveats** — the negative result is real within the paper's configuration and resolution-robust, but cannot carry "supercritical filaments don't fragment" as a universal claim. A middle path: keep the campaign but retitle that section as "radial collapse dominance in the standard Athena++ filament configuration" and present the R2 replication result as an open question driving the future-work section.

---

## 4. File inventory

- `referee_v32_overnight_report.md` — this document
- `fig_mode_competition.png` — axial profiles + collapse/mode-growth, both generators
- `fig_resolution_ladder.png` — R1 ladder summary (Γ_mode, peaks, C vs resolution)
- `fig_replication.png` — R2 beading/replication summary
- `mode_competition_*.json` — full per-snapshot series for all R1/R2 runs
- `analyze_mode_competition.py`, `fig_mode_competition.py`, generators — analysis code
- `campaignR*.json` — runner status files
