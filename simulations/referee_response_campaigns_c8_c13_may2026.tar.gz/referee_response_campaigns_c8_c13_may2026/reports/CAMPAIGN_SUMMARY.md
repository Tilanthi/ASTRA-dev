# Referee Response Campaigns C8–C13: Complete Summary
**Completed**: 2026-05-01 | **System**: astra-climate (224 CPUs)

## Campaign Overview

| Campaign | Sims | FRAG | TIMEOUT | Wall time | Purpose |
|---|---|---|---|---|---|
| **C8** | 175 | 169 | 6 | ~3.2h | θ-dependent fragmentation timescales |
| **C8_lw** | 35 | 35 | 0 | ~53 min | λ/W(θ,β) calibration |
| **C10** | — (Python) | — | — | instant | L/3 observational bias validation |
| **C12** | 300 | 299 | 1 | ~6.5h | DTC stable-ridge re-verification |
| **C13** | — (literature) | — | — | — | Plasma β observational validation |

**Total MHD sims**: 510 | **Total FRAG**: 503/510 (98.6%) | **Total TIMEOUT**: 7/510 (1.4%)

---

## C8 — Field Angle Dependence (175 sims)
**Config**: f=1.5, β=[0.3,0.5,1.0,1.5,2.0], θ=[0,15,30,45,60,75,90]°, seeds=[42,137,314,527,816], 512×64×64

**t_frag vs θ**:
| θ | t_frag (t_J) | σ | n |
|---|---|---|---|
| 0° | 1.355 | ±0.128 | 23 |
| 15° | 1.306 | ±0.111 | 21 |
| 30° | 0.874 | ±0.046 | 25 |
| 45° | 0.710 | ±0.062 | 25 |
| 60° | 0.618 | ±0.054 | 25 |
| 75° | 0.582 | ±0.052 | 25 |
| 90° | 0.584 | ±0.054 | 25 |

**Key result**: Sharp transition between θ=15° and θ=30° (~35% drop in t_frag).
Two physical regimes: (i) θ≤15°: axial beading mode (slow); (ii) θ≥30°: radial collapse mode (fast).

---

## C8_lw — λ/W Calibration (35 sims)
**Config**: f=1.5, β=[0.3,0.5,1.0,1.5,2.0], θ=[0,15,30,45,60,75,90]°, seed=42 fixed

**λ/W matrix (FLAT = radial collapse, no axial beading)**:
```
θ\β   0.3    0.5    1.0    1.5    2.0
  0°: FLAT  4.236  1.300  2.287  2.521   mean=2.586 (n=4)
 15°: 4.236  1.715  2.131  1.170  2.443  mean=2.339 (n=5)
 30°: FLAT   FLAT   FLAT  3.067  1.196   mean=2.131 (n=2)
 45°: FLAT   FLAT   FLAT   FLAT   FLAT   —
 60°: FLAT   FLAT   FLAT   FLAT   FLAT   —
 75°: FLAT   FLAT   FLAT   FLAT   FLAT   —
 90°: FLAT   FLAT   FLAT   FLAT  1.248   mean=1.248 (n=1)
```
**Key result**: λ/W only measurable for θ≤30°. Consistent with C5/C6 values. θ≥45° is purely radial collapse.

---

## C10 — L/3 Pairwise Bias (pure Python)
**Key result**: Pairwise spacing estimator is biased by factor ≈ L/3 / true_spacing.
- Mean pairwise bias: **7.0× (σ=2.2)** across 8 HGBS regions (Taurus, OrionB, Aquila, Perseus, Ophiuchus, Serpens, TMC1, CrA)
- Mean NN bias: **≈0%** — nearest-neighbour estimator is unbiased
- Bias scales exactly as L/3 (predicted and confirmed)

---

## C12 — DTC Stable Ridge Re-verification (300 sims)
**Config**: β=0.3, f=[1.2,1.4,1.6,1.8,2.0,2.2], M=1, seeds=[42,137,314,527,816] + 10 per f, 256×64×64, tlim=5.0 t_J

| f | t_frag (t_J) | σ | n |
|---|---|---|---|
| 1.2 | 1.452 | ±0.095 | 50 |
| 1.4 | 1.407 | ±0.088 | 49 |
| 1.6 | 1.359 | ±0.090 | 50 |
| 1.8 | 1.307 | ±0.096 | 50 |
| 2.0 | 1.255 | ±0.087 | 50 |
| 2.2 | 1.203 | ±0.080 | 50 |

**Key result**: 299/300 FRAG. The DTC stable ridge at β=0.3, M=1 is definitively confirmed as an artifact — fragmentation occurs at t_frag = 1.2–1.5 t_J (just beyond the DTC tlim=1.5 t_J). Δt_frag ≈ −0.050 t_J per Δf=0.2.

---

## C13 — Literature β Validation (23 published measurements)
**Key result**: Purely thermal β in HGBS filaments = 0.014–0.385, median 0.057.
Simulation range β=0.3–2.0 corresponds to the **turbulent-effective β** for M~2 filaments.
See full report: `reports/C13_BETA_VALIDATION_REPORT.md`

---

## Files in This Package
- `results/C8/results.json` — 175 sim results (θ, β, f, seed, outcome, t_frag, wall_s)
- `results/C8_lw/results.json` — 35 sim results (θ, β, t_frag, n_hdf5)
- `results/C8_lw/lambda_W_analysis.json` — λ/W per sim (lambda_W, n_peaks, quality)
- `results/C10/C10_results.json` — pairwise/NN bias, random_uniform, bias_stats
- `results/C12/results.json` — 300 sim results (f, β, seed, outcome, t_frag)
- `figures/fig_C8_C12_summary.{pdf,png}` — 4-panel summary
- `figures/fig_C8_tfrag.{pdf,png}` — C8 t_frag(θ) and t_frag(β)
- `figures/fig_C8lw_lambda_W.{pdf,png}` — C8_lw λ/W matrix
- `reports/MASTER_campaign_log.txt` — full campaign log
- `reports/CAMPAIGN_SUMMARY.md` — this file
- `reports/C13_BETA_VALIDATION_REPORT.md` — C13 literature analysis
