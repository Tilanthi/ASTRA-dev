# Paper I package — Filament fragmentation and core spacing — I.
## Two spacing statistics and a clustered core distribution in Herschel Gould Belt clouds

Authors: Glenn J. White, Robin Dey

## Contents
- `paper1.tex` — LaTeX source
- `paper1.pdf` — compiled PDF (19 pages)
- `paper1.bbl` — pre-compiled bibliography (bibtex output)
- `references_complete.bib` — full bibliography source
- `mnras.cls`, `mnras.bst` — MNRAS journal class/style files
- `figures/` — all 8 figures referenced by this paper

## To recompile from scratch
```
pdflatex paper1.tex
bibtex paper1
pdflatex paper1.tex
pdflatex paper1.tex
```
Verified: this package compiles cleanly (0 errors) from these files alone, in a fresh directory.

Last updated: 2026-09-04 (packaged from the version last edited 2026-08-04, verified byte-identical
to `simulations/paper_series_aug2026/paper1.tex`/`paper1.pdf` in this repo).
