# Paper II package — Filament fragmentation and core spacing — II.
## Contracting filaments need not select the equilibrium wavelength

Authors: Glenn J. White, Robin Dey

## Contents
- `paper2.tex` — LaTeX source
- `paper2.pdf` — compiled PDF (17 pages)
- `paper2.bbl` — pre-compiled bibliography (bibtex output)
- `references_complete.bib` — full bibliography source
- `mnras.cls`, `mnras.bst` — MNRAS journal class/style files
- `figures/` — all 4 figures referenced by this paper

## To recompile from scratch
```
pdflatex paper2.tex
bibtex paper2
pdflatex paper2.tex
pdflatex paper2.tex
```
Verified: this package compiles cleanly (0 errors) from these files alone, in a fresh directory.

Last updated: 2026-09-04 (packaged from the version last edited 2026-08-04, verified byte-identical
to `simulations/paper_series_aug2026/paper2.tex`/`paper2.pdf` in this repo).
