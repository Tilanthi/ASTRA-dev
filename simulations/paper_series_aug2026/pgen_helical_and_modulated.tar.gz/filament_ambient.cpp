// ============================================================
// Athena++ Problem Generator: filament_ambient
// Referee-v34 boundary-condition arbitration campaigns (Jul 2026)
//
// Purpose: resolve the configuration dependence of the supercritical
// fragmentation result (paper Section 4.6.6 / referee major point 1) with a
// SINGLE binary in which the transverse boundary condition (user
// external-pressure, reflecting, or periodic) is selected purely from the
// input file, the transverse domain size is a free parameter (so the
// boundary can be moved away from the filament while the pressurized
// ambient medium inside the domain provides the confinement), and the
// initial radial profile can be either the paper's Gaussian or a
// scaled-Ostriker near-equilibrium profile (equilibration test).
//
// Profiles (profile parameter):
//   gaussian : rho(r) = rho_bg + rho_amp * exp(-r^2/(2 W_core^2))
//              rho_amp = f * M_crit / (2 pi W_core^2)      [paper standard]
//   ostriker : rho(r) = rho_bg + f * rho_c / (1 + (r/W_core)^2)^2
//              rho_c   = 2 cs^2 / (pi G W_core^2)
//              (exact unmagnetized hydrostatic equilibrium at f=1 in
//               isolation; radial force imbalance ~ (f-1), vs O(1) for the
//               Gaussian.  Both profiles carry filament line mass f*M_crit.)
//
// B-field geometries (bfield_geometry): longitudinal | perpendicular | oblique
//
// Boundary conditions: if <mesh> ix2_bc = user, the four transverse faces
// are enrolled with the external-pressure zero-gradient BCs (identical
// implementation to filament_rce.cpp; p_ext_ratio=0 -> standard outflow).
// If ix2_bc = reflecting or periodic, Athena++ built-ins are used and no
// user functions are enrolled.
//
// Author: ASTRA automated system (astra-pa) | Date: 2026-07-21
// ============================================================

#include "../athena.hpp"
#include "../athena_arrays.hpp"
#include "../parameter_input.hpp"
#include "../mesh/mesh.hpp"
#include "../hydro/hydro.hpp"
#include "../field/field.hpp"
#include "../coordinates/coordinates.hpp"
#include <cmath>
#include <random>
#include <vector>
#include <string>
#include <algorithm>

// ── Global external pressure ratio (shared across all BC functions) ──────────
static Real g_p_ext = 0.0;

// ---- helical (flux-frozen) equilibrium: Bz = a*rho, Bphi = b*r*rho -------
static const int NHEL = 20001;
static Real g_hr[NHEL], g_hrho[NHEL], g_hBz[NHEL], g_hBphi[NHEL], g_hAx[NHEL], g_hAphi[NHEL];
static Real g_hdr = 0.0; static bool g_hel_ready = false; static Real g_hel_mean = 0.0;
static void BuildHelix(Real a, Real b, Real rho_c, Real cs, Real Ggrav, Real rmax, Real mean) {
    g_hel_mean = mean;
    g_hdr = rmax / (NHEL - 1);
    Real rho = rho_c, u = 0.0;
    for (int i = 0; i < NHEL; ++i) {
        Real r = i * g_hdr;
        g_hr[i] = r; g_hrho[i] = rho;
        g_hBz[i] = a * rho; g_hBphi[i] = b * r * rho;
        Real rr = (r > 1e-9) ? r : 1e-9;
        Real den = cs*cs + rho*(a*a + b*b*r*r)/(4.0*M_PI);
        Real drho = (-rho*u - b*b*r*rho*rho/(2.0*M_PI)) / den;
        Real du   = 4.0*M_PI*Ggrav*(rho - g_hel_mean) - u/rr;
        rho += drho * g_hdr; u += du * g_hdr;
        if (rho < 1e-8) rho = 1e-8;
    }
    // vector potential: Ax(r) = -int Bphi dr ; Aphi(r) = (1/r) int Bz r dr
    g_hAx[0] = 0.0; Real acc = 0.0;
    for (int i = 1; i < NHEL; ++i) { acc += -0.5*(g_hBphi[i]+g_hBphi[i-1])*g_hdr; g_hAx[i] = acc; }
    Real m = 0.0; g_hAphi[0] = 0.0;
    for (int i = 1; i < NHEL; ++i) {
        m += 0.5*(g_hBz[i]*g_hr[i] + g_hBz[i-1]*g_hr[i-1])*g_hdr;
        g_hAphi[i] = m / g_hr[i];
    }
    g_hel_ready = true;
}
static Real HelInterp(const Real *tab, Real r) {
    if (!g_hel_ready) return 0.0;
    Real x = r / g_hdr; int i = (int)x;
    if (i < 0) return tab[0];
    if (i >= NHEL-1) return tab[NHEL-1];
    Real f = x - i; return tab[i]*(1.0-f) + tab[i+1]*f;
}


// ── Relaxation (velocity damping) + delayed broadband axial kick ─────────────
static Real g_damp_rate = 0.0, g_t_damp_end = 0.0;
static Real g_kick_ampl = 0.0, g_kick_time = 0.0, g_kick_tau = 0.1;
static int  g_kick_Nm = 12;
static std::vector<Real> g_kx, g_ph, g_amp;
static Real g_vnorm = 0.0;

void RelaxKickSource(MeshBlock *pmb, const Real time, const Real dt,
        const AthenaArray<Real> &prim, const AthenaArray<Real> &prim_scalar,
        const AthenaArray<Real> &bcc, AthenaArray<Real> &cons,
        AthenaArray<Real> &cons_scalar) {
    // (a) velocity damping during the relaxation window t < t_damp_end
    if (g_damp_rate > 0.0 && time < g_t_damp_end) {
        Real fac = g_damp_rate * dt;
        if (fac > 1.0) fac = 1.0;
        for (int k = pmb->ks; k <= pmb->ke; ++k)
        for (int j = pmb->js; j <= pmb->je; ++j)
        for (int i = pmb->is; i <= pmb->ie; ++i) {
            cons(IM1,k,j,i) -= fac * cons(IM1,k,j,i);
            cons(IM2,k,j,i) -= fac * cons(IM2,k,j,i);
            cons(IM3,k,j,i) -= fac * cons(IM3,k,j,i);
        }
    }
    // (b) impulsive broadband axial velocity kick over [kick_time, +kick_tau]
    if (g_kick_ampl > 0.0 && time >= g_kick_time && time < g_kick_time + g_kick_tau) {
        Real frac = dt / g_kick_tau;   // accumulates to full amplitude over window
        for (int k = pmb->ks; k <= pmb->ke; ++k)
        for (int j = pmb->js; j <= pmb->je; ++j)
        for (int i = pmb->is; i <= pmb->ie; ++i) {
            Real x1 = pmb->pcoord->x1v(i);
            Real v1 = 0.0;
            for (int n = 0; n < g_kick_Nm; ++n)
                v1 += g_vnorm * g_amp[n] * std::cos(g_kx[n] * x1 + g_ph[n]);
            cons(IM1,k,j,i) += cons(IDN,k,j,i) * v1 * frac;
        }
    }
}

void InnerX2_ExtPressure(MeshBlock *pmb, Coordinates *pco,
    AthenaArray<Real> &prim, FaceField &b, Real time, Real dt,
    int is, int ie, int js, int je, int ks, int ke, int ngh);
void OuterX2_ExtPressure(MeshBlock *pmb, Coordinates *pco,
    AthenaArray<Real> &prim, FaceField &b, Real time, Real dt,
    int is, int ie, int js, int je, int ks, int ke, int ngh);
void InnerX3_ExtPressure(MeshBlock *pmb, Coordinates *pco,
    AthenaArray<Real> &prim, FaceField &b, Real time, Real dt,
    int is, int ie, int js, int je, int ks, int ke, int ngh);
void OuterX3_ExtPressure(MeshBlock *pmb, Coordinates *pco,
    AthenaArray<Real> &prim, FaceField &b, Real time, Real dt,
    int is, int ie, int js, int je, int ks, int ke, int ngh);

// ── Mesh-level init ──────────────────────────────────────────────────────────
void Mesh::InitUserMeshData(ParameterInput *pin) {
    if (SELF_GRAVITY_ENABLED) {
        Real four_pi_G = pin->GetOrAddReal("problem", "four_pi_G",
                                           4.0 * M_PI * M_PI);
        SetFourPiG(four_pi_G);
    }
    g_p_ext = pin->GetOrAddReal("problem", "p_ext_ratio", 0.0);

    // ── Relaxation / kick controls ──────────────────────────────────────────
    g_damp_rate  = pin->GetOrAddReal("problem", "damp_rate",  0.0);
    g_t_damp_end = pin->GetOrAddReal("problem", "t_damp_end", 0.0);
    g_kick_ampl  = pin->GetOrAddReal("problem", "kick_ampl",  0.0);
    g_kick_time  = pin->GetOrAddReal("problem", "kick_time",  0.0);
    g_kick_tau   = pin->GetOrAddReal("problem", "kick_tau",   0.1);
    if (g_damp_rate > 0.0 || g_kick_ampl > 0.0) {
        Real cs   = pin->GetOrAddReal("hydro",   "iso_sound_speed", 1.0);
        Real mach = pin->GetOrAddReal("problem", "mach_number",     1.0);
        int  seed = pin->GetOrAddInteger("problem", "kick_seed",    42);
        Real x1min = pin->GetReal("mesh", "x1min");
        Real x1max = pin->GetReal("mesh", "x1max");
        Real Lx1 = x1max - x1min;
        g_kx.assign(g_kick_Nm, 0.0); g_ph.assign(g_kick_Nm, 0.0); g_amp.assign(g_kick_Nm, 0.0);
        std::mt19937 rng(static_cast<unsigned int>(seed));
        std::uniform_real_distribution<Real> U_phase(0.0, 2.0 * M_PI);
        Real sumsq = 0.0;
        for (int n = 0; n < g_kick_Nm; ++n) {
            g_kx[n]  = 2.0 * M_PI * (n + 1) / Lx1;
            g_ph[n]  = U_phase(rng);
            g_amp[n] = std::pow(g_kx[n], -11.0 / 6.0);
            sumsq   += 0.5 * g_amp[n] * g_amp[n];
        }
        Real vtgt = mach * g_kick_ampl * cs;
        g_vnorm = (sumsq > 0.0) ? vtgt / std::sqrt(sumsq) : 0.0;
        EnrollUserExplicitSourceFunction(RelaxKickSource);
    }

    // Enroll external-pressure user BCs only when requested in <mesh>
    std::string bc2 = pin->GetOrAddString("mesh", "ix2_bc", "periodic");
    if (bc2 == "user") {
        EnrollUserBoundaryFunction(BoundaryFace::inner_x2, InnerX2_ExtPressure);
        EnrollUserBoundaryFunction(BoundaryFace::outer_x2, OuterX2_ExtPressure);
        EnrollUserBoundaryFunction(BoundaryFace::inner_x3, InnerX3_ExtPressure);
        EnrollUserBoundaryFunction(BoundaryFace::outer_x3, OuterX3_ExtPressure);
    }
}

// ── Problem generator ────────────────────────────────────────────────────────
void MeshBlock::ProblemGenerator(ParameterInput *pin) {

    Real four_pi_G  = pin->GetOrAddReal("problem", "four_pi_G",
                                        4.0 * M_PI * M_PI);
    Real f_line     = pin->GetOrAddReal("problem", "f_line_mass",  1.0);
    Real beta       = pin->GetOrAddReal("problem", "plasma_beta",  1.0);
    Real mach       = pin->GetOrAddReal("problem", "mach_number",  1.0);
    Real W_core     = pin->GetOrAddReal("problem", "W_core",       0.3);
    Real perturb_a  = pin->GetOrAddReal("problem", "perturb_ampl", 1.0e-4);
    int  seed       = pin->GetOrAddInteger("problem", "random_seed", 42);
    Real cs         = pin->GetOrAddReal("hydro", "iso_sound_speed", 1.0);
    Real theta_deg  = pin->GetOrAddReal("problem", "theta_deg",    0.0);
    std::string bgeom = pin->GetOrAddString("problem", "bfield_geometry",
                                             "longitudinal");
    std::string prof  = pin->GetOrAddString("problem", "profile", "gaussian");
    Real hel_a    = pin->GetOrAddReal("problem", "hel_a", 0.35);
    Real hel_b    = pin->GetOrAddReal("problem", "hel_b", 0.0);
    Real hel_rhoc = pin->GetOrAddReal("problem", "hel_rhoc", 5.268);
    Real hel_ramb = pin->GetOrAddReal("problem", "hel_ramb", 0.5);
    if (prof == "helical") {
        Real Ggrav = pin->GetOrAddReal("problem","four_pi_G",39.4784176044)/(4.0*M_PI);
        Real rmx = 4.0*(pmy_mesh->mesh_size.x2max - pmy_mesh->mesh_size.x2min);
        BuildHelix(hel_a, hel_b, hel_rhoc, cs, Ggrav, rmx, pin->GetOrAddReal("gravity","grav_mean_rho",1.0));
    }

    // ── Derived quantities ───────────────────────────────────────────────────
    Real rho_bg  = 1.0;
    Real G_code  = four_pi_G / (4.0 * M_PI);
    Real M_crit  = 2.0 * cs * cs / G_code;
    // Gaussian amplitude (paper standard): line mass f*M_crit
    Real fmod_amp = pin->GetOrAddReal("problem", "fmod_amp", 0.0);
    Real fmod_lam = pin->GetOrAddReal("problem", "fmod_lam", 8.0);
    int  fmod_sd  = (int)pin->GetOrAddReal("problem", "fmod_seed", 7.0);
    // irregular axial line-mass field: random-phase band around 1/fmod_lam
    Real Lx1f = pmy_mesh->mesh_size.x1max - pmy_mesh->mesh_size.x1min;
    int  nc   = (int)std::max(1.0, Lx1f/fmod_lam);
    int  n1   = std::max(1, nc/2), n2 = nc*2;
    std::vector<Real> fk, fph;
    { std::mt19937 rg(fmod_sd); std::uniform_real_distribution<Real> U(0.0, 2.0*M_PI);
      Real ss=0.0;
      for (int n=n1; n<=n2; ++n) { fk.push_back(2.0*M_PI*n/Lx1f); fph.push_back(U(rg)); ss+=0.5; }
      for (size_t q=0;q<fk.size();++q) fph[q]=fph[q];
      fmod_amp = (ss>0.0) ? fmod_amp/std::sqrt(ss) : 0.0; }
    Real rho_amp = f_line * M_crit / (2.0 * M_PI * W_core * W_core);
    // Ostriker central density: equilibrium value for core radius W_core
    Real rho_c_ost = 2.0 * cs * cs / (M_PI * G_code * W_core * W_core);
    // ── TRUE equilibrium (ostriker_eq) parameters ─────────────────────────
    // Central density set directly; scale radius R0 is the self-consistent
    // Ostriker value R0^2 = 2 cs^2 / (pi G rho_c).  NO uniform background is
    // added: the profile's own low-density tail is the confining ambient,
    // truncated by the transverse walls (pressure p_ext = cs^2 rho(edge)).
    Real rho_c_eq  = pin->GetOrAddReal("problem", "rho_c_eq",  2.24);
    Real R0_eq     = std::sqrt(2.0 * cs * cs / (M_PI * G_code * rho_c_eq));
    Real rho_floor = pin->GetOrAddReal("problem", "rho_floor", 1.0e-3);
    // ── Homologous initial radial contraction (ladder parameter A) ──────────
    // v_r(r) = -A * (cs/R_ref) * r  for r <= R_out, tapered smoothly beyond.
    // A = 0 recovers the static equilibrium control.
    Real contract_A    = pin->GetOrAddReal("problem", "contract_ampl", 0.0);
    Real contract_Rref = pin->GetOrAddReal("problem", "contract_rref", R0_eq);
    Real contract_Rout = pin->GetOrAddReal("problem", "contract_rout", 3.0*R0_eq);
    Real B0      = (beta > 0.0) ? cs * std::sqrt(2.0 * rho_bg / beta) : 0.0;

    // ── Kolmogorov velocity perturbation along x1 (identical to
    //    filament_supercritical.cpp: 12 modes, k^-11/6 amplitudes) ────────────
    const int Nm = (int)(pin->GetOrAddReal("problem", "n_modes", 12.0));
    Real Lx1 = pmy_mesh->mesh_size.x1max - pmy_mesh->mesh_size.x1min;

    std::vector<Real> kx_v(Nm), ph(Nm), amp_k(Nm);
    std::mt19937 rng(static_cast<unsigned int>(seed));
    std::uniform_real_distribution<Real> U_phase(0.0, 2.0 * M_PI);

    for (int n = 0; n < Nm; ++n) {
        kx_v[n]  = 2.0 * M_PI * (n + 1) / Lx1;
        ph[n]    = U_phase(rng);
        amp_k[n] = std::pow(kx_v[n], -11.0 / 6.0);
    }
    Real sumsq = 0.0;
    for (int n = 0; n < Nm; ++n)
        sumsq += 0.5 * amp_k[n] * amp_k[n];
    Real vtgt  = mach * perturb_a * cs;
    Real vnorm = (sumsq > 0.0) ? vtgt / std::sqrt(sumsq) : 0.0;

    // ── Fill conserved arrays ────────────────────────────────────────────────
    for (int k = ks; k <= ke; ++k)
    for (int j = js; j <= je; ++j)
    for (int i = is; i <= ie; ++i) {
        Real x1 = pcoord->x1v(i);
        Real x2 = pcoord->x2v(j);
        Real x3 = pcoord->x3v(k);

        Real r2  = x2 * x2 + x3 * x3;
        Real rho;
        if (prof == "helical") {
            rho = HelInterp(g_hrho, std::sqrt(r2));
            if (rho < hel_ramb) rho = hel_ramb;
        } else if (prof == "ostriker_eq") {
            // exact truncated isothermal equilibrium cylinder
            Real qeq = 1.0 + r2 / (R0_eq * R0_eq);
            rho = rho_c_eq / (qeq * qeq);
            if (rho < rho_floor) rho = rho_floor;
        } else if (prof == "ostriker") {
            Real q = 1.0 + r2 / (W_core * W_core);
            rho = rho_bg + f_line * rho_c_ost / (q * q);
        } else {  // gaussian (default)
            Real fx = 1.0;
            for (size_t q=0; q<fk.size(); ++q)
                fx += fmod_amp * std::cos(fk[q]*pcoord->x1v(i) + fph[q]);
            if (fx < 0.0) fx = 0.0;
            rho = rho_bg + fx * rho_amp * std::exp(-r2 / (2.0 * W_core * W_core));
        }

        Real v1 = 0.0;
        for (int n = 0; n < Nm; ++n)
            v1 += vnorm * amp_k[n] * std::cos(kx_v[n] * x1 + ph[n]);

        phydro->u(IDN, k, j, i) = rho;
        phydro->u(IM1, k, j, i) = rho * v1;
        Real rr = std::sqrt(r2);
        Real vr = 0.0;
        if (contract_A > 0.0 && rr > 0.0) {
            Real vmag = contract_A * (cs / contract_Rref) * rr;
            if (rr > contract_Rout) {
                Real tap = std::exp(-(rr - contract_Rout) * (rr - contract_Rout)
                                    / (contract_Rout * contract_Rout));
                vmag *= tap;
            }
            vr = -vmag;
        }
        Real ct = (rr > 0.0) ? x2 / rr : 0.0;
        Real st = (rr > 0.0) ? x3 / rr : 0.0;
        phydro->u(IM2, k, j, i) = rho * vr * ct;
        phydro->u(IM3, k, j, i) = rho * vr * st;
    }

    // ── Magnetic field (uniform geometries) ──────────────────────────────────
    if (MAGNETIC_FIELDS_ENABLED && prof == "helical") {
        // A_x(r) gives B_phi ; A_phi(r) gives B_axial. Cartesian:
        //   A1 = Ax(r) ; A2 = -Aphi(r) * x3/r ; A3 = Aphi(r) * x2/r
        // B = curl A on the staggered mesh -> div B = 0 to machine precision.
        auto A1 = [&](Real y, Real z) { return HelInterp(g_hAx, std::sqrt(y*y+z*z)); };
        auto A2 = [&](Real y, Real z) { Real r=std::sqrt(y*y+z*z);
                                        return (r>1e-12) ? -HelInterp(g_hAphi,r)*z/r : 0.0; };
        auto A3 = [&](Real y, Real z) { Real r=std::sqrt(y*y+z*z);
                                        return (r>1e-12) ?  HelInterp(g_hAphi,r)*y/r : 0.0; };
        Real dx2 = pcoord->dx2v(js), dx3 = pcoord->dx3v(ks);
        for (int k = ks; k <= ke; ++k)
        for (int j = js; j <= je; ++j)
        for (int i = is; i <= ie+1; ++i) {
            // A3 lives at (x1f,x2f,x3v); A2 lives at (x1f,x2v,x3f)
            Real yf = pcoord->x2f(j), yf1 = pcoord->x2f(j+1);
            Real yv = pcoord->x2v(j);
            Real zv = pcoord->x3v(k);
            Real zf = pcoord->x3f(k), zf1 = pcoord->x3f(k+1);
            pfield->b.x1f(k,j,i) = (A3(yf1,zv)-A3(yf,zv))/dx2 - (A2(yv,zf1)-A2(yv,zf))/dx3;
        }
        Real dx1 = pcoord->dx1v(is);
        for (int k = ks; k <= ke; ++k)
        for (int j = js; j <= je+1; ++j)
        for (int i = is; i <= ie; ++i) {
            Real yf = pcoord->x2f(j);
            Real zf = pcoord->x3f(k), zf1 = pcoord->x3f(k+1);
            pfield->b.x2f(k,j,i) = (A1(yf,zf1)-A1(yf,zf))/dx3;   // -dA3/dx1 = 0
        }
        for (int k = ks; k <= ke+1; ++k)
        for (int j = js; j <= je; ++j)
        for (int i = is; i <= ie; ++i) {
            Real yf = pcoord->x2f(j), yf1 = pcoord->x2f(j+1);
            Real zf = pcoord->x3f(k);
            pfield->b.x3f(k,j,i) = -(A1(yf1,zf)-A1(yf,zf))/dx2;  // dA2/dx1 = 0
        }
        pfield->CalculateCellCenteredField(pfield->b, pfield->bcc, pcoord,
                                           is, ie, js, je, ks, ke);
    } else if (MAGNETIC_FIELDS_ENABLED) {
        Real Bx1 = 0.0, Bx2 = 0.0, Bx3 = 0.0;
        if (bgeom == "perpendicular") {
            Bx2 = B0;
        } else if (bgeom == "oblique") {
            Real theta_rad = theta_deg * M_PI / 180.0;
            Bx1 = B0 * std::cos(theta_rad);
            Bx2 = B0 * std::sin(theta_rad);
        } else {
            Bx1 = B0;  // longitudinal (default)
        }

        for (int k = ks; k <= ke; ++k)
        for (int j = js; j <= je; ++j)
        for (int i = is; i <= ie + 1; ++i)
            pfield->b.x1f(k, j, i) = Bx1;

        for (int k = ks; k <= ke; ++k)
        for (int j = js; j <= je + 1; ++j)
        for (int i = is; i <= ie; ++i)
            pfield->b.x2f(k, j, i) = Bx2;

        for (int k = ks; k <= ke + 1; ++k)
        for (int j = js; j <= je; ++j)
        for (int i = is; i <= ie; ++i)
            pfield->b.x3f(k, j, i) = Bx3;

        pfield->CalculateCellCenteredField(
            pfield->b, pfield->bcc, pcoord,
            is, ie, js, je, ks, ke);
    }
}
// ── inner_x2: ghost cells at j = js-1, js-2, ..., js-ngh ───────────────────
void InnerX2_ExtPressure(MeshBlock *pmb, Coordinates *pco,
    AthenaArray<Real> &prim, FaceField &b,
    Real time, Real dt,
    int is, int ie, int js, int je, int ks, int ke, int ngh) {

    // Primitives: zero-gradient with density floor
    for (int k = ks; k <= ke; ++k) {
        for (int n = 1; n <= ngh; ++n) {
            for (int i = is; i <= ie; ++i) {
                prim(IDN, k, js-n, i) = std::max(prim(IDN, k, js, i), g_p_ext);
                prim(IVX, k, js-n, i) = prim(IVX, k, js, i);
                prim(IVY, k, js-n, i) = prim(IVY, k, js, i);
                prim(IVZ, k, js-n, i) = prim(IVZ, k, js, i);
            }
        }
    }

    if (MAGNETIC_FIELDS_ENABLED) {
        // x1f: face-centered in x1 (i has extra +1 face)
        for (int k = ks; k <= ke; ++k)
            for (int n = 1; n <= ngh; ++n)
                for (int i = is; i <= ie + 1; ++i)
                    b.x1f(k, js-n, i) = b.x1f(k, js, i);

        // x2f: face-centered in x2; ghost faces at js-n (boundary face = js)
        for (int k = ks; k <= ke; ++k)
            for (int n = 1; n <= ngh; ++n)
                for (int i = is; i <= ie; ++i)
                    b.x2f(k, js-n, i) = b.x2f(k, js, i);

        // x3f: face-centered in x3 (k has extra +1 face)
        for (int k = ks; k <= ke + 1; ++k)
            for (int n = 1; n <= ngh; ++n)
                for (int i = is; i <= ie; ++i)
                    b.x3f(k, js-n, i) = b.x3f(k, js, i);
    }
}

// ── outer_x2: ghost cells at j = je+1, je+2, ..., je+ngh ───────────────────
void OuterX2_ExtPressure(MeshBlock *pmb, Coordinates *pco,
    AthenaArray<Real> &prim, FaceField &b,
    Real time, Real dt,
    int is, int ie, int js, int je, int ks, int ke, int ngh) {

    // Primitives: zero-gradient with density floor
    for (int k = ks; k <= ke; ++k) {
        for (int n = 1; n <= ngh; ++n) {
            for (int i = is; i <= ie; ++i) {
                prim(IDN, k, je+n, i) = std::max(prim(IDN, k, je, i), g_p_ext);
                prim(IVX, k, je+n, i) = prim(IVX, k, je, i);
                prim(IVY, k, je+n, i) = prim(IVY, k, je, i);
                prim(IVZ, k, je+n, i) = prim(IVZ, k, je, i);
            }
        }
    }

    if (MAGNETIC_FIELDS_ENABLED) {
        // x1f
        for (int k = ks; k <= ke; ++k)
            for (int n = 1; n <= ngh; ++n)
                for (int i = is; i <= ie + 1; ++i)
                    b.x1f(k, je+n, i) = b.x1f(k, je, i);

        // x2f: last active face = je+1; ghost faces at je+1+n
        for (int k = ks; k <= ke; ++k)
            for (int n = 1; n <= ngh; ++n)
                for (int i = is; i <= ie; ++i)
                    b.x2f(k, je+1+n, i) = b.x2f(k, je+1, i);

        // x3f
        for (int k = ks; k <= ke + 1; ++k)
            for (int n = 1; n <= ngh; ++n)
                for (int i = is; i <= ie; ++i)
                    b.x3f(k, je+n, i) = b.x3f(k, je, i);
    }
}

// ── inner_x3: ghost cells at k = ks-1, ks-2, ..., ks-ngh ───────────────────
void InnerX3_ExtPressure(MeshBlock *pmb, Coordinates *pco,
    AthenaArray<Real> &prim, FaceField &b,
    Real time, Real dt,
    int is, int ie, int js, int je, int ks, int ke, int ngh) {

    // Primitives: zero-gradient with density floor
    for (int n = 1; n <= ngh; ++n) {
        for (int j = js; j <= je; ++j) {
            for (int i = is; i <= ie; ++i) {
                prim(IDN, ks-n, j, i) = std::max(prim(IDN, ks, j, i), g_p_ext);
                prim(IVX, ks-n, j, i) = prim(IVX, ks, j, i);
                prim(IVY, ks-n, j, i) = prim(IVY, ks, j, i);
                prim(IVZ, ks-n, j, i) = prim(IVZ, ks, j, i);
            }
        }
    }

    if (MAGNETIC_FIELDS_ENABLED) {
        // x1f
        for (int n = 1; n <= ngh; ++n)
            for (int j = js; j <= je; ++j)
                for (int i = is; i <= ie + 1; ++i)
                    b.x1f(ks-n, j, i) = b.x1f(ks, j, i);

        // x2f: face-centered in x2 (j has extra +1 face)
        for (int n = 1; n <= ngh; ++n)
            for (int j = js; j <= je + 1; ++j)
                for (int i = is; i <= ie; ++i)
                    b.x2f(ks-n, j, i) = b.x2f(ks, j, i);

        // x3f: ghost faces at ks-n (boundary face = ks)
        for (int n = 1; n <= ngh; ++n)
            for (int j = js; j <= je; ++j)
                for (int i = is; i <= ie; ++i)
                    b.x3f(ks-n, j, i) = b.x3f(ks, j, i);
    }
}

// ── outer_x3: ghost cells at k = ke+1, ke+2, ..., ke+ngh ───────────────────
void OuterX3_ExtPressure(MeshBlock *pmb, Coordinates *pco,
    AthenaArray<Real> &prim, FaceField &b,
    Real time, Real dt,
    int is, int ie, int js, int je, int ks, int ke, int ngh) {

    // Primitives: zero-gradient with density floor
    for (int n = 1; n <= ngh; ++n) {
        for (int j = js; j <= je; ++j) {
            for (int i = is; i <= ie; ++i) {
                prim(IDN, ke+n, j, i) = std::max(prim(IDN, ke, j, i), g_p_ext);
                prim(IVX, ke+n, j, i) = prim(IVX, ke, j, i);
                prim(IVY, ke+n, j, i) = prim(IVY, ke, j, i);
                prim(IVZ, ke+n, j, i) = prim(IVZ, ke, j, i);
            }
        }
    }

    if (MAGNETIC_FIELDS_ENABLED) {
        // x1f
        for (int n = 1; n <= ngh; ++n)
            for (int j = js; j <= je; ++j)
                for (int i = is; i <= ie + 1; ++i)
                    b.x1f(ke+n, j, i) = b.x1f(ke, j, i);

        // x2f
        for (int n = 1; n <= ngh; ++n)
            for (int j = js; j <= je + 1; ++j)
                for (int i = is; i <= ie; ++i)
                    b.x2f(ke+n, j, i) = b.x2f(ke, j, i);

        // x3f: last active face = ke+1; ghost faces at ke+1+n
        for (int n = 1; n <= ngh; ++n)
            for (int j = js; j <= je; ++j)
                for (int i = is; i <= ie; ++i)
                    b.x3f(ke+1+n, j, i) = b.x3f(ke+1, j, i);
    }
}
