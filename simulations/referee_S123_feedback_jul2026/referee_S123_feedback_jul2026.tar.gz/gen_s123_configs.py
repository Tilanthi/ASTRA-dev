#!/usr/bin/env python3
"""Generate S1/S2/S3 configs (Jul 2026, astra-pa) — referee-response campaigns.

S1 (referee pt 1): MHD + user-BCs f-grid, two amplitudes — deconfounds
   BCs vs MHD physics vs perturbation amplitude for the t_frag exponent.
S2 (referee pt 2): hydro Lx ladder {8..48} for perturbation-spectrum
   diagnostic (matches Table 8 config: hydro, user transverse BCs, amp=1e-4).
S3 (minor): ambipolar-diffusion support runs (eta_ad via <problem> block;
   no recompile needed — FieldDiffusion compiled in the validated binary).
"""
from pathlib import Path

FOUR_PI_G = 39.4784176044
W_CORE = 0.3


def make_cfg(pid, f, beta, theta, Lx, seed, ampl=1e-4, mhd=False, eta_ad=None,
             nproc=16, mbx=32, tlim=0.5, hdt=0.001, odt=0.005):
    nx = int(Lx * 64)
    assert nx % mbx == 0 and nx // mbx == nproc, (nx, mbx, nproc)
    mhd_block = "<mhd>\nb_flag        = true\n</mhd>\n\n" if mhd else ""
    eta_line = f"eta_ad          = {eta_ad}\n" if eta_ad is not None else ""
    return f"""<comment>
problem   = {pid}
f={f} beta={beta} theta={theta} Lx={Lx} seed={seed} ampl={ampl} mhd={mhd} eta_ad={eta_ad}

<job>
problem_id      = {pid}
max_runtime     = 3600
num_cores       = {nproc}
restart_file    =

<output1>
file_type   = hdf5
variable    = prim
dt          = {odt}
id          = prim
data_dir    = ./{pid}/

<output2>
file_type   = hst
dt          = {hdt}
id          = hst
data_dir    = ./{pid}/

<time>
cfl_number  = 0.3
tlim        = {tlim}
nlim        = -1

<mesh>
nx1         = {nx}
x1min       = 0.0
x1max       = {Lx}
ix1_bc      = periodic
ox1_bc      = periodic
nx2         = 64
x2min       = -0.5
x2max       = 0.5
ix2_bc      = user
ox2_bc      = user
nx3         = 64
x3min       = -0.5
x3max       = 0.5
ix3_bc      = user
ox3_bc      = user

<meshblock>
nx1 = {mbx}
nx2 = 64
nx3 = 64

{mhd_block}<hydro>
gamma           = 1.0
iso_sound_speed  = 1.0

<gravity>
grav_mean_rho   = 1.0

<problem>
four_pi_G       = {FOUR_PI_G}
f_line_mass     = {f}
plasma_beta     = {beta}
theta_deg       = {theta}
mach_number     = 1.0
perturb_ampl    = {ampl}
random_seed     = {seed}
W_core          = {W_CORE}
{eta_line}"""


out = Path('configs')
n = 0
# ---- S1: MHD f-grid x 2 amplitudes x 2 seeds (20 runs)
for ampl, atag in ((1e-4, 'a4'), (1e-2, 'a2')):
    for f in (1.1, 1.5, 2.0, 2.5, 3.0):
        for seed in (42, 137):
            pid = f'S1_f{f}_b1.0_th0_Lx8_{atag}_s{seed}'
            d = out / 'S1_mhd_fgrid'
            d.mkdir(parents=True, exist_ok=True)
            (d / f'{pid}.athinput').write_text(
                make_cfg(pid, f, 1.0, 0.0, 8, seed, ampl=ampl, mhd=True,
                         nproc=16, mbx=32, tlim=0.6))
            n += 1
# ---- S2: hydro Lx ladder x 2 seeds (10 runs)
for Lx in (8, 16, 24, 32, 48):
    for seed in (42, 137):
        pid = f'S2_f1.5_b1.0_th0_Lx{Lx}_a4_s{seed}'
        d = out / 'S2_lx_ladder'
        d.mkdir(parents=True, exist_ok=True)
        (d / f'{pid}.athinput').write_text(
            make_cfg(pid, 1.5, 1.0, 0.0, Lx, seed, ampl=1e-4, mhd=False,
                     nproc=Lx, mbx=64, tlim=0.3))
        n += 1
# ---- S3: ambipolar support runs (6 runs)
for f in (1.0, 1.5):
    for eta in (0.0, 0.01, 0.05):
        tag = 'ctrl' if eta == 0.0 else f'ad{eta:g}'
        pid = f'S3_f{f}_b0.5_th0_Lx8_{tag}_s42'
        d = out / 'S3_ambipolar'
        d.mkdir(parents=True, exist_ok=True)
        (d / f'{pid}.athinput').write_text(
            make_cfg(pid, f, 0.5, 0.0, 8, 42, ampl=1e-4, mhd=True,
                     eta_ad=eta, nproc=16, mbx=32, tlim=0.5))
        n += 1
print(f'wrote {n} configs (S1=20, S2=10, S3=6)')
