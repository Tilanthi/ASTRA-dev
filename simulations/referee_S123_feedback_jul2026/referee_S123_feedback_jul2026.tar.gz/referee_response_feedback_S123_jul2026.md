# Referee-Response Feedback Package — S1/S2/S3 Campaigns (Jul 2026)

**Date**: 2026-07-20 · **Prepared by**: astra-pa (cluster-side ASTRA) · **For**: G. J. White's external ASTRA (paper revision)
**Scope**: referee report on `filament_spacing_streamlined_mnras_v31.pdf` — sims-related concerns, new evidence, and recommended paper actions
**New simulations**: 36 runs (S1: 20, S2: 10, S3: 6), all complete by 20:25 UTC 2026-07-20
**Prior package**: Campaign A/B + T1 forward model (referee #4/#5 of the *previous* round) — `simulations/referee_followup_results_jul2026/`

---

## 0. Executive summary

| Referee point | New evidence | Verdict & action |
|---|---|---|
| **1. α=0.39 vs α≈0 contradiction** | S1 (20 MHD runs, validated BCs): α = **−0.002** (amp=10⁻²) but α = **−0.29 … −0.57** (amp=10⁻⁴, r² up to 0.90) — the exponent *changes sign* with perturbation amplitude | The t_frag–f "scaling" is a **configuration-dependent artifact**, not a physical law. Remove from abstract / reframe as artifact study (§1) |
| **2. Domain-size dependence of t_coll** | S2 (10 hydro runs): the generator seeds 12 Kolmogorov velocity modes with **wavelengths that scale with Lx** (k_n = 2πn/Lx) — at Lx=48 the shortest seeded wavelength is 4 λ_J (no Jeans-scale power) and the filament **does not collapse at all** by t=0.3 | Referee's suspicion **confirmed mechanistically**: the t_coll(Lx) trend (Table 8A) is a seeding-spectrum artifact. Flag Table 8A; extended-domain (Lx≥24) results should not be used as physical evidence (§2) |
| **Minor: non-ideal MHD** | S3 (6 runs, η_AD = 0/0.01/0.05): all runs still collapse; timing ~12–15% *earlier* with AD | Claim supported; can now cite actual non-ideal runs instead of dimensional analysis alone (§3) |
| 3 (T1 propagation) | Yesterday's forward-model band η_W = 0.59–0.78 | Propagate into all λ/W_fil tables (§4.2) |
| 4–7 (budget, Aquila, split, style) | — | Editorial; specific text fixes flagged (§4) |

---

## 1. S1 — configuration isolation of the collapse-time exponent (referee point 1)

**Design**: 20 runs — MHD + transverse user BCs (validated binary), Lx=8, β=1.0, θ=0°, f = {1.1, 1.5, 2.0, 2.5, 3.0} × seeds {42, 137} × perturbation amplitude {10⁻², 10⁻⁴}. Dense HDF5 (Δt=0.005), both diagnostics per run (CFL-trigger time at dt≤10⁻⁶; density-contrast crossing times at 10/100/1000×, full-grid assembly). MHD field verified genuinely initialized (|B|max ≈ 1.4 at β=1).

**Fitted exponents** (fit: log(1/t) = a + α log f; paper convention, paper value α=+0.39):

| Amplitude | α (contrast-100) | α (contrast-1000) | α (CFL) | Interpretation |
|---|---|---|---|---|
| 10⁻² | **−0.002** (r²=0.23) | +0.007 (n=4) | −0.007 | flat — reproduces July hydro result |
| 10⁻⁴ | **−0.570** (r²=0.72) | −0.286 (r²=0.90) | −0.487 (r²=0.69) | **inverted** — collapse is *later* at higher f |

Directly observed: at amp=10⁻⁴, f=3.0 had not collapsed by t≈0.46 t_J (one seed still uncollapsed at wall-timeout; the other entering runaway only at t≈0.458) while f=1.1 collapsed at t≈0.235. Physically plausible cause: at low seeding amplitude and β~1, flux-freezing during radial compression amplifies B enough for magnetic support to resist — more strongly at higher f (deeper potential → more compression → more flux-frozen support). At amp=10⁻² the initial kinetic seeding dominates and all memory of this is erased (flat α≈0, as in hydro).

**Together with the archived results**, the exponent now spans:
- **+0.39** — May main grid (MHD, *periodic* transverse BCs, turbulent velocity seeding RMS = M·10⁻⁴ with M up to 3, i.e. 5–30× larger velocities)
- **≈ 0** — hydro+user, amp=10⁻² (July) and MHD+user, amp=10⁻² (S1)
- **−0.3 … −0.6** — MHD+user, amp=10⁻⁴ (S1)

**Verdict for the referee response**: The referee asked "which configuration is right?" The answer: the exponent is not a physical constant — it ranges from −0.5 to +0.4 across defensible configurations (boundary conditions, seeding amplitude, field). Within any one configuration the CFL trigger and the density-contrast diagnostic agree (S1 and July both), so the *diagnostic* is validated — but the *scaling* must not appear as a headline result. **Recommended actions**:
1. Remove t_frag ∝ f^−0.39 from the abstract entirely (or state it only as an example of the configuration dependence).
2. Reframe §4.6.4 as "the collapse-time–f relation is configuration-dependent (α from −0.5 to +0.4); we therefore do not quote a universal exponent" — this turns the referee's strongest criticism into a demonstration of rigor.
3. Cite Fig. S1 (`figS1_exponent_by_config.png`) as the summary evidence.
4. Note the physically interesting new result in its own right (flux-frozen support at low amplitude inverts the trend) as a secondary paragraph — possibly worth a follow-up paper.

**Residual confound (disclose honestly)**: the May grid differed from S1 in *both* BCs and amplitude. Full attribution would require re-running periodic-BC configs, which the validated binary refuses (its problem generator hard-requires user transverse BCs; rebuilding the legacy generator is possible but was judged unnecessary — the "not a physical law" conclusion is already decisive).

---

## 2. S2 — domain-size seeding diagnostic (referee point 2)

**Design**: 10 runs — hydro, f=1.5, β=1.0, amp=10⁻⁴, Lx = {8, 16, 24, 32, 48} λ_J × 2 seeds, dense snapshots; 1-D longitudinal density-perturbation power spectrum + collapse times.

**Findings**:
1. **t_coll(Lx) reproduces Table 8A** at Lx ≤ 32: 0.238 / 0.100 / 0.073 / 0.050 (Table 8A: 0.240 / 0.101 / 0.066 / 0.050). Good — same physics regime.
2. **At Lx=48 the filament does not collapse at all** by t=0.3 t_J (Table 8A claims t_coll=0.036). IC density-perturbation rms ≈ 0 — see next point.
3. **Mechanism found** (referee's requested diagnostic): the problem generator (`filament_rce.cpp`, and identically `filament_fspace.cpp`) seeds **12 Kolmogorov velocity modes with k_n = 2πn/Lx** and normalizes to fixed RMS velocity *regardless of Lx*. Consequences:
   - Seeded wavelengths are λ ∈ [Lx/12, Lx] — they **scale with the box**, not with any physical scale. At Lx=48 the shortest seeded wavelength is 4 λ_J: **zero Jeans-scale seeding**.
   - The k^−11/6 spectrum puts most power in the **n=1 box-scale mode** — exactly the referee's hypothesized artifact.
   - Measured IC density-perturbation power vs Lx is non-monotonic and spans 6 orders of magnitude (P_tot: 6×10⁻¹¹ at Lx=8 → 8×10⁻⁵ at Lx=24 → ~0 at Lx=48), and at Lx=24 both seeds give *identical* power — the seeding is effectively uncontrolled across Lx.
4. So the t_coll(Lx) decrease in Table 8A is **box-scale coherent compression by the seeding field**, not faster local Jeans physics — precisely the referee's concern. (The Lx=48 non-collapse in our runs vs 0.036 in Table 8A additionally indicates the extended-domain results are realization/config-fragile; the external ASTRA should reconcile its definitive-campaign Lx=48 records against this.)

**Recommended actions**:
1. Table 8A must be flagged: the Lx-trend is a seeding artifact; the extended-domain campaign cannot be used as evidence about physical collapse timescales or about beading at Lx≥24.
2. The **Lx=8–16 results stand** (seeding covers Jeans scales there; Lx=8 vs 16 t_frag agree <1% in §4.6.2 of the paper) — the "no supercritical beading" conclusion should be explicitly re-anchored to those.
3. For any future domain study: fix the generator to seed a **fixed physical wavelength range** (e.g., k_n = 2π/λ_n with λ_n ∈ [0.5, 8] λ_J independent of Lx). One-line code change; I can implement and re-run a corrected ladder in ~2h if wanted.
4. Cite Fig. S2 (`figS2_domain_seeding.png`).

---

## 3. S3 — ambipolar-diffusion support runs (minor point)

**Design**: 6 runs — MHD, β=0.5, θ=0°, f={1.0, 1.5} × η_AD = {0 (control), 0.01, 0.05} (η_AD set via the `<problem>` input block; the validated binary has FieldDiffusion compiled in; η_AD=0.01 corresponds to t_AD ≈ 9 t_ff at the core scale, bracketing the paper's claimed 10–20).

**Result** (`figS3_ambipolar.png`):

| | control | η_AD=0.01 | η_AD=0.05 |
|---|---|---|---|
| f=1.0 t_coll | 0.216 | 0.189 | 0.181 |
| f=1.5 t_coll | 0.226 | 0.198 | 0.192 |

All non-ideal runs **still collapse radially** (outcome unchanged); collapse is ~12–15% *earlier* (flux leakage erodes magnetic support — the conservative direction for the paper's conclusions). The referee's "at least one supporting non-ideal run" request is now satisfied by four; the text can say the ideal-MHD approximation is supported by direct non-ideal runs, not only by the dimensional estimate.

---

## 4. Other points for the external ASTRA (from my reading of the referee report + v31)

1. **Fig. 6 caption in v31 says "(Campaign A, referee #4)"** — this is exactly the retained-editorial-artifact class the referee's point 7 criticizes. Rename all such references (Campaign A/B → descriptive names) before resubmission.
2. **Table 8 internal inconsistency**: Panel A (Lx=8, amp=10⁻⁴) gives t_coll = 0.240 but Panel B at amp=10⁻⁴ gives 0.066 — Panel B must be at Lx=24 but is not labelled. Fix the label (and given S2, consider whether the whole table should carry the seeding-artifact caveat).
3. **T1 propagation (point 3)**: use the forward-model band η_W = 0.59–0.78 (yesterday's package) as the systematic and propagate it into *every* λ/W_fil entry in the main tables; demote "marginally inside the window" claims to "inside/outside depending on η_W within its 1σ band" where applicable.
4. **Error budget (point 4)**: the referee is right — the NN injection–recovery bias (±3.05%) does not belong in the pairwise-median systematic budget; recompute and separate the two budgets, showing arithmetic as done for the NN 28% figure.
5. **Abstract**: rewrite to the ~250-word convention; the configuration-dependence of the collapse-time scaling (S1) should replace the α=0.39 headline if the scaling is mentioned at all.
6. **Zenodo DOI**: mint before resubmission (referee explicitly asks; GitHub alone is not acceptable to MNRAS).
7. **Compute acknowledgment**: add CPU-hours/cost/funding statement for the ~2,200-sim campaign (referee's final minor point). From the cluster side I can supply exact run counts/wall-times for all Jul-2026 campaigns if useful — the S1/S2/S3 set alone is 36 runs ≈ 5.8 kCPU-h.
8. **On splitting (point 6)**: no sims implication; if the paper is split, the sims-based sections map naturally onto campaigns already archived on GitHub by name (May grids, Jul referee-followup, S1–S3) — cite the tarballs as data sources.

---

## 5. File inventory (this package)

| File | Content |
|---|---|
| `referee_response_feedback_S123_jul2026.md` | this document |
| `figS1_exponent_by_config.png` | exponent by configuration vs paper's 0.39 |
| `figS2_domain_seeding.png` | seeding spectrum vs Lx + t_coll vs Lx vs Table 8A |
| `figS3_ambipolar.png` | ambipolar timing comparison |
| `campaignS1_a2_timing.json`, `campaignS1_a4_timing.json` | per-run crossing times + exponent fits, both amplitudes |
| `S2_spectrum_analysis.json` | per-run IC spectra, t_coll vs Lx |
| `campaignS{1,2,3}_results.json` | runner status files |
| `analyze_campaignA_v2.py`, `analyze_S2_spectrum.py`, `gen_s123_configs.py` | analysis/config code (corrected full-grid assembly) |

Raw snapshots (~150 GB) remain on the cluster pending GJW's cleanup confirmation. Prior package (Campaign A/B + T1 forward model): `simulations/referee_followup_results_jul2026/`.
