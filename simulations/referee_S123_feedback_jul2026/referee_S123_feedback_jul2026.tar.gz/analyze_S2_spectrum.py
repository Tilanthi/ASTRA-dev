#!/usr/bin/env python3
"""S2 domain-ladder perturbation-spectrum diagnostic (referee point 2).

For each Lx-ladder run:
  1. assemble global density grid at the earliest snapshots;
  2. longitudinal profile rho_bar(x) = <rho>_{y,z}; delta = rho_bar/mean - 1;
  3. 1-D power spectrum P(k) = |FFT(delta)|^2 (density-perturbation power);
  4. report n=1 mode power, total power, and power vs k vs Lx;
  5. collapse time from .hst (dt <= 2e-5, matching the paper's Table 8
     trigger, plus dt <= 1e-6), and contrast crossings from snapshots.

If a box-scale (n=1) mode drives extended-domain collapse, its power should
grow relative to Jeans-scale power as Lx increases.

Run from the campaign directory:
  python3 analyze_S2_spectrum.py --include 'S2_*' --odt 0.005
"""
import argparse
import glob
import json
import re
from pathlib import Path

import h5py
import numpy as np


def parse(pid):
    def g(p, cast, default=None):
        m = re.search(p, pid)
        return cast(m.group(1)) if m else default
    return {'pid': pid, 'Lx': g(r'_Lx([0-9.]+)', float),
            'f': g(r'_f([0-9.]+)', float),
            'seed': g(r'_s([0-9.]+)', int)}


def global_rho(fn):
    with h5py.File(fn, 'r') as h5:
        prim = np.array(h5['prim'][0])
        loc = np.array(h5['LogicalLocations'])
    order = np.argsort(loc[:, 0])
    return np.concatenate([prim[i] for i in order], axis=2)  # (nz, ny, nx)


def spectrum(rho):
    prof = rho.mean(axis=(0, 1))          # rho_bar(x)
    d = prof / prof.mean() - 1.0
    n = len(d)
    F = np.fft.rfft(d)
    P = np.abs(F) ** 2 / n
    k = np.fft.rfftfreq(n, d=1.0 / n)     # mode index (n=1,2,...)
    return k, P, float(d.std()), float(prof.max() / prof.mean())


def hst_time(hst, thr):
    try:
        d = np.loadtxt(hst, comments='#')
    except Exception:
        return None
    if d.ndim == 1:
        d = d[None, :]
    idx = np.where(d[:, 1] <= thr)[0]
    return float(d[idx[0], 0]) if len(idx) else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--include', default='S2_*')
    ap.add_argument('--odt', type=float, default=0.005)
    ap.add_argument('--epochs', type=int, nargs='+', default=[1, 4, 10],
                    help='snapshot indices to analyse (t = idx*odt)')
    ap.add_argument('--out', default='S2_spectrum_analysis.json')
    a = ap.parse_args()

    pids = sorted(set(re.sub(r'\.prim\..*$', '', Path(x).stem)
                      for x in glob.glob(f'{a.include}.prim.*.athdf')))
    print(f'{len(pids)} runs')
    runs = []
    for pid in pids:
        rec = dict(parse(pid))
        snaps = sorted(glob.glob(f'{pid}.prim.*.athdf'),
                       key=lambda s: int(re.search(r'\.(\d+)\.athdf$', s).group(1)))
        rec['epochs'] = {}
        for want in a.epochs:
            fn = next((s for s in snaps
                       if int(re.search(r'\.(\d+)\.athdf$', s).group(1)) >= want),
                      None)
            if fn is None:
                continue
            ix = int(re.search(r'\.(\d+)\.athdf$', fn).group(1))
            try:
                rho = global_rho(fn)
            except Exception:
                continue
            k, P, rms, contrast = spectrum(rho)
            Lx = rec['Lx']
            rec['epochs'][f't={ix * a.odt:.3f}'] = {
                'rms_delta': rms,
                'axial_contrast': contrast,
                'P_n1': float(P[1]) if len(P) > 1 else None,
                'P_n2': float(P[2]) if len(P) > 2 else None,
                'P_total': float(P[1:].sum()),
                # Jeans-scale band: modes with wavelength ~ 2.8 W_core*FWHM.. use
                # wavelength in [1, 8] lambda_J -> mode n in [Lx/8, Lx/1]
                'P_jeans_band': float(P[max(1, int(Lx / 8)):int(Lx / 1) + 1].sum()),
                'spectrum_modes': [float(x) for x in P[1:9]],  # n=1..8
            }
        for thr in (2e-5, 1e-6):
            rec[f't_coll_{thr:g}'] = hst_time(f'{pid}.hst', thr)
        runs.append(rec)
        e0 = list(rec['epochs'].values())
        print(f"{pid}: t_coll(2e-5)={rec['t_coll_2e-05']} "
              f"P_n1={e0[0]['P_n1']:.2e} rms={e0[0]['rms_delta']:.2e}"
              if e0 else f'{pid}: no epochs', flush=True)

    out = {'purpose': 'referee point 2: is extended-domain collapse driven by '
                      'a box-scale (n=1) seeding mode? P(k) of the longitudinal '
                      'density perturbation vs Lx, plus t_coll vs Lx',
           'runs': runs}
    Path(a.out).write_text(json.dumps(out, indent=2))
    # summary table
    print('\nLx ladder summary (earliest epoch):')
    print(f'{"Lx":>5} {"seed":>5} {"t_coll2e-5":>10} {"P_n1":>10} '
          f'{"P_n2":>10} {"P_tot":>10} {"rms":>9}')
    for r in sorted(runs, key=lambda x: (x['Lx'], x['seed'])):
        e = list(r['epochs'].values())
        if not e:
            continue
        e = e[0]
        print(f"{r['Lx']:>5.0f} {r['seed']:>5} "
              f"{str(r['t_coll_2e-05']):>10} {e['P_n1']:>10.2e} "
              f"{e['P_n2']:>10.2e} {e['P_total']:>10.2e} {e['rms_delta']:>9.2e}")


if __name__ == '__main__':
    main()
