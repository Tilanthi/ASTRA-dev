#!/usr/bin/env python3
"""
Campaign B: Sub-Isothermal EOS in Supercritical Regime
192 sims: f=[1.5,2.0,2.5,3.0] x beta=[0.5,1.0,2.0] x gamma=[0.5,0.7,0.9,1.0]
          x theta=[0,90] x seed=[0,1]
Domain: 256x64x64, L=8 lJ, NP=32, HDF5_DT=0.01 (finer cadence)
EOS: isothermal binary with cs_eff = sqrt(gamma)
Analysis: peak-finding + power spectrum P(kx) contrast ratio
"""
import subprocess, os, time, json, math, signal
import numpy as np
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# ── config ──────────────────────────────────────────────────────────────────
ATHENA_BIN   = "/home/fetch-agi/athena/bin/athena_pr"
BASE_DIR     = Path("/data/campaign_b_runs")
RESULTS_FILE = BASE_DIR / "campaign_b_results.json"
LOG_FILE     = Path("/data/nohup_campaign_b.out")

NP           = 32
MAX_CONC     = 6
DT_KILL      = 1e-6
WALL_TIME    = 14400   # 4 hours
HDF5_DT      = 0.01    # finer cadence for transient beading
POLL         = 8       # seconds between HST checks
FOUR_PI_G    = 39.4784176044
CS_REF       = 1.0
W_CORE       = 0.3
DX1          = 8.0 / 256   # 0.03125 lJ
PS_THRESHOLD = 5.0          # P(kpeak)/P(k=0) > 5 → beading detected

BASE_DIR.mkdir(exist_ok=True)

# ── parameter grid ───────────────────────────────────────────────────────────
def build_sims():
    sims = []
    for f in [1.5, 2.0, 2.5, 3.0]:
        for beta in [0.5, 1.0, 2.0]:
            for gamma in [0.5, 0.7, 0.9, 1.0]:
                for theta in [0, 90]:
                    for seed in [0, 1]:
                        cs_eff = math.sqrt(gamma)
                        geom   = "longitudinal" if theta == 0 else "perpendicular"
                        tag    = (f"CB_f{str(f).replace('.','p')}_b{str(beta).replace('.','p')}"
                                  f"_g{str(gamma).replace('.','p')}_th{theta}_s{seed}")
                        sims.append({
                            "run_id": tag, "f": f, "beta": beta, "gamma": gamma,
                            "theta": theta, "seed": seed, "cs_eff": cs_eff,
                            "bgeom": geom,
                        })
    return sims

# ── athinput writer ──────────────────────────────────────────────────────────
def make_athinput(run_dir, p):
    cs = p["cs_eff"]
    txt = f"""<comment>
problem = campaign_b_subisothermal_eos  id={p['run_id']}

<job>
problem_id = filament_spacing_pr

<time>
cfl_number  = 0.3
nlim        = -1
tlim        = 4.0

<mesh>
nx1 = 256
x1min = 0.0
x1max = 8.0
ix1_bc = periodic
ox1_bc = periodic
nx2 = 64
x2min = -1.0
x2max = 1.0
ix2_bc = outflow
ox2_bc = outflow
nx3 = 64
x3min = -1.0
x3max = 1.0
ix3_bc = outflow
ox3_bc = outflow

<meshblock>
nx1 = 32
nx2 = 32
nx3 = 32

<hydro>
iso_sound_speed = {cs:.8f}

<field>
<problem>
four_pi_G      = {FOUR_PI_G}
f_line_mass    = {p['f']}
plasma_beta    = {p['beta']}
mach_number    = 1.0
W_core         = {W_CORE}
perturb_ampl   = 1.0e-4
random_seed    = {p['seed']}
bfield_geometry = {p['bgeom']}
theta_deg      = {p['theta']}.0

<gravity>
grav_mean_rho  = 1.0

<output1>
file_type = hst
dt        = 0.001

<output2>
file_type = hdf5
variable  = prim
id        = out2
dt        = {HDF5_DT}
"""
    (run_dir / "athinput.inp").write_text(txt)

# ── power spectrum analysis ──────────────────────────────────────────────────
def compute_power_spectrum(athdf_path):
    """Load HDF5, column-average density, FFT along x1, return (k, Pk)."""
    try:
        import h5py
        with h5py.File(athdf_path, "r") as f:
            prim        = f["prim"][:]          # (nvars, nmb, nk, nj, ni)
            locs        = f["LogicalLocations"][:] # (nmb, 3)
            nx1_mb = prim.shape[4]
            nx2_mb = prim.shape[3]
            nx3_mb = prim.shape[2]
            nmb    = prim.shape[1]
            # global grid extent
            nx1g = int(locs[:,0].max() + 1) * nx1_mb
            nx2g = int(locs[:,1].max() + 1) * nx2_mb
            nx3g = int(locs[:,2].max() + 1) * nx3_mb
            rho_3d = np.zeros((nx3g, nx2g, nx1g))
            for mb in range(nmb):
                li, lj, lk = int(locs[mb,0]), int(locs[mb,1]), int(locs[mb,2])
                i0, j0, k0 = li*nx1_mb, lj*nx2_mb, lk*nx3_mb
                rho_3d[k0:k0+nx3_mb, j0:j0+nx2_mb, i0:i0+nx1_mb] = prim[0, mb]
        # column-average over x2, x3
        rho_x = rho_3d.mean(axis=(0, 1))   # shape (nx1g,)
        rho_f = rho_x - rho_x.mean()
        Pk    = np.abs(np.fft.rfft(rho_f))**2
        k     = np.fft.rfftfreq(len(rho_x), d=DX1)
        return k, Pk
    except Exception:
        return None, None

def analyse_and_purge(run_dir, p):
    """Load all HDF5, compute lw + power spectrum, delete all HDF5."""
    hdf5_files = sorted(run_dir.glob("*.athdf"))
    if not hdf5_files:
        return {"lw_mean": None, "lw_std": None, "classification": "NO_HDF5",
                "ps_beading_detected": False, "ps_contrast_max": 0.0,
                "ps_k_peak": None, "n_snaps": 0}

    import h5py
    from scipy.signal import find_peaks

    lw_series = []
    ps_contrasts = []
    ps_kpeaks    = []
    t_series     = []

    for hf in hdf5_files:
        try:
            with h5py.File(hf, "r") as f:
                t    = float(f.attrs.get("Time", 0))
                prim = f["prim"][:]
                locs = f["LogicalLocations"][:]
            nx1_mb = prim.shape[4]; nx2_mb = prim.shape[3]; nx3_mb = prim.shape[2]
            nmb    = prim.shape[1]
            nx1g   = int(locs[:,0].max() + 1) * nx1_mb
            nx2g   = int(locs[:,1].max() + 1) * nx2_mb
            nx3g   = int(locs[:,2].max() + 1) * nx3_mb
            rho_3d = np.zeros((nx3g, nx2g, nx1g))
            for mb in range(nmb):
                li,lj,lk = int(locs[mb,0]),int(locs[mb,1]),int(locs[mb,2])
                i0,j0,k0 = li*nx1_mb, lj*nx2_mb, lk*nx3_mb
                rho_3d[k0:k0+nx3_mb, j0:j0+nx2_mb, i0:i0+nx1_mb] = prim[0, mb]

            # column density along x1
            col = rho_3d.mean(axis=(0, 1))

            # peak-finding for lw
            col_n = col / col.max()
            pks, _ = find_peaks(col_n, height=0.5, distance=int(0.5/DX1))
            if len(pks) >= 2:
                spacings = np.diff(pks) * DX1
                lw = np.mean(spacings) / W_CORE
                lw_series.append({"t": t, "lw": lw, "n_peaks": len(pks)})

            # power spectrum
            rho_x  = col - col.mean()
            Pk     = np.abs(np.fft.rfft(rho_x))**2
            k      = np.fft.rfftfreq(len(col), d=DX1)
            if len(Pk) > 1 and Pk[0] > 0:
                contrast = Pk[1:].max() / Pk[0]
                k_peak   = k[1:][np.argmax(Pk[1:])]
                ps_contrasts.append(contrast)
                ps_kpeaks.append(k_peak)
            t_series.append(t)
        except Exception:
            pass

    # delete all HDF5 + XDMF
    for hf in hdf5_files:
        hf.unlink(missing_ok=True)
    for xf in run_dir.glob("*.xdmf"):
        xf.unlink(missing_ok=True)

    # classification
    if len(lw_series) >= 2:
        lw_vals = [x["lw"] for x in lw_series]
        cv      = np.std(lw_vals) / np.mean(lw_vals) if np.mean(lw_vals) > 0 else 1
        classification = "BEADING_STABLE" if cv < 0.3 else "BEADING_TRANSIENT"
        lw_mean = float(np.mean(lw_vals)); lw_std = float(np.std(lw_vals))
    elif len(lw_series) == 1:
        classification = "BEADING_TRANSIENT"
        lw_mean = float(lw_series[0]["lw"]); lw_std = 0.0
    else:
        classification = "RADIAL_COLLAPSE"
        lw_mean = None; lw_std = None

    ps_detected = bool(ps_contrasts and max(ps_contrasts) > PS_THRESHOLD)
    ps_contrast_max = float(max(ps_contrasts)) if ps_contrasts else 0.0
    ps_k_peak   = float(np.median(ps_kpeaks)) if ps_kpeaks else None

    return {"lw_mean": lw_mean, "lw_std": lw_std, "classification": classification,
            "ps_beading_detected": ps_detected, "ps_contrast_max": ps_contrast_max,
            "ps_k_peak": ps_k_peak, "n_snaps": len(hdf5_files)}

# ── sim runner ────────────────────────────────────────────────────────────────
results_store = []

def run_sim(p):
    run_dir = BASE_DIR / p["run_id"]
    run_dir.mkdir(exist_ok=True)
    make_athinput(run_dir, p)

    cmd = ["mpirun", "--oversubscribe", f"-np", str(NP),
           ATHENA_BIN, "-i", str(run_dir/"athinput.inp"), "-d", str(run_dir)]

    t0 = time.time()
    proc = subprocess.Popen(cmd, stdout=open(run_dir/"stdout.txt","w"),
                            stderr=subprocess.STDOUT,
                            preexec_fn=os.setsid)

    hst_path  = run_dir / "filament_spacing_pr.hst"
    outcome   = "TIMEOUT"
    t_frag    = None
    dt_min    = None
    last_dt   = None

    while True:
        time.sleep(POLL)
        elapsed = time.time() - t0
        if elapsed > WALL_TIME:
            outcome = "TIMEOUT"; break

        if proc.poll() is not None:
            outcome = "FAILED"; break

        if not hst_path.exists():
            continue

        try:
            last_line = None
            with open(hst_path) as hf:
                for line in hf:
                    if not line.startswith("#"):
                        last_line = line
            if last_line:
                cols = last_line.split()
                t_cur = float(cols[0]); dt_cur = float(cols[1])
                last_dt = dt_cur
                if dt_cur < DT_KILL:
                    t_frag  = t_cur; dt_min = dt_cur
                    outcome = "FRAG"; break
                # safety HDF5 prune
                hdfs = sorted(run_dir.glob("*.athdf"))
                if len(hdfs) > 60:
                    for hf in hdfs[:-40]:
                        hf.unlink(missing_ok=True)
        except Exception:
            pass

    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except Exception:
        pass

    wall_s  = time.time() - t0
    ana     = analyse_and_purge(run_dir, p)

    rec = {**p, "outcome": outcome, "t_frag": t_frag, "dt_min": dt_min,
           "wall_s": round(wall_s,1), **ana}

    results_store.append(rec)
    with open(RESULTS_FILE, "w") as f:
        json.dump(results_store, f, indent=2)

    lw_str = f"{ana['lw_mean']:.3f}" if ana['lw_mean'] else "---"
    ps_str = f"PS:{ana['ps_contrast_max']:.1f}x" if ana['ps_contrast_max'] else "PS:---"
    tf_str = f"{t_frag:.4f}" if t_frag is not None else "---"
    print(f"[{p['run_id']}] {outcome:7s}  t={tf_str}  "
          f"{ana['classification']:20s}  lw={lw_str}  {ps_str}  wall={wall_s:.0f}s",
          flush=True)

    return rec

# ── main ──────────────────────────────────────────────────────────────────────
def main():
    sims = build_sims()
    print(f"Campaign B: {len(sims)} simulations | MAX_CONC={MAX_CONC} | NP={NP}")
    print(f"f=[1.5,2.0,2.5,3.0] | beta=[0.5,1.0,2.0] | gamma=[0.5,0.7,0.9,1.0] "
          f"| theta=[0,90] | seeds=[0,1]", flush=True)

    with ThreadPoolExecutor(max_workers=MAX_CONC) as ex:
        futs = {ex.submit(run_sim, s): s for s in sims}
        for fut in as_completed(futs):
            try:
                fut.result()
            except Exception as e:
                print(f"ERROR: {futs[fut]['run_id']}: {e}", flush=True)

    # final summary
    frags    = [r for r in results_store if r["outcome"]=="FRAG"]
    timeouts = [r for r in results_store if r["outcome"]=="TIMEOUT"]
    beadings = [r for r in results_store if r.get("lw_mean")]
    ps_det   = [r for r in results_store if r.get("ps_beading_detected")]
    lw_all   = [r["lw_mean"] for r in beadings]

    print(f"\n{'='*72}")
    print(f"CAMPAIGN B COMPLETE: {len(results_store)} sims")
    print(f"  FRAG={len(frags)}  TIMEOUT={len(timeouts)}")
    print(f"  Peak-finding beading: {len(beadings)}  "
          f"lw={np.mean(lw_all):.3f}+-{np.std(lw_all):.3f}" if lw_all else "  No lw")
    print(f"  Power-spectrum beading detected: {len(ps_det)}")
    for f_val in [1.5, 2.0, 2.5, 3.0]:
        grp = [r for r in results_store if r["f"]==f_val and r.get("lw_mean")]
        ps_g= [r for r in results_store if r["f"]==f_val and r.get("ps_beading_detected")]
        if grp:
            lws = [r["lw_mean"] for r in grp]
            print(f"  f={f_val}: lw={np.mean(lws):.3f}+-{np.std(lws):.3f} "
                  f"(n={len(grp)})  PS-det={len(ps_g)}")
    print(f"Results: {RESULTS_FILE}", flush=True)

if __name__ == "__main__":
    main()
