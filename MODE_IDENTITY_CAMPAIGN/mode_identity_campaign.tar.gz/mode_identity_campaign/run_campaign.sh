#!/bin/bash

################################################################################
# Mode Identity Campaign Execution Script
# Runs sub-isothermal vs isothermal filament simulations on Ray cluster
################################################################################

set -e  # Exit on error

# Configuration
CAMPAIGN_DIR="/tmp/mode_identity_campaign"
ATHENA_BIN="${ATHENA_BIN:-athena_pr}"  # Path to Athena++ binary
PROBLEM_GEN="filament_spacing_pr"
N_WORKERS=54
SIM_TIMEOUT=43200  # 12 hours in seconds

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "=================================="
echo "Mode Identity Validation Campaign"
echo "=================================="
echo ""
echo "This campaign will run 36 Athena++ simulations to validate mode identity"
echo "between isothermal and sub-isothermal fragmentation physics."
echo ""
echo "Resources required:"
echo "  - 220 vCPUs (54 workers × 4 CPUs)"
echo "  - ~12-24 hours walltime"
echo "  - ~500-900 GB disk storage"
echo ""

################################################################################
# Step 1: Environment Check
################################################################################

echo -e "${YELLOW}Step 1: Checking environment...${NC}"

# Check if Ray is installed
if ! command -v ray &> /dev/null; then
    echo -e "${RED}Error: Ray is not installed${NC}"
    echo "Install with: pip install ray[default]"
    exit 1
fi

# Check if Athena++ binary exists
if ! command -v $ATHENA_BIN &> /dev/null; then
    echo -e "${YELLOW}Warning: Athena++ binary not found in PATH${NC}"
    echo "Will assume 'athena_pr' is available on worker nodes"
    ATHENA_BIN="athena_pr"
fi

# Check Python packages
echo "Checking Python dependencies..."
python3 -c "import ray, numpy, pandas, h5py" 2>/dev/null || {
    echo -e "${RED}Error: Required Python packages missing${NC}"
    echo "Install with: pip install -r requirements.txt"
    exit 1
}

echo -e "${GREEN}Environment check complete${NC}"
echo ""

################################################################################
# Step 2: Create Log and Results Directories
################################################################################

echo -e "${YELLOW}Step 2: Setting up directories...${NC}"

mkdir -p "$CAMPAIGN_DIR/logs"
mkdir -p "$CAMPAIGN_DIR/results/snapshots"
mkdir -p "$CAMPAIGN_DIR/results/analysis"

echo -e "${GREEN}Directories created${NC}"
echo ""

################################################################################
# Step 3: Prepare Simulation Parameters
################################################################################

echo -e "${YELLOW}Step 3: Preparing simulation parameters...${NC}"

# Extract parameters for this worker
WORKER_ID="${RAY_WORKER_ID:-0}"
echo "Worker ID: $WORKER_ID"

# Split parameters among workers (simple round-robin)
TOTAL_SIMS=$(tail -n +2 "$CAMPAIGN_DIR/parameters.csv" | wc -l)
SIMS_PER_WORKER=$((TOTAL_SIMS / N_WORKERS))
START_IDX=$((WORKER_ID * SIMS_PER_WORKER))
END_IDX=$((START_IDX + SIMS_PER_WORKER))

if [ $WORKER_ID -eq $((N_WORKERS - 1)) ]; then
    END_IDX=$TOTAL_SIMS  # Last worker takes remainder
fi

echo "This worker will run simulations $START_IDX to $END_IDX (of $TOTAL_SIMS total)"
echo ""

# Create temporary parameter file for this worker
WORKER_PARAMS="$CAMPAIGN_DIR/logs/worker_${WORKER_ID}_params.csv"
tail -n +2 "$CAMPAIGN_DIR/parameters.csv" | sed -n "${START_IDX},$((END_IDX - 1))p" > "$WORKER_PARAMS"

echo -e "${GREEN}Parameters prepared${NC}"
echo ""

################################################################################
# Step 4: Launch Simulations via Ray
################################################################################

echo -e "${YELLOW}Step 4: Launching simulations via Ray...${NC}"

# Initialize Ray
echo "Initializing Ray cluster..."
ray start --head --port=6379 --config="$CAMPAIGN_DIR/config/ray_cluster.yaml" &
RAY_PID=$!
sleep 10

# Wait for Ray head to start
echo "Waiting for Ray cluster to initialize..."
sleep 30

# Run simulation campaign using Python
echo "Starting simulation campaign..."
python3 "$CAMPAIGN_DIR/analysis/run_simulations_ray.py" \
    --params "$WORKER_PARAMS" \
    --athena_bin "$ATHENA_BIN" \
    --output_dir "$CAMPAIGN_DIR/results" \
    --timeout $SIM_TIMEOUT \
    --workers $N_WORKERS

# Cleanup
echo "Cleaning up..."
kill $RAY_PID 2>/dev/null || true

echo ""
echo -e "${GREEN}Campaign execution complete${NC}"
echo ""
echo "Results are in: $CAMPAIGN_DIR/results"
echo "Logs are in: $CAMPAIGN_DIR/logs"
echo ""

################################################################################
# Step 5: Run Mode Identity Analysis
################################################################################

echo -e "${YELLOW}Step 5: Running mode identity analysis...${NC}"

echo "Running power spectrum comparison..."
python3 "$CAMPAIGN_DIR/analysis/power_spectrum_comparison.py" \
    --results_dir "$CAMPAIGN_DIR/results" \
    --output_dir "$CAMPAIGN_DIR/results/analysis"

echo "Running growth rate analysis..."
python3 "$CAMPAIGN_DIR/analysis/growth_rate_analysis.py" \
    --results_dir "$CAMPAIGN_DIR/results" \
    --output_dir "$CAMPAIGN_DIR/results/analysis"

echo "Running phase coherence analysis..."
python3 "$CAMPAIGN_DIR/analysis/phase_coherence.py" \
    --results_dir "$CAMPAIGN_DIR/results" \
    --output_dir "$CAMPAIGN_DIR/results/analysis"

echo ""
echo -e "${GREEN}Mode identity analysis complete${NC}"
echo ""

################################################################################
# Step 6: Generate Validation Report
################################################################################

echo -e "${YELLOW}Step 6: Generating validation report...${NC}"

python3 "$CAMPAIGN_DIR/analysis/generate_report.py" \
    --results_dir "$CAMPAIGN_DIR/results" \
    --analysis_dir "$CAMPAIGN_DIR/results/analysis" \
    --output "$CAMPAIGN_DIR/results/mode_identity_validation_report.pdf"

echo ""
echo -e "${GREEN}Validation report generated${NC}"
echo "Report location: $CAMPAIGN_DIR/results/mode_identity_validation_report.pdf"
echo ""

################################################################################
# Summary
################################################################################

echo "=================================="
echo "Campaign Summary"
echo "=================================="
echo ""
echo "Simulations run: $SIMS_PER_WORKER"
echo "Results directory: $CAMPAIGN_DIR/results"
echo "Analysis directory: $CAMPAIGN_DIR/results/analysis"
echo "Validation report: $CAMPAIGN_DIR/results/mode_identity_validation_report.pdf"
echo ""
echo "Next steps:"
echo "1. Review validation report"
echo "2. Check mode identity conclusions"
echo "3. Update paper based on findings"
echo ""
