# Mode Identity Validation Campaign
## Critical Sub-Isothermal vs Isothermal Comparison for Fragmentation Spacing Analysis

### Campaign Goal

Resolve the fundamental **mode identity uncertainty** in the filament spacing paper: Does sub-isothermal physics (γ < 1) produce the same physical fragmentation mode as isothermal physics (γ = 1.0), or are we observing different collapse processes that happen to produce similar λ/W values?

### Scientific Context

The paper claims that sub-isothermal physics "resolves" the supercritical measurement gap by enabling longitudinal beading detection at f ≥ 1.5. However, a critical caveat remains:

- **Isothermal beading** (f ≤ 1.3, γ = 1.0): Classical sausage instability mode
- **Sub-isothermal beading** (f ≥ 1.5, γ < 1): Unknown physical mode - could be:
  - Same sausage instability slowed by reduced sound speed
  - Different radial collapse mode producing axial density artefacts

**Without validation, we cannot claim the physical mechanism is the same.**

### Simulation Design

We will run **matched pairs** of isothermal and sub-isothermal simulations at overlapping line-mass fractions to enable direct mode comparison:

#### Parameter Pairs for Mode Identity Testing

| Pair | Isothermal (f, γ) | Sub-Isothermal (f, γ) | β | Purpose |
|------|-------------------|----------------------|---|---------|
| 1 | f=1.2, γ=1.0 | f=1.5, γ=0.9 | 0.5, 1.0, 2.0 | Near-critical comparison |
| 2 | f=1.3, γ=1.0 | f=1.6, γ=0.8 | 0.5, 1.0, 2.0 | Transition zone |
| 3 | f=1.0, γ=1.0 | f=1.5, γ=0.7 | 0.5, 1.0, 2.0 | Supercritical boundary |

**Total: 3 pairs × 3 β values × 2 seeds = 18 isothermal + 18 sub-isothermal = 36 simulations**

### Required Resources

- **Ray cluster**: 220 vCPUs
- **Memory per simulation**: ~6-8 GB RAM (256³ resolution)
- **Disk per simulation**: ~15-25 GB output
- **Walltime per simulation**: ~6-12 hours
- **Total walltime**: ~12-24 hours with 220 vCPUs (parallel execution)

### Setup Instructions

#### 1. Install Dependencies

```bash
# Ray cluster setup (if not already installed)
pip install ray[default] psutil
pip install numpy pandas matplotlib scipy h5py
```

#### 2. Configure Cluster

Edit `config/ray_cluster.yaml` to match your cluster configuration:
- Number of CPUs
- Memory per worker
- Object store memory

#### 3. Launch Simulations

```bash
# Activate Ray cluster
ray start --head --port=6379 --config=config/ray_cluster.yaml

# In another terminal, run the campaign
./run_campaign.sh
```

### Mode Identity Analysis Pipeline

#### 1. Power Spectrum Shape Analysis
- **Purpose**: Compare spectral signatures of isothermal vs sub-isothermal cases
- **Method**: Compute FFT of axial density profiles, compare:
  - Peak width in spectral space (narrow = coherent mode, broad = incoherent)
  - Harmonic content (multiple peaks indicate mode mixing)
  - Spectral slope (power-law tail behavior)

#### 2. Growth Rate Analysis
- **Purpose**: Measure how fast the dominant mode grows
- **Method**: Track peak density amplitude vs time, fit exponential growth
- **Expected**: Same physical mode → similar growth rates; Different modes → different growth rates

#### 3. Phase Coherence Analysis
- **Purpose**: Test if peaks form in phase along the filament
- **Method**: Compute cross-correlation between spatial segments
- **Expected**: True instability → coherent phase structure; Collapse artefacts → incoherent

#### 4. Radial Density Profile Evolution
- **Purpose**: Distinguish radial vs axial collapse
- **Method**: Extract radial profiles at peak locations over time
- **Expected**: Radial collapse → inward propagating density fronts; Axial instability → standing wave pattern

### Expected Outcomes

#### Scenario A: Same Physical Mode (Validation)
- Power spectra have similar shapes and peak widths
- Growth rates differ by < 30% after accounting for sound speed difference
- Phase coherence shows similar patterns
- **Conclusion**: Sub-isothermal beading IS the same sausage instability → paper claim validated

#### Scenario B: Different Physical Modes (Refutation)
- Power spectra have fundamentally different shapes
- Growth rates differ by > factor of 2
- Phase coherence patterns are qualitatively different
- **Conclusion**: Sub-isothermal beading is a different phenomenon → paper claim needs revision

### Deliverables

1. **Simulation data**: All 36 simulation outputs archived
2. **Mode identity analysis**: Comparative plots and statistical tests
3. **Validation report**: Scientific conclusion with quantitative confidence assessment
4. **Paper revision**: Updated abstract and conclusions based on findings

### Timeline

- **Day 1**: Setup cluster and launch simulations (12-24 hours runtime)
- **Day 2**: Initial data quality check and preliminary analysis
- **Day 3**: Mode identity analysis and report generation
- **Day 4**: Paper revision and conclusions

### Contact

For questions or issues, contact: Glenn White (G.J.White@open.ac.uk)

---

## IMPORTANT NOTES

1. **This is NOT optional**: The referee has flagged this as a critical issue that must be addressed
2. **Scientific credibility**: The paper's central claim depends on this validation
3. **Resource commitment**: Requires 220 vCPUs for ~24 hours
4. **Analysis priority**: Mode identity analysis takes priority over other work

---

## Quick Start Commands

```bash
# Clone or extract package
tar -xzf mode_identity_campaign.tar.gz
cd mode_identity_campaign

# Install dependencies
pip install -r requirements.txt

# Start Ray cluster
ray start --head --port=6379 --config=config/ray_cluster.yaml

# Run simulations (in background)
./run_campaign.sh &

# Monitor progress
watch -n 60 'tail -f logs/*.log | grep -E "FRAG|STABLE|ERROR"'
```

## File Structure

```
mode_identity_campaign/
├── README.md                    # This file
├── requirements.txt             # Python dependencies
├── run_campaign.sh              # Main execution script
├── setup_ray_cluster.py         # Ray cluster setup
├── parameters.csv                # All simulation parameters
├── config/
│   ├── ray_cluster.yaml         # Ray cluster configuration
│   └── filament_subiso.athinput # Athena++ problem generator
├── analysis/
│   ├── mode_identity_analysis.py # Main mode identification script
│   ├── power_spectrum_comparison.py
│   ├── growth_rate_analysis.py
│   ├── phase_coherence.py
│   └── radial_profile_analysis.py
├── logs/                         # Log directory
└── results/                      # Output directory
```

## Success Criteria

The campaign is successful if we can answer YES to these questions:

1. [ ] Do power spectra show similar shapes for matched isothermal/sub-isothermal pairs?
2. [ ] Do growth rates scale predictably with effective sound speed (c_eff = c_s × √γ)?
3. [ ] Is phase coherence qualitatively similar between modes?
4. [ ] Can we scientifically conclude whether the same physical instability operates?

If YES to all → Mode identity validated, paper claim strengthened
If NO to any → Mode identity uncertain, paper needs revision
