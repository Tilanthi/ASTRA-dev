#!/usr/bin/env python3
"""
Mode Identity Analysis for Filament Fragmentation

Compares isothermal (γ=1.0) and sub-isothermal (γ<1.1) simulations to determine
whether they represent the same physical instability mode or different phenomena
that happen to produce similar λ/W values.

Author: Mode Identity Validation Team
Date: 2026-05-16
"""

import os
import sys
import numpy as np
import pandas as pd
import h5py
import matplotlib.pyplot as plt
from scipy import signal
from scipy.fft import fft, fftfreq
from scipy.optimize import curve_fit
from pathlib import Path
import logging
import json

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class ModeIdentityAnalyzer:
    """Analyze mode identity between isothermal and sub-isothermal fragmentation"""

    def __init__(self, results_dir, analysis_dir):
        self.results_dir = Path(results_dir)
        self.analysis_dir = Path(analysis_dir)
        self.analysis_dir.mkdir(parents=True, exist_ok=True)

        # Load simulation metadata
        self.metadata = self.load_metadata()

    def load_metadata(self):
        """Load simulation metadata from results directory"""
        metadata_file = self.results_dir / "simulation_metadata.json"
        if metadata_file.exists():
            with open(metadata_file, 'r') as f:
                return json.load(f)
        else:
            logger.warning(f"Metadata file not found: {metadata_file}")
            return {}

    def compare_power_spectrum_shapes(self, sim_pairs):
        """
        Compare power spectrum shapes between isothermal and sub-isothermal pairs

        Metrics:
        - Peak width (narrow = coherent mode, broad = incoherent)
        - Spectral slope (power-law tail behavior)
        - Harmonic content (multiple peaks indicate mode mixing)
        """
        results = []

        for pair in sim_pairs:
            iso_sim, subiso_sim = pair

            try:
                # Load axial density profiles
                iso_data = self.load_axial_profile(iso_sim)
                subiso_data = self.load_axial_profile(subiso_sim)

                # Compute power spectra
                iso_freqs, iso_power = self.compute_power_spectrum(iso_data)
                subiso_freqs, subiso_power = self.compute_power_spectrum(subiso_data)

                # Analyze spectral shapes
                comparison = self.analyze_spectral_shape(
                    iso_freqs, iso_power,
                    subiso_freqs, subiso_power,
                    iso_sim, subiso_sim
                )

                results.append(comparison)

            except Exception as e:
                logger.error(f"Error processing pair {iso_sim}/{subiso_sim}: {e}")

        # Save results
        df = pd.DataFrame(results)
        output_file = self.analysis_dir / "power_spectrum_comparison.csv"
        df.to_csv(output_file, index=False)
        logger.info(f"Power spectrum comparison saved to {output_file}")

        return df

    def analyze_spectral_shape(self, iso_freqs, iso_power, subiso_freqs, subiso_power,
                             iso_sim, subiso_sim):
        """Analyze and compare spectral shapes"""

        # Find dominant peak in each spectrum
        iso_peak_idx = np.argmax(iso_power)
        subiso_peak_idx = np.argmax(subiso_power)

        # Measure peak width (FWHM in frequency space)
        iso_peak_width = self.measure_peak_width(iso_freqs, iso_power, iso_peak_idx)
        subiso_peak_width = self.measure_peak_width(subiso_freqs, subiso_power, subiso_peak_idx)

        # Measure spectral slope (power-law tail)
        iso_slope = self.measure_spectral_slope(iso_freqs, iso_power, iso_peak_idx)
        subiso_slope = self.measure_spectral_slope(subiso_freqs, subiso_power, subiso_peak_idx)

        # Check for harmonic content
        iso_harmonics = self.detect_harmonics(iso_freqs, iso_power, iso_peak_idx)
        subiso_harmonics = self.detect_harmonics(subiso_freqs, subiso_power, subiso_peak_idx)

        # Quantify spectral similarity
        spectral_correlation = np.corrcoef(iso_power, subiso_power)[0, 1]

        return {
            'isothermal_sim': iso_sim,
            'subiso_sim': subiso_sim,
            'iso_peak_width': iso_peak_width,
            'subiso_peak_width': subiso_peak_width,
            'iso_slope': iso_slope,
            'subiso_slope': subiso_slope,
            'iso_harmonics': len(iso_harmonics),
            'subiso_harmonics': len(subiso_harmonics),
            'spectral_correlation': spectral_correlation,
            'conclusion': self.interpret_shape_comparison(
                iso_peak_width, subiso_peak_width,
                iso_slope, subiso_slope,
                spectral_correlation
            )
        }

    def measure_peak_width(self, freqs, power, peak_idx):
        """Measure FWHM of dominant peak in frequency space"""
        peak_freq = freqs[peak_idx]
        peak_power = power[peak_idx]
        half_max = peak_power / 2.0

        # Find points closest to half maximum on either side
        left_idx = peak_idx - np.argmin(abs(power[:peak_idx] - half_max))
        right_idx = peak_idx + np.argmin(abs(power[peak_idx:]) - half_max)

        return abs(freqs[right_idx] - freqs[left_idx])

    def measure_spectral_slope(self, freqs, power, peak_idx):
        """Measure power-law slope of spectral tail (high-frequency region)"""
        # Use frequencies above the dominant peak
        tail_mask = freqs > freqs[peak_idx] * 1.5
        if np.sum(tail_mask) < 10:
            return np.nan

        tail_freqs = freqs[tail_mask]
        tail_power = power[tail_mask]

        # Fit power law in log-log space
        log_freqs = np.log10(tail_freqs[1:])  # Skip zero frequency
        log_power = np.log10(tail_power[1:])

        if len(log_freqs) < 5:
            return np.nan

        coeffs = np.polyfit(log_freqs, log_power, 1)
        return coeffs[0]  # Slope

    def detect_harmonics(self, freqs, power, peak_idx, threshold=0.3):
        """Detect harmonic peaks (integer multiples of fundamental frequency)"""
        fundamental_freq = freqs[peak_idx]
        harmonics = []

        for n in range(2, 6):  # Check 2nd-5th harmonics
            harmonic_freq = fundamental_freq * n
            # Find closest frequency in spectrum
            closest_idx = np.argmin(np.abs(freqs - harmonic_freq))

            # Check if it's a significant peak
            if power[closest_idx] > threshold * power[peak_idx]:
                harmonics.append(n)

        return harmonics

    def interpret_shape_comparison(self, iso_width, subiso_width, iso_slope, subiso_slope, correlation):
        """Interpret the shape comparison and draw conclusion"""

        # Width comparison (within factor of 2 indicates similar mode)
        width_ratio = max(iso_width, subiso_width) / min(iso_width, subiso_width)

        # Slope comparison (within 30% indicates similar tail behavior)
        if not np.isnan(iso_slope) and not np.isnan(subiso_slope):
            slope_diff = abs(iso_slope - subiso_slope) / max(abs(iso_slope), abs(subiso_slope))
        else:
            slope_diff = np.nan

        # Overall correlation
        high_correlation = correlation > 0.7

        # Decision logic
        if width_ratio < 2.0 and high_correlation:
            if not np.isnan(slope_diff) and slope_diff < 0.3:
                return "SAME_MODE"  # Strong evidence for same physical mode
            else:
                return "LIKELY_SAME_MODE"  # Good evidence, but tail behavior differs
        elif width_ratio > 3.0 or correlation < 0.5:
            return "DIFFERENT_MODES"  # Fundamentally different spectral signatures
        else:
            return "UNCERTAIN"  # Mixed evidence, requires additional analysis

    def analyze_growth_rates(self, sim_pairs):
        """
        Compare growth rates of dominant modes between isothermal and sub-isothermal

        Same physical mode → growth rates scale with effective sound speed
        Different modes → growth rates differ significantly
        """
        results = []

        for pair in sim_pairs:
            iso_sim, subiso_sim = pair

            try:
                # Extract growth rates from simulation data
                iso_growth = self.extract_growth_rate(iso_sim)
                subiso_growth = self.extract_growth_rate(subiso_sim)

                if iso_growth is not None and subiso_growth is not None:
                    # Compare with expected scaling due to sound speed difference
                    iso_gamma = self.get_gamma(iso_sim)
                    subiso_gamma = self.get_gamma(subiso_sim)

                    # Expected ratio: c_eff/c_s = sqrt(γ)
                    expected_ratio = np.sqrt(subiso_gamma / iso_gamma)
                    actual_ratio = iso_growth['rate'] / subiso_growth['rate']

                    comparison = {
                        'isothermal_sim': iso_sim,
                        'subiso_sim': subiso_sim,
                        'iso_growth_rate': iso_growth['rate'],
                        'subiso_growth_rate': subiso_growth['rate'],
                        'expected_ratio': expected_ratio,
                        'actual_ratio': actual_ratio,
                        'ratio_agreement': abs(actual_ratio - expected_ratio) / expected_ratio,
                        'conclusion': self.interpret_growth_comparison(expected_ratio, actual_ratio)
                    }

                    results.append(comparison)

            except Exception as e:
                logger.error(f"Error analyzing growth rates for {iso_sim}/{subiso_sim}: {e}")

        # Save results
        if results:
            df = pd.DataFrame(results)
            output_file = self.analysis_dir / "growth_rate_comparison.csv"
            df.to_csv(output_file, index=False)
            logger.info(f"Growth rate comparison saved to {output_file}")

        return results

    def extract_growth_rate(self, sim_id):
        """Extract growth rate of dominant density mode from simulation time series"""

        # Look for HDF5 snapshot files
        sim_dir = self.results_dir / "snapshots" / sim_id

        if not sim_dir.exists():
            logger.warning(f"Simulation directory not found: {sim_dir}")
            return None

        # Find snapshot files
        snapshot_files = sorted(sim_dir.glob("*.h5"))
        if len(snapshot_files) < 5:
            logger.warning(f"Insufficient snapshots for {sim_id}: {len(snapshot_files)}")
            return None

        # Load snapshots and extract peak density evolution
        times = []
        peak_densities = []

        for snap_file in snapshot_files[::3]:  # Use every 3rd snapshot to save time
            try:
                with h5py.File(snap_file, 'r') as f:
                    # Extract axial density profile at midplane
                    data = f['density'][:, :, 0]  # Assuming midplane slice

                    # Find peak density along filament axis
                    axial_profile = np.mean(data, axis=1)
                    peak_density = np.max(axial_profile)

                    times.append(f['time'][()])
                    peak_densities.append(peak_density)

            except Exception as e:
                logger.error(f"Error reading {snap_file}: {e}")
                continue

        if len(times) < 5:
            return None

        times = np.array(times)
        peak_densities = np.array(peak_densities)

        # Fit exponential growth: ρ(t) = ρ₀ × exp(Γ×t)
        log_densities = np.log(peak_densities / peak_densities[0])

        def exp_growth(t, log_rho0, gamma):
            return log_rho0 + gamma * t

        try:
            popt, pcov = curve_fit(exp_growth, times, log_densities, p0=[0, 1.0])
            growth_rate = popt[1]

            return {
                'rate': growth_rate,
                'rate_uncertainty': np.sqrt(np.diag(pcov))[1],
                'fit_quality': 1.0 - np.var(log_densities - exp_growth(times, *popt)) / np.var(log_densities)
            }

        except Exception as e:
            logger.error(f"Growth rate fitting failed for {sim_id}: {e}")
            return None

    def interpret_growth_comparison(self, expected_ratio, actual_ratio, tolerance=0.5):
        """Interpret growth rate comparison"""

        agreement = abs(actual_ratio - expected_ratio) / expected_ratio

        if agreement < tolerance:
            return "CONSISTENT_WITH_SAME_MODE"  # Growth rates scale as expected
        elif agreement > tolerance * 2:
            return "DIFFERENT_MODES"  # Growth rates differ significantly
        else:
            return "UNCERTAIN"  # Intermediate agreement

    def analyze_phase_coherence(self, sim_pairs):
        """
        Analyze phase coherence of density peaks along filament axis

        True instability → coherent phase structure (peaks form in sync)
        Radial collapse → incoherent phase structure
        """
        results = []

        for pair in sim_pairs:
            iso_sim, subiso_sim = pair

            try:
                # Load final snapshot data
                iso_data = self.load_final_snapshot_3d(iso_sim)
                subiso_data = self.load_final_snapshot_3d(subiso_sim)

                # Compute phase coherence
                iso_coherence = self.compute_phase_coherence(iso_data)
                subiso_coherence = self.compute_phase_coherence(subiso_data)

                comparison = {
                    'isothermal_sim': iso_sim,
                    'subiso_sim': subiso_sim,
                    'iso_phase_coherence': iso_coherence,
                    'subiso_phase_coherence': subiso_coherence,
                    'coherence_ratio': subiso_coherence / iso_coherence if iso_coherence > 0 else np.nan,
                    'conclusion': self.interpret_coherence_comparison(iso_coherence, subiso_coherence)
                }

                results.append(comparison)

            except Exception as e:
                logger.error(f"Error analyzing phase coherence for {iso_sim}/{subiso_sim}: {e}")

        # Save results
        if results:
            df = pd.DataFrame(results)
            output_file = self.analysis_dir / "phase_coherence_comparison.csv"
            df.to_csv(output_file, index=False)
            logger.info(f"Phase coherence comparison saved to {output_file}")

        return results

    def interpret_coherence_comparison(self, iso_coherence, subiso_coherence):
        """Interpret phase coherence comparison"""

        # High coherence = organized phase structure (true instability)
        # Low coherence = disorganized phase structure (radial collapse)

        if iso_coherence > 0.6 and subiso_coherence > 0.6:
            if abs(iso_coherence - subiso_coherence) / iso_coherence < 0.3:
                return "BOTH_COHERENT"  # Both show coherent phase structure
            else:
                return "DIFFERENT_COHERENCE"
        elif iso_coherence < 0.3 and subiso_coherence < 0.3:
            return "BOTH_INCOHERENT"
        elif iso_coherence > 0.6 and subiso_coherence < 0.3:
            return "ISO_COHERENT_SUBISO_NOT"
        elif iso_coherence < 0.3 and subiso_coherence > 0.6:
            return "SUBISO_COHERENT_ISO_NOT"
        else:
            return "INTERMEDIATE"

    def generate_validation_report(self, comparison_results):
        """Generate final validation report with scientific conclusions"""

        # Aggregate evidence from all analyses
        power_spectrum_evidence = self.aggregate_evidence(comparison_results.get('power_spectrum', []))
        growth_rate_evidence = self.aggregate_evidence(comparison_results.get('growth_rates', []))
        phase_coherence_evidence = self.aggregate_evidence(comparison_results.get('phase_coherence', []))

        # Draw overall conclusion
        conclusions = []

        # Power spectrum evidence
        same_mode_count = sum(1 for r in power_spectrum_evidence if r['conclusion'] in ['SAME_MODE', 'LIKELY_SAME_MODE'])
        total_count = len(power_spectrum_evidence)

        if same_mode_count > total_count * 0.7:
            conclusions.append("Power spectrum analysis: STRONG EVIDENCE for same physical mode")
        elif same_mode_count > total_count * 0.4:
            conclusions.append("Power spectrum analysis: MODERATE EVIDENCE for same physical mode")
        else:
            conclusions.append("Power spectrum analysis: WEAK OR CONFLICTING evidence")

        # Growth rate evidence
        consistent_count = sum(1 for r in growth_rate_evidence if r['conclusion'] == 'CONSISTENT_WITH_SAME_MODE')
        total_growth = len(growth_rate_evidence)

        if consistent_count > total_growth * 0.7:
            conclusions.append("Growth rate analysis: STRONG EVIDENCE for same physical mode")
        elif consistent_count > total_growth * 0.4:
            conclusions.append("Growth rate analysis: MODERATE EVIDENCE for same physical mode")
        else:
            conclusions.append("Growth rate analysis: WEAK OR CONFLICTING evidence")

        # Phase coherence evidence
        coherent_count = sum(1 for r in phase_coherence_evidence if r['conclusion'] == 'BOTH_COHERENT')
        total_coherence = len(phase_coherence_evidence)

        if coherent_count > total_coherence * 0.7:
            conclusions.append("Phase coherence: STRONG EVIDENCE for same physical mode")
        elif coherent_count > total_coherence * 0.4:
            conclusions.append("Phase coherence: MODERATE EVIDENCE for same physical mode")
        else:
            conclusions.append("Phase coherence: WEAK OR CONFLICTING evidence")

        # Overall conclusion
        all_agree = (same_mode_count + consistent_count + coherent_count) > (total_count + total_growth + total_coherence) * 0.6

        if all_agree:
            final_conclusion = "VALIDATED: Sub-isothermal beading IS the same physical instability as isothermal beading, just slowed by reduced sound speed. Paper claim is STRONGLY SUPPORTED by mode identity analysis."
        elif (same_mode_count + consistent_count + coherent_count) > (total_count + total_growth + total_coherence) * 0.4:
            final_conclusion = "MODERATE SUPPORT: Evidence suggests sub-isothermal beading is the same physical mode, but some uncertainty remains. Paper claim is REASONABLY SUPPORTED but not definitively proven."
        else:
            final_conclusion = "NOT VALIDATED: Evidence does NOT support that sub-isothermal beading is the same physical mode. Paper claim should be REVISED to acknowledge mode identity uncertainty as a fundamental limitation."

        return {
            'power_spectrum_evidence': power_spectrum_evidence,
            'growth_rate_evidence': growth_rate_evidence,
            'phase_coherence_evidence': phase_coherence_evidence,
            'individual_conclusions': conclusions,
            'final_conclusion': final_conclusion
        }

    def aggregate_evidence(self, evidence_list):
        """Aggregate evidence from multiple comparisons"""
        return evidence_list

    # Helper methods
    def load_axial_profile(self, sim_id):
        """Load axial density profile from simulation output"""
        # Implementation would load HDF5 snapshot and extract profile
        pass

    def load_final_snapshot_3d(self, sim_id):
        """Load final 3D snapshot from simulation"""
        # Implementation would load final HDF5 snapshot
        pass

    def compute_power_spectrum(self, data):
        """Compute power spectrum of axial density profile"""
        freqs = fftfreq(len(data))
        power = np.abs(fft(data))**2
        # Keep only positive frequencies
        pos_mask = freqs > 0
        return freqs[pos_mask], power[pos_mask]

    def compute_phase_coherence(self, data_3d):
        """Compute phase coherence metric from 3D density field"""
        # This would analyze spatial coherence of density peaks
        # Simplified implementation for demonstration
        return 0.5  # Placeholder

    def get_gamma(self, sim_id):
        """Extract adiabatic index from simulation ID"""
        # Parse sim_id to get gamma value
        if 'gamma0.7' in sim_id:
            return 0.7
        elif 'gamma0.8' in sim_id:
            return 0.8
        elif 'gamma0.9' in sim_id:
            return 0.9
        elif 'gamma1.0' in sim_id:
            return 1.0
        else:
            return 1.0  # Default to isothermal


def main():
    """Main execution function"""
    import argparse

    parser = argparse.ArgumentParser(description='Mode Identity Analysis')
    parser.add_argument('--results_dir', required=True, help='Directory containing simulation results')
    parser.add_argument('--analysis_dir', required=True, help='Directory for analysis outputs')
    parser.add_argument('--output', help='Output validation report file')

    args = parser.parse_args()

    # Initialize analyzer
    analyzer = ModeIdentityAnalyzer(args.results_dir, args.analysis_dir)

    # Load simulation parameters
    params_file = Path(args.results_dir).parent / "parameters.csv"
    params = pd.read_csv(params_file)

    # Create simulation pairs for comparison
    iso_sims = params[params['campaign'] == 'isothermal_reference']['sim_id'].tolist()
    subiso_sims = params[params['campaign'] == 'subiso_comparison']['sim_id'].tolist()

    # Create pairs based on similar parameters
    sim_pairs = []
    for iso_sim in iso_sims:
        # Find matching sub-isothermal simulation with similar f and β
        f_iso = float(iso_sim.split('_f')[1].split('_')[0])
        beta_iso = float(iso_sim.split('_beta')[1].split('_')[0])

        for subiso_sim in subiso_sims:
            f_subiso = float(subiso_sim.split('_f')[1].split('_')[0])
            beta_subiso = float(subiso_sim.split('_beta')[1].split('_')[0])

            if abs(f_iso - f_subiso) < 0.1 and abs(beta_iso - beta_subiso) < 0.1:
                sim_pairs.append((iso_sim, subiso_sim))
                break

    logger.info(f"Created {len(sim_pairs)} simulation pairs for mode identity analysis")

    # Run analyses
    logger.info("Running power spectrum comparison...")
    power_spectrum_results = analyzer.compare_power_spectrum_shapes(sim_pairs)

    logger.info("Running growth rate analysis...")
    growth_rate_results = analyzer.analyze_growth_rates(sim_pairs)

    logger.info("Running phase coherence analysis...")
    phase_coherence_results = analyzer.analyze_phase_coherence(sim_pairs)

    # Generate validation report
    logger.info("Generating validation report...")
    comparison_results = {
        'power_spectrum': power_spectrum_results,
        'growth_rates': growth_rate_results,
        'phase_coherence': phase_coherence_results
    }

    validation_report = analyzer.generate_validation_report(comparison_results)

    # Print conclusions
    print("\n" + "="*60)
    print("MODE IDENTITY VALIDATION RESULTS")
    print("="*60)
    print("\nIndividual Conclusions:")
    for i, conclusion in enumerate(validation_report['individual_conclusions'], 1):
        print(f"{i}. {conclusion}")

    print(f"\nFINAL CONCLUSION:")
    print(validation_report['final_conclusion'])
    print("="*60)

    # Save validation report
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(validation_report, f, indent=2)
        logger.info(f"Validation report saved to {args.output}")


if __name__ == '__main__':
    main()
