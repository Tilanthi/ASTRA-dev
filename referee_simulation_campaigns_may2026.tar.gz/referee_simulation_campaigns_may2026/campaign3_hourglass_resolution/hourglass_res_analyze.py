#!/usr/bin/env python3
"""Hourglass Resolution Convergence Analysis"""
import h5py
import numpy as np
import json
from pathlib import Path

def analyze_hourglass_resolution():
    """Test convergence across 128^3 -> 256^3 -> 512^3"""
    with open("hourglass_res_params.json") as f:
        config = json.load(f)
    
    results = []
    for sim in config["simulations"]:
        output_dir = Path(sim["output_dir"])
        # Measure t_frag at each resolution
        results.append({"sim_id": sim["sim_id"], "t_frag": 0.0})
    
    # Test: inverted f-dependence persists across all resolutions?
    # Compute relative convergence
    with open("hourglass_res_convergence.json", "w") as f:
        json.dump(results, f, indent=2)
    return results

if __name__ == "__main__":
    analyze_hourglass_resolution()
