// Athena++ Problem Generator for Hourglass Resolution Convergence
// Based on existing hourglass problem generator
// Key modifications: test resolutions 128^3, 256^3, 512^3
// Hourglass field: B_z(r) = B_0 * [1 + (r/r_waist)^2]^(-1)
//
// Find existing hourglass implementation and modify for resolution testing
