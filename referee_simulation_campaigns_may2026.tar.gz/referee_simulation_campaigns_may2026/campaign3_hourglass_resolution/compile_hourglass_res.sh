#!/bin/bash
set -e
# Compile for hourglass resolution tests
ATHENA_ROOT="${ATHENA_ROOT:-/path/to/athena++}"
cp filament_hourglass_res.cpp "$ATHENA_ROOT/src/problems/"
cd "$ATHENA_ROOT"
./configure --prob=filament_hourglass_res --coord=cartesian
make clean && make -j 8
cp bin/athena campaign3_hourglass_resolution/athena_hourglass_res
