#!/usr/bin/env python3
"""
CTZM Validation Campaign Launcher - Ray Distributed Task Scheduler
====================================================================

Launches 8 Athena++ simulations for extended CTZM validation (Referee Comment #4).
Configured for 200-CPU cluster execution.

Usage:
    python ctzm_validation_launcher.py

Author: ASTRA Autonomous System
Date: 2026-05-17
"""

import ray
import subprocess
import json
import time
import sys
import argparse
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any
import logging
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ctzm_validation_launcher.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ======================================================================
# Campaign Configuration
# ======================================================================

CAMPAIGN_CONFIG = {
    "infrastructure": {
        "num_cpus": 200,
        "concurrent_sims": 4,
        "mpi_ranks_per_sim": 32,
        "memory_per_sim_gb": 8,
        "timeout_sec": 14400,  # 4 hours
    },
    "simulation": {
        "binary_path": "./athena_ctzm_val",
        "domain": "16x2x2",
        "geometry": "slab",
        "boundary": "periodic",
        "eos": "isothermal",
        "cs": 1.0,
    },
    "output": {
        "hdf5_interval": "0.01",  # CRITICAL: Very fine sampling
        "max_snapshots": 300,
    }
}

# ======================================================================
# Ray Remote Task Execution
# ======================================================================

@ray.remote(num_cpus=32, max_calls=1)
def run_simulation(sim_params: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run a single Athena++ simulation as a Ray remote task.

    Args:
        sim_params: Simulation parameters (f, beta, gamma, seed, output_dir)
        config: Campaign configuration

    Returns:
        Dictionary with simulation results
    """
    import subprocess
    import os
    from pathlib import Path
    import time

    sim_id = sim_params['sim_id']
    output_dir = Path(sim_params['output_dir'])

    # Create output directory
    output_dir.mkdir(parents=True, exist_ok=True)

    # Prepare environment
    env = os.environ.copy()
    env['OMP_NUM_THREADS'] = '1'

    # Prepare MPI command
    mpi_cmd = [
        'mpirun',
        '-np', str(config['infrastructure']['mpi_ranks_per_sim']),
        str(config['simulation']['binary_path']),
        '-i', 'input_ctzm_val',
        '-d', str(output_dir)
    ]

    # Create input file
    input_file = output_dir / 'input_ctzm_val'
    _create_input_file(input_file, sim_params, config)

    # Run simulation
    start_time = time.time()
    log_file = output_dir / f'{sim_id}.log'

    try:
        with open(log_file, 'w') as f:
            result = subprocess.run(
                mpi_cmd,
                cwd=output_dir,
                env=env,
                stdout=f,
                stderr=subprocess.STDOUT,
                timeout=config['infrastructure']['timeout_sec']
            )

        wall_time = time.time() - start_time

        return {
            'sim_id': sim_id,
            'status': 'success' if result.returncode == 0 else 'failed',
            'returncode': result.returncode,
            'wall_time_hours': wall_time / 3600,
            'output_dir': str(output_dir),
        }

    except subprocess.TimeoutExpired:
        return {
            'sim_id': sim_id,
            'status': 'timeout',
            'wall_time_hours': config['infrastructure']['timeout_sec'] / 3600,
            'output_dir': str(output_dir),
        }
    except Exception as e:
        return {
            'sim_id': sim_id,
            'status': 'error',
            'error': str(e),
            'output_dir': str(output_dir),
        }

def _create_input_file(input_path: Path, params: Dict, config: Dict):
    """Create Athena++ input file for CTZM validation simulation."""
    f = params['f']
    beta = params['beta']
    gamma = params.get('gamma', 1.0)
    seed = params['seed']

    content = f"""<job>
  problem_id   = filament_ctzm_val

  <time>
    nlim          = 1.0e8
    tlim          = 3.0
    dt_watchdog   = 1.0e-8
  </time>

  <mesh>
    nx1           = 256
    nx2           = 32
    nx3           = 32
    x1min         = -8.0
    x1max         = 8.0
    x2min         = -1.0
    x2max         = 1.0
    x3min         = -1.0
    x3max         = 1.0
    ix1_bc        = periodic
    ix2_bc        = periodic
    ix3_bc        = periodic
    block_size    = 32
  </mesh>

  <hydro>
    iso_sound_speed = {config['simulation']['cs']}
    gamma_e         = {gamma}
  </hydro>

  <field>
    b_type        = block
    b1            = 0.0
    b2            = 0.0
    b3            = {1.0 / (beta**0.5)}
  </field>

  <problem>
    f_mass        = {f}
    pert_seed     = {seed}
  </problem>

  <output1>
    out_fmt       = 24
    dt            = {config['output']['hdf5_interval']}
    data_format   = %12.5e
    variable      = cons
    file_num      = 0
    file_sfre     = full
  </output1>
"""

    with open(input_path, 'w') as f:
        f.write(content)

# ======================================================================
# Main Execution
# ======================================================================

def main():
    """Main execution function."""
    parser = argparse.ArgumentParser(description='Launch CTZM validation campaign')
    parser.add_argument('--config', default='ctzm_validation_params.json', help='Parameter file')
    parser.add_argument('--cpus', type=int, default=200, help='Number of CPUs')
    args = parser.parse_args()

    logger.info("=" * 70)
    logger.info("CTZM VALIDATION CAMPAIGN LAUNCHER")
    logger.info("=" * 70)
    logger.info(f"Start time: {datetime.now().isoformat()}")

    # Load parameter grid
    config_file = Path(__file__).parent / args.config
    with open(config_file, 'r') as f:
        campaign_config = json.load(f)

    simulations = campaign_config['simulations']
    total_sims = len(simulations)

    logger.info(f"Total simulations: {total_sims}")
    logger.info(f"CPUs available: {args.cpus}")
    logger.info(f"Concurrent simulations: {CAMPAIGN_CONFIG['infrastructure']['concurrent_sims']}")

    # Initialize Ray
    ray.init(num_cpus=args.cpus, logging_level=logging.WARNING)

    # Launch simulations in batches
    batch_size = CAMPAIGN_CONFIG['infrastructure']['concurrent_sims']
    results = []

    for i in range(0, len(simulations), batch_size):
        batch = simulations[i:i+batch_size]
        logger.info(f"Launching batch {i//batch_size + 1}/{(len(simulations)-1)//batch_size + 1}")

        # Submit batch to Ray
        futures = [
            run_simulation.remote(sim_params, CAMPAIGN_CONFIG)
            for sim_params in batch
        ]

        # Wait for completion
        batch_results = ray.get(futures)
        results.extend(batch_results)

        # Report batch results
        for r in batch_results:
            logger.info(f"  {r['sim_id']}: {r['status']} ({r['wall_time_hours']:.2f} hours)")

    # Save results summary
    results_file = Path('ctzm_validation_results.json')
    with open(results_file, 'w') as f:
        json.dump({
            'campaign': 'CTZM Validation',
            'timestamp': datetime.now().isoformat(),
            'total_simulations': total_sims,
            'results': results
        }, f, indent=2)

    # Summary statistics
    successful = sum(1 for r in results if r['status'] == 'success')
    failed = sum(1 for r in results if r['status'] == 'failed')
    timeout = sum(1 for r in results if r['status'] == 'timeout')

    logger.info("=" * 70)
    logger.info("CAMPAIGN COMPLETE")
    logger.info("=" * 70)
    logger.info(f"Successful: {successful}/{total_sims}")
    logger.info(f"Failed: {failed}/{total_sims}")
    logger.info(f"Timeout: {timeout}/{total_sims}")
    logger.info(f"Results saved to: {results_file}")

    ray.shutdown()

    return 0 if successful == total_sims else 1

if __name__ == '__main__':
    sys.exit(main())
