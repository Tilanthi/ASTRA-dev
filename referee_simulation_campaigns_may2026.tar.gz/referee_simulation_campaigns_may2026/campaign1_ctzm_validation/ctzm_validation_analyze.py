#!/usr/bin/env python3
"""
CTZM Validation Analysis - Peak Detection and Classification
============================================================

Analyzes HDF5 outputs from CTZM validation campaign to determine
whether beading detection window is resolved by temporal sampling.

Usage:
    python ctzm_validation_analyze.py

Author: ASTRA Autonomous System
Date: 2026-05-17
"""

import h5py
import numpy as np
from scipy.signal import find_peaks
from scipy.ndimage import gaussian_filter1d
from pathlib import Path
import json
import logging
from typing import Dict, List, Tuple
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ======================================================================
# Analysis Configuration
# ======================================================================

ANALYSIS_CONFIG = {
    'hdf5_interval': 0.01,  # tJ
    'density_threshold': 0.10,  # 10% above background
    'peak_prominence': 0.05,  # 5% above background
    'smooth_sigma': 2.0,  # cells
    'wavelength_cells': 32.0,  # W = 0.1 pc in our units
}

# ======================================================================
# HDF5 Data Loading
# ======================================================================

def load_simulation_data(output_dir: Path) -> List[Dict]:
    """Load all HDF5 snapshots from simulation directory."""
    snapshots = []

    for snap_file in sorted(output_dir.glob('*.hdf5')):
        try:
            with h5py.File(snap_file, 'r') as f:
                time = f['Attributes'].get('Time', 0.0)[()]

                # Get density field
        rho = f['dens'][()]  # Full 3D density

                # Extract axial profile
                nx, ny, nz = rho.shape
                ax_profile = np.mean(rho[:, ny//2-4:ny//2+4, nz//2-4:nz//2+4], axis=(1, 2))

                # Normalize by background
                rho0 = np.mean(ax_profile)
                delta_rho = (ax_profile - rho0) / rho0

                snapshots.append({
                    'time': time,
                    'delta_rho': delta_rho,
                    'rho': ax_profile,
                    'rho0': rho0,
                })
        except Exception as e:
            logger.warning(f"Failed to load {snap_file}: {e}")
            continue

    return snapshots

# ======================================================================
# Peak Detection
# ======================================================================

def detect_peaks(delta_rho: np.ndarray, config: Dict) -> Tuple[np.ndarray, Dict]:
    """Detect peaks in axial density profile."""
    # Smooth
    delta_smooth = gaussian_filter1d(delta_rho, sigma=config['smooth_sigma'])

    # Find peaks
    peaks, properties = find_peaks(
        delta_smooth,
        prominence=config['peak_prominence'],
        distance=8  # Minimum spacing between peaks
    )

    # Filter by threshold
    valid_peaks = peaks[delta_smooth[peaks] > config['density_threshold']]

    return valid_peaks, {
        'n_peaks': len(valid_peaks),
        'prominences': properties.get('prominences', []),
        'widths': properties.get('widths', []),
    }

# ======================================================================
# Beading Classification
# ======================================================================

def classify_beading(snapshots: List[Dict], config: Dict) -> Dict:
    """
    Classify simulation based on beading detection.

    Returns:
        Dictionary with classification and measurements
    """
    n_snapshots = len(snapshots)
    times = [s['time'] for s in snapshots]
    hdf5_interval = config['hdf5_interval']

    # Detect peaks in each snapshot
    peak_counts = []
    peak_detected = []

    for snap in snapshots:
        peaks, props = detect_peaks(snap['delta_rho'], config)
        peak_counts.append(props['n_peaks'])
        peak_detected.append(props['n_peaks'] >= 2)

    # Find detection window
    detected_snapshots = [i for i, p in enumerate(peak_detected) if p]

    if len(detected_snapshots) == 0:
        return {
            'classification': 'NO_BEADING',
            't_detect_start': None,
            't_detect_end': None,
            'dt_beading': 0.0,
            'n_peaks_max': 0,
        }

    t_detect_start = times[detected_snapshots[0]]
    t_detect_end = times[detected_snapshots[-1]]
    dt_beading = t_detect_end - t_detect_start

    # Classification based on detection window vs sampling interval
    if dt_beading > 2 * hdf5_interval:
        classification = 'RESOLVED'
    elif dt_beading > hdf5_interval:
        classification = 'MARGINAL'
    else:
        classification = 'UNRESOLVED'

    return {
        'classification': classification,
        't_detect_start': t_detect_start,
        't_detect_end': t_detect_end,
        'dt_beading': dt_beading,
        'n_peaks_max': max(peak_counts),
        'n_snapshots_detected': len(detected_snapshots),
    }

# ======================================================================
# Main Analysis
# ======================================================================

def analyze_campaign(params_file: Path = Path('ctzm_validation_params.json')):
    """Analyze all simulations in campaign."""
    with open(params_file, 'r') as f:
        campaign = json.load(f)

    results = []

    for sim in campaign['simulations']:
        logger.info(f"Analyzing {sim['sim_id']}")

        output_dir = Path(sim['output_dir'])
        if not output_dir.exists():
            logger.warning(f"Output directory not found: {output_dir}")
            continue

        # Load data
        snapshots = load_simulation_data(output_dir)
        if len(snapshots) == 0:
            logger.warning(f"No snapshots found for {sim['sim_id']}")
            continue

        # Classify
        classification = classify_beading(snapshots, ANALYSIS_CONFIG)
        classification.update(sim)

        results.append(classification)
        logger.info(f"  Classification: {classification['classification']}")
        logger.info(f"  Δt_beading: {classification['dt_beading']:.3f} tJ")

    # Save results
    output_file = Path('ctzm_validation_classification.json')
    with open(output_file, 'w') as f:
        json.dump({
            'campaign': 'CTZM Validation',
            'analysis_config': ANALYSIS_CONFIG,
            'results': results,
        }, f, indent=2)

    logger.info(f"Results saved to {output_file}")

    # Generate summary figure
    generate_summary_figure(results, Path('fig_ctzm_validation_summary.pdf'))

    return results

def generate_summary_figure(results: List[Dict], output_path: Path):
    """Generate summary figure of classification results."""
    with PdfPages(output_path) as pdf:
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))

        # Plot 1: Classification by (f, beta)
        ax = axes[0, 0]
        for r in results:
            color = {'RESOLVED': 'green', 'MARGINAL': 'orange', 'UNRESOLVED': 'red', 'NO_BEADING': 'gray'}
            ax.scatter(r['beta'], r['f'], c=color.get(r['classification'], 'blue'), s=100)
        ax.set_xlabel('Plasma Beta')
        ax.set_ylabel('Line-mass fraction f')
        ax.set_title('Classification by (β, f)')

        # Plot 2: Δt_beading vs beta
        ax = axes[0, 1]
        for r in results:
            if r['classification'] != 'NO_BEADING':
                ax.scatter(r['beta'], r['dt_beading'], c='blue', s=100)
        ax.axhline(ANALYSIS_CONFIG['hdf5_interval'], linestyle='--', color='red', label='HDF5 interval')
        ax.set_xlabel('Plasma Beta')
        ax.set_ylabel('Δt_beading (tJ)')
        ax.set_title('Detection Window vs β')
        ax.legend()

        # Plot 3: Classification distribution
        ax = axes[1, 0]
        classifications = [r['classification'] for r in results]
    counts = {c: classifications.count(c) for c in set(classifications)}
        ax.bar(counts.keys(), counts.values())
        ax.set_ylabel('Count')
        ax.set_title('Classification Distribution')

        # Plot 4: Statistical summary
        ax = axes[1, 1]
        ax.axis('off')
        summary_text = f"""
        CTZM Validation Summary

        Total simulations: {len(results)}

        RESOLVED: {sum(1 for r in results if r['classification'] == 'RESOLVED')}
        MARGINAL: {sum(1 for r in results if r['classification'] == 'MARGINAL')}
        UNRESOLVED: {sum(1 for r in results if r['classification'] == 'UNRESOLVED')}
        NO_BEADING: {sum(1 for r in results if r['classification'] == 'NO_BEADING')}

        Statistical confidence:
        {(sum(1 for r in results if r['classification'] in ['RESOLVED', 'MARGINAL']) / len(results) * 100):.1f}% show detectable beading
        """
        ax.text(0.1, 0.5, summary_text, fontsize=12, verticalalignment='center')

        plt.tight_layout()
        pdf.savefig(fig)
        plt.close()

    logger.info(f"Figure saved to {output_path}")

if __name__ == '__main__':
    analyze_campaign()
