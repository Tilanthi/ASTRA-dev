#!/bin/bash
# Compile Athena++ for CTZM Validation Campaign
# Usage: bash compile_ctzm_val.sh

set -e

ATHENA_ROOT="${ATHENA_ROOT:-/path/to/athena++}"
CAMPAIGN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=========================================="
echo "CTZM Validation Campaign Compilation"
echo "=========================================="
echo "Athena++ root: $ATHENA_ROOT"
echo "Campaign directory: $CAMPAIGN_DIR"
echo ""

# Check Athena++ exists
if [ ! -d "$ATHENA_ROOT" ]; then
    echo "ERROR: Athena++ directory not found: $ATHENA_ROOT"
    echo "Set ATHENA_ROOT environment variable or edit this script."
    exit 1
fi

# Copy problem generator
echo "Copying problem generator..."
cp "$CAMPAIGN_DIR/filament_ctzm_val.cpp" "$ATHENA_ROOT/src/problems/"

# Configure for compilation
cd "$ATHENA_ROOT"

echo "Configuring Athena++..."
./configure \
    --prob=filament_ctzm_val \
    --coord=cartesian \
    --flux=hllc \
    --eos=adiabatic \
    --bparty=fft

echo "Compiling (this may take a few minutes)..."
make clean
make -j 8

# Copy binary to campaign directory
if [ -f "bin/athena" ]; then
    echo "Copying binary to campaign directory..."
    cp bin/athena "$CAMPAIGN_DIR/athena_ctzm_val"
    echo "✓ Binary created: $CAMPAIGN_DIR/athena_ctzm_val"
else
    echo "✗ Compilation failed"
    exit 1
fi

echo ""
echo "=========================================="
echo "Compilation complete!"
echo "=========================================="
