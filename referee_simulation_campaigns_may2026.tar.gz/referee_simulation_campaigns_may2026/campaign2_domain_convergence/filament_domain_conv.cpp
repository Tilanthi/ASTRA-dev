// Athena++ Problem Generator for Domain Convergence Campaign
// Based on filament_ctzm.cpp
// Key modifications: variable domain size (Lx = 8, 16, 32 lambdaJ)
// Resolution scales to maintain constant cell size: 16 cells per lambdaJ
// 
// Copy from: /Users/gjw255/astrodata/SWARM/ASTRA-dev-main/ctzm_campaign_may2026/filament_ctzm.cpp
// Modify to accept Lx parameter from input file
