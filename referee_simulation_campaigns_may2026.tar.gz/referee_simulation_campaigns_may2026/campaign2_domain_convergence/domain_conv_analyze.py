#!/usr/bin/env python3
"""Domain Convergence Analysis - Test f<1 robustness"""
import h5py
import numpy as np
import json
from pathlib import Path

def analyze_domain_convergence():
    """Analyze t_frag and lambda/W vs domain size"""
    with open("domain_conv_params.json") as f:
        config = json.load(f)
    
    results = []
    for sim in config["simulations"]:
        output_dir = Path(sim["output_dir"])
        # Measure t_frag, lambda/W
        # Compare with linear theory predictions
        results.append({"sim_id": sim["sim_id"], "t_frag": 0.0, "lambda_W": 0.0})
    
    # Test convergence: |value(L=32) - value(L=16)| / value(L=16) < 0.15
    with open("domain_convergence_results.json", "w") as f:
        json.dump(results, f, indent=2)
    return results

if __name__ == "__main__":
    analyze_domain_convergence()
