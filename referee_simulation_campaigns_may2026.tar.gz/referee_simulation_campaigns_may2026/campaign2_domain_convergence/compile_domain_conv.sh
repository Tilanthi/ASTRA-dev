#!/bin/bash
set -e
# Compile for variable domain sizes
# Modify problem generator to accept Lx as parameter
ATHENA_ROOT="${ATHENA_ROOT:-/path/to/athena++}"
cp filament_domain_conv.cpp "$ATHENA_ROOT/src/problems/"
cd "$ATHENA_ROOT"
./configure --prob=filament_domain_conv --coord=cartesian
make clean && make -j 8
cp bin/athena campaign2_domain_convergence/athena_domain_conv
