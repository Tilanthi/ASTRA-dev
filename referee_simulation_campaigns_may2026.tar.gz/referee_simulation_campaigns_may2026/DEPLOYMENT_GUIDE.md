# Referee Simulation Campaigns - Deployment Guide
**Date**: 2026-05-17
**Purpose**: 200-CPU cluster deployment instructions

---

## Quick Start

```bash
# Extract package
tar -xzf referee_simulation_campaigns_may2026.tar.gz
cd referee_simulation_campaigns_may2026

# Edit compilation scripts to set ATHENA_ROOT path
nano campaign*_validation/compile_*.sh

# Compile binaries (requires Athena++ source)
bash campaign1_ctzm_validation/compile_ctzm_val.sh
bash campaign2_domain_convergence/compile_domain_conv.sh
bash campaign3_hourglass_resolution/compile_hourglass_res.sh

# Run campaigns
# Option A: Run sequentially
python campaign1_ctzm_validation/ctzm_validation_launcher.py
python campaign2_domain_convergence/domain_conv_launcher.py
python campaign3_hourglass_resolution/hourglass_res_launcher.py

# Option B: Run campaigns 1+3 in parallel
python campaign1_ctzm_validation/ctzm_validation_launcher.py &
python campaign3_hourglass_resolution/hourglass_res_launcher.py &
wait
python campaign2_domain_convergence/domain_conv_launcher.py

# Analyze results
python unified_analyze.py
```

---

## System Requirements

- **CPUs**: 200+ (flexible, scales with concurrent_sims setting)
- **Memory**: 8–16 GB per concurrent simulation
- **Disk**: ~2 GB per simulation for HDF5 outputs
- **Software**:
  - Python 3.9+
  - Ray 2.0+ (`pip install ray`)
  - MPI (OpenMPI or MPICH)
  - HDF5 libraries
  - Athena++ source code

---

## Athena++ Problem Generators

### Campaign 1: CTZM Validation
**Source**: Copy from `/path/to/ctzm_campaign_may2026/filament_ctzm.cpp`
**Modifications needed**:
- Change `dt` in output block to `0.01`
- Increase `max_snapshots` to 300
- Ensure `gamma_e` can be set via input file

### Campaign 2: Domain Convergence
**Source**: Copy from `/path/to/ctzm_campaign_may2026/filament_ctzm.cpp`
**Modifications needed**:
- Make `x1max` (domain length) configurable via input parameter
- Resolution should scale with domain size (16 cells per λJ)

### Campaign 3: Hourglass Resolution
**Source**: Copy from existing hourglass problem generator
**Modifications needed**:
- Support resolution parameter (128³, 256³, 512³)
- Hourglass field: `B_z(r) = B_0 * [1 + (r/r_waist)²]⁻¹`

---

## Cluster Configuration

### For Slurm clusters:
```bash
#!/bin/bash
#SBATCH --job-name=referee_sims
#SBATCH --nodes=10
#SBATCH --ntasks-per-node=20
#SBATCH --cpus-per-task=1
#SBATCH --time=48:00:00

module load python/3.9
module load openmpi
module load hdf5

python campaign1_ctzm_validation/ctzm_validation_launcher.py
```

### For PBS clusters:
```bash
#!/bin/bash
#PBS -N referee_sims
#PBS -l nodes=10:ppn=20
#PBS -l walltime=48:00:00

cd $PBS_O_WORKDIR
module load python/3.9 openmpi hdf5

python campaign1_ctzm_validation/ctzm_validation_launcher.py
```

### For Google Cloud / AWS:
- Use Ray autoscaling: `ray.init(address="auto")`
- Configure cluster in `~/.ray/config.yaml`

---

## Troubleshooting

### Issue: `ModuleNotFoundError: No module named 'ray'`
**Fix**: `pip install ray`

### Issue: `mpirun: command not found`
**Fix**: Install MPI (`apt install openmpi-bin` or `yum install openmpi`)

### Issue: Simulations timeout
**Fix**: Increase `timeout_sec` in launcher script

### Issue: HDF5 files not found
**Fix**: Check output directory permissions; verify `hdf5_interval` in input file

---

## Output Structure

```
referee_simulation_campaigns_may2026/
├── output_ctzm_val/
│   ├── 0000_ISO_1.5_0.5_0/
│   │   ├── *.hdf5          # 300 snapshots
│   │   └── *.log           # Execution log
│   └── ...
├── output_domain_conv/
│   └── ...
├── output_hourglass_res/
│   └── ...
├── ctzm_validation_results.json
├── domain_conv_results.json
├── hourglass_res_results.json
└── all_campaigns_combined.json
```

---

## Verification

After completion, verify:

```bash
# Check all simulations completed
python -c "
import json
for f in ['*_results.json']:
    with open(f) as file:
        data = json.load(file)
        success = sum(1 for r in data['results'] if r['status'] == 'success')
        print(f'{f}: {success}/{len(data[\"results\"])} success')
"

# Check HDF5 files exist
find output_* -name "*.hdf5" | wc -l

# Expected output:
# Campaign 1: 8 simulations × 300 snapshots = 2400 files
# Campaign 2: 18 simulations × 400 snapshots = 7200 files
# Campaign 3: 3 simulations × 200 snapshots = 600 files
# Total: ~10,200 HDF5 files
```

---

## Contact

**Questions**: Glenn White (g.j.white@open.ac.uk)
**ASTRA Repository**: https://github.com/Tilanthi/ASTRA-dev
