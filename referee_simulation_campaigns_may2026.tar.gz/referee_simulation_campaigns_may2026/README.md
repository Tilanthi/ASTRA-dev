# Referee Simulation Campaigns Package — May 2026
**Date**: 2026-05-17 | **Purpose**: Address Referee Comments Requiring New Athena++ Simulations

---

## Overview

This package contains three targeted simulation campaigns designed to address specific referee concerns that cannot be resolved with text changes alone. All campaigns are configured for execution on a 200-CPU cluster using Ray distributed task scheduling.

### Campaigns Included

1. **CTZM Validation Campaign** — Referee Comment #4
2. **Near-Critical Domain Convergence Campaign** — Referee Comment #7
3. **Hourglass Resolution Convergence Campaign** — Referee Comment #10

**Total Simulations**: 28 Athena++ runs across all campaigns

---

## Campaign 1: CTZM vs Supercritical Matched-Simulation Validation

### Referee Concern (Comment #4)

"The resolution — that beading develops over a window of only Δt ≈ 0.03 tJ, missed by the HDF5 sampling interval of 0.05 tJ — is physically plausible and supported by the linear stability calculation. However, this resolution was demonstrated for a single matched pair (f = 1.5, β = 2.0, seed = 0). Given that this discrepancy is central to the paper's narrative about when longitudinal fragmentation can be detected, it should be demonstrated for at least 3–5 parameter combinations spanning the β range. One matched pair is not statistically convincing."

### Campaign Design

**Objective**: Validate the temporal sampling mismatch explanation for the CTZM vs Supercritical discrepancy at f = 1.5 across multiple β values.

**Parameter Space**:
| Parameter | Values | Rationale |
|-----------|--------|-----------|
| Line-mass fraction (f) | 1.5 | The disputed parameter point |
| Plasma beta (β) | 0.5, 1.0, 2.0 | Full magnetic range (referee requested span) |
| EOS type | ISO (γ=1.0), SUB (γ=0.7) | Matched pairs by f_eff = f×√γ |
| Random seeds | 0, 1, 2 | Statistical robustness |
| Temporal sampling | Δt = 0.01 tJ | 2× finer than claimed detection window |

**Matched Pairs** (8 simulations total):
```
Pair 1: ISO(f=1.5, β=0.5) vs SUB(f=1.79, γ=0.7) giving f_eff ≈ 1.5
Pair 2: ISO(f=1.5, β=1.0) vs SUB(f=1.79, γ=0.7) giving f_eff ≈ 1.5
Pair 3: ISO(f=1.5, β=2.0) vs SUB(f=1.79, γ=0.7) giving f_eff ≈ 1.5

Each pair tested with seeds [0, 1, 2] → 6 simulations total
Plus original ISO(f=1.5, β=2.0, seed=0) as reference → 1 simulation
```

**Technical Requirements**:
- HDF5 output interval: Δt = 0.01 tJ (5× finer than standard 0.05 tJ)
- Maximum snapshots: 300 (covers t = 0 → 3.0 tJ)
- Domain size: 16λJ × 2λJ × 2λJ (standard)
- Resolution: 256³ (standard)

**Analysis Protocol**:
1. For each simulation, extract longitudinal density profiles at all 300 snapshots
2. Apply peak detection algorithm (prominence > 5% above background)
3. Determine t_detect when peaks first exceed δρ/ρ ≈ 10% threshold
4. Measure Δt_beading = t_detect_end - t_detect_start (duration of detectable beading)
5. Compare Δt_beading against HDF5 sampling interval (0.01 tJ)
6. Classify as:
   - **RESOLVED**: Δt_beading > 2× sampling interval (well-sampled)
   - **MARGINAL**: Δt_beading ≈ 1–2× sampling interval (may be missed)
   - **UNRESOLVED**: Δt_beading < 1× sampling interval (likely missed)

**Success Criteria**:
- All 3 β values show consistent behavior (all RESOLVED or all MARGINAL)
- Original β=2.0 result is reproduced (independent validation)
- Statistical confidence: ≥2 out of 3 seeds per (f, β) show same classification

**Total Simulations**: 8

---

## Campaign 2: Near-Critical Domain Convergence Tests

### Referee Concern (Comment #7)

"Section 4.3 states that even f = 1.00 (the Jeans-critical value) produces longitudinal beading with t_frag = 1.62 ± 0.03 tJ, and that 'no stability threshold exists.' Section 4.9.4 also reports fragmentation at f = 0.9. This contradicts classical linear stability analysis (Inutsuka & Miyama 1992; Ostriker 1964), which predicts linear stability for f < 1. The paper attributes this to finite domain effects and non-linear local collapse, but this explanation is brief. Given that this result, if robust, has significant implications for filament lifetime arguments and the interpretation of 'stable' HGBS filaments, it warrants a dedicated subsection with convergence tests at different domain sizes and a comparison with analytic sub-critical mode growth rates."

### Campaign Design

**Objective**: Determine whether f = 0.9–1.0 fragmentation is a robust physical result or a finite-domain artifact.

**Parameter Space**:
| Parameter | Values | Rationale |
|-----------|--------|-----------|
| Line-mass fraction (f) | 0.9, 1.0, 1.1 | Sub-critical to near-critical |
| Domain size (Lx) | 8λJ, 16λJ, 32λJ | Test finite-domain effects |
| Plasma beta (β) | 2.0 | Weak magnetic field (standard test) |
| Field geometry | Longitudinal (θ=0°) | Standard for beading detection |
| Random seeds | 0, 1 | Statistical robustness |

**Simulation Matrix** (18 simulations total):
```
Domain Sizes:
- L = 8λJ:  f=0.9, 1.0, 1.1  × 2 seeds = 6 sims
- L = 16λJ: f=0.9, 1.0, 1.1  × 2 seeds = 6 sims
- L = 32λJ: f=0.9, 1.0, 1.1  × 2 seeds = 6 sims
```

**Technical Requirements**:
- HDF5 output interval: Δt = 0.02 tJ
- Maximum snapshots: 400 (covers t = 0 → 8.0 tJ for slow growth)
- Resolution: Scaled to maintain constant cell size across domains:
  - 8λJ domain: 128³ cells (16 cells per λJ)
  - 16λJ domain: 256³ cells (16 cells per λJ)
  - 32λJ domain: 512³ cells (16 cells per λJ)
- Boundary: Periodic on all faces
- EOS: Isothermal (γ=1.0)

**Analysis Protocol**:
1. **Fragmentation Detection**: Measure t_frag (when δρ/ρ > 10% threshold first exceeded)
2. **Wavelength Measurement**: Extract λ/W at t = 2.0 tJ for all simulations
3. **Growth Rate Estimation**: Fit exponential growth phase to estimate ω (growth rate)
4. **Domain Size Dependence**:
   - Plot t_frag vs L for each f value
   - Plot λ/W vs L for each f value
   - Test for convergence: |value(L=32λJ) - value(L=16λJ)| / value(L=16λJ) < 10%
5. **Comparison with Linear Theory**:
   - For f < 1.0: Calculate theoretical growth rate from dispersion relation
   - Compare measured ω with theoretical prediction
   - If measured ω > 0 but theory predicts ω² < 0: **FINITE-DOMAIN EFFECT**
   - If measured ω ≈ 0 and theory predicts ω² < 0: **LINEAR STABILITY CONFIRMED**

**Success Criteria**:
- Clear domain-size dependence identified (or absence thereof)
- Quantitative statement on whether f < 1 fragmentation is robust
- Comparison with linear theory produces physically interpretable result
- All domain sizes show consistent trend (no erratic behavior)

**Total Simulations**: 18

---

## Campaign 3: Hourglass Resolution Convergence Test

### Referee Concern (Comment #10)

"Section 4.9.3 reports that at βc = 0.5, higher f produces slower fragmentation — the reverse of all other campaigns. This is physically interesting and the proposed self-regulating mechanism (larger filament cross-section dilutes pinching effect) is qualitatively plausible. However, this result is presented without any convergence test or resolution check. Given its anomalous character, at least one resolution convergence test at the extreme βc = 0.5, f = 3.0 parameter point should be performed to confirm it is not a numerical artifact."

### Campaign Design

**Objective**: Verify that the inverted f-dependence at βc = 0.5 is not a numerical artifact due to insufficient resolution.

**Parameter Space**:
| Parameter | Values | Rationale |
|-----------|--------|-----------|
| Line-mass fraction (f) | 3.0 | Extreme supercritical (referee's specified point) |
| Central plasma beta (βc) | 0.5 | Strong magnetic field (referee's specified point) |
| Resolution | 128³, 256³, 512³ | Test convergence |
| Hourglass waist ratio | 1.5 | Standard pinching strength |
| Field geometry | Hourglass (pinched) | The geometry in question |
| Random seeds | 0 | Single test point |

**Simulation Matrix** (3 simulations total):
```
βc=0.5, f=3.0, r_waist_ratio=1.5:
- 128³: Low-resolution test
- 256³: Standard resolution (original result)
- 512³: High-resolution test
```

**Technical Requirements**:
- Domain size: 16λJ × 4λJ × 4λJ (standard hourglass domain)
- Hourglass field: B_z(r) = B_0 × [1 + (r/r_waist)²]⁻¹
- HDF5 output interval: Δt = 0.05 tJ
- Maximum snapshots: 200 (covers t = 0 → 10.0 tJ for slow fragmentation)
- Boundary: Periodic on all faces
- EOS: Isothermal (γ=1.0)

**Analysis Protocol**:
1. **Fragmentation Time Measurement**: Determine t_frag for all 3 resolutions
2. **Wavelength Measurement**: Extract λ/W at fragmentation for all 3 resolutions
3. **Convergence Test**:
   - Compute relative difference: |value(512³) - value(256³)| / value(256³)
   - Compute relative difference: |value(256³) - value(128³)| / value(128³)
   - Convergence criterion: Both differences < 15%
4. **Inverted f-Dependence Check**:
   - If convergence confirmed: Result is robust
   - If trend changes with resolution: Result is artifact
   - Compare t_frag(f=3.0) vs t_frag(f=2.5) across resolutions
   - Inverted dependence confirmed if t_frag(f=3.0) > t_frag(f=2.5) at all resolutions

**Success Criteria**:
- Convergence achieved across 128³ → 256³ → 512³
- Inverted f-dependence (higher f → slower fragmentation) persists at all resolutions
- Quantitative uncertainty on t_frag and λ/W from resolution variation

**Total Simulations**: 3

---

## Unified Execution Instructions

### Infrastructure Requirements

- **Platform**: Any Linux cluster with 200+ CPUs
- **Software**: Python 3.9+, Ray 2.0+, MPI (OpenMPI or MPICH)
- **Memory**: ~8 GB per concurrent simulation
- **Disk**: ~2 GB per simulation for HDF5 outputs
- **Wall time**: ~48–72 hours for all campaigns combined

### Directory Structure

```
referee_simulation_campaigns_may2026/
├── README.md                           # This file
├── campaign1_ctzm_validation/
│   ├── ctzm_validation_launcher.py     # Ray launcher
│   ├── ctzm_validation_analyze.py      # Analysis script
│   ├── ctzm_validation_params.json     # Parameter grid
│   ├── filament_ctzm_val.cpp           # Athena++ problem generator
│   └── compile_ctzm_val.sh             # Compilation script
├── campaign2_domain_convergence/
│   ├── domain_conv_launcher.py         # Ray launcher
│   ├── domain_conv_analyze.py          # Analysis script
│   ├── domain_conv_params.json         # Parameter grid
│   ├── filament_domain_conv.cpp        # Athena++ problem generator
│   └── compile_domain_conv.sh          # Compilation script
├── campaign3_hourglass_resolution/
│   ├── hourglass_res_launcher.py       # Ray launcher
│   ├── hourglass_res_analyze.py        # Analysis script
│   ├── hourglass_res_params.json       # Parameter grid
│   ├── filament_hourglass_res.cpp      # Athena++ problem generator
│   └── compile_hourglass_res.sh        # Compilation script
└── unified_analyze.py                  # Cross-campaign analysis
```

### Execution Order (Recommended)

1. **Campaign 1** (CTZM validation): 8 simulations, ~12 hours
   - Highest priority for referee response
   - Resolves central discrepancy claim

2. **Campaign 3** (Hourglass resolution): 3 simulations, ~18 hours
   - Lowest computational cost
   - Addresses anomalous result

3. **Campaign 2** (Domain convergence): 18 simulations, ~48 hours
   - Highest computational cost
   - Important but not time-critical

### Parallel Execution Strategy

If cluster resources permit, campaigns can run in parallel:
```
Total concurrent load: 29 simulations
- Campaign 1: 8 concurrent
- Campaign 2: 18 concurrent (if 512³ not memory-bound)
- Campaign 3: 3 concurrent

Recommended: Run Campaigns 1+3 in parallel, Campaign 2 separately
```

---

## Analysis Deliverables

### Per-Campaign Outputs

**Campaign 1 (CTZM Validation)**:
- `ctzm_validation_classification.json`: Resolved/Marginal/Unresolved for each (f, β, seed)
- `ctzm_validation_dt_beading.csv`: Δt_beading measurements
- `fig_ctzm_validation_summary.pdf`: Visual summary of resolution assessment

**Campaign 2 (Domain Convergence)**:
- `domain_convergence_summary.json`: t_frag and λ/W vs domain size
- `domain_convergence_linear_theory.json`: Comparison with analytic predictions
- `fig_domain_convergence.pdf`: Convergence plots

**Campaign 3 (Hourglass Resolution)**:
- `hourglass_resolution_convergence.json`: t_frag and λ/W vs resolution
- `fig_hourglass_resolution.pdf`: Convergence assessment

### Unified Outputs

- `referee_response_table.tex`: LaTeX table summarizing all results
- `referee_response_summary.md`: Structured response to each referee comment
- `all_campaigns_combined.json`: Combined dataset for paper integration

---

## Integration with Paper

### Text Additions Required

**For Campaign 1** (Comment #4):
```latex
\subsection{Extended CTZM Validation}

To address the referee's concern that our matched-simulation validation
was based on a single parameter point (f = 1.5, $\beta = 2.0$, seed = 0),
we performed extended matched-simulation tests across $\beta = [0.5, 1.0, 2.0]$
with three random seeds per parameter point (8 simulations total).
The high-cadence HDF5 sampling ($\Delta t = 0.01\,t_{\rm J}$) confirmed that
the detectable beading window $\Delta t_{\rm beading} = [TODO]$ tJ is
[well-resolved / marginally resolved / poorly resolved] across all tested
$\beta$ values, validating the temporal sampling mismatch explanation.
```

**For Campaign 2** (Comment #7):
```latex
\subsection{Near-Critical Domain Convergence Tests}

To address the referee's concern that our reported fragmentation at
$f = 0.9$--$1.0$ might be a finite-domain artifact, we performed domain
size convergence tests at $L = [8, 16, 32]\lambda_{\rm J}$ for
$f = [0.9, 1.0, 1.1]$ (18 simulations total). The results show that
[fragmentation persists at all domain sizes / fragmentation converges
to stability at large domains / no clear trend], establishing that
the $f < 1$ behavior is [robust / artifact].
```

**For Campaign 3** (Comment #10):
```latex
\subsection{Hourglass Resolution Convergence}

To address the referee's concern that the inverted $f$-dependence at
$\beta_{\rm c} = 0.5$ might be a numerical artifact, we performed
resolution convergence tests at $[128^3, 256^3, 512^3]$ for the
extreme parameter point ($f = 3.0$, $\beta_{\rm c} = 0.5$). The inverted
dependence [persists / does not persist] across all resolutions,
with relative convergence of [X]\% between $256^3$ and $512^3$,
confirming that this result is [robust / artifact].
```

---

## Quick Start Commands

```bash
# Extract package
tar -xzf referee_simulation_campaigns_may2026.tar.gz
cd referee_simulation_campaigns_may2026

# Compile Athena++ binaries for all campaigns
./campaign1_ctzm_validation/compile_ctzm_val.sh
./campaign2_domain_convergence/compile_domain_conv.sh
./campaign3_hourglass_resolution/compile_hourglass_res.sh

# Launch campaigns (adjust Ray config for your cluster)
# Campaign 1: CTZM validation
python campaign1_ctzm_validation/ctzm_validation_launcher.py

# Campaign 3: Hourglass resolution (can run in parallel with Campaign 1)
python campaign3_hourglass_resolution/hourglass_res_launcher.py

# Campaign 2: Domain convergence (run separately due to 512³ memory)
python campaign2_domain_convergence/domain_conv_launcher.py

# Analyze results
python unified_analyze.py
```

---

## Success Metrics

All three campaigns will be considered successful if:

1. **Campaign 1**: Statistical confidence ≥ 67% (5/8 simulations agree) on classification
2. **Campaign 2**: Clear domain-size trend identified (or ruled out) with < 15% scatter
3. **Campaign 3**: Convergence achieved (< 15% variation from 256³ → 512³)

**Overall Success**: All three referee concerns are addressed with quantitative results suitable for inclusion in the referee response.

---

**Package Status**: READY FOR DEPLOYMENT
**Last Updated**: 2026-05-17
**Contact**: Glenn White (g.j.white@open.ac.uk)
