# Deployment Guide: Supercritical Campaigns on Ray Cluster
## For ASTRA 220 vCPU Infrastructure Team

### Pre-Deployment Checklist

**1. Verify Athena++ Modules**

Campaign D requires sink particle module (development branch):
```bash
cd /path/to/athena++
git checkout development  # Ensure sink module is available
make clean
make -j8

# Verify sink module is compiled
ls src/sink_particles/
# Should show sink_particle.cpp, etc.
```

Campaign A requires turbulence forcing module:
```bash
# Check for stochastic forcing implementation
ls src/turbulence/
# Should show forcing_stochastic.cpp or similar
```

**2. Verify Ray Cluster Status**

```bash
# On head node (astra-climate)
ray status

# Check available resources
ray cluster_resources

# Expected: ~208 CPUs available
```

**3. Prepare Storage**

```bash
# Create campaign directories
mkdir -p /mnt/raid0/astra_simulations/{campaign_a_turbulent_support,campaign_b_subisothermal_eos,campaign_c_hourglass_geometry,campaign_d_sink_particles}

mkdir -p /mnt/raid0/astra_simulations/analysis/results
```

**4. Install Dependencies**

```bash
conda activate astra
pip install numpy h5py scipy pandas matplotlib

# Verify
python -c "import h5py; print(h5py.__version__)"
```

### Deployment Instructions

**Step 1: Extract Package**

```bash
cd /path/to/deployment
tar -xzf supercritical_campaigns.tar.gz
cd supercritical_campaigns
```

**Step 2: Review Campaign Specifications**

Each campaign has a `specification.py` file:
```bash
cat campaign_a/specification.py
cat campaign_b/specification.py
cat campaign_c/specification.py
cat campaign_d/specification.py
```

**Step 3: Run Campaigns in Priority Order**

**Priority 1: Campaign B (Sub-Isothermal EOS)**
```bash
# Lowest risk, tests existing result
python run_campaigns.py --campaign B --parallel 50 --timeout 14400

# Expected: ~1 day for 192 simulations
# Monitor: tail -f /var/log/ray/session_*/logs/worker-*.log
```

**Priority 2: Campaign A (Turbulent Pressure Support)**
```bash
# Only after B completes successfully
python run_campaigns.py --campaign A --parallel 25 --timeout 21600

# Expected: ~2 days for 216 simulations
# Note: Requires forcing module validation first
```

**Priority 3: Campaign C (Hourglass Field Geometry)**
```bash
python run_campaigns.py --campaign C --parallel 12 --timeout 259200

# Expected: ~3 days for 108 simulations
# Note: Wider domain = more expensive
```

**Priority 4: Campaign D (Sink Particles)**
```bash
# Only after sink module verified
python run_campaigns.py --campaign D --parallel 25 --timeout 43200

# Expected: ~2 days for 144 simulations
# Note: Most complex, requires validation
```

### Monitoring During Execution

**Check Ray Dashboard:**
```bash
# On head node
ray dashboard  # Visit http://localhost:8265

# Or from local machine with SSH tunnel
ssh -L 8265:localhost:8265 user@astra-climate
```

**Monitor Simulation Progress:**
```bash
# Count completed simulations
find /mnt/raid0/astra_simulations/campaign_b_subisothermal_eos/f* -name "output.hdf5" | wc -l

# Check disk usage
df -h /mnt/raid0/astra_simulations/

# Check for timeout failures
grep -r "TIMEOUT" /mnt/raid0/astra_simulations/campaign_b_*/results/
```

**Common Issues and Solutions:**

| Issue | Symptom | Solution |
|-------|----------|----------|
| Out of memory | Workers killed | Reduce `--parallel` by 25% |
| Disk full | No HDF5 output | Clean `/mnt/raid0/`, check `df -h` |
| Timeout failure | Simulations stop | Increase `--timeout` or check for runaway collapse |
| Module missing | Import error | Verify Athena++ modules compiled |

### Post-Campaign Analysis

After each campaign completes:

**1. Run Analysis Script**
```bash
cd /path/to/supercritical_campaigns

python analysis/analyze_campaign_b.py
python analysis/analyze_campaign_a.py
python analysis/analyze_campaign_c.py
python analysis/analyze_campaign_d.py
```

**2. Check Results**
```bash
ls -lh analysis/results/

# Should show:
# campaign_a_summary.csv
# campaign_b_summary.csv
# campaign_c_summary.csv
# campaign_d_summary.csv
# campaign_*_summary.png
```

**3. Generate Summary Report**
```bash
python analysis/generate_summary_report.py
```

### Data Transfer to Glenn's GitHub

After all campaigns and analysis complete:

**1. Package Results**
```bash
cd /mnt/raid0/astra_simulations

# Create results package
tar -czf supercritical_results_$(date +%Y%m%d).tar.gz \
    campaign_a_turbulent_support/ \
    campaign_b_subisothermal_eos/ \
    campaign_c_hourglass_geometry/ \
    campaign_d_sink_particles/ \
    analysis/results/
```

**2. Push to GitHub**
```bash
cd /path/to/ASTRA-dev
git checkout -b supercritical-campaign-results

# Copy results
cp /mnt/raid0/astra_simulations/supercritical_results_*.tar.gz .
git add supercritical_results_*.tar.gz
git commit -m "Add supercritical campaign results"
git push origin supercritical-campaign-results
```

### Success Criteria

**Campaign A (Turbulent Support):**
- ✅ f_eff ≈ 1.0-1.3 measured from turbulent pressure
- ✅ λ/W consistent with Campaign 7 calibration at f_eff
- ✅ Driven turbulence maintained throughout simulation

**Campaign B (Sub-Isothermal EOS):**
- ✅ Finer snapshot cadence (0.01 t_J) captures transient beading
- ✅ Systematic γ-dependence observed in supercritical regime
- ✅ Power spectrum analysis shows longitudinal mode growth

**Campaign C (Hourglass Geometry):**
- ✅ Hourglass morphology preserved during collapse
- ✅ λ/W ≈ 2.0-3.0 intermediate between pure geometries
- ✅ Resolves Planck tension (no 2.5σ discrepancy)

**Campaign D (Sink Particles):**
- ✅ Sink spacing matches HGBS PM (2.79 ± 0.09)
- ✅ Secondary fragmentation observed after first sink
- ✅ NN and PM statistics both consistent with observations

**Null Result (All Campaigns Fail):**
- No λ/W measurements in supercritical regime
- Confirms ideal MHD is insufficient
- Makes compelling case for non-ideal MHD (ambipolar diffusion, Hall effect)

### Contact

For infrastructure issues: cluster-team@astra.example.com
For simulation issues: physics-team@astra.example.com
For analysis issues: glenn@example.com

---

**Version:** 1.0
**Date:** 2026-05-15
**Target:** ASTRA 220 vCPU Ray Cluster
