"""
Campaign A: Turbulent Pressure Support (Driven Turbulence)
Physical Rationale: Sustained turbulent pressure reduces effective line-mass fraction,
potentially bringing supercritical filaments back into measurable regime.

Total simulations: 216
Domain: 16 × 2 × 2 λ_J (doubled axial for driven modes)
Resolution: 512 × 64 × 64 cells (32 cells/λ_J transverse)
"""

CAMPAIGN_NAME = "campaign_a_turbulent_support"
TOTAL_SIMULATIONS = 216

# Parameter grid
PARAMETER_GRID = {
    'f': [1.5, 2.0, 2.5, 3.0],           # line-mass fraction
    'beta': [0.5, 1.0, 2.0],             # plasma beta
    'M_driven': [1.0, 2.0, 3.0],         # sustained Mach number
    'theta': [0, 90],                     # field angle (degrees)
    'seed': [0, 1, 2]                     # random seeds
}

# Domain specification
DOMAIN = {
    'L_x': 16.0,   # λ_J units (doubled for driven turbulence)
    'L_y': 2.0,
    'L_z': 2.0,
    'N_x': 512,
    'N_y': 64,
    'N_z': 64,
}

# Initial conditions
INITIAL_CONDITIONS = {
    'profile': 'gaussian',
    'rho_c': 1.0,
    'W_core': 0.3,  # λ_J units
    'B0': 1.0,      # will be scaled by beta
}

# Turbulence driving specification
TURBULENCE_DRIVING = {
    'type': 'ornstein_uhlenbeck',        # Federrath et al. 2010 scheme
    'mode': 'solenoidal',                 # divergence-free driving
    'k_min': 1.0,                        # minimum driving wavenumber
    'k_max': 4.0,                        # maximum driving wavenumber
    't_corr': 0.5,                       # correlation time (t_J units)
    'driving_direction': 'axial',         # drive only k_x dominated modes
    'target_Mach': None,                  # set from M_driven parameter
}

# Runtime configuration
RUNTIME = {
    't_max': 3.0,                         # minimum 3.0 t_J (increased from standard)
    'timeout_seconds': 21600,            # 6 hours wall-clock
    'output_interval': 0.05,              # HDF5 output interval (t_J)
    'checkpoint_interval': 1.0,           # checkpoint every t_J
}

# Resources
RAY_RESOURCES = {
    'cpus_per_sim': 8,
    'concurrent_jobs': 25,
    'memory_per_sim': '4GB',
}

# Analysis requirements
ANALYSIS_CONFIG = {
    'measure_f_eff': True,                # measure effective line-mass from turbulent pressure
    'peak_finding_prominence': 0.2,      # 20% of peak density
    'compare_campaign7_calibration': True,
}

def generate_parameter_points():
    """Generate all parameter combinations for Ray execution."""
    import itertools

    points = []
    for f in PARAMETER_GRID['f']:
        for beta in PARAMETER_GRID['beta']:
            for M_driven in PARAMETER_GRID['M_driven']:
                for theta in PARAMETER_GRID['theta']:
                    for seed in PARAMETER_GRID['seed']:
                        points.append({
                            'f': f,
                            'beta': beta,
                            'M_driven': M_driven,
                            'theta': theta,
                            'seed': seed,
                            'campaign': CAMPAIGN_NAME,
                        })
    return points

def compute_B0(beta, f):
    """Compute magnetic field strength from beta and line-mass fraction."""
    # beta = 8*pi*P/B^2, need to scale B0 appropriately
    # This will be computed in the problem generator
    return {'beta': beta, 'scale_with_f': False}

def validate_simulation_output(sim_dir):
    """Validate that simulation output is complete and valid."""
    import os
    import h5py

    required_files = ['output/output.hdf5']

    for fname in required_files:
        fpath = os.path.join(sim_dir, fname)
        if not os.path.exists(fpath):
            return False, f"Missing {fname}"

        try:
            with h5py.File(fpath, 'r') as f:
                # Check that we have data up to at least t=2.0 t_J
                times = f['times'][:]
                if times[-1] < 2.0:
                    return False, f"Insufficient time coverage: {times[-1]} < 2.0"
        except Exception as e:
            return False, f"HDF5 read error: {e}"

    return True, "OK"

if __name__ == "__main__":
    points = generate_parameter_points()
    print(f"Campaign A: {len(points)} parameter points")
    print(f"Expected runtime: {len(points) * RAY_RESOURCES['cpus_per_sim'] / RAY_RESOURCES['concurrent_jobs'] / 24:.1f} days")
