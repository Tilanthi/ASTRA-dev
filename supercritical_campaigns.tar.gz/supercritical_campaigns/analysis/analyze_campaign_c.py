#!/usr/bin/env python
"""
Analysis script for Campaign C: Hourglass Field Geometry

Key analyses:
1. Track field geometry evolution θ(r, t) at each snapshot
2. Extract λ/W from on-axis density profile
3. Compute population-weighted prediction using actual internal geometry
4. Test whether hourglass resolves Planck tension
"""

import numpy as np
import h5py
from pathlib import Path
from scipy.signal import find_peaks
from scipy.optimize import curve_fit
import pandas as pd
import matplotlib.pyplot as plt

def load_simulation_data(sim_dir):
    """Load HDF5 output including full B field vectors."""
    output_file = Path(sim_dir) / 'output' / 'output.hdf5'

    with h5py.File(output_file, 'r') as f:
        data = {
            'times': f['times'][:],
            'rho': f['density'][:],
            'B_x': f['B_x'][:],  # full 3D field vectors
            'B_y': f['B_y'][:],
            'B_z': f['B_z'][:],
        }

    return data

def compute_field_angle_profile(data, snapshot_idx):
    """
    Compute magnetic field angle θ as function of cylindrical radius r.

    θ = 0°: longitudinal (along x-axis)
    θ = 90°: perpendicular (in y-z plane)
    """
    rho = data['rho'][snapshot_idx]  # (Nx, Ny, Nz)
    B_x = data['B_x'][snapshot_idx]
    B_y = data['B_y'][snapshot_idx]
    B_z = data['B_z'][snapshot_idx]

    Nx, Ny, Nz = rho.shape

    # Compute radial coordinate from filament axis
    # Assume axis at center of transverse plane
    cy, cz = Ny // 2, Nz // 2

    r_profile = []
    theta_profile = []

    for x_idx in range(Nx):
        # Get field at this x-slice
        B_x_slice = B_x[x_idx, cy, cz]
        B_y_slice = B_y[x_idx, cy, cz]
        B_z_slice = B_z[x_idx, cy, cz]

        # Compute field magnitude
        B_mag = np.sqrt(B_x_slice**2 + B_y_slice**2 + B_z_slice**2)

        # Compute angle: θ = atan2(B_perp, B_parallel)
        # where B_parallel = B_x, B_perp = sqrt(B_y^2 + B_z^2)
        B_para = B_x_slice
        B_perp = np.sqrt(B_y_slice**2 + B_z_slice**2)

        theta = np.arctan2(B_perp, B_para)  # radians
        theta_deg = np.degrees(theta)

        r_profile.append(x_idx)  # proxy for radius from axis
        theta_profile.append(theta_deg)

    return np.array(r_profile), np.array(theta_profile)

def track_hourglass_evolution(data):
    """
    Track hourglass morphology throughout collapse.

    Returns: dict with evolution of θ(r) over time
    """
    times = data['times']
    n_snapshots = len(times)

    theta_evolution = []

    for i in range(n_snapshots):
        r, theta = compute_field_angle_profile(data, i)
        theta_evolution.append(theta)

    return {
        'times': times,
        'r_profile': r,
        'theta_evolution': theta_evolution,
    }

def extract_on_axis_lambda_W(data):
    """
    Extract λ/W from on-axis density profile.

    For hourglass geometry, the relevant measurement is along the
    filament axis where the field is predominantly longitudinal.
    """
    rho_final = data['rho'][-1]  # final snapshot

    # Extract on-axis profile
    cy, cz = rho_final.shape[1]//2, rho_final.shape[2]//2
    rho_onaxis = rho_final[:, cy, cz]

    # Find peaks
    peaks, properties = find_peaks(
        rho_onaxis,
        prominence=0.2 * np.max(rho_onaxis),
        distance=10,
    )

    if len(peaks) < 2:
        return {
            'lambda_W': None,
            'n_peaks': len(peaks),
            'detection': 'FAILED',
        }

    dx = 8.0 / rho_final.shape[0]  # L_x = 8 λ_J
    spacings = np.diff(peaks) * dx
    lambda_phys = np.median(spacings)
    lambda_W = lambda_phys / 0.3

    return {
        'lambda_W': lambda_W,
        'n_peaks': len(peaks),
        'detection': 'SUCCESS',
    }

def compute_population_weighted_prediction(campaign_df):
    """
    Compute population-weighted λ/W prediction using actual internal geometry.

    This is the key test for resolving Planck tension:
    - If hourglass internal geometry gives λ/W ≈ 2.0-3.0 (intermediate),
      this explains why HGBS observes intermediate values despite Planck's
      perpendicular-dominated large-scale statistics.
    """
    # Weight by observed filament population (simplified)
    # Planck: ~90% perpendicular, ~10% longitudinal at large scales
    # Internal geometry may differ

    from campaign_c.specification import PARAMETER_GRID

    # Simple model: if hourglass produces intermediate λ/W,
    # weighted average will also be intermediate
    mean_lambda_W = campaign_df['lambda_W'].mean()
    std_lambda_W = campaign_df['lambda_W'].std()

    # Compare to Planck-weighted prediction from pure geometries:
    # <λ/W>_Planck = 0.9 * 1.25 + 0.1 * 3.7 ≈ 1.5
    # HGBS observed: 2.79

    planck_prediction = 0.9 * 1.25 + 0.1 * 3.7
    hgbs_observed = 2.79

    tension_planck = abs(mean_lambda_W - planck_prediction)
    tension_hgbs = abs(mean_lambda_W - hgbs_observed)

    return {
        'mean_lambda_W': mean_lambda_W,
        'std_lambda_W': std_lambda_W,
        'planck_prediction': planck_prediction,
        'tension_with_planck': tension_planck,
        'tension_with_hgbs': tension_hgbs,
        'resolves_tension': tension_hgbs < 0.5,  # close to HGBS value
    }

def analyze_single_simulation(sim_dir):
    """Complete analysis pipeline for single simulation."""
    params = {}  # read from metadata

    data = load_simulation_data(sim_dir)

    # Track hourglass evolution
    hourglass_result = track_hourglass_evolution(data)

    # Extract λ/W from on-axis profile
    lambda_W_result = extract_on_axis_lambda_W(data)

    # Check if hourglass morphology preserved
    # (field should remain curved, not straighten to pure longitudinal)
    final_theta = hourglass_result['theta_evolution'][-1]
    theta_on_axis = final_theta[len(final_theta)//2]  # angle at r=0
    theta_edge = final_theta[-1]  # angle at edge

    hourglass_preserved = (theta_on_axis < 30) and (theta_edge > 60)

    return {
        'sim_dir': str(sim_dir),
        'params': params,
        'hourglass_evolution': hourglass_result,
        'lambda_W': lambda_W_result,
        'hourglass_preserved': hourglass_preserved,
    }

def analyze_campaign(campaign_dir='/mnt/raid0/astra_simulations/campaign_c_hourglass_geometry/'):
    """Analyze all simulations in Campaign C."""
    results = []

    sim_dirs = list(Path(campaign_dir).glob('f*'))

    print(f"Found {len(sim_dirs)} simulations")

    for sim_dir in sim_dirs:
        try:
            result = analyze_single_simulation(sim_dir)
            results.append(result)

            if result['lambda_W']['detection'] == 'SUCCESS':
                preserved = "preserved" if result['hourglass_preserved'] else "not preserved"
                print(f"✓ {sim_dir.name}: λ/W = {result['lambda_W']['lambda_W']:.2f}, "
                      f"hourglass {preserved}")
            else:
                print(f"✗ {sim_dir.name}: No beading detected")
        except Exception as e:
            print(f"✗ {sim_dir.name}: {e}")

    df = pd.DataFrame(results)

    # Compute population-weighted prediction
    pop_prediction = compute_population_weighted_prediction(df)

    # Save results
    output_file = 'analysis/results/campaign_c_summary.csv'
    df.to_csv(output_file, index=False)

    print(f"\nCampaign C analysis complete!")
    print(f"Results saved to {output_file}")
    print(f"\nPopulation-weighted analysis:")
    print(f"  Mean λ/W: {pop_prediction['mean_lambda_W']:.2f} ± {pop_prediction['std_lambda_W']:.2f}")
    print(f"  Planck pure-geometry prediction: {pop_prediction['planck_prediction']:.2f}")
    print(f"  HGBS observed: {pop_prediction['tension_with_hgbs']:.2f}")
    print(f"  Resolves Planck tension: {pop_prediction['resolves_tension']}")

    return df

if __name__ == "__main__":
    analyze_campaign()
