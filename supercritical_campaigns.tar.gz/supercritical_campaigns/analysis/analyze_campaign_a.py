#!/usr/bin/env python
"""
Analysis script for Campaign A: Turbulent Pressure Support

Key analyses:
1. Measure effective line-mass fraction f_eff from turbulent pressure
2. Extract λ/W from density profiles
3. Compare with Campaign 7 calibration applied to f_eff
"""

import numpy as np
import h5py
from pathlib import Path
from scipy.signal import find_peaks
from scipy.optimize import curve_fit
import pandas as pd
import matplotlib.pyplot as plt

def load_simulation_data(sim_dir):
    """Load HDF5 output from simulation directory."""
    output_file = Path(sim_dir) / 'output' / 'output.hdf5'

    with h5py.File(output_file, 'r') as f:
        data = {
            'times': f['times'][:],
            'rho_x_mean': f['rho_x_mean'][:],  # longitudinal mean density
            'rho_x_slice': f['rho_x_slice'][:],  # full 2D slice if available
            'turbulent_velocity': f['velocity_rms'][:],
        }

    return data

def compute_effective_line_mass(data, params):
    """
    Compute effective line-mass fraction f_eff from turbulent pressure support.

    f_eff = f / (1 + M^2/2) where M is the instantaneous Mach number

    For driven turbulence, M fluctuates around the target value, so we
    compute time-averaged f_eff.
    """
    # Compute turbulent pressure: P_turb = rho * sigma_turb^2 / 3
    # Thermal pressure: P_therm = rho * cs^2
    # Total pressure: P_tot = P_therm + P_turb

    cs = 1.0  # isothermal sound speed
    rho_c = params.get('rho_c', 1.0)

    f_eff_timeseries = []
    for i, (rho_mean, v_rms) in enumerate(zip(data['rho_x_mean'], data['turbulent_velocity'])):

        M = v_rms / cs
        P_turb_ratio = 0.5 * M**2
        f_eff = params['f'] / (1 + P_turb_ratio)
        f_eff_timeseries.append(f_eff)

    # Return time-averaged f_eff (excluding initial transient)
    transient_idx = int(len(data['times']) * 0.2)  # skip first 20%
    f_eff_avg = np.mean(f_eff_timeseries[transient_idx:])
    f_eff_std = np.std(f_eff_timeseries[transient_idx:])

    return {
        'f_eff_avg': f_eff_avg,
        'f_eff_std': f_eff_std,
        'f_eff_timeseries': f_eff_timeseries,
    }

def extract_lambda_W(data, params):
    """
    Extract fragmentation wavelength from longitudinal density profile.

    Uses peak-finding with 20% prominence threshold.
    """
    # Get final snapshot density profile
    rho_final = data['rho_x_slice'][-1]  # shape: (Nx, Ny, Nz)

    # Compute on-axis average (center of transverse plane)
    cy, cz = rho_final.shape[1]//2, rho_final.shape[2]//2
    rho_onaxis = rho_final[:, cy, cz]

    # Find peaks
    peaks, properties = find_peaks(
        rho_onaxis,
        prominence=0.2 * np.max(rho_onaxis),
        distance=10,  # minimum spacing between peaks
    )

    if len(peaks) < 2:
        return {
            'lambda_W': None,
            'n_peaks': len(peaks),
            'detection': 'FAILED',
        }

    # Compute spacing between peaks
    dx = params['L_x'] / params['N_x']
    spacings = np.diff(peaks) * dx

    # Median spacing in physical units
    lambda_phys = np.median(spacings)

    # Convert to λ/W (W = 0.1 pc for HGBS comparison)
    # But internally we use W_core = 0.3 λ_J
    # So: λ/W_core = lambda_phys / (0.3 * λ_J)
    # Where λ_J = 1.0 in our units
    lambda_W_core = lambda_phys / 0.3

    return {
        'lambda_W': lambda_W_core,
        'n_peaks': len(peaks),
        'detection': 'SUCCESS',
        'spacings': spacings,
    }

def compare_with_campaign7(f_eff, lambda_W_measured):
    """
    Compare measured λ/W with Campaign 7 calibration applied to f_eff.

    Campaign 7 found: λ/W decreases smoothly with f and β
    Expected: λ/W(f_eff) ≈ calibration_value(f_eff, β)
    """
    # Campaign 7 calibration (from their Table)
    # For β = 1.0: λ/W = 3.19, 3.17, 3.10, 3.07 for f = 1.2, 1.3, 1.4, 1.5
    # Linear fit: λ/W ≈ 3.47 - 0.55*f for β=1.0

    def calibration_model(f, a=3.47, b=-0.55):
        return a + b * f

    # For other β values, scaling differs
    beta_scales = {
        0.5: 0.8,   # stronger field -> longer λ/W
        1.0: 1.0,   # baseline
        2.0: 0.7,   # weaker field -> shorter λ/W
    }

    params['beta_scale'] = beta_scales.get(params['beta'], 1.0)
    expected_lambda_W = calibration_model(f_eff) * params['beta_scale']

    residual = lambda_W_measured - expected_lambda_W
    residual_pct = (residual / expected_lambda_W) * 100

    return {
        'expected_lambda_W': expected_lambda_W,
        'measured_lambda_W': lambda_W_measured,
        'residual': residual,
        'residual_pct': residual_pct,
        'agreement': 'GOOD' if abs(residual_pct) < 10 else 'POOR',
    }

def analyze_single_simulation(sim_dir):
    """Complete analysis pipeline for single simulation."""
    # Load params
    # (In practice, these would be read from a metadata file)
    params = {}

    # Load data
    data = load_simulation_data(sim_dir)

    # Compute f_eff
    f_eff_result = compute_effective_line_mass(data, params)

    # Extract λ/W
    lambda_W_result = extract_lambda_W(data, params)

    # Compare with calibration
    comparison = None
    if lambda_W_result['detection'] == 'SUCCESS':
        comparison = compare_with_campaign7(
            f_eff_result['f_eff_avg'],
            lambda_W_result['lambda_W']
        )

    return {
        'sim_dir': str(sim_dir),
        'params': params,
        'f_eff': f_eff_result,
        'lambda_W': lambda_W_result,
        'comparison': comparison,
    }

def analyze_campaign(campaign_dir='/mnt/raid0/astra_simulations/campaign_a_turbulent_support/'):
    """Analyze all simulations in Campaign A."""
    results = []

    sim_dirs = list(Path(campaign_dir).glob('f*'))

    print(f"Found {len(sim_dirs)} simulations")

    for sim_dir in sim_dirs:
        try:
            result = analyze_single_simulation(sim_dir)
            results.append(result)
            print(f"✓ {sim_dir.name}: λ/W = {result['lambda_W']['lambda_W']:.2f}")
        except Exception as e:
            print(f"✗ {sim_dir.name}: {e}")

    # Create summary DataFrame
    df = pd.DataFrame(results)

    # Save results
    output_file = 'analysis/results/campaign_a_summary.csv'
    df.to_csv(output_file, index=False)

    # Create summary plots
    create_summary_plots(df)

    print(f"\nCampaign A analysis complete!")
    print(f"Results saved to {output_file}")

    return df

def create_summary_plots(df):
    """Create summary plots for Campaign A."""
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))

    # Plot 1: f_eff vs f for different M_driven
    # Plot 2: λ/W vs f_eff
    # Plot 3: Residual comparison with Campaign 7
    # Plot 4: Detection rate vs parameters

    plt.tight_layout()
    plt.savefig('analysis/results/campaign_a_summary.png', dpi=150)

if __name__ == "__main__":
    analyze_campaign()
