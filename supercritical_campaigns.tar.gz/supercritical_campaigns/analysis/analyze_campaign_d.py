#!/usr/bin/env python
"""
Analysis script for Campaign D: Adaptive Sink Particles

Key analyses:
1. Extract 3D sink particle positions and formation times
2. Compute 1D projected spacing distribution along filament axis
3. Compare sink spacing with HGBS PM (2.79) and NN (2.08)
4. Track secondary fragmentation after first sink forms
"""

import numpy as np
import h5py
from pathlib import Path
from scipy.stats import ks_2samp
from scipy.signal import find_peaks
import pandas as pd
import matplotlib.pyplot as plt

def load_simulation_data(sim_dir):
    """Load HDF5 output including sink particle data."""
    output_file = Path(sim_dir) / 'output' / 'output.hdf5'
    sink_file = Path(sim_dir) / 'sinks' / 'sink_data.hdf5'

    with h5py.File(output_file, 'r') as f:
        data = {
            'times': f['times'][:],
            'rho': f['density'][:],
        }

    # Load sink data
    with h5py.File(sink_file, 'r') as f:
        sink_data = {
            'n_sinks': f['n_sinks'][...],
            'positions': f['positions'][...],  # (time, sink, 3)
            'formation_times': f['formation_times'][...],
            'masses': f['masses'][...],
        }

    return {**data, **sink_data}

def extract_sink_positions(sink_data):
    """
    Extract final 3D positions of all sink particles.
    """
    positions_final = sink_data['positions'][-1]  # (n_sinks, 3)
    formation_times = sink_data['formation_times']

    return {
        'positions': positions_final,  # (n_sinks, 3) in λ_J units
        'formation_times': formation_times,  # formation times in t_J
        'n_sinks': len(positions_final),
    }

def compute_sink_spacing_distribution(positions):
    """
    Compute 1D projected spacing distribution along filament axis.

    This directly mimics what observers measure from core catalogues.
    """
    if len(positions) < 2:
        return None

    # Sort by x-coordinate (filament axis)
    x_sorted = np.sort(positions[:, 0])

    # Compute spacings between consecutive sinks
    spacings = np.diff(x_sorted)

    # Normalize by W_core = 0.3 λ_J
    spacings_W = spacings / 0.3

    # Compute both NN and PM statistics
    # NN: median of consecutive spacings
    lambda_NN = np.median(spacings_W)

    # PM: median of all pairwise distances
    from itertools import combinations
    pairwise_dists = [abs(x_sorted[i] - x_sorted[j])
                     for i, j in combinations(range(len(x_sorted)), 2)]
    lambda_PM = np.median(pairwise_dists) / 0.3

    return {
        'spacings_W': spacings_W,
        'lambda_NN': lambda_NN,
        'lambda_PM': lambda_PM,
        'n_sinks': len(positions),
    }

def compare_with_hgbs(spacing_result):
    """
    Compare sink spacing with HGBS PM (2.79 ± 0.09) and NN (2.08 ± 0.03).

    Test whether the fragmentation process reproduces observations.
    """
    lambda_PM_obs = 2.79
    lambda_PM_err = 0.09
    lambda_NN_obs = 2.08
    lambda_NN_err = 0.03

    lambda_PM_sim = spacing_result['lambda_PM']
    lambda_NN_sim = spacing_result['lambda_NN']

    # Compute consistency
    pm_consistent = abs(lambda_PM_sim - lambda_PM_obs) < 3 * lambda_PM_err
    nn_consistent = abs(lambda_NN_sim - lambda_NN_obs) < 3 * lambda_NN_err

    return {
        'lambda_PM_sim': lambda_PM_sim,
        'lambda_NN_sim': lambda_NN_sim,
        'pm_consistent': pm_consistent,
        'nn_consistent': nn_consistent,
        'matches_hgbs': pm_consistent and nn_consistent,
        'pm_residual': lambda_PM_sim - lambda_PM_obs,
        'nn_residual': lambda_NN_sim - lambda_NN_obs,
    }

def track_secondary_fragmentation(data, sink_data):
    """
    Track whether secondary fragmentation occurs after first sink forms.

    Tests whether longitudinal beading is suppressed entirely or merely delayed.
    """
    formation_times = sink_data['formation_times']
    n_sinks_history = sink_data['n_sinks']  # time series

    if len(formation_times) < 2:
        return {
            'secondary_fragmentation': False,
            'first_sink_time': formation_times[0] if len(formation_times) > 0 else None,
        }

    first_sink_time = formation_times[0]
    final_n_sinks = n_sinks_history[-1]

    # Check if additional sinks formed after first
    additional_sinks = final_n_sinks - 1
    time_to_last_sink = formation_times[-1] - first_sink_time

    # Also check density profile evolution
    # Longitudinal variance should increase if beading occurs
    times = data['times']
    rho = data['rho']

    # Compute longitudinal variance over time
    longitudinal_variance = []
    for rho_snap in rho:
        rho_x_mean = np.mean(rho_snap, axis=(1, 2))
        var = np.var(rho_x_mean)
        longitudinal_variance.append(var)

    # Look for increase in variance after first sink
    first_sink_idx = np.searchsorted(times, first_sink_time)

    if first_sink_idx < len(longitudinal_variance) - 1:
        var_before = longitudinal_variance[first_sink_idx]
        var_after = longitudinal_variance[-1]
        var_increased = var_after > 1.5 * var_before
    else:
        var_increased = False

    return {
        'secondary_fragmentation': additional_sinks > 0,
        'additional_sinks': additional_sinks,
        'time_to_last_sink': time_to_last_sink,
        'longitudinal_variance_increased': var_increased,
    }

def analyze_single_simulation(sim_dir):
    """Complete analysis pipeline for single simulation."""
    params = {}  # read from metadata

    data = load_simulation_data(sim_dir)

    # Extract sink positions
    sink_result = extract_sink_positions(data)

    # Compute spacing distribution
    spacing_result = compute_sink_spacing_distribution(sink_result['positions'])

    if spacing_result is None:
        return {
            'sim_dir': str(sim_dir),
            'params': params,
            'n_sinks': sink_result['n_sinks'],
            'detection': 'INSUFFICIENT_SINKS',
        }

    # Compare with HGBS
    hgbs_comparison = compare_with_hgbs(spacing_result)

    # Track secondary fragmentation
    secondary_frag = track_secondary_fragmentation(data, sink_result)

    return {
        'sim_dir': str(sim_dir),
        'params': params,
        'n_sinks': sink_result['n_sinks'],
        'spacing': spacing_result,
        'hgbs_comparison': hgbs_comparison,
        'secondary_fragmentation': secondary_frag,
        'detection': 'SUCCESS',
    }

def analyze_campaign(campaign_dir='/mnt/raid0/astra_simulations/campaign_d_sink_particles/'):
    """Analyze all simulations in Campaign D."""
    results = []

    sim_dirs = list(Path(campaign_dir).glob('f*'))

    print(f"Found {len(sim_dirs)} simulations")

    pm_values = []
    nn_values = []

    for sim_dir in sim_dirs:
        try:
            result = analyze_single_simulation(sim_dir)
            results.append(result)

            if result['detection'] == 'SUCCESS':
                pm = result['spacing']['lambda_PM']
                nn = result['spacing']['lambda_NN']
                pm_values.append(pm)
                nn_values.append(nn)

                matches = "✓ MATCHES HGBS" if result['hgbs_comparison']['matches_hgbs'] else "✗ does not match"
                secondary = " + secondary frag" if result['secondary_fragmentation']['secondary_fragmentation'] else ""

                print(f"✓ {sim_dir.name}: λ_PM = {pm:.2f}, λ_NN = {nn:.2f}, "
                      f"n_sinks = {result['n_sinks']}{matches}{secondary}")
            else:
                print(f"✗ {sim_dir.name}: {result['detection']}")
        except Exception as e:
            print(f"✗ {sim_dir.name}: {e}")

    df = pd.DataFrame(results)

    # Save results
    output_file = 'analysis/results/campaign_d_summary.csv'
    df.to_csv(output_file, index=False)

    # Summary statistics
    if pm_values:
        pm_mean = np.mean(pm_values)
        pm_std = np.std(pm_values)
        nn_mean = np.mean(nn_values)
        nn_std = np.std(nn_values)

        print(f"\nCampaign D analysis complete!")
        print(f"Results saved to {output_file}")
        print(f"\nAggregate Statistics:")
        print(f"  PM: {pm_mean:.2f} ± {pm_std:.2f} (HGBS: 2.79 ± 0.09)")
        print(f"  NN: {nn_mean:.2f} ± {nn_std:.2f} (HGBS: 2.08 ± 0.03)")

        pm_match = abs(pm_mean - 2.79) < 3 * 0.09
        nn_match = abs(nn_mean - 2.08) < 3 * 0.03
        print(f"  PM matches HGBS: {pm_match}")
        print(f"  NN matches HGBS: {nn_match}")

    return df

if __name__ == "__main__":
    analyze_campaign()
