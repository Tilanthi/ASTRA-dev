#!/usr/bin/env python
"""
Generate comprehensive summary report for all supercritical campaigns.

Compiles results from all four campaigns into a unified report addressing
the core question: Can we measure λ/W in the supercritical regime?
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import json
from datetime import datetime

def load_all_campaign_results():
    """Load results from all four campaigns."""
    base_path = Path('/mnt/raid0/astra_simulations/')

    campaigns = {
        'A': 'campaign_a_turbulent_support',
        'B': 'campaign_b_subisothermal_eos',
        'C': 'campaign_c_hourglass_geometry',
        'D': 'campaign_d_sink_particles',
    }

    results = {}

    for key, name in campaigns.items():
        summary_file = Path(f'analysis/results/campaign_{key.lower()}_summary.csv')

        if summary_file.exists():
            results[key] = pd.read_csv(summary_file)
            print(f"✓ Loaded Campaign {key} results: {len(results[key])} simulations")
        else:
            print(f"✗ Campaign {key} results not found")
            results[key] = None

    return results

def generate_executive_summary(results):
    """Generate executive summary addressing core question."""
    summary = {
        'date': datetime.now().isoformat(),
        'total_simulations': sum(len(df) for df in results.values() if df is not None),
        'campaigns_completed': sum(1 for df in results.values() if df is not None),
    }

    # Core question: Can we measure λ/W in supercritical regime?
    measurements = []

    for key, df in results.items():
        if df is None or 'detection' not in df.columns:
            continue

        successful = df[df['detection'] == 'SUCCESS']
        measurements.append({
            'campaign': key,
            'total': len(df),
            'successful': len(successful),
            'success_rate': len(successful) / len(df) if len(df) > 0 else 0,
        })

    summary['measurement_stats'] = measurements

    return summary

def generate_comparison_table(results):
    """Generate comparison table of λ/W measurements across campaigns."""
    comparison_data = []

    for key, df in results.items():
        if df is None or 'lambda_W' not in df.columns:
            continue

        successful = df[df['detection'] == 'SUCCESS']

        if len(successful) > 0 and 'lambda_W' in successful.columns:
            lambda_W_mean = successful['lambda_W'].mean()
            lambda_W_std = successful['lambda_W'].std()

            comparison_data.append({
                'Campaign': key,
                'Description': {
                    'A': 'Turbulent Pressure Support',
                    'B': 'Sub-Isothermal EOS',
                    'C': 'Hourglass Geometry',
                    'D': 'Sink Particles',
                }[key],
                'N_successful': len(successful),
                'lambda_W_mean': lambda_W_mean,
                'lambda_W_std': lambda_W_std,
            })

    comparison_df = pd.DataFrame(comparison_data)
    return comparison_df

def test_hypotheses(results):
    """Test key hypotheses from campaign specifications."""

    tests = {}

    # Test 1: Campaign A - Does f_eff match predicted values?
    if results.get('A') is not None:
        df_A = results['A']
        if 'f_eff_avg' in df_A.columns:
            predicted_f_eff = 1.0  # target range 1.0-1.3
            actual_f_eff = df_A['f_eff_avg'].mean()

            tests['campaign_a_f_eff'] = {
                'hypothesis': 'Driven turbulence produces f_eff ≈ 1.0-1.3',
                'result': 'PASS' if 0.8 <= actual_f_eff <= 1.5 else 'NEEDS_INSPECTION',
                'actual_f_eff': actual_f_eff,
            }

    # Test 2: Campaign B - Is there γ-dependence?
    if results.get('B') is not None:
        df_B = results['B']
        # Check for gamma dependence in results
        # (Would be computed by campaign B analysis)

        tests['campaign_b_gamma_dependence'] = {
            'hypothesis': 'λ/W shows γ-dependence in supercritical regime',
            'result': 'ANALYZE_FROM_DATA',
        }

    # Test 3: Campaign C - Does hourglass resolve Planck tension?
    if results.get('C') is not None:
        df_C = results['C']
        if 'mean_lambda_W' in df_C.columns:
            lambda_W_mean = df_C['mean_lambda_W'].iloc[0] if 'mean_lambda_W' in df_C.columns else None

            if lambda_W_mean is not None:
                planck_prediction = 1.5
                hgbs_observed = 2.79

                tests['campaign_c_planck_tension'] = {
                    'hypothesis': 'Hourglass geometry produces λ/W ≈ 2.0-3.0, resolving Planck tension',
                    'result': 'PASS' if 2.0 <= lambda_W_mean <= 3.0 else 'NEEDS_INSPECTION',
                    'lambda_W_mean': lambda_W_mean,
                    'planck_prediction': planck_prediction,
                    'hgbs_observed': hgbs_observed,
                }

    # Test 4: Campaign D - Does sink spacing match HGBS?
    if results.get('D') is not None:
        df_D = results['D']
        if 'lambda_PM_sim' in df_D.columns:
            pm_mean = df_D['lambda_PM_sim'].mean()
            pm_observed = 2.79
            pm_error = 0.09

            tests['campaign_d_hgbs_match'] = {
                'hypothesis': 'Sink spacing matches HGBS PM (2.79 ± 0.09)',
                'result': 'PASS' if abs(pm_mean - pm_observed) < 3*pm_error else 'NEEDS_INSPECTION',
                'pm_simulated': pm_mean,
                'pm_observed': pm_observed,
            }

    return tests

def create_summary_plots(results):
    """Create comprehensive summary plots."""
    fig, axes = plt.subplots(2, 2, figsize=(14, 12))

    # Plot 1: Success rates by campaign
    ax = axes[0, 0]
    campaigns_plot = []
    success_rates = []

    for key, df in results.items():
        if df is not None and 'detection' in df.columns:
            successful = df[df['detection'] == 'SUCCESS']
            rate = len(successful) / len(df) * 100
            campaigns_plot.append(key)
            success_rates.append(rate)

    ax.bar(campaigns_plot, success_rates, color='steelblue')
    ax.set_ylabel('Success Rate (%)')
    ax.set_title('Supercritical Campaign Success Rates')
    ax.set_ylim(0, 100)

    # Plot 2: λ/W comparison across campaigns
    ax = axes[0, 1]
    lambda_W_means = []
    lambda_W_stds = []
    campaigns_with_data = []

    for key, df in results.items():
        if df is not None and 'lambda_W' in df.columns:
            successful = df[df['detection'] == 'SUCCESS']
            if len(successful) > 0 and 'lambda_W' in successful.columns:
                mean = successful['lambda_W'].mean()
                std = successful['lambda_W'].std()
                lambda_W_means.append(mean)
                lambda_W_stds.append(std)
                campaigns_with_data.append(key)

    if lambda_W_means:
        ax.bar(campaigns_with_data, lambda_W_means, yerr=lambda_W_stds,
                color='coral', capsize=5)
        ax.axhline(y=2.79, color='green', linestyle='--', label='HGBS PM')
        ax.axhline(y=2.08, color='blue', linestyle='--', label='HGBS NN')
        ax.set_ylabel('λ/W')
        ax.set_title('Fragmentation Wavelength Comparison')
        ax.legend()

    # Plot 3: f_eff distribution (Campaign A)
    ax = axes[1, 0]
    if results.get('A') is not None and 'f_eff_avg' in results['A'].columns:
        f_eff = results['A']['f_eff_avg'].dropna()
        ax.hist(f_eff, bins=20, color='lightblue', edgecolor='black')
        ax.axvline(x=1.0, color='red', linestyle='--', label='Target (f_eff=1.0)')
        ax.set_xlabel('Effective Line-Mass f_eff')
        ax.set_ylabel('Count')
        ax.set_title('Campaign A: f_eff Distribution')
        ax.legend()

    # Plot 4: Hypothesis test results
    ax = axes[1, 1]
    tests = test_hypotheses(results)

    test_names = []
    test_results = []
    for test_key, test_data in tests.items():
        if isinstance(test_data.get('result'), str):
            test_names.append(test_key)
            test_results.append(1 if test_data['result'] == 'PASS' else 0)

    if test_names:
        colors = ['green' if r == 1 else 'orange' for r in test_results]
        ax.barh(test_names, test_results, color=colors)
        ax.set_xlabel('Test Result (1=PASS, 0=NEEDS INSPECTION)')
        ax.set_title('Hypothesis Test Results')
        ax.set_xlim(0, 1.1)

    plt.tight_layout()
    plt.savefig('analysis/results/supercritical_summary.png', dpi=150)
    print("✓ Summary plots saved to analysis/results/supercritical_summary.png")

def generate_markdown_report(results, summary, comparison_df, tests):
    """Generate comprehensive markdown report."""
    report = []

    report.append("# Supercritical Filament Fragmentation Campaigns")
    report.append("## Final Report")
    report.append(f"**Generated:** {summary['date']}")
    report.append(f"**Total Simulations:** {summary['total_simulations']}")
    report.append(f"**Campaigns Completed:** {summary['campaigns_completed']}/4")
    report.append("")

    # Executive Summary
    report.append("## Executive Summary")
    report.append("")
    report.append("**Core Question:** Can we measure λ/W in the supercritical regime (f ≥ 1.5)?")
    report.append("")

    # Count successful measurements
    total_successful = sum(s['successful'] for s in summary['measurement_stats'])
    total_simulated = summary['total_simulations']

    report.append(f"**Results:**")
    report.append(f"- Total simulations: {total_simulated}")
    report.append(f"- Successful λ/W measurements: {total_successful}")
    report.append(f"- Overall success rate: {total_successful/total_simulated*100:.1f}%")
    report.append("")

    if total_successful > 0:
        report.append("**✅ POSITIVE RESULT:** Longitudinal beading detected in supercritical regime!")
        report.append("- Validating that the physics modifications successfully retarded radial collapse.")
    else:
        report.append("**❌ NULL RESULT:** No longitudinal beading detected across all campaigns.")
        report.append("- Suggests ideal MHD is fundamentally incapable of explaining HGBS observations.")
        report.append("- Makes compelling case for non-ideal MHD (ambipolar diffusion, Hall effect).")
    report.append("")

    # Campaign-by-Campaign Results
    report.append("## Campaign Results")
    report.append("")

    for key, df in results.items():
        if df is None:
            report.append(f"### Campaign {key}: Results not available")
            continue

        report.append(f"### Campaign {key}: {df['params'].iloc[0] if 'params' in df.columns else 'Subcritical'}")
        report.append("")

        if 'detection' in df.columns:
            successful = df[df['detection'] == 'SUCCESS']
            failed = df[df['detection'] != 'SUCCESS']

            report.append(f"- **Total:** {len(df)}")
            report.append(f"- **Successful:** {len(successful)} ({len(successful)/len(df)*100:.1f}%)")
            report.append(f"- **Failed:** {len(failed)} ({len(failed)/len(df)*100:.1f}%)")

            if len(successful) > 0 and 'lambda_W' in successful.columns:
                lambda_W_mean = successful['lambda_W'].mean()
                lambda_W_std = successful['lambda_W'].std()
                report.append(f"- **Mean λ/W:** {lambda_W_mean:.2f} ± {lambda_W_std:.2f}")

        report.append("")

    # Hypothesis Tests
    report.append("## Hypothesis Tests")
    report.append("")

    for test_key, test_data in tests.items():
        report.append(f"### {test_key}")
        report.append(f"**Hypothesis:** {test_data['hypothesis']}")
        report.append(f"**Result:** {test_data['result']}")

        for key, value in test_data.items():
            if key not in ['hypothesis', 'result']:
                report.append(f"- **{key}:** {value}")

        report.append("")

    # Comparison Table
    report.append("## λ/W Comparison Across Campaigns")
    report.append("")

    if comparison_df is not None and len(comparison_df) > 0:
        report.append("| Campaign | Description | N_succ | λ/W (mean) | λ/W (std) |")
        report.append("|----------|-------------|-------|-------------|------------|")
        for _, row in comparison_df.iterrows():
            report.append(f"| {row['Campaign']} | {row['Description']} | "
                        f"{row['N_successful']} | {row['lambda_W_mean']:.2f} | "
                        f"{row['lambda_W_std']:.2f} |")

    report.append("")
    report.append("**Reference values:**")
    report.append("- HGBS PM: 2.79 ± 0.09")
    report.append("- HGBS NN: 2.08 ± 0.03")
    report.append("- Classical isothermal (IM92): 4.0")
    report.append("")

    # Recommendations
    report.append("## Recommendations")
    report.append("")

    if total_successful > 0:
        report.append("### For Paper Revision:")
        report.append("1. Update supercritical section with measured λ/W values")
        report.append("2. Add comparison with Campaign 7 calibration")
        report.append("3. Discuss which physics modification(s) best explain observations")
        report.append("")

        report.append("### For Future Work:")
        report.append("1. Extend successful campaign(s) to parameter space not yet covered")
        report.append("2. Test combinations of successful physics (e.g., turbulence + hourglass)")
        report.append("3. Consider next-generation simulations with non-ideal MHD")
    else:
        report.append("### For Paper Revision:")
        report.append("1. Emphasize that ideal MHD fails in supercritical regime")
        report.append("2. Make strong case for non-ideal MHD as prerequisite")
        report.append("3. Position these results as motivation for next-generation simulations")
        report.append("")

        report.append("### For Future Work:")
        report.append("1. Implement ambipolar diffusion module")
        report.append("2. Test Hall effect in supercritical regime")
        report.append("3. Consider radiative transfer coupling")

    # Write report
    report_text = "\n".join(report)

    report_file = Path('analysis/results/SUPERCRITICAL_FINAL_REPORT.md')
    with open(report_file, 'w') as f:
        f.write(report_text)

    print(f"✓ Final report saved to {report_file}")

def main():
    print("="*60)
    print("Supercritical Campaigns: Final Report Generator")
    print("="*60)
    print("")

    # Load results
    results = load_all_campaign_results()

    if not any(results.values()):
        print("✗ No campaign results found. Run analysis scripts first.")
        return

    # Generate summary
    summary = generate_executive_summary(results)

    print(f"Total simulations analyzed: {summary['total_simulations']}")
    print(f"Campaigns completed: {summary['campaigns_completed']}/4")
    print("")

    # Generate comparison table
    comparison_df = generate_comparison_table(results)

    # Test hypotheses
    tests = test_hypotheses(results)

    # Create plots
    create_summary_plots(results)

    # Generate markdown report
    generate_markdown_report(results, summary, comparison_df, tests)

    print("")
    print("="*60)
    print("Analysis complete!")
    print("="*60)
    print(f"Results saved to analysis/results/")
    print(f"- SUPERCRITICAL_FINAL_REPORT.md")
    print(f"- supercritical_summary.png")
    print(f"- campaign_*_summary.csv")

if __name__ == "__main__":
    main()
