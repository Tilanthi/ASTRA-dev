#!/usr/bin/env python
"""
Analysis script for Campaign B: Sub-Isothermal EOS

Key analyses:
1. Compute longitudinal power spectrum P(k_x) at each snapshot
2. Flag beading when P(k_peak)/P(k=0) > 5
3. Measure growth rate dP(k_peak)/dt
4. Test for γ-dependence in supercritical regime
"""

import numpy as np
import h5py
from pathlib import Path
from scipy.signal import find_peaks
from scipy.fft import fft, fftfreq
import pandas as pd
import matplotlib.pyplot as plt

def load_simulation_data(sim_dir):
    """Load HDF5 output from simulation directory."""
    output_file = Path(sim_dir) / 'output' / 'output.hdf5'

    with h5py.File(output_file, 'r') as f:
        data = {
            'times': f['times'][:],
            'rho': f['density'][:],  # full 3D density (snapshots, Nx, Ny, Nz)
        }

    return data

def compute_longitudinal_power_spectrum(rho_snapshot):
    """
    Compute longitudinal power spectrum P(k_x) from 3D density.

    Takes 3D density, averages over transverse directions, then FFT.
    """
    # Average over transverse plane
    rho_x_mean = np.mean(rho_snapshot, axis=(1, 2))

    # Subtract mean to get fluctuations
    rho_x_fluct = rho_x_mean - np.mean(rho_x_mean)

    # FFT along x
    rho_k = fft(rho_x_fluct)
    P_k = np.abs(rho_k)**2

    # Get wavenumbers
    Nx = len(rho_x_mean)
    k = fftfreq(Nx, d=1.0/Nx)  # in units of 2π/L_x

    # Keep positive frequencies
    pos_k = k >= 0
    k_pos = k[pos_k]
    P_k_pos = P_k[pos_k]

    return k_pos, P_k_pos

def detect_beading_power_spectrum(data, threshold=5.0):
    """
    Detect beading using power spectrum contrast ratio.

    Beading detected when P(k_peak) / P(k=0) > threshold.
    """
    times = data['times']
    rho = data['rho']

    beading_times = []
    peak_k_history = []
    growth_rates = []

    for i, (t, rho_snap) in enumerate(zip(times, rho)):
        k, P_k = compute_longitudinal_power_spectrum(rho_snap)

        # Exclude k=0 mode
        P_k_nozero = P_k[1:]
        k_nozero = k[1:]

        # Find peak wavenumber
        k_peak_idx = np.argmax(P_k_nozero)
        k_peak = k_nozero[k_peak_idx]
        P_k_peak = P_k_nozero[k_peak_idx]
        P_k0 = P_k[0]

        contrast_ratio = P_k_peak / P_k0 if P_k0 > 0 else 0

        if contrast_ratio > threshold:
            beading_times.append(t)
            peak_k_history.append(k_peak)

            # Estimate growth rate from recent history
            if len(peak_k_history) >= 3:
                recent_P = P_k_nozero[k_peak_idx][-3:]
                # Linear fit in log-space gives growth rate
                log_P = np.log(recent_P_P)
                t_recent = times[-3:]
                growth_rate = np.polyfit(t_recent, log_P, 1)[0]
                growth_rates.append(growth_rate)

    return {
        'beading_detected': len(beading_times) > 0,
        'beading_times': beading_times,
        'k_peak_history': peak_k_history,
        'growth_rates': growth_rates,
        'final_contrast_ratio': contrast_ratio,
    }

def extract_lambda_W_from_power_spectrum(data):
    """
    Extract λ/W from power spectrum peak wavenumber.
    """
    # Use final snapshot
    rho_final = data['rho'][-1]
    k, P_k = compute_longitudinal_power_spectrum(rho_final)

    # Find peak (excluding k=0)
    P_k_nozero = P_k[1:]
    k_nozero = k[1:]

    k_peak_idx = np.argmax(P_k_nozero)
    k_peak = k_nozero[k_peak_idx]

    # Convert wavenumber to wavelength
    # k = 2π / λ  =>  λ = 2π / k
    L_x = 8.0  # domain length in λ_J units
    lambda_peak = 2 * np.pi / k_peak

    # Convert to λ/W_core
    lambda_W = lambda_peak / 0.3

    return {
        'lambda_W': lambda_W,
        'k_peak': k_peak,
        'P_k_peak': P_k_nozero[k_peak_idx],
    }

def test_gamma_dependence(campaign_df):
    """
    Test whether λ/W shows systematic γ-dependence in supercritical regime.

    Campaign 7 (near-critical) found no significant γ-dependence (< 2.8% variation).
    Test whether this changes for supercritical filaments.
    """
    # Group by γ and compute mean λ/W
    gamma_groups = campaign_df.groupby('gamma')['lambda_W'].agg(['mean', 'std', 'count'])

    # Linear regression: λ/W vs γ
    from scipy.stats import linregress

    valid_data = campaign_df[campaign_df['detection'] == 'SUCCESS'][['gamma', 'lambda_W']]

    if len(valid_data) > 10:
        slope, intercept, r_value, p_value, std_err = linregress(
            valid_data['gamma'],
            valid_data['lambda_W']
        )

        return {
            'slope': slope,
            'intercept': intercept,
            'r_squared': r_value**2,
            'p_value': p_value,
            'std_err': std_err,
            'significant_gamma_dependence': p_value < 0.05,
        }

    return None

def analyze_single_simulation(sim_dir):
    """Complete analysis pipeline for single simulation."""
    # Load params
    params = {}  # read from metadata

    # Load data
    data = load_simulation_data(sim_dir)

    # Detect beading using power spectrum
    beading_result = detect_beading_power_spectrum(data)

    # Extract λ/W if beading detected
    lambda_W_result = None
    if beading_result['beading_detected']:
        lambda_W_result = extract_lambda_W_from_power_spectrum(data)
        lambda_W_result['detection'] = 'SUCCESS'
    else:
        lambda_W_result = {'detection': 'FAILED', 'beading_detected': False}

    return {
        'sim_dir': str(sim_dir),
        'params': params,
        'beading': beading_result,
        'lambda_W': lambda_W_result,
    }

def analyze_campaign(campaign_dir='/mnt/raid0/astra_simulations/campaign_b_subisothermal_eos/'):
    """Analyze all simulations in Campaign B."""
    results = []

    sim_dirs = list(Path(campaign_dir).glob('f*'))

    print(f"Found {len(sim_dirs)} simulations")

    for sim_dir in sim_dirs:
        try:
            result = analyze_single_simulation(sim_dir)
            results.append(result)
            detection = result['lambda_W']['detection']
            if detection == 'SUCCESS':
                print(f"✓ {sim_dir.name}: λ/W = {result['lambda_W']['lambda_W']:.2f}, "
                      f"γ = {result['params']['gamma']}")
            else:
                print(f"✗ {sim_dir.name}: No beading detected")
        except Exception as e:
            print(f"✗ {sim_dir.name}: {e}")

    # Create DataFrame
    df = pd.DataFrame(results)

    # Test for γ-dependence
    gamma_test = test_gamma_dependence(df)

    # Save results
    output_file = 'analysis/results/campaign_b_summary.csv'
    df.to_csv(output_file, index=False)

    print(f"\nCampaign B analysis complete!")
    print(f"Results saved to {output_file}")

    if gamma_test:
        print(f"\nγ-dependence test:")
        print(f"  Slope: {gamma_test['slope']:.3f} ± {gamma_test['std_err']:.3f}")
        print(f"  R²: {gamma_test['r_squared']:.3f}")
        print(f"  p-value: {gamma_test['p_value']:.3f}")
        print(f"  Significant γ-dependence: {gamma_test['significant_gamma_dependence']}")

    return df

if __name__ == "__main__":
    analyze_campaign()
