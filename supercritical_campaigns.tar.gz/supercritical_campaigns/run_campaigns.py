#!/usr/bin/env python
"""
Ray deployment script for supercritical filament fragmentation campaigns.

Usage:
    python run_campaigns.py --campaign B --parallel 50 --timeout 14400
    python run_campaigns.py --campaign A --parallel 25 --timeout 21600

Run in priority order: B -> A -> C -> D
"""

import argparse
import os
import sys
import ray
from pathlib import Path

# Add campaign specifications to path
sys.path.insert(0, str(Path(__file__).parent))

def setup_ray_cluster(num_cpus, memory_per_sim):
    """Initialize Ray cluster with appropriate resources."""
    ray.init(
        address=os.environ.get('RAY_ADDRESS', 'auto'),  # Connect to existing cluster
        runtime_env={
            'pip': ['numpy', 'h5py', 'scipy'],
            'env_vars': {
                'PYTHONPATH': '/path/to/astra_core:$PYTHONPATH',
                'LD_LIBRARY_PATH': '/path/to/athena++/lib:$LD_LIBRARY_PATH',
            }
        }
    )
    print(f"Connected to Ray cluster at {ray.cluster_resources()}")

def run_campaign_b(n_parallel=50, timeout=14400):
    """Run Campaign B (Sub-Isothermal EOS)."""
    from campaign_b.specification import (
        CAMPAIGN_NAME, generate_parameter_points, RAY_RESOURCES
    )

    print(f"\n{'='*60}")
    print(f"Running Campaign B: {CAMPAIGN_NAME}")
    print(f"{'='*60}")

    points = generate_parameter_points()
    print(f"Total simulations: {len(points)}")
    print(f"Parallel jobs: {n_parallel}")
    print(f"Timeout per job: {timeout}s")

    @ray.remote(num_cpus=RAY_RESOURCES['cpus_per_sim'])
    def run_single_simulation(params):
        """Execute single Athena++ simulation with given parameters."""
        import subprocess
        import os
        from pathlib import Path

        # Create simulation directory
        sim_dir = Path(f"/mnt/raid0/astra_simulations/{params['campaign']}")
        sim_dir.mkdir(parents=True, exist_ok=True)

        # Create problem generator config
        config_file = sim_dir / "problem_config.ini"
        write_problem_generator_config(params, config_file)

        # Run Athena++ simulation
        cmd = [
            'athena++',
            '-i', str(config_file),
            '-d', str(sim_dir),
            'output/output_file=sink_data.hdf5' if 'sink' in params['campaign'] else '',
        ]

        try:
            result = subprocess.run(
                cmd,
                timeout=timeout,
                capture_output=True,
                text=True,
            )

            if result.returncode == 0:
                # Validate output
                valid, msg = validate_output(sim_dir)
                if valid:
                    return {'status': 'SUCCESS', 'params': params, 'sim_dir': str(sim_dir)}
                else:
                    return {'status': 'INVALID_OUTPUT', 'params': params, 'error': msg}
            else:
                return {'status': 'FAILED', 'params': params, 'error': result.stderr}

        except subprocess.TimeoutExpired:
            return {'status': 'TIMEOUT', 'params': params}
        except Exception as e:
            return {'status': 'ERROR', 'params': params, 'error': str(e)}

    # Submit all jobs
    futures = [run_single_simulation.remote(p) for p in points]

    # Collect results
    results = ray.get(futures)

    # Summary
    success = sum(1 for r in results if r['status'] == 'SUCCESS')
    failed = sum(1 for r in results if r['status'] == 'FAILED')
    timeout = sum(1 for r in results if r['status'] == 'TIMEOUT')

    print(f"\nCampaign B Results:")
    print(f"  SUCCESS: {success}")
    print(f"  FAILED:  {failed}")
    print(f"  TIMEOUT: {timeout}")

    return results

def write_problem_generator_config(params, config_file):
    """Write Athena++ problem generator configuration file."""
    import configparser

    config = configparser.ConfigParser()

    # Problem setup
    config['job'] = {
        'problem': 'filament',
        'tlim': params.get('t_max', 2.0),
        'dt': params.get('dt', '0.001'),
    }

    # Mesh
    config['mesh'] = {
        'nx1': params['N_x'],
        'nx2': params['N_y'],
        'nx3': params['N_z'],
        'x1min': 0.0,
        'x1max': params['L_x'],
        'x2min': -params['L_y']/2,
        'x2max': params['L_y']/2,
        'x3min': -params['L_z']/2,
        'x3max': params['L_z']/2,
    }

    # Output
    config['output'] = {
        'output_dir': 'output/',
        'file_type': 'hdf5',
        'dt': params.get('output_interval', 0.01),
    }

    # Hydro
    config['hydro'] = {
        'iso_sound_speed': 1.0,
    }

    # EOS ( Campaign B specific)
    if params['campaign'] == 'campaign_b_subisothermal_eos':
        config['eos'] = {
            'eos': 'polytropic',
            'Gamma': params['gamma'],
            'T_floor': params.get('T_floor', 0.01),
        }

    # Magnetic field
    if 'theta' in params:
        config['field'] = {
            'b_initial': 'uniform',
            'bx': params['B0'] * np.cos(np.radians(params['theta'])),
            'by': 0.0,
            'bz': params['B0'] * np.sin(np.radians(params['theta'])),
        }

    # Boundary conditions
    config['boundary'] = {
        'bc_x1': 'periodic',
        'bc_x2': 'outflow',
        'bc_x3': 'outflow',
    }

    # Write config
    with open(config_file, 'w') as f:
        config.write(f)

def validate_output(sim_dir):
    """Validate simulation output."""
    # Import validation from campaign spec
    if 'campaign_b' in str(sim_dir):
        from campaign_b.specification import validate_simulation_output
    elif 'campaign_a' in str(sim_dir):
        from campaign_a.specification import validate_simulation_output
    elif 'campaign_c' in str(sim_dir):
        from campaign_c.specification import validate_simulation_output
    elif 'campaign_d' in str(sim_dir):
        from campaign_d.specification import validate_simulation_output
    else:
        return True, "OK"

    return validate_simulation_output(sim_dir)

def main():
    parser = argparse.ArgumentParser(description='Run supercritical campaigns on Ray cluster')
    parser.add_argument('--campaign', type=str, required=True,
                        choices=['A', 'B', 'C', 'D'],
                        help='Campaign to run (A=Turbulent, B=EOS, C=Hourglass, D=Sink)')
    parser.add_argument('--parallel', type=int, default=25,
                        help='Number of concurrent jobs')
    parser.add_argument('--timeout', type=int, default=21600,
                        help='Wall-clock timeout per simulation (seconds)')
    parser.add_argument('--cpus-per-sim', type=int, default=8,
                        help='CPUs per simulation')

    args = parser.parse_args()

    # Setup Ray
    setup_ray_cluster(args.parallel * args.cpus_per_sim, '4GB')

    # Run requested campaign
    campaign_map = {
        'A': run_campaign_a,
        'B': run_campaign_b,
        'C': run_campaign_c,
        'D': run_campaign_d,
    }

    if args.campaign in campaign_map:
        results = campaign_map[args.campaign](
            n_parallel=args.parallel,
            timeout=args.timeout
        )

        # Save results summary
        import json
        summary_file = f"{args.campaign.lower()}_results_summary.json"
        with open(summary_file, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"\nResults saved to {summary_file}")

    ray.shutdown()

if __name__ == "__main__":
    main()
