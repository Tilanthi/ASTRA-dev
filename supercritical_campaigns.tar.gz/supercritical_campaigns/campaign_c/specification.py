"""
Campaign C: Hourglass Field Geometry
Physical Rationale: Model internal field transition from perpendicular (large-scale)
to longitudinal (core) to resolve Planck tension.

Total simulations: 108
Domain: 8 × 4 × 4 λ_J (wider transverse to accommodate curved field)
Resolution: 256 × 128 × 128 cells
Requires full 3D field vector output for geometry tracking
"""

CAMPAIGN_NAME = "campaign_c_hourglass_geometry"
TOTAL_SIMULATIONS = 108

# Parameter grid
PARAMETER_GRID = {
    'f': [1.5, 2.0, 3.0],               # line-mass fraction
    'beta_central': [0.5, 1.0, 2.0],    # on-axis plasma beta
    'r_waist_ratio': [0.3, 0.5, 1.0],    # r_waist / W_core
    'M': [1.0, 2.0],                     # Mach number
    'seed': [0, 1]                        # random seeds
}

# Domain specification (wider transverse for hourglass)
DOMAIN = {
    'L_x': 8.0,
    'L_y': 4.0,                          # doubled transverse
    'L_z': 4.0,                          # doubled transverse
    'N_x': 256,
    'N_y': 128,
    'N_z': 128,
}

# Initial conditions
INITIAL_CONDITIONS = {
    'profile': 'gaussian',
    'rho_c': 1.0,
    'W_core': 0.3,
}

# Hourglass field geometry specification
HOURGLASS_FIELD = {
    'type': 'curved_hourglass',
    'B_x': lambda r, B0, r_w: B0 * np.tanh(r / r_w),
    'B_z': lambda r, B0, r_w: B0 / np.cosh(r / r_w),
    'r_waist': None,                      # set from r_waist_ratio * W_core
    'B0_scaling': 'from_beta_central',   # compute from beta_central parameter
}

# Runtime configuration with field output
RUNTIME = {
    't_max': 2.0,                         # t_J
    'timeout_seconds': 259200,           # 72 hours (expensive domain)
    'output_interval': 0.01,              # fine cadence for geometry tracking
    'checkpoint_interval': 0.5,
    'output_full_B': True,                 # full 3D field vector at each snapshot
}

# Resources (more CPUs per sim due to wider domain)
RAY_RESOURCES = {
    'cpus_per_sim': 16,
    'concurrent_jobs': 12,
    'memory_per_sim': '8GB',
}

# Analysis requirements
ANALYSIS_CONFIG = {
    'track_field_geometry': True,         # compute θ(r) at each snapshot
    'measure_on_axis_spacing': True,      # extract λ/W from on-axis profile
    'population_weighted_prediction': True, # using actual internal geometry
    'compare_to_planck': True,           # evaluate tension resolution
}

def generate_parameter_points():
    """Generate all parameter combinations for Ray execution."""
    import itertools

    points = []
    for f in PARAMETER_GRID['f']:
        for beta_c in PARAMETER_GRID['beta_central']:
            for r_w in PARAMETER_GRID['r_waist_ratio']:
                for M in PARAMETER_GRID['M']:
                    for seed in PARAMETER_GRID['seed']:
                        points.append({
                            'f': f,
                            'beta_central': beta_c,
                            'r_waist_ratio': r_w,
                            'M': M,
                            'seed': seed,
                            'campaign': CAMPAIGN_NAME,
                        })
    return points

def hourglass_field_function(r, B0, r_waist):
    """Return hourglass field components at cylindrical radius r."""
    import numpy as np

    B_x = B0 * np.tanh(r / r_waist)
    B_z = B0 / np.cosh(r / r_waist)

    # Also compute magnitude for normalization
    B_mag = np.sqrt(B_x**2 + B_z**2)

    return B_x, B_z, B_mag

def validate_simulation_output(sim_dir):
    """Validate that simulation output is complete and valid."""
    import os
    import h5py

    required_files = ['output/output.hdf5']

    for fname in required_files:
        fpath = os.path.join(sim_dir, fname)
        if not os.path.exists(fpath):
            return False, f"Missing {fname}"

        try:
            with h5py.File(fpath, 'r') as f:
                # Check for full B field output
                if 'B_x' not in f or 'B_y' not in f or 'B_z' not in f:
                    return False, "Missing full B field components"
        except Exception as e:
            return False, f"HDF5 read error: {e}"

    return True, "OK"

if __name__ == "__main__":
    points = generate_parameter_points()
    print(f"Campaign C: {len(points)} parameter points")
    print(f"Expected runtime: {len(points) * RAY_RESOURCES['cpus_per_sim'] / RAY_RESOURCES['concurrent_jobs'] / 24:.1f} days")
