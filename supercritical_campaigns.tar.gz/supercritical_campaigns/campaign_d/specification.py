"""
Campaign D: Adaptive Sink Particles to Prevent Runaway Collapse
Physical Rationale: Sink particles prevent CFL timestep collapse by removing
high-density material, allowing simulation to continue and potentially reveal
longitudinal fragmentation after initial radial collapse.

Total simulations: 144
Domain: 8 × 2 × 2 λ_J
Resolution: 256 × 64 × 64 cells
Requires Athena++ sink particle module (development branch)
"""

CAMPAIGN_NAME = "campaign_d_sink_particles"
TOTAL_SIMULATIONS = 144

# Parameter grid
PARAMETER_GRID = {
    'f': [1.5, 2.0, 2.5, 3.0],           # line-mass fraction
    'beta': [0.5, 1.0, 2.0],             # plasma beta
    'theta': [0, 45, 90],                 # field angle (degrees)
    'M': [1.0, 2.0],                     # Mach number
    'seed': [0, 1]                        # random seeds
}

# Domain specification
DOMAIN = {
    'L_x': 8.0,
    'L_y': 2.0,
    'L_z': 2.0,
    'N_x': 256,
    'N_y': 64,
    'N_z': 64,
}

# Initial conditions
INITIAL_CONDITIONS = {
    'profile': 'gaussian',
    'rho_c': 1.0,
    'W_core': 0.3,
    'B0': 1.0,
}

# Sink particle configuration
SINK_PARTICLE_CONFIG = {
    'enabled': True,
    'creation_threshold': 100.0,         # ρ_sink = 100 ρ_0 (two orders above initial)
    'sink_radius': 2.0,                   # r_sink = 2 Δx (minimum to avoid artifacts)
    'accretion_model': 'bondi_hoyle',    # Bondi-Hoyle accretion
    'merge_radius': None,                 # don't merge sinks (track individual fragments)
    'output_sink_data': True,             # track 3D positions and formation times
}

# Runtime configuration with extended runtime
RUNTIME = {
    't_max': 5.0,                         # extended to 5.0 t_J
    'timeout_seconds': 43200,            # 12 hours wall-clock
    'output_interval': 0.02,
    'checkpoint_interval': 1.0,
    'stop_condition': {
        'type': 'sink_count_threshold',
        'max_sinks': 10,                   # stop if >10 sinks form
    },
}

# Resources
RAY_RESOURCES = {
    'cpus_per_sim': 8,
    'concurrent_jobs': 25,
    'memory_per_sim': '4GB',
}

# Analysis requirements
ANALYSIS_CONFIG = {
    'extract_sink_positions': True,        # 3D positions of all sinks
    'compute_sink_spacing': True,          # 1D projected spacing along x-axis
    'compare_to_hgbs': True,              # test against PM (2.79) and NN (2.08)
    'track_secondary_fragmentation': True, # check for beading after first sink
    'sink_statistics': {
        'formation_time': True,
        'mass_history': True,
        'accretion_rate': True,
    },
}

def generate_parameter_points():
    """Generate all parameter combinations for Ray execution."""
    import itertools

    points = []
    for f in PARAMETER_GRID['f']:
        for beta in PARAMETER_GRID['beta']:
            for theta in PARAMETER_GRID['theta']:
                for M in PARAMETER_GRID['M']:
                    for seed in PARAMETER_GRID['seed']:
                        points.append({
                            'f': f,
                            'beta': beta,
                            'theta': theta,
                            'M': M,
                            'seed': seed,
                            'campaign': CAMPAIGN_NAME,
                        })
    return points

def validate_simulation_output(sim_dir):
    """Validate that simulation output is complete and valid."""
    import os
    import h5py

    required_files = ['output/output.hdf5', 'sinks/sink_data.hdf5']

    for fname in required_files:
        fpath = os.path.join(sim_dir, fname)
        if not os.path.exists(fpath):
            return False, f"Missing {fname}"

        try:
            with h5py.File(fpath, 'r') as f:
                if 'sink_data' in fname:
                    # Check sink data
                    if len(f['sink_positions']) == 0:
                        return False, "No sinks formed"
        except Exception as e:
            return False, f"HDF5 read error: {e}"

    return True, "OK"

if __name__ == "__main__":
    points = generate_parameter_points()
    print(f"Campaign D: {len(points)} parameter points")
    print(f"Expected runtime: {len(points) * RAY_RESOURCES['cpus_per_sim'] / RAY_RESOURCES['concurrent_jobs'] / 24:.1f} days")
    print("\nWARNING: Requires Athena++ development branch with sink particle module!")
    print("Verify availability before deployment.")
"""