"""
Campaign B: Sub-Isothermal Equation of State in Supercritical Regime
Physical Rationale: Test whether γ-dependence in supercritical regime differs from
near-critical, potentially allowing longitudinal beading to develop.

Total simulations: 192
Domain: 8 × 2 × 2 λ_J
Resolution: 256 × 64 × 64 cells
CRITICAL: Finer snapshot cadence (0.01 t_J) to capture transient beading
"""

CAMPAIGN_NAME = "campaign_b_subisothermal_eos"
TOTAL_SIMULATIONS = 192

# Parameter grid
PARAMETER_GRID = {
    'f': [1.5, 2.0, 2.5, 3.0],           # line-mass fraction
    'beta': [0.5, 1.0, 2.0],             # plasma beta
    'gamma': [0.5, 0.7, 0.9, 1.0],       # adiabatic index
    'theta': [0, 90],                     # field angle (degrees)
    'seed': [0, 1]                        # random seeds
}

# Domain specification
DOMAIN = {
    'L_x': 8.0,
    'L_y': 2.0,
    'L_z': 2.0,
    'N_x': 256,
    'N_y': 64,
    'N_z': 64,
}

# Initial conditions
INITIAL_CONDITIONS = {
    'profile': 'gaussian',
    'rho_c': 1.0,
    'W_core': 0.3,
    'B0': 1.0,
}

# EOS specification
EOS_CONFIG = {
    'type': 'polytropic',                 # NOT isothermal approximation
    'gamma': None,                        # set from parameter grid
    'T_floor': 0.01,                     # prevent numerical issues (relative to T_0)
    'use_general_eos_module': True,      # CRITICAL: don't use isothermal solver
}

# Runtime configuration with finer snapshot cadence
RUNTIME = {
    't_max': 2.0,                         # t_J
    'timeout_seconds': 14400,            # 4 hours wall-clock
    'output_interval': 0.01,              # 5× finer than supercritical campaign
    'checkpoint_interval': 0.5,
}

# Resources
RAY_RESOURCES = {
    'cpus_per_sim': 4,
    'concurrent_jobs': 50,
    'memory_per_sim': '2GB',
}

# Analysis requirements
ANALYSIS_CONFIG = {
    'use_power_spectrum': True,           # analyze P(k_x) instead of just peak-finding
    'beading_threshold': 5.0,             # P(k_peak) / P(k=0) > 5 for detection
    'measure_growth_rate': True,          # dP(k_peak)/dt
    'dense_temporal_sampling': True,      # flag transient beading
}

def generate_parameter_points():
    """Generate all parameter combinations for Ray execution."""
    import itertools

    points = []
    for f in PARAMETER_GRID['f']:
        for beta in PARAMETER_GRID['beta']:
            for gamma in PARAMETER_GRID['gamma']:
                for theta in PARAMETER_GRID['theta']:
                    for seed in PARAMETER_GRID['seed']:
                        points.append({
                            'f': f,
                            'beta': beta,
                            'gamma': gamma,
                            'theta': theta,
                            'seed': seed,
                            'campaign': CAMPAIGN_NAME,
                        })
    return points

def validate_simulation_output(sim_dir):
    """Validate that simulation output is complete and valid."""
    import os
    import h5py

    required_files = ['output/output.hdf5']

    for fname in required_files:
        fpath = os.path.join(sim_dir, fname)
        if not os.path.exists(fpath):
            return False, f"Missing {fname}"

        try:
            with h5py.File(fpath, 'r') as f:
                times = f['times'][:]
                # For Campaign B, expect more snapshots due to finer cadence
                if len(times) < 100:  # should have ~200 snapshots at 0.01 cadence
                    return False, f"Insufficient snapshots: {len(times)} < 100"
        except Exception as e:
            return False, f"HDF5 read error: {e}"

    return True, "OK"

if __name__ == "__main__":
    points = generate_parameter_points()
    print(f"Campaign B: {len(points)} parameter points")
    print(f"Expected runtime: {len(points) * RAY_RESOURCES['cpus_per_sim'] / RAY_RESOURCES['concurrent_jobs'] / 24:.1f} days")
