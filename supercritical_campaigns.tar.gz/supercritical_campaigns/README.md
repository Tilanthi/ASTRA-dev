# Supercritical Filament Fragmentation Campaigns
## Deployment on ASTRA 220 vCPU Ray Cluster

### Overview
This package contains four independent campaigns designed to solve the core problem: **existing 2,000 simulations fail in the supercritical regime (f ≥ 1.5) because radial collapse reaches runaway before longitudinal beading can develop.**

Each campaign implements a physically motivated strategy to retard radial collapse long enough for longitudinal fragmentation to be measured.

### Campaign Priority Order (Run in this sequence)

1. **Campaign B** (Sub-Isothermal EOS) - 192 simulations
   - Lowest implementation risk
   - Directly tests existing λ/W EOS-insensitivity result
   - Finer snapshot cadence (0.01 t_J) may reveal missed beading

2. **Campaign A** (Turbulent Pressure Support) - 216 simulations
   - Highest scientific payoff (tests Heitsch f_eff formalism)
   - Requires forcing module implementation
   - Run after B validates infrastructure

3. **Campaign C** (Hourglass Field Geometry) - 108 simulations
   - Directly addresses Planck tension
   - Straightforward implementation but expensive (wider domain)

4. **Campaign D** (Adaptive Sink Particles) - 144 simulations
   - Most directly comparable to observations
   - Requires sink particle module verification
   - Highest complexity

### Quick Start Deployment

```bash
# On astra-cluster head node
cd /path/to/supercritical_campaigns

# Activate environment
source ~/.bashrc
conda activate astra

# Run Campaign B first (lowest risk)
python run_campaign_b.py --parallel 50 --timeout 14400

# Then Campaign A (after validating forcing module)
python run_campaign_a.py --parallel 25 --timeout 21600

# Then Campaign C
python run_campaign_c.py --parallel 12 --timeout 259200

# Finally Campaign D
python run_campaign_d.py --parallel 25 --timeout 43200
```

### Ray Cluster Configuration

**Available Resources:**
- Total CPUs: 208 usable slots
- Memory: ~1 TB across cluster
- Storage: /mnt/raid0/astra_simulations/ (fast local storage)

**CPU Allocation per Campaign:**
- Campaign A: 8 CPUs/sim, 25 concurrent jobs (200 CPUs)
- Campaign B: 4 CPUs/sim, 50 concurrent jobs (200 CPUs)
- Campaign C: 16 CPUs/sim, 12 concurrent jobs (192 CPUs)
- Campaign D: 8 CPUs/sim, 25 concurrent jobs (200 CPUs)

### Expected Runtime

- Campaign B: ~1 day (192 sims × 4 hours)
- Campaign A: ~2 days (216 sims × 6 hours)
- Campaign C: ~3 days (108 sims × extended domain)
- Campaign D: ~2 days (144 sims × extended runtime)

**Sequential total: 8-10 days**
**Parallel total: 3-4 days**

### Data Organization

```
/mnt/raid0/astra_simulations/supercritical/
├── campaign_a_turbulent_support/
│   ├── f1.5_beta0.5_M1.0_theta0_seed0/
│   └── ...
├── campaign_b_subisothermal_eos/
│   ├── f1.5_beta0.5_gamma0.7_theta0_seed0/
│   └── ...
├── campaign_c_hourglass_geometry/
│   ├── f1.5_beta0.5_rwaist0.3_seed0/
│   └── ...
└── campaign_d_sink_particles/
    ├── f1.5_beta0.5_theta0_seed0/
    └── ...
```

### Analysis Pipeline

After each campaign completes, run the analysis script:

```bash
python analysis/analyze_campaign_a.py
python analysis/analyze_campaign_b.py
python analysis/analyze_campaign_c.py
python analysis/analyze_campaign_d.py
```

Results will be written to `analysis/results/` with summary tables and plots.

### Success Criteria

**Positive Result:** Measurement of λ/W in supercritical regime (f ≥ 1.5) with:
- Campaign A: f_eff ≈ 1.0-1.3 from turbulent support
- Campaign B: Systematic γ-dependence in supercritical regime
- Campaign C: λ/W ≈ 2.0-3.0 from hourglass geometry
- Campaign D: Sink spacing matching HGBS PM (2.79 ± 0.09)

**Null Result:** All campaigns fail to measure λ/W → Confirms ideal MHD is insufficient, makes case for non-ideal MHD (ambipolar diffusion, Hall effect).

### Troubleshooting

**If simulations timeout:**
- Check `/var/log/ray/session_*/logs/` for worker errors
- Verify domain size matches specification
- Reduce concurrent jobs by 25% and retry

**If HDF5 snapshots are missing:**
- Verify output_interval in problem generator
- Check disk space: `df -h /mnt/raid0/astra_simulations/`

**If analysis fails:**
- Verify all simulations completed: `python analysis/check_completion.py`
- Check for corrupted HDF5 files: `h5ls -r <sim_path>/output/`

### Contact & Support

For issues with Ray deployment or Athena++ configurations, consult the ASTRA infrastructure documentation or the simulation team directly.

---

**Generated:** 2026-05-15
**Target Cluster:** astra-climate (220 vCPU Ray cluster)
**Total Simulations:** 660 (216 + 192 + 108 + 144)
