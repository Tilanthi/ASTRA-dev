#!/usr/bin/env python3
"""
TAURUS Campaign v2: Spatially Varying ISRF — the definitive test.

Sweeps ISRF gradient models x amplitudes x base temperatures x simulation
snapshots, running the full RT + M-T diagnostic suite on each combination.

Usage (on TAURUS with 220 CPUs):
  python run_campaign_v2.py --snapshots_dir /data/obl2_campaign/sims \
      --output campaign_v2_results.json --ncpu 220

Or specify individual snapshots:
  python run_campaign_v2.py --snapshots snap1.athdf snap2.athdf ... \
      --output campaign_v2_results.json --ncpu 220
"""
import argparse, json, glob, os, time, itertools
import numpy as np

# ISRF gradient models to test
ISRF_MODELS = ["uniform", "linear_x", "linear_y", "linear_z",
               "dipole", "two_faced", "ic5146"]

# Parameter grid
T_BASES = [12.0, 15.0]           # base ISRF temperature
DELTA_TS = [0.0, 2.0, 4.0, 6.0, 8.0, 12.0]  # gradient amplitude
KAPPAS = [0.1]                   # dust opacity (standard)
THRESHOLDS = [0.001]             # core extraction threshold
DIPOLE_DIRECTIONS = [(1,0,0), (0,1,0), (0,0,1), (1,1,0)]  # dipole model directions


def build_parameter_grid(snapshots):
    """Build the full parameter grid for the campaign."""
    grid = []
    for snap in snapshots:
        for model in ISRF_MODELS:
            if model == "dipole":
                # Dipole has multiple directions
                for direction in DIPOLE_DIRECTIONS:
                    for T_base in T_BASES:
                        for dT in DELTA_TS:
                            if dT == 0 and model != "uniform":
                                continue  # dT=0 is the uniform control
                            grid.append({
                                "snapshot": snap, "isrf_model": model,
                                "T_base": T_base, "dT": dT, "kappa": 0.1,
                                "direction": direction, "threshold": 0.001,
                            })
            else:
                for T_base in T_BASES:
                    for dT in DELTA_TS:
                        if dT == 0 and model != "uniform":
                            continue
                        grid.append({
                            "snapshot": snap, "isrf_model": model,
                            "T_base": T_base, "dT": dT, "kappa": 0.1,
                            "direction": (1,0,0), "threshold": 0.001,
                        })
    return grid


def run_sequential(grid, output_path):
    """Run the campaign serially (for small grids or testing)."""
    from rt_varying_isrf import process_snapshot
    from analyze_detailed import compare_to_observations
    results = []
    for i, params in enumerate(grid):
        try:
            r = process_snapshot(**params)
            r["run_name"] = f"{params['isrf_model']}_dT{params['dT']}_T{params['T_base']}"
            r["status"] = "ok"
            r["comparison"] = compare_to_observations(r)
            results.append(r)
        except Exception as e:
            results.append({"status": "error", "error": str(e), "params": params})
        if (i+1) % 50 == 0:
            print(f"  {i+1}/{len(grid)} done...")
    with open(output_path, 'w') as f:
        json.dump(results, f, indent=2)
    return results


def run_ray(grid, output_path, ncpu=220):
    """Run the campaign with Ray parallelism."""
    import ray
    from rt_varying_isrf import process_snapshot
    from analyze_detailed import compare_to_observations

    ray.init(num_cpus=ncpu, ignore_reinit_error=True)

    @ray.remote
    def run_one(params):
        try:
            r = process_snapshot(**params)
            r["run_name"] = f"{params['isrf_model']}_dT{params['dT']}_T{params['T_base']}"
            r["status"] = "ok"
            r["comparison"] = compare_to_observations(r)
            return r
        except Exception as e:
            return {"status": "error", "error": str(e), "params": str(params)}

    futures = [run_one.remote(p) for p in grid]
    results = ray.get(futures)
    ray.shutdown()

    with open(output_path, 'w') as f:
        json.dump(results, f, indent=2)
    return results


def main():
    parser = argparse.ArgumentParser(description="TAURUS Campaign v2: Varying ISRF")
    parser.add_argument("--snapshots_dir", default="/data/obl2_campaign/sims",
                        help="Directory containing simulation snapshots")
    parser.add_argument("--snapshots", nargs="*", default=None,
                        help="Explicit snapshot paths (overrides --snapshots_dir)")
    parser.add_argument("--output", default="campaign_v2_results.json")
    parser.add_argument("--ncpu", type=int, default=220)
    parser.add_argument("--no_ray", action="store_true", help="Serial mode")
    parser.add_argument("--max_snapshots", type=int, default=None,
                        help="Limit number of snapshots (for testing)")
    args = parser.parse_args()

    # Collect snapshots
    if args.snapshots:
        snapshots = args.snapshots
    else:
        snapshots = sorted(glob.glob(os.path.join(args.snapshots_dir,
            "**", "filament_frag.prim.*.athdf"), recursive=True))
    if args.max_snapshots:
        snapshots = snapshots[:args.max_snapshots]

    print(f"Ssnapshots: {len(snapshots)}")

    # Build parameter grid
    grid = build_parameter_grid(snapshots)
    print(f"Parameter combinations: {len(grid)}")
    print(f"  Models: {ISRF_MODELS}")
    print(f"  T_base: {T_BASES}, dT: {DELTA_TS}, kappa: {KAPPAS}")

    t0 = time.time()
    if args.no_ray:
        results = run_sequential(grid, args.output)
    else:
        results = run_ray(grid, args.output, args.ncpu)
    dt = time.time() - t0

    # Summary
    ok = [r for r in results if r.get("status") == "ok"]
    sig = [r for r in ok if r.get("spatial_variation_significant", False)]
    inv = [r for r in ok if r.get("has_inversion", False)]
    print(f"\n{'='*70}")
    print(f"CAMPAIGN COMPLETE: {len(results)} runs in {dt:.0f}s")
    print(f"  OK: {len(ok)}, Errors: {len(results)-len(ok)}")
    print(f"  Significant spatial variation (p<0.05): {len(sig)}")
    print(f"  M-T slope inversions detected: {len(inv)}")
    if sig:
        print(f"\n  SIGNIFICANT RUNS:")
        for r in sig[:10]:
            print(f"    {r['run_name']}: F={r['F']:.2f} p={r['p_value']:.4f} "
                  f"slope_range={r.get('slope_range',0):.1f} "
                  f"inversion={r.get('has_inversion',False)}")
    print(f"\nResults saved to {args.output}")


if __name__ == "__main__":
    main()
