#!/usr/bin/env python3
"""
RT post-processing with SPATIALLY VARYING ISRF.

Modified from rt_postprocess.py: T_isrf is now a 3D array (not a scalar),
computed from an ISRF gradient model. The dust temperature at each cell is:

  T_dust(x,y,z) = T_isrf(x,y,z) * exp(-tau_min(x,y,z) / 4)

where tau_min is the minimum optical depth to any domain boundary (6 directions).

This tests whether a spatially varying radiation field reproduces the observed
spatial M-T slope variation in IC5146 (F=6.78, p=0.002).
"""
import numpy as np
from isrf_models import MODELS


def read_athdf_density(athdf_path):
    """Read density from Athena++ athdf snapshot."""
    try:
        import sys; sys.path.insert(0, '.')
        from athena_read import ath
        return ath(athdf_path)['rho']
    except Exception:
        import h5py
        with h5py.File(athdf_path, 'r') as f:
            blocks = sorted(f.keys())
            rho_list = [f[b]['Tens_0']['rho'][:] for b in blocks if 'rho' in f[b].get('Tens_0',{})]
            if rho_list: return np.concatenate(rho_list, axis=0)
        raise RuntimeError("Cannot read athdf. Place athena_read.py in CWD.")


def compute_tau_min(rho, kappa):
    """Minimum optical depth to any of 6 domain boundaries."""
    cols = []
    for axis in range(3):
        for direction in [+1, -1]:
            col = np.cumsum(rho, axis=axis) if direction > 0 else np.cumsum(rho[::-1], axis=axis)[::-1]
            cols.append(kappa * col)
    return np.min(np.stack(cols, axis=0), axis=0)


def compute_T_dust_varying(rho, T_isrf_3d, kappa):
    """Compute dust temperature with spatially varying ISRF."""
    tau_min = compute_tau_min(rho, kappa)
    return T_isrf_3d * np.exp(-tau_min / 4.0)


def process_snapshot(athdf_path, isrf_model_name, T_base, dT, kappa,
                     direction=(1,0,0), threshold=0.001):
    """Full pipeline: read density -> compute T_dust -> extract cores -> analyse."""
    from analyze_detailed import extract_cores, mt_spatial_test_detailed
    
    rho = read_athdf_density(athdf_path)
    shape = rho.shape
    
    # Compute spatially varying ISRF
    model_fn = MODELS[isrf_model_name]
    T_isrf_3d = model_fn(shape, T_base=T_base, dT=dT, direction=direction)
    
    # Compute dust temperature
    T_dust = compute_T_dust_varying(rho, T_isrf_3d, kappa)
    
    # Extract cores and analyse
    cores = extract_cores(rho, T_dust, threshold_factor=threshold)
    result = mt_spatial_test_detailed(cores)
    
    result.update({
        "snapshot": athdf_path, "isrf_model": isrf_model_name,
        "T_base": T_base, "dT": dT, "kappa": kappa,
        "direction": list(direction), "n_cores": len(cores),
        "T_dust_min": float(np.min(T_dust)), "T_dust_max": float(np.max(T_dust)),
        "T_isrf_min": float(np.min(T_isrf_3d)), "T_isrf_max": float(np.max(T_isrf_3d)),
        "density_min": float(np.min(rho)), "density_max": float(np.max(rho)),
        "shape": list(shape),
    })
    return result
