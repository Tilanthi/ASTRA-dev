# TAURUS Campaign v2: Spatially Varying ISRF — The Definitive Test

## Science case

We detected (z=3.71 sigma, Fisher-combined IC5146 + Orion A) that the core
mass-temperature (M-T) relation varies SPATIALLY within active star-forming
clouds. Column density is falsified as the driver. The leading candidate is
the local interstellar radiation field (ISRF).

Campaign v1 (519 runs, uniform ISRF) confirmed:
  - The RT reproduces the GLOBAL M-T slope (-7.2 K/dex, matching observations).
  - T_isrf controls the slope steepness (12K -> -6, 15K -> -8, 20K -> -10 K/dex).
  - ZERO spatial variation with uniform ISRF (all F~0).

Campaign v2 tests the CRITICAL HYPOTHESIS: does a SPATIALLY VARYING ISRF
produce the observed spatial M-T slope variation?

## What this campaign does

For each combination of:
  - ISRF gradient model (7 types: uniform control, linear x/y/z, dipole,
    two-faced, IC5146-matched)
  - Gradient amplitude (dT = 0, 2, 4, 6, 8, 12 K)
  - Base temperature (T_base = 12, 15 K)
  - Dipole direction (4 options, for the dipole model)
  - Simulation snapshot (from the existing OBL2 + RCC campaigns)

The campaign:
  1. Reads the density snapshot.
  2. Computes a 3D ISRF field T_isrf(x,y,z) from the gradient model.
  3. Computes dust temperature: T_dust(x,y,z) = T_isrf(x,y,z) * exp(-tau_min/4).
  4. Extracts synthetic cores.
  5. Runs the FULL diagnostic suite:
     - F-test for spatial M-T variation
     - Per-quadrant M-T slopes (compare to IC5146: SW=-12.4, NW=+1.1)
     - Per-octant slopes
     - M-T slope INVERSION detection (positive slope in some regions)
     - Comparison to IC5146, Orion A, Taurus L1495

## How to run (on TAURUS, 220 CPUs, Ray)

```bash
# 1. Extract
tar xzf taurus_isrf_gradient_campaign.tar.gz
cd taurus_isrf_gradient_campaign

# 2. Ensure athena_read.py is in the working directory
cp /path/to/athena_read.py .

# 3. Run the full campaign
python run_campaign_v2.py \
    --snapshots_dir /data/obl2_campaign/sims \
    --output campaign_v2_results.json \
    --ncpu 220

# 4. Or run a subset for testing
python run_campaign_v2.py \
    --snapshots_dir /data/obl2_campaign/sims \
    --max_snapshots 5 \
    --output campaign_v2_test.json \
    --ncpu 220

# 5. Return the results
# Upload campaign_v2_results.json to:
# https://github.com/Tilanthi/ASTRA-dev/simulations/rt_postprocess_jul2026/
```

## Expected parameter space
- ~59 snapshots x 7 models x 6 amplitudes x 2 T_base + dipole variants
  = ~1000-1500 runs
- Each run: <1 second (RT + analysis)
- Total: ~10-30 minutes on 220 CPUs with Ray

## Key diagnostic: does the ISRF gradient produce spatial M-T variation?

The campaign will answer:
1. Does ANY ISRF gradient model produce F > 3 (matching IC5146)?
2. Which gradient model best matches the observed IC5146 pattern
   (quadrant slopes SW=-12.4, NW=+1.1)?
3. What gradient AMPLITUDE is needed? (dT = 2, 4, 6, 8, 12 K?)
4. Does the gradient produce M-T slope INVERSION (positive in some regions)?
5. Does the uniform control (dT=0) still give F~0 (validating the setup)?

## Data to return
Upload `campaign_v2_results.json` to the GitHub repo at:
  simulations/rt_postprocess_jul2026/campaign_v2_results.json

This file will contain the full diagnostic suite for every parameter combination.
