"""
ISRF gradient models for spatially varying dust-temperature post-processing.

Each model returns T_isrf(x, y, z) — the unattenuated ISRF dust temperature
at each position in the simulation domain (normalised to [-1, 1] per axis).

Models:
  uniform    — constant T_isrf everywhere (CONTROL; should reproduce F~0).
  linear_x   — gradient along filament axis (longitudinal).
  linear_y   — gradient transverse in-plane (matches IC5146 observed direction).
  linear_z   — gradient transverse out-of-plane.
  dipole     — point-source ISRF from a specific direction (OB association).
  two_faced  — asymmetric: warm on +face, cold on -face (sharp gradient).
  ic5146     — IC5146-matched: y-gradient with observed amplitude (~6 K).
"""
import numpy as np


def uniform(shape, T_base=15.0, dT=0.0, **kw):
    """Control: uniform ISRF."""
    return np.full(shape, T_base)


def linear_x(shape, T_base=15.0, dT=6.0, **kw):
    """Linear gradient along x (filament axis): T_base on -x, T_base+dT on +x."""
    nx = shape[0]
    t = np.linspace(0, 1, nx).reshape(-1, 1, 1)
    return T_base + dT * t * np.ones(shape)


def linear_y(shape, T_base=15.0, dT=6.0, **kw):
    """Linear gradient along y (transverse, IC5146 direction)."""
    ny = shape[1]
    t = np.linspace(0, 1, ny).reshape(1, -1, 1)
    return T_base + dT * t * np.ones(shape)


def linear_z(shape, T_base=15.0, dT=6.0, **kw):
    """Linear gradient along z (transverse out-of-plane)."""
    nz = shape[2]
    t = np.linspace(0, 1, nz).reshape(1, 1, -1)
    return T_base + dT * t * np.ones(shape)


def dipole(shape, T_base=12.0, dT=8.0, direction=(1, 0, 0), **kw):
    """Point-source ISRF: T_peak toward `direction`, T_base away."""
    nx, ny, nz = shape
    x = np.linspace(-1, 1, nx).reshape(-1, 1, 1)
    y = np.linspace(-1, 1, ny).reshape(1, -1, 1)
    z = np.linspace(-1, 1, nz).reshape(1, 1, -1)
    d = np.array(direction, dtype=float)
    d /= max(np.linalg.norm(d), 1e-10)
    cos_angle = (x*d[0] + y*d[1] + z*d[2])
    cos_angle = np.clip(cos_angle, -1, 1)
    # Smooth transition: T = T_base + dT * (cos_angle + 1) / 2
    return T_base + dT * (cos_angle + 1.0) / 2.0 * np.ones(shape)


def two_faced(shape, T_base=15.0, dT=8.0, axis=1, **kw):
    """Sharp gradient: T_base+dT on +axis face, T_base on -axis face."""
    result = np.full(shape, T_base)
    slc = [slice(None)] * 3
    slc[axis] = slice(shape[axis] // 2, None)
    result[tuple(slc)] = T_base + dT
    return result


def ic5146(shape, T_base=12.0, dT=6.0, **kw):
    """IC5146-matched: y-gradient (observed variation direction) with ~6 K amplitude.
    Models the OB association heating one side of the cloud."""
    return linear_y(shape, T_base=T_base, dT=dT)


MODELS = {
    "uniform": uniform,
    "linear_x": linear_x,
    "linear_y": linear_y,
    "linear_z": linear_z,
    "dipole": dipole,
    "two_faced": two_faced,
    "ic5146": ic5146,
}
