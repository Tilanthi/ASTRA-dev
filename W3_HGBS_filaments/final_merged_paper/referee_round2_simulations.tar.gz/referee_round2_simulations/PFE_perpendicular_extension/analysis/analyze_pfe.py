#!/usr/bin/env python3
"""
Campaign PFE: Perpendicular Field Extension Analysis
Analyzes simulation outputs to test whether perpendicular-field geometry
can match HGBS observations.
"""

import numpy as np
import h5py
import matplotlib.pyplot as plt
from pathlib import Path
import pandas as pd
from scipy.optimize import curve_fit
from scipy.signal import find_peaks
import warnings
warnings.filterwarnings('ignore')

# ============================================================================
# CONFIGURATION
# ============================================================================
CAMPAIGN_DIR = Path("/path/to/workdir/PFE_perpendicular_extension")
OUTPUT_DIR = CAMPAIGN_DIR / "runs"
ANALYSIS_DIR = CAMPAIGN_DIR / "analysis"
RESULTS_DIR = ANALYSIS_DIR / "results"
FIGURES_DIR = ANALYSIS_DIR / "figures"

# Create directories
RESULTS_DIR.mkdir(exist_ok=True, parents=True)
FIGURES_DIR.mkdir(exist_ok=True, parents=True)

# Simulation parameters
F_VALUES = [1.5, 2.0, 2.5, 3.0]
BETA_VALUES = [0.3, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0]
THETA_VALUES = [60, 75, 90]
SEEDS = [0]

# HGBS reference value
HGBS_LAMBDA_W = 2.8

# ============================================================================
# LAMBDA/W MEASUREMENT
# ============================================================================

def measure_lambda_W(sim_id, theta):
    """
    Measure fragmentation spacing λ/W from simulation output.

    For inclined fields, extract axial profile and perform Fourier analysis.
    """
    output_path = OUTPUT_DIR / sim_id

    # Read HDF5 snapshots
    hdf5_files = sorted(output_path.glob("*.hdf5"))

    for snapshot in hdf5_files:
        try:
            with h5py.File(snapshot, 'r') as hf:
                t = hf['Attributes'].get('Time', 0.0)
                rho = hf['dens'][:]

                # Extract axial profile (average over transverse dimensions)
                rho_axial = rho.mean(axis=(1, 2))

                # Fourier analysis to find dominant wavelength
                power_spectrum = np.abs(np.fft.rfft(rho_axial))**2
                k = np.fft.rfftfreq(len(rho_axial))

                # Find peak in power spectrum (exclude k=0)
                if len(power_spectrum[1:]) > 0:
                    k_peak_idx = np.argmax(power_spectrum[1:]) + 1
                    k_peak = k[k_peak_idx]

                    if k_peak > 0:
                        lambda_peak = 1.0 / k_peak

                        # Measure width from radial profile
                        rho_radial = rho.mean(axis=(0, 2))
                        rho_center = rho_radial.max()
                        half_max = rho_center / 2.0

                        # FWHM
                        half_max_indices = np.where(rho_radial >= half_max)[0]
                        if len(half_max_indices) > 0:
                            W = half_max_indices[-1] - half_max_indices[0]
                            lambda_W = lambda_peak / (W + 1e-10)

                            # Check for reasonable values
                            if 0.5 < lambda_W < 10.0:
                                return lambda_W, t

        except Exception as e:
            continue

    return None, None

# ============================================================================
# FRAGMENTATION CLASSIFICATION
# ============================================================================

def classify_fragmentation(sim_id):
    """
    Classify fragmentation as LONGITUDINAL, RADIAL, or STABLE.
    """
    output_path = OUTPUT_DIR / sim_id

    # Read HDF5 snapshots
    hdf5_files = sorted(output_path.glob("*.hdf5"))

    if len(hdf5_files) == 0:
        return "NO_DATA", None

    for snapshot in hdf5_files:
        try:
            with h5py.File(snapshot, 'r') as hf:
                t = hf['Attributes'].get('Time', 0.0)
                rho = hf['dens'][:]

                # Compute axial variance
                rho_axial = rho.mean(axis=(1, 2))
                axial_var = rho_axial.var() / (rho_axial.mean()**2 + 1e-10)

                # Detect peaks
                peaks, properties = find_peaks(rho_axial, prominence=0.1)
                peak_count = len(peaks)

                # Peak-to-trough contrast
                if len(peaks) >= 2:
                    peak_val = rho_axial[peaks].max()
                    trough_val = rho_axial.min()
                    contrast = (peak_val - trough_val) / (peak_val + trough_val + 1e-10)
                else:
                    contrast = 0.0

                # Classify
                if axial_var > 0.02 and peak_count >= 2 and contrast > 0.5:
                    return "LONGITUDINAL", t
                elif axial_var < 0.02 and contrast < 0.5:
                    return "RADIAL", t

        except Exception as e:
            continue

    return "STABLE", None

# ============================================================================
# GEOMETRY EFFECT QUANTIFICATION
# ============================================================================

def quantify_geometry_effect():
    """
    Quantify the geometry effect: λ/W(θ) for fixed (f, β).
    """
    results = []

    for f in F_VALUES:
        for beta in BETA_VALUES:
            for theta in THETA_VALUES:
                sim_id = f"pfe_f{f}_beta{beta}_theta{theta}_seed0"

                classification, t_frag = classify_fragmentation(sim_id)
                lambda_W, t_measured = measure_lambda_W(sim_id, theta)

                results.append({
                    'sim_id': sim_id,
                    'f': f,
                    'beta': beta,
                    'theta': theta,
                    'classification': classification,
                    't_frag': t_frag,
                    'lambda_W': lambda_W
                })

    return pd.DataFrame(results)

# ============================================================================
# HGBS MATCHING TEST
# ============================================================================

def test_HGBS_matching(results_df):
    """
    Test whether any (θ, f, β) combination yields λ/W ≈ 2.8 (HGBS value).
    """
    matches = []

    for _, row in results_df.iterrows():
        if row['lambda_W'] is not None:
            if abs(row['lambda_W'] - HGBS_LAMBDA_W) < 0.3:  # Within 10%
                matches.append(row)

    return pd.DataFrame(matches)

# ============================================================================
# FIGURE GENERATION
# ============================================================================

def generate_figures(results_df):
    """Generate publication-ready figures."""

    # Figure PFE-1: λ/W vs θ for all (f, β) combinations
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    axes = axes.flatten()

    plot_idx = 0
    for f in F_VALUES:
        ax = axes[plot_idx]

        for beta in [0.5, 1.0, 2.0, 5.0]:
            if beta in BETA_VALUES:
                subset = results_df[
                    (results_df['f'] == f) &
                    (results_df['beta'] == beta) &
                    (results_df['lambda_W'].notna())
                ]

                if len(subset) > 0:
                    ax.plot(subset['theta'], subset['lambda_W'],
                           'o-', label=f'β = {beta}',
                           markersize=8, linewidth=2)

        ax.axhline(y=HGBS_LAMBDA_W, color='black', linestyle='--',
                  linewidth=2, label=f'HGBS ({HGBS_LAMBDA_W})')
        ax.set_xlabel('Field angle θ (degrees)')
        ax.set_ylabel('λ/W')
        ax.set_title(f'Geometry Effect at f = {f}')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_xlim(55, 95)
        ax.set_ylim(0, 5)

        plot_idx += 1

    fig.savefig(FIGURES_DIR / 'PFE-1_geometry_effect.pdf',
                dpi=300, bbox_inches='tight')
    plt.close()

    # Figure PFE-2: λ/W heatmap in (θ, β) plane
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    axes = axes.flatten()

    plot_idx = 0
    for f in F_VALUES:
        ax = axes[plot_idx]

        # Create heatmap data
        theta_grid, beta_grid = np.meshgrid(THETA_VALUES, BETA_VALUES)
        lambda_W_grid = np.full_like(theta_grid.astype(float), np.nan)

        for i, beta in enumerate(BETA_VALUES):
            for j, theta in enumerate(THETA_VALUES):
                subset = results_df[
                    (results_df['f'] == f) &
                    (results_df['beta'] == beta) &
                    (results_df['theta'] == theta)
                ]

                if len(subset) > 0 and subset['lambda_W'].notna().any():
                    lambda_W_grid[i, j] = subset['lambda_W'].values[0]

        # Heatmap
        im = ax.pcolormesh(theta_grid, beta_grid, lambda_W_grid,
                          cmap='RdYlBu', vmin=0.5, vmax=5.0, shading='auto')
        ax.axhline(y=HGBS_LAMBDA_W, color='black', linestyle='--',
                  linewidth=2, label=f'HGBS ({HGBS_LAMBDA_W})')
        ax.set_xlabel('Field angle θ (degrees)')
        ax.set_ylabel('Plasma beta β')
        ax.set_title(f'λ/W at f = {f}')
        ax.invert_xaxis()  # Stronger B (lower β) on left
        plt.colorbar(im, ax=ax, label='λ/W')

        plot_idx += 1

    fig.savefig(FIGURES_DIR / 'PFE-2_lambdaW_heatmap.pdf',
                dpi=300, bbox_inches='tight')
    plt.close()

    # Figure PFE-3: Geometry effect size quantification
    fig, ax = plt.subplots(figsize=(10, 8))

    # Compute geometry effect size for each (f, β)
    geometry_effects = []

    for f in F_VALUES:
        for beta in BETA_VALUES:
            subset = results_df[
                (results_df['f'] == f) &
                (results_df['beta'] == beta) &
                (results_df['lambda_W'].notna())
            ]

            if len(subset) >= 2:
                theta_min = subset['theta'].min()
                theta_max = subset['theta'].max()
                lambda_W_min = subset[subset['theta'] == theta_min]['lambda_W'].values[0]
                lambda_W_max = subset[subset['theta'] == theta_max]['lambda_W'].values[0]

                effect_size = abs(lambda_W_max - lambda_W_min) / lambda_W_min
                geometry_effects.append({
                    'f': f,
                    'beta': beta,
                    'effect_size': effect_size
                })

    if geometry_effects:
        effect_df = pd.DataFrame(geometry_effects)

        for f in F_VALUES:
            subset = effect_df[effect_df['f'] == f]
            ax.plot(subset['beta'], subset['effect_size'],
                   'o-', label=f'f = {f}',
                   markersize=8, linewidth=2)

        ax.set_xlabel('Plasma beta β')
        ax.set_ylabel('Geometry effect size')
        ax.set_title('Geometry Effect Size: |λ_W(90°) - λ_W(60°)| / λ_W(60°)')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.invert_xaxis()

    fig.savefig(FIGURES_DIR / 'PFE-3_geometry_effect_size.pdf',
                dpi=300, bbox_inches='tight')
    plt.close()

    print("Figures generated successfully")

# ============================================================================
# MAIN ANALYSIS
# ============================================================================

def main():
    """Run complete PFE analysis."""
    print("=" * 60)
    print("Campaign PFE: Perpendicular Field Extension Analysis")
    print("=" * 60)

    # Quantify geometry effect
    print("\n1. Quantifying geometry effect...")
    results_df = quantify_geometry_effect()

    results_df.to_csv(RESULTS_DIR / 'PFE_all_measurements.csv', index=False)

    print(f"   Measured {len(results_df)} simulations")
    print(f"   Valid λ/W measurements: {len(results_df[results_df['lambda_W'].notna()])}")

    # Test HGBS matching
    print("\n2. Testing HGBS matching (λ/W ≈ 2.8)...")
    matches_df = test_HGBS_matching(results_df)

    if len(matches_df) > 0:
        print(f"   Found {len(matches_df)} matches within 10% of HGBS value:")
        print(matches_df[['f', 'beta', 'theta', 'lambda_W']].to_string(index=False))
    else:
        print("   ❌ NO matches found")
        print("   Perpendicular-field geometry CANNOT explain HGBS observations")

    # Generate figures
    print("\n3. Generating figures...")
    generate_figures(results_df)

    # Generate summary report
    print("\n4. Generating summary report...")
    generate_summary_report(results_df, matches_df)

    print("\n" + "=" * 60)
    print("Analysis complete!")
    print("=" * 60)

def generate_summary_report(results_df, matches_df):
    """Generate text summary report."""
    report_path = RESULTS_DIR / 'PFE_analysis_report.txt'

    with open(report_path, 'w') as f:
        f.write("CAMPAIGN PFE: PERPENDICULAR FIELD EXTENSION REPORT\n")
        f.write("=" * 60 + "\n\n")

        f.write("HGBS MATCHING TEST\n")
        f.write("-" * 40 + "\n")
        f.write(f"HGBS reference value: λ/W = {HGBS_LAMBDA_W}\n")
        f.write(f"Tolerance: ±0.3 (±10%)\n\n")

        if len(matches_df) > 0:
            f.write(f"✅ FOUND {len(matches_df)} MATCHES:\n\n")
            f.write(matches_df[['f', 'beta', 'theta', 'lambda_W']].to_string(index=False))
            f.write("\n\nCONCLUSION: Perpendicular-field geometry CAN match HGBS observations\n")
            f.write(f"at specific parameters: θ ≈ {matches_df['theta'].median():.0f}°, ")
            f.write(f"β ≈ {matches_df['beta'].median():.1f}\n")
        else:
            f.write("❌ NO MATCHES FOUND\n\n")
            f.write("No tested (θ, f, β) combination yields λ/W ≈ 2.8\n\n")

            # Report closest matches
            valid_data = results_df[results_df['lambda_W'].notna()]
            if len(valid_data) > 0:
                valid_data['diff'] = abs(valid_data['lambda_W'] - HGBS_LAMBDA_W)
                closest = valid_data.nsmallest(5, 'diff')

                f.write("Closest approaches:\n")
                f.write(closest[['f', 'beta', 'theta', 'lambda_W', 'diff']].to_string(index=False))

            f.write("\n\nCONCLUSION: Perpendicular-field geometry CANNOT explain HGBS observations\n")
            f.write("The discrepancy is WORSE than with longitudinal-field theory.\n")
            f.write("This supports alternative explanations (hierarchical, etc.).\n")

        f.write("\n\nGEOMETRY EFFECT SIZE\n")
        f.write("-" * 40 + "\n")

        # Compute average geometry effect
        geometry_effects = []
        for f in F_VALUES:
            for beta in BETA_VALUES:
                subset = results_df[
                    (results_df['f'] == f) &
                    (results_df['beta'] == beta) &
                    (results_df['lambda_W'].notna())
                ]

                if len(subset) >= 2:
                    theta_min = subset['theta'].min()
                    theta_max = subset['theta'].max()
                    lambda_W_min = subset[subset['theta'] == theta_min]['lambda_W'].values[0]
                    lambda_W_max = subset[subset['theta'] == theta_max]['lambda_W'].values[0]

                    effect_size = abs(lambda_W_max - lambda_W_min) / (lambda_W_min + 1e-10)
                    geometry_effects.append(effect_size)

        if geometry_effects:
            mean_effect = np.mean(geometry_effects)
            std_effect = np.std(geometry_effects)

            f.write(f"Mean geometry effect size: {mean_effect:.2f} ± {std_effect:.2f}\n")
            f.write(f"This represents a {mean_effect*100:.0f}% change in λ/W\n")
            f.write("from θ = 60° to θ = 90°\n")

            if mean_effect > 0.5:
                f.write("\nGeometry is a FIRST-ORDER parameter for λ/W\n")
            else:
                f.write("\nGeometry has MODERATE effect on λ/W\n")

        f.write("\n\nIMPLICATIONS FOR REFEREE CONCERN #4\n")
        f.write("-" * 40 + "\n")
        f.write("Referee: 'Perpendicular-field result transforms the problem'\n")
        f.write("but is 'underemphasized' in the paper.\n\n")

        if len(matches_df) == 0:
            f.write("This analysis CONFIRMS the referee's assessment:\n")
            f.write("  - Perpendicular fields give λ/W ≈ 1.25 (Campaign 6)\n")
            f.write("  - Extended campaign finds NO matches to HGBS (λ/W ≈ 2.8)\n")
            f.write("  - The discrepancy is LARGER than with longitudinal theory\n")
            f.write("  - This genuinely IS a 'transformed problem'\n\n")
            f.write("RECOMMENDATION: Emphasize this result in abstract and conclusions\n")
        else:
            f.write("Extended campaign finds specific parameter matches:\n")
            f.write("  - This PARTIALLY resolves the transformed problem\n")
            f.write("  - But requires fine-tuned (θ, f, β) combinations\n")
            f.write("  - Statistical significance requires broader parameter study\n")

    print(f"Report saved to {report_path}")

if __name__ == "__main__":
    main()
