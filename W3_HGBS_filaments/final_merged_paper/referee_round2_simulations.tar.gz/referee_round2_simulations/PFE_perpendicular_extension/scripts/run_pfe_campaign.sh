#!/bin/bash

###############################################################################
# Campaign PFE: Perpendicular Field Extension - Run Script
# Purpose: Test whether perpendicular-field geometry can match HGBS observations
###############################################################################

# ===== USER CONFIGURATION =====
ATHENA_ROOT="/path/to/athena++"  # UPDATE THIS PATH
WORK_DIR="/path/to/workdir"       # UPDATE THIS PATH

# ===== CAMPAIGN PARAMETERS =====
F_VALUES=(1.5 2.0 2.5 3.0)                   # Line-mass ratios
BETA_VALUES=(0.3 0.5 1.0 1.5 2.0 3.0 5.0)    # Plasma beta values
THETA_VALUES=(60 75 90)                      # Field angles (degrees)
SEEDS=(0)                                     # Single seed (pilot study)

# ===== RUN PARAMETERS =====
NCORES=200                                   # MPI cores per simulation
SIMS_PER_BATCH=15                            # Parallel simulations
WALLCLOCK_LIMIT=3600                         # 1 hour per simulation

# ===== DIRECTORIES =====
CAMPAIGN_DIR="${WORK_DIR}/PFE_perpendicular_extension"
CONFIG_DIR="${CAMPAIGN_DIR}/configs"
RUN_DIR="${CAMPAIGN_DIR}/runs"
LOG_DIR="${CAMPAIGN_DIR}/logs"
mkdir -p "${RUN_DIR}" "${LOG_DIR}"

# ===== ATHENA++ EXECUTABLE =====
ATHENA_EXE="${ATHENA_ROOT}/bin/athena"

# ===== FUNCTION: Run single simulation =====
run_simulation() {
    local f=$1
    local beta=$2
    local theta=$3
    local seed=$4

    # Compute magnetic field strength from plasma beta
    local b_field=$(python3 -c "import numpy as np; print(f'{np.sqrt(8.0 * np.pi / beta):.6f}')")

    # Create simulation ID
    local sim_id="pfe_f${f}_beta${beta}_theta${theta}_seed${seed}"

    # Create output directory
    local output_dir="${RUN_DIR}/${sim_id}"
    mkdir -p "${output_dir}"

    # Copy and modify config file
    local config_file="${CONFIG_DIR}/athinput.pfe_${sim_id}"

    sed "s|# <-OUTPUT-> output directory = /path/to/workdir|# <-OUTPUT-> output directory = ${output_dir}|g" \
        "${CONFIG_DIR}/athinput.pfe_template" > "${config_file}"

    sed -i.bak "s|# <-MHD> b_initial = 1.0|# <-MHD> b_initial = ${b_field}|g" "${config_file}"
    sed -i.bak "s|# <-MHD> b_initial_angle = 90.0|# <-MHD> b_initial_angle = ${theta}.0|g" "${config_file}"
    sed -i.bak "s|# <-PROBLEM-> fil_mass = 2.0|# <-PROBLEM-> fil_mass = ${f}|g" "${config_file}"
    sed -i.bak "s|# <-PROBLEM-> fil_perturb_seed = 0|# <-PROBLEM-> fil_perturb_seed = ${seed}|g" "${config_file}"

    rm -f "${config_file}.bak"

    # Log file
    local log_file="${LOG_DIR}/${sim_id}.log"

    echo "Starting simulation: ${sim_id}"
    echo "Parameters: f=${f}, beta=${beta}, theta=${theta}°, seed=${seed}"
    echo "B-field: ${b_field}"

    # Run simulation
    mpirun -np ${NCORES} ${ATHENA_EXE} -i "${config_file}" > "${log_file}" 2>&1

    if [ $? -eq 0 ]; then
        echo "Simulation completed: ${sim_id}"
        echo "${sim_id}" >> "${CAMPAIGN_DIR}/completed_sims.txt"
    else
        echo "Simulation FAILED: ${sim_id}"
        echo "${sim_id}" >> "${CAMPAIGN_DIR}/failed_sims.txt"
    fi

    rm -f "${config_file}"
}

# ===== FUNCTION: Run batch of simulations =====
run_batch() {
    local batch_id=$1
    shift
    local sim_params=("$@")

    echo "Starting batch ${batch_id} with ${#sim_params[@]} simulations"

    for params in "${sim_params[@]}"; do
        IFS=',' read -r f beta theta seed <<< "${params}"
        run_simulation "${f}" "${beta}" "${theta}" "${seed}" &

        if [[ $(jobs -r | wc -l) -ge ${SIMS_PER_BATCH} ]]; then
            wait -n
        fi
    done

    wait
    echo "Batch ${batch_id} completed"
}

# ===== MAIN EXECUTION =====

if [ ! -f "${ATHENA_EXE}" ]; then
    echo "ERROR: Athena++ executable not found at ${ATHENA_EXE}"
    exit 1
fi

MODE=${1:-run}

case "${MODE}" in
    test)
        echo "Running test simulation..."
        run_simulation 2.0 1.0 90 0
        ;;

    run)
        echo "Starting full campaign: ${#F_VALUES[@]} x ${#BETA_VALUES[@]} x ${#THETA_VALUES[@]} simulations"
        echo "Total simulations: $((${#F_VALUES[@]} * ${#BETA_VALUES[@]} * ${#THETA_VALUES[@]}))"

        > "${CAMPAIGN_DIR}/completed_sims.txt"
        > "${CAMPAIGN_DIR}/failed_sims.txt"

        all_sims=()
        for f in "${F_VALUES[@]}"; do
            for beta in "${BETA_VALUES[@]}"; do
                for theta in "${THETA_VALUES[@]}"; do
                    for seed in "${SEEDS[@]}"; do
                        all_sims+=("${f},${beta},${theta},${seed}")
                    done
                done
            done
        done

        batch_id=0
        for ((i=0; i<${#all_sims[@]}; i+=SIMS_PER_BATCH)); do
            batch=("${all_sims[@]:i:SIMS_PER_BATCH}")
            run_batch "${batch_id}" "${batch[@]}"
            ((batch_id++))
        done

        echo "Campaign completed!"
        echo "Completed: $(wc -l < ${CAMPAIGN_DIR}/completed_sims.txt)"
        echo "Failed: $(wc -l < ${CAMPAIGN_DIR}/failed_sims.txt)"
        ;;

    restart)
        echo "Restarting failed simulations..."
        if [ ! -f "${CAMPAIGN_DIR}/failed_sims.txt" ]; then
            echo "No failed simulations found"
            exit 0
        fi

        failed_sims=($(cat "${CAMPAIGN_DIR}/failed_sims.txt"))
        for sim_id in "${failed_sims[@]}"; do
            if [[ ${sim_id} =~ pfe_f([0-9.]+)_beta([0-9.]+)_theta([0-9]+)_seed([0-9]+) ]]; then
                f="${BASH_REMATCH[1]}"
                beta="${BASH_REMATCH[2]}"
                theta="${BASH_REMATCH[3]}"
                seed="${BASH_REMATCH[4]}"
                run_simulation "${f}" "${beta}" "${theta}" "${seed}"
            fi
        done
        ;;

    *)
        echo "Usage: $0 {test|run|restart}"
        exit 1
        ;;
esac

echo "Done!"
