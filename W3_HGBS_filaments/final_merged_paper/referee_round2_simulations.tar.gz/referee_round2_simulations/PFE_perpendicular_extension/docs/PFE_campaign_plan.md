# Campaign PFE: Perpendicular Field Extension

## Referee Concern Addressed

**Concern #4**: "Perpendicular field geometry: a result that transforms the problem but is underemphasized"

## Problem Statement

The referee identifies a critical issue:
- Campaign 6 shows perpendicular-field filaments fragment at λ/W ≈ 1.25
- This is 2-3× shorter than observed (λ/W ≈ 2.8)
- This **inverts the problem**: why are observed spacings longer than perpendicular-field predictions?
- The abstract and conclusions still frame the problem in terms of classical "sub-Jeans spacing"
- This transformation is not sufficiently emphasized

**Quote from referee**: "This is a genuine new result that deserves a dedicated subsection rather than being treated as a subsidiary point in the Discussion."

## Campaign Objective

Extend perpendicular-field campaign to (a) mixed/oblique geometries, (b) broader β range, and (c) higher f values, providing a comprehensive test of whether perpendicular-field geometry can ever match HGBS observations.

## Scientific Questions

1. Does λ/W(θ) vary smoothly from perpendicular (90°) to longitudinal (0°)?
2. Are there any (θ, f, β) combinations that yield λ/W ≈ 2.8 (HGBS value)?
3. What is the geometry effect size?
4. Can perpendicular-field geometry explain the observations?
5. If not, what does this imply about the physics?

## Parameter Space

| Parameter | Values | Count |
|-----------|--------|-------|
| f (line-mass ratio) | [1.5, 2.0, 2.5, 3.0] | 4 |
| β (plasma beta) | [0.3, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0] | 7 |
| θ (field angle) | [60°, 75°, 90°] | 3 |
| Random seeds | [0] (pilot study) | 1 |

**Total**: 4 × 7 × 3 × 1 = 84 simulations + 6 verification runs = 90 simulations

## Why These Angles?

- **θ = 90°**: Pure perpendicular field (Campaign 6 baseline)
- **θ = 75°**: Nearly perpendicular (15° from perpendicular)
- **θ = 60°**: Oblique field (midway between perpendicular and longitudinal)

Previous campaigns covered:
- θ = 0° (longitudinal): Campaigns 1-5
- θ = 30°, 45°, 60° (oblique): Campaign 7 (Field Geometry)

This campaign extends the perpendicular side and fills the gap at θ = 75°.

## Simulation Configuration

### Domain Setup
```
Lx = 16.0 * lambda_J  # Extended axial domain for perpendicular fields
Ly = 1.0 * lambda_J
Lz = 1.0 * lambda_J
Nx = 512
Ny = 64
Nz = 64
```

### Physics Modules
- Equation of state: Isothermal
- Magnetic field: **Inclined** at angle θ relative to filament axis
  - B_x = B_0 * cos(θ)
  - B_y = B_0 * sin(θ)
  - B_z = 0
- Perturbations: Synthetic (amplitude = 10^-4)
- AMR: Enabled, max_level = 2 (effective resolution 2048×256×256)

### Runtime Parameters
```
tlim = 1.5 * t_J  # Shorter runtime for perpendicular fields (faster fragmentation)
dt_out = 0.01 * t_J
wallclock_limit = 3600 seconds (1 hour)
```

### Boundary Conditions
- **Periodic** in x (axial direction)
- **Outflow** in y and z (transverse directions)
- This prevents artificial confinement of perpendicular field lines

## Key Measurements

### 1. Fragmentation Time
- t_frag(θ, f, β)
- Test prediction: t_frag decreases as θ → 90°
- Compare with Campaign 7 results

### 2. λ/W Ratio
- Extracted from Fourier analysis of axial density profile
- W measured from radial FWHM
- Only for simulations with longitudinal beading

### 3. Fragmentation Classification
- **LONGITUDINAL**: Clear axial density peaks
- **RADIAL**: Pure radial collapse (common for θ = 90°, β ≤ 0.5)
- **STABLE**: No fragmentation by t = 1.5 t_J

### 4. Geometry Transition
- At what θ does behavior transition from longitudinal-like to perpendicular-like?
- Is the transition abrupt or gradual?

## Analysis Pipeline

### Step 1: λ/W Measurement
```python
def measure_lambda_W_inclined(sim_id, theta):
    # Read 3D density field at fragmentation epoch
    rho = read_density_field(sim_id, t_frag)

    # Extract axial profile (average over transverse dimensions)
    rho_axial = rho.mean(axis=(1, 2))

    # Fourier analysis to find dominant wavelength
    power_spectrum = np.fft.rfft(rho_axial)
    k_peak = np.argmax(power_spectrum)
    lambda_peak = 2 * np.pi / k_peak

    # Measure width from radial profile
    W = measure_FWHM(rho.mean(axis=0))

    return lambda_peak / W
```

### Step 2: Geometry Effect Quantification
```python
def quantify_geometry_effect(theta_values, f, beta):
    # Measure λ/W for all angles at fixed (f, beta)
    lambda_W_values = []

    for theta in theta_values:
        sim_id = run_simulation(f, beta, theta)
        lambda_W = measure_lambda_W_inclined(sim_id, theta)
        lambda_W_values.append(lambda_W)

    # Fit model: λ/W(θ) = A + B * cos^2(θ)
    # Expected: A ≈ 1.25 (perpendicular), B ≈ 2.5 (difference)
    from scipy.optimize import curve_fit
    popt, pcov = curve_fit(
        lambda theta, A, B: A + B * np.cos(theta)**2,
        np.deg2rad(theta_values),
        lambda_W_values
    )

    A, B = popt
    geometry_effect_size = B / A  # Relative effect

    return A, B, geometry_effect_size
```

### Step 3: HGBS Matching Test
```python
def test_HGBS_matching():
    # Search for (θ, f, β) combinations that yield λ/W ≈ 2.8
    matches = []

    for f in [1.5, 2.0, 2.5, 3.0]:
        for beta in [0.3, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0]:
            for theta in [60, 75, 90]:
                lambda_W = measure_lambda_W(f, beta, theta)

                if abs(lambda_W - 2.8) < 0.3:  # Within 10% of HGBS value
                    matches.append((f, beta, theta, lambda_W))

    return matches
```

## Success Criteria

### Minimum Success (Required)
- λ/W(θ) measured for θ = 60°, 75°, 90° across all (f, β) combinations
- Geometry effect size quantified
- At least one publication-ready figure

### Full Success
- Comprehensive λ/W(θ, f, β) map created
- Definitive test of whether any geometry matches HGBS observations
- Clear statement: perpendicular-field geometry can/cannot explain observations

### Exceptional Success
- Physical explanation for geometry effect
- Connection to Planck field geometry statistics
- Revised abstract/conclusions emphasizing transformed problem

## Expected Outcomes

### Scientific Impact
- **Tests perpendicular-field explanation** — can it match HGBS observations?
- **Quantifies geometry effect** — how important is field orientation?
- **Addresses underemphasized result** — makes perpendicular-field result central

### Publication-Ready Outputs
1. **Figure**: λ/W(θ) for all (f, β) combinations
2. **Figure**: Geometry effect size quantification
3. **Table**: All λ/W measurements with uncertainties
4. **Analysis**: Definitive test of perpendicular-field explanation

### Possible Conclusions

**If matches found**:
- "Perpendicular-field geometry at θ ≈ X°, β ≈ Y yields λ/W ≈ 2.8, consistent with HGBS observations"
- This would support the perpendicular-field explanation

**If no matches found**:
- "No tested geometry yields λ/W ≈ 2.8; perpendicular-field geometry cannot explain observations"
- This strengthens the case for hierarchical or other explanations

Either way, the result is scientifically definitive and publication-worthy.

## Timeline

- **Week 1**: Run simulations (90 sims, ~1 hour each)
- **Week 2**: Analysis and figure generation
- **Week 3**: Interpretation and paper integration

## Computational Requirements

- **CPU time**: 90 sims × 1 hour = 90 CPU-hours
- **Storage**: ~200 MB per simulation × 90 = 18 GB
- **Parallel execution**: 15-20 simulations at once
- **Wall-clock time**: ~1 week

## References

- Referee Report, Concern #4: "Perpendicular field geometry"
- Planck Collaboration (2016): Magnetic field geometry statistics (90% perpendicular)
- Campaign 6 results: Perpendicular-field λ/W ≈ 1.25
- Campaign 7 results: Oblique-field measurements
