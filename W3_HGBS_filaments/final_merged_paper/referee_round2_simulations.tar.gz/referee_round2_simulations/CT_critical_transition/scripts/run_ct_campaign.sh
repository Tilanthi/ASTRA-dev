#!/bin/bash

###############################################################################
# Campaign CT: Critical Transition Mapping - Run Script
# Purpose: Measure the critical transition where longitudinal beading ceases
###############################################################################

# ===== USER CONFIGURATION =====
ATHENA_ROOT="/path/to/athena++"  # UPDATE THIS PATH
WORK_DIR="/path/to/workdir"       # UPDATE THIS PATH

# ===== CAMPAIGN PARAMETERS =====
F_VALUES=(1.2 1.3 1.4 1.5 1.6 1.7)           # Line-mass ratios
BETA_VALUES=(0.3 0.5 1.0 1.5 2.0)            # Plasma beta values
M_VALUES=(1.0 2.0)                           # Mach numbers
SEEDS=(0 1 2)                                # Random seeds

# ===== RUN PARAMETERS =====
NCORES=180                                   # MPI cores per simulation
SIMS_PER_BATCH=10                            # Parallel simulations
WALLCLOCK_LIMIT=7200                         # 2 hours per simulation

# ===== DIRECTORIES =====
CAMPAIGN_DIR="${WORK_DIR}/CT_critical_transition"
CONFIG_DIR="${CAMPAIGN_DIR}/configs"
RUN_DIR="${CAMPAIGN_DIR}/runs"
LOG_DIR="${CAMPAIGN_DIR}/logs"
mkdir -p "${RUN_DIR}" "${LOG_DIR}"

# ===== ATHENA++ EXECUTABLE =====
ATHENA_EXE="${ATHENA_ROOT}/bin/athena"

# ===== FUNCTION: Run single simulation =====
run_simulation() {
    local f=$1
    local beta=$2
    local M=$3
    local seed=$4

    # Compute magnetic field strength from plasma beta
    # beta = P_gas / P_mag = (rho * c_s^2) / (B^2 / 8pi)
    # B = sqrt(8pi * rho * c_s^2 / beta)
    local b_field=$(python3 -c "import numpy as np; print(f'{np.sqrt(8.0 * np.pi / beta):.6f}')")

    # Create simulation ID
    local sim_id="ct_f${f}_beta${beta}_M${M}_seed${seed}"

    # Create output directory
    local output_dir="${RUN_DIR}/${sim_id}"
    mkdir -p "${output_dir}"

    # Copy and modify config file
    local config_file="${CONFIG_DIR}/athinput.ct_${sim_id}"

    sed "s|# <-OUTPUT-> output directory = /path/to/workdir|# <-OUTPUT-> output directory = ${output_dir}|g" \
        "${CONFIG_DIR}/athinput.ct_template" > "${config_file}"

    sed -i.bak "s|# <-MHD> b_initial = 1.0|# <-MHD> b_initial = ${b_field}|g" "${config_file}"
    sed -i.bak "s|# <-PROBLEM-> fil_mass = 1.2|# <-PROBLEM-> fil_mass = ${f}|g" "${config_file}"
    sed -i.bak "s|# <-PROBLEM-> fil_perturb_seed = 0|# <-PROBLEM-> fil_perturb_seed = ${seed}|g" "${config_file}"

    # Remove backup file
    rm -f "${config_file}.bak"

    # Log file
    local log_file="${LOG_DIR}/${sim_id}.log"

    echo "Starting simulation: ${sim_id}"
    echo "Parameters: f=${f}, beta=${beta}, M=${M}, seed=${seed}"
    echo "B-field: ${b_field}"

    # Run simulation
    mpirun -np ${NCORES} ${ATHENA_EXE} -i "${config_file}" > "${log_file}" 2>&1

    # Check if simulation completed successfully
    if [ $? -eq 0 ]; then
        echo "Simulation completed: ${sim_id}"
        echo "${sim_id}" >> "${CAMPAIGN_DIR}/completed_sims.txt"
    else
        echo "Simulation FAILED: ${sim_id}"
        echo "${sim_id}" >> "${CAMPAIGN_DIR}/failed_sims.txt"
    fi

    # Clean up config file
    rm -f "${config_file}"
}

# ===== FUNCTION: Run batch of simulations =====
run_batch() {
    local batch_id=$1
    shift
    local sim_params=("$@")

    echo "Starting batch ${batch_id} with ${#sim_params[@]} simulations"

    for params in "${sim_params[@]}"; do
        # Parse parameters: f,beta,M,seed
        IFS=',' read -r f beta M seed <<< "${params}"

        # Run simulation in background
        run_simulation "${f}" "${beta}" "${M}" "${seed}" &

        # Limit parallel jobs
        if [[ $(jobs -r | wc -l) -ge ${SIMS_PER_BATCH} ]]; then
            wait -n
        fi
    done

    # Wait for all background jobs to finish
    wait
    echo "Batch ${batch_id} completed"
}

# ===== MAIN EXECUTION =====

# Check if Athena++ exists
if [ ! -f "${ATHENA_EXE}" ]; then
    echo "ERROR: Athena++ executable not found at ${ATHENA_EXE}"
    echo "Please update ATHENA_ROOT in the script"
    exit 1
fi

# Parse command line arguments
MODE=${1:-run}

case "${MODE}" in
    test)
        echo "Running test simulation..."
        run_simulation 1.5 1.0 1.0 0
        ;;

    run)
        echo "Starting full campaign: ${#F_VALUES[@]} x ${#BETA_VALUES[@]} x ${#M_VALUES[@]} x ${#SEEDS[@]} simulations"
        echo "Total simulations: $((${#F_VALUES[@]} * ${#BETA_VALUES[@]} * ${#M_VALUES[@]} * ${#SEEDS[@]}))"

        # Clear previous logs
        > "${CAMPAIGN_DIR}/completed_sims.txt"
        > "${CAMPAIGN_DIR}/failed_sims.txt"

        # Generate all parameter combinations
        all_sims=()
        for f in "${F_VALUES[@]}"; do
            for beta in "${BETA_VALUES[@]}"; do
                for M in "${M_VALUES[@]}"; do
                    for seed in "${SEEDS[@]}"; do
                        all_sims+=("${f},${beta},${M},${seed}")
                    done
                done
            done
        done

        # Run in batches
        batch_id=0
        for ((i=0; i<${#all_sims[@]}; i+=SIMS_PER_BATCH)); do
            batch=("${all_sims[@]:i:SIMS_PER_BATCH}")
            run_batch "${batch_id}" "${batch[@]}"
            ((batch_id++))
        done

        echo "Campaign completed!"
        echo "Completed simulations: $(wc -l < ${CAMPAIGN_DIR}/completed_sims.txt)"
        echo "Failed simulations: $(wc -l < ${CAMPAIGN_DIR}/failed_sims.txt)"
        ;;

    restart)
        echo "Restarting failed simulations..."

        if [ ! -f "${CAMPAIGN_DIR}/failed_sims.txt" ]; then
            echo "No failed simulations found"
            exit 0
        fi

        # Read failed simulations
        failed_sims=($(cat "${CAMPAIGN_DIR}/failed_sims.txt"))

        for sim_id in "${failed_sims[@]}"; do
            # Extract parameters from sim_id
            if [[ ${sim_id} =~ ct_f([0-9.]+)_beta([0-9.]+)_M([0-9.]+)_seed([0-9]+) ]]; then
                f="${BASH_REMATCH[1]}"
                beta="${BASH_REMATCH[2]}"
                M="${BASH_REMATCH[3]}"
                seed="${BASH_REMATCH[4]}"

                echo "Restarting: ${sim_id}"
                run_simulation "${f}" "${beta}" "${M}" "${seed}"
            fi
        done
        ;;

    *)
        echo "Usage: $0 {test|run|restart}"
        echo ""
        echo "Commands:"
        echo "  test    - Run single test simulation"
        echo "  run     - Run full campaign (180 simulations)"
        echo "  restart - Restart failed simulations only"
        exit 1
        ;;
esac

echo "Done!"
