#!/usr/bin/env python3
"""
Campaign CT: Critical Transition Analysis
Analyzes simulation outputs to measure the critical transition where
longitudinal beading ceases and radial collapse dominates.
"""

import numpy as np
import h5py
import matplotlib.pyplot as plt
from pathlib import Path
import pandas as pd
from scipy.optimize import curve_fit
from scipy.signal import find_peaks
import warnings
warnings.filterwarnings('ignore')

# ============================================================================
# CONFIGURATION
# ============================================================================
CAMPAIGN_DIR = Path("/path/to/workdir/CT_critical_transition")
OUTPUT_DIR = CAMPAIGN_DIR / "runs"
RUN_DIR = CAMPAIGN_DIR / "runs"
ANALYSIS_DIR = CAMPAIGN_DIR / "analysis"
RESULTS_DIR = ANALYSIS_DIR / "results"
FIGURES_DIR = ANALYSIS_DIR / "figures"

# Create directories
RESULTS_DIR.mkdir(exist_ok=True, parents=True)
FIGURES_DIR.mkdir(exist_ok=True, parents=True)

# Simulation parameters
F_VALUES = [1.2, 1.3, 1.4, 1.5, 1.6, 1.7]
BETA_VALUES = [0.3, 0.5, 1.0, 1.5, 2.0]
M_VALUES = [1.0, 2.0]
SEEDS = [0, 1, 2]

# ============================================================================
# FRAGMENTATION CLASSIFICATION
# ============================================================================

def classify_fragmentation(sim_id):
    """
    Classify fragmentation as LONGITUDINAL, RADIAL, or STABLE.

    Criteria:
    - LONGITUDINAL: Axial variance > 0.02 AND >= 2 axial peaks
    - RADIAL: Axial variance < 0.02 AND peak density contrast < 0.5
    - STABLE: No fragmentation by t = 2.0 t_J
    """
    output_path = OUTPUT_DIR / sim_id

    # Read HDF5 snapshots
    hdf5_files = sorted(output_path.glob("*.hdf5"))

    if len(hdf5_files) == 0:
        return "NO_DATA", None, None

    times = []
    axial_variances = []
    peak_counts = []
    peak_contrasts = []

    for snapshot in hdf5_files:
        try:
            with h5py.File(snapshot, 'r') as hf:
                t = hf['Attributes'].get('Time', 0.0)
                rho = hf['dens'][:]

                # Compute axial variance (variance along x-axis)
                rho_axial = rho.mean(axis=(1, 2))
                axial_var = rho_axial.var() / (rho_axial.mean()**2 + 1e-10)
                axial_variances.append(axial_var)

                # Detect peaks in axial profile
                peaks, properties = find_peaks(rho_axial, prominence=0.1)
                peak_counts.append(len(peaks))

                # Peak-to-trough contrast
                if len(peaks) >= 2:
                    peak_val = rho_axial[peaks].max()
                    trough_val = rho_axial.min()
                    contrast = (peak_val - trough_val) / (peak_val + trough_val + 1e-10)
                else:
                    contrast = 0.0
                peak_contrasts.append(contrast)

                times.append(t)

        except Exception as e:
            continue

    if len(times) == 0:
        return "NO_DATA", None, None

    times = np.array(times)
    axial_variances = np.array(axial_variances)
    peak_counts = np.array(peak_counts)
    peak_contrasts = np.array(peak_contrasts)

    # Final-time classification
    final_var = axial_variances[-1]
    final_peaks = peak_counts[-1]
    final_contrast = peak_contrasts[-1]

    # Fragmentation time (when contrast first exceeds 50%)
    frag_idx = np.where(peak_contrasts > 0.5)[0]
    t_frag = times[frag_idx[0]] if len(frag_idx) > 0 else None

    if final_var > 0.02 and final_peaks >= 2 and final_contrast > 0.5:
        return "LONGITUDINAL", t_frag, final_contrast
    elif final_var < 0.02 and final_contrast < 0.5:
        return "RADIAL", t_frag, final_contrast
    else:
        return "STABLE", None, final_contrast

# ============================================================================
# LAMBDA/W MEASUREMENT
# ============================================================================

def measure_lambda_W(sim_id):
    """
    Measure fragmentation spacing λ/W from simulation output.

    Only meaningful for LONGITUDINAL classifications.
    """
    output_path = OUTPUT_DIR / sim_id

    # Find snapshot at fragmentation epoch
    hdf5_files = sorted(output_path.glob("*.hdf5"))

    for snapshot in hdf5_files:
        try:
            with h5py.File(snapshot, 'r') as hf:
                t = hf['Attributes'].get('Time', 0.0)
                rho = hf['dens'][:]

                # Extract axial profile
                rho_axial = rho.mean(axis=(1, 2))

                # Fourier analysis to find dominant wavelength
                power_spectrum = np.abs(np.fft.rfft(rho_axial))**2
                k = np.fft.rfftfreq(len(rho_axial))

                # Find peak in power spectrum (exclude k=0)
                k_peak = k[1:][np.argmax(power_spectrum[1:])]
                lambda_peak = 1.0 / (k_peak + 1e-10)

                # Measure width from radial profile
                rho_radial = rho.mean(axis=(0, 2))
                rho_center = rho_radial.max()
                half_max = rho_center / 2.0

                # FWHM
        except Exception as e:
            continue

    return None, None  # No valid measurement

# ============================================================================
# TRANSITION MAPPING
# ============================================================================

def map_transition():
    """
    Map the critical transition f_transition(β, M).

    For each (β, M), fit a sigmoid to the classification probability vs f.
    """
    results = []

    for beta in BETA_VALUES:
        for M in M_VALUES:
            # Collect classifications across f values
            f_vals = []
            P_long = []

            for f in F_VALUES:
                long_count = 0
                total_count = 0

                for seed in SEEDS:
                    sim_id = f"ct_f{f}_beta{beta}_M{M}_seed{seed}"
                    classification, _, _ = classify_fragmentation(sim_id)

                    if classification != "NO_DATA":
                        total_count += 1
                        if classification == "LONGITUDINAL":
                            long_count += 1

                if total_count > 0:
                    f_vals.append(f)
                    P_long.append(long_count / total_count)

            # Fit sigmoid: P_long(f) = 1 / (1 + exp(-(f - f_50) / df))
            if len(f_vals) >= 3:
                try:
                    def sigmoid(f, f_50, df):
                        return 1.0 / (1.0 + np.exp(-(f - f_50) / df))

                    popt, pcov = curve_fit(sigmoid, f_vals, P_long,
                                          p0=[1.5, 0.1],
                                          maxfev=10000)

                    f_transition = popt[0]  # f_50
                    df = popt[1]  # Transition width
                    f_transition_err = np.sqrt(np.diag(pcov))[0]
                    df_err = np.sqrt(np.diag(pcov))[1]

                    results.append({
                        'beta': beta,
                        'M': M,
                        'f_transition': f_transition,
                        'f_transition_err': f_transition_err,
                        'df': df,
                        'df_err': df_err,
                        'abruptness': 1.0 / df  # Higher = more abrupt
                    })
                except:
                    pass

    return pd.DataFrame(results)

# ============================================================================
# FIGURE GENERATION
# ============================================================================

def generate_figures(transition_df):
    """Generate publication-ready figures."""

    # Figure CT-1: Classification map
    fig, ax = plt.subplots(figsize=(10, 8))

    for beta in BETA_VALUES:
        for M in M_VALUES:
            f_vals = []
            P_long = []

            for f in F_VALUES:
                long_count = 0
                total_count = 0

                for seed in SEEDS:
                    sim_id = f"ct_f{f}_beta{beta}_M{M}_seed{seed}"
                    classification, _, _ = classify_fragmentation(sim_id)

                    if classification != "NO_DATA":
                        total_count += 1
                        if classification == "LONGITUDINAL":
                            long_count += 1

                if total_count > 0:
                    f_vals.append(f)
                    P_long.append(long_count / total_count)

            label = f'β={beta}, M={M}'
            ax.plot(f_vals, P_long, 'o-', label=label, markersize=6)

    ax.set_xlabel('Line-mass ratio f')
    ax.set_ylabel('P(longitudinal beading)')
    ax.set_title('Critical Transition: Longitudinal Beading Probability vs f')
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.set_ylim(-0.1, 1.1)

    fig.savefig(FIGURES_DIR / 'CT-1_classification_map.pdf',
                dpi=300, bbox_inches='tight')
    plt.close()

    # Figure CT-2: Transition map
    if len(transition_df) > 0:
        fig, ax = plt.subplots(figsize=(10, 8))

        for M in M_VALUES:
            subset = transition_df[transition_df['M'] == M]
            ax.errorbar(subset['beta'], subset['f_transition'],
                       yerr=subset['f_transition_err'],
                       fmt='o-', label=f'M = {M}',
                       markersize=8, capsize=5)

        ax.set_xlabel('Plasma beta β')
        ax.set_ylabel('Transition line-mass f_transition')
        ax.set_title('Critical Transition Line-mass vs Plasma Beta')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.invert_xaxis()  # Stronger B (lower β) on left

        fig.savefig(FIGURES_DIR / 'CT-2_transition_map.pdf',
                    dpi=300, bbox_inches='tight')
        plt.close()

    # Figure CT-3: Transition width
    if len(transition_df) > 0:
        fig, ax = plt.subplots(figsize=(10, 8))

        for M in M_VALUES:
            subset = transition_df[transition_df['M'] == M]
            ax.errorbar(subset['beta'], subset['df'],
                       yerr=subset['df_err'],
                       fmt='o-', label=f'M = {M}',
                       markersize=8, capsize=5)

        ax.axhline(y=0.2, color='black', linestyle='--',
                   label='Abrupt threshold (Δf = 0.2)')
        ax.set_xlabel('Plasma beta β')
        ax.set_ylabel('Transition width Δf')
        ax.set_title('Critical Transition Width vs Plasma Beta')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.invert_xaxis()

        fig.savefig(FIGURES_DIR / 'CT-3_transition_width.pdf',
                    dpi=300, bbox_inches='tight')
        plt.close()

    print("Figures generated successfully")

# ============================================================================
# MAIN ANALYSIS
# ============================================================================

def main():
    """Run complete CT analysis."""
    print("=" * 60)
    print("Campaign CT: Critical Transition Analysis")
    print("=" * 60)

    # Classify all simulations
    print("\n1. Classifying fragmentations...")
    all_classifications = []

    for f in F_VALUES:
        for beta in BETA_VALUES:
            for M in M_VALUES:
                for seed in SEEDS:
                    sim_id = f"ct_f{f}_beta{beta}_M{M}_seed{seed}"
                    classification, t_frag, contrast = classify_fragmentation(sim_id)

                    all_classifications.append({
                        'sim_id': sim_id,
                        'f': f,
                        'beta': beta,
                        'M': M,
                        'seed': seed,
                        'classification': classification,
                        't_frag': t_frag,
                        'contrast': contrast
                    })

    # Save classifications
    df_classifications = pd.DataFrame(all_classifications)
    df_classifications.to_csv(RESULTS_DIR / 'CT_classifications.csv', index=False)

    print(f"   Classified {len(all_classifications)} simulations")
    print(f"   LONGITUDINAL: {len(df_classifications[df_classifications['classification'] == 'LONGITUDINAL'])}")
    print(f"   RADIAL: {len(df_classifications[df_classifications['classification'] == 'RADIAL'])}")
    print(f"   STABLE: {len(df_classifications[df_classifications['classification'] == 'STABLE'])}")

    # Map transition
    print("\n2. Mapping critical transition...")
    transition_df = map_transition()

    if len(transition_df) > 0:
        transition_df.to_csv(RESULTS_DIR / 'CT_transition_map.csv', index=False)

        print("   Transition map:")
        print(transition_df.to_string(index=False))

        # Generate report
        print("\n3. Generating summary report...")
        generate_summary_report(transition_df, df_classifications)
    else:
        print("   WARNING: Could not fit transition curves")

    # Generate figures
    print("\n4. Generating figures...")
    generate_figures(transition_df)

    print("\n" + "=" * 60)
    print("Analysis complete!")
    print("=" * 60)

def generate_summary_report(transition_df, classifications_df):
    """Generate text summary report."""
    report_path = RESULTS_DIR / 'CT_analysis_report.txt'

    with open(report_path, 'w') as f:
        f.write("CAMPAIGN CT: CRITICAL TRANSITION ANALYSIS REPORT\n")
        f.write("=" * 60 + "\n\n")

        f.write("TRANSITION MAP\n")
        f.write("-" * 40 + "\n")
        if len(transition_df) > 0:
            f.write(transition_df.to_string(index=False))

            # Calculate statistics
            mean_f_transition = transition_df['f_transition'].mean()
            std_f_transition = transition_df['f_transition'].std()
            mean_df = transition_df['df'].mean()

            f.write(f"\n\nMean f_transition: {mean_f_transition:.3f} ± {std_f_transition:.3f}\n")
            f.write(f"Mean transition width Δf: {mean_df:.3f}\n")

            if mean_df < 0.2:
                f.write("\nTransition is ABRUPT (Δf < 0.2)\n")
            else:
                f.write("\nTransition is GRADUAL (Δf ≥ 0.2)\n")

        f.write("\n\nCLASSIFICATION SUMMARY\n")
        f.write("-" * 40 + "\n")
        f.write(f"Total simulations: {len(classifications_df)}\n")
        f.write(f"LONGITUDINAL: {len(classifications_df[classifications_df['classification'] == 'LONGITUDINAL'])}\n")
        f.write(f"RADIAL: {len(classifications_df[classifications_df['classification'] == 'RADIAL'])}\n")
        f.write(f"STABLE: {len(classifications_df[classifications_df['classification'] == 'STABLE'])}\n")

        f.write("\n\nCONCLUSIONS\n")
        f.write("-" * 40 + "\n")

        if len(transition_df) > 0:
            f.write(f"Critical transition occurs at f ≈ {mean_f_transition:.2f}\n")
            f.write(f"Transition width: Δf ≈ {mean_df:.2f}\n")

            if mean_df < 0.2:
                f.write("Abrupt transition suggests distinct fragmentation regimes\n")
            else:
                f.write("Gradual transition suggests continuous evolution\n")

            # Compare with HGBS range
            f.write("\nHGBS filaments: f ≈ 1.5-3.0\n")
            if mean_f_transition < 1.5:
                f.write("Transition occurs BELOW HGBS range → HGBS filaments in radial collapse regime\n")
            else:
                f.write("Transition occurs WITHIN HGBS range → mixed behavior expected\n")

    print(f"Report saved to {report_path}")

if __name__ == "__main__":
    main()
