# Campaign CT: Critical Transition Mapping

## Referee Concern Addressed

**Concern #2**: "The central theoretical disconnect — simulations and observations measure different regimes"

## Problem Statement

The referee identifies a critical gap:
- λ/W measurements come from near-critical simulations (f ≈ 1.0-1.2)
- HGBS filaments are predominantly supercritical (f ≈ 1.5-3.0)
- The smooth λ/W(f) relationship is only shown for f = 0.9-1.3
- Extrapolation to supercritical regime (f = 1.5-3.0) is unsupported

**Quote from referee**: "The paper cannot directly test whether the magnetic tension mechanism produces the observed spacing in the regime where HGBS filaments actually reside."

## Campaign Objective

Directly measure the critical transition where longitudinal beading ceases and radial collapse dominates, bridging the gap between near-critical (measurable λ/W) and supercritical (radial collapse only) regimes.

## Scientific Questions

1. At what f-value does longitudinal beading cease for each (β, M)?
2. Is the transition abrupt or gradual?
3. What is the transition width Δf?
4. Can λ/W be measured in the transition regime?
5. How does f_transition depend on magnetic field strength (β) and turbulence (M)?

## Parameter Space

| Parameter | Values | Count |
|-----------|--------|-------|
| f (line-mass ratio) | [1.2, 1.3, 1.4, 1.5, 1.6, 1.7] | 6 |
| β (plasma beta) | [0.3, 0.5, 1.0, 1.5, 2.0] | 5 |
| M (Mach number) | [1.0, 2.0] | 2 |
| Random seeds | [0, 1, 2] | 3 |

**Total**: 6 × 5 × 2 × 3 = 180 simulations

## Simulation Configuration

### Domain Setup
```
Lx = 8.0 * lambda_J  # Extended axial domain
Ly = 2.0 * lambda_J
Lz = 2.0 * lambda_J
Nx = 512
Ny = 128
Nz = 128
```

### Physics Modules
- Equation of state: Isothermal
- Magnetic field: Longitudinal (θ = 0°)
- Perturbations: Synthetic (amplitude = 10^-4)
- AMR: Enabled, max_level = 2 (effective resolution 2048^3)

### Runtime Parameters
```
tlim = 2.0 * t_J  # Extended runtime to capture late-time evolution
dt_out = 0.01 * t_J  # High-cadence output
wallclock_limit = 7200 seconds (2 hours)
```

### Diagnostic Outputs
- HDF5 snapshots: Every 0.01 t_J (200 snapshots per simulation)
- Sink particles: Disabled (we want to measure beading, not core formation)
- 1D profiles: Axial density profiles every 0.01 t_J
- Fragmentation detection: Automated peak finding

## Key Measurements

### 1. Fragmentation Classification
- **LONGITUDINAL**: Clear axial density peaks with λ/W measurable
- **RADIAL**: Pure radial collapse, axial variance < 0.02%
- **STABLE**: No fragmentation by t = 2.0 t_J

### 2. Fragmentation Time
- Time when peak-to-trough density contrast exceeds 50%
- Measured from axial density profiles

### 3. λ/W Measurement
- Extracted from Fourier analysis of axial density profile
- W measured from radial FWHM at fragmentation epoch
- Only reported for LONGITUDINAL classifications

### 4. Transition Metrics
- f_transition: Midpoint where P(longitudinal) = P(radial) = 50%
- Δf: Width of transition zone (10% - 90% longitudinal probability)
- Transition abruptness: dP/df at f_transition

## Analysis Pipeline

### Step 1: Fragmentation Classification
```python
def classify_fragmentation(sim_id):
    # Read axial density profiles
    profiles = read_axial_profiles(sim_id)

    # Compute axial variance
    variance = compute_axial_variance(profiles)

    # Detect longitudinal peaks
    peaks = detect_peaks(profiles)

    if variance > 0.02 and len(peaks) >= 2:
        return "LONGITUDINAL"
    elif variance < 0.02 and peaks_density_contrast < 0.5:
        return "RADIAL"
    else:
        return "STABLE"
```

### Step 2: Transition Mapping
```python
def map_transition(f_values, beta_values, M_values):
    # For each (beta, M), fit sigmoid to classification data
    P_long = np.array([classify_fragmentation(f, beta, M) for f in f_values])

    # Fit sigmoid: P_long(f) = 1 / (1 + exp(-(f - f_50) / df))
    from scipy.optimize import curve_fit
    popt, pcov = curve_fit(sigmoid, f_values, P_long)

    f_transition = popt[0]  # f_50
    df = popt[1]  # Transition width
```

### Step 3: λ/W Extraction
```python
def extract_lambda_W(sim_id):
    # Read 3D density field at fragmentation epoch
    rho = read_density_field(sim_id, t_frag)

    # Extract axial profile
    rho_axial = rho.mean(axis=(1, 2))

    # Fourier analysis
    power_spectrum = np.fft.rfft(rho_axial)
    lambda_peak = 2 * np.pi / k_peak

    # Measure width from radial profile
    W = measure_FWHM(rho_radial)

    return lambda_peak / W
```

## Success Criteria

### Minimum Success
- f_transition(β, M) map created for all (β, M) combinations
- Transition width Δf quantified
- At least 3 λ/W measurements in transition regime

### Full Success
- Smooth λ/W(f) curve from f = 1.0 to f = 1.7
- Transition characterized as abrupt (Δf < 0.2) or gradual (Δf > 0.2)
- Publication-ready figure showing classification probability P(f, β, M)
- Table: f_transition, Δf for all (β, M) combinations

### Exceptional Success
- Physical explanation for transition behavior
- Connection to linear theory stability analysis
- Predictive model for f_transition(β, M)

## Expected Outcomes

### Scientific Impact
- **Directly addresses referee's "central theoretical disconnect" concern**
- Provides the missing link between near-critical and supercritical regimes
- Enables direct comparison between simulations and HGBS observations

### Publication-Ready Outputs
1. **Figure**: 3-panel showing (a) classification map, (b) transition curves, (c) λ/W across f = 1.2-1.7
2. **Table**: f_transition(β, M), Δf(β, M), classification for all 180 simulations
3. **Analysis**: Transition abruptness quantification, physical interpretation

## Timeline

- **Week 1-2**: Run simulations (180 sims, ~2 hours each)
- **Week 3**: Analysis and figure generation
- **Week 4**: Interpretation and paper integration

## Computational Requirements

- **CPU time**: 180 sims × 2 hours = 360 CPU-hours
- **Storage**: ~500 MB per simulation × 180 = 90 GB
- **Parallel execution**: 10-20 simulations at once on 220 CPU cluster
- **Wall-clock time**: ~3 weeks

## References

- Referee Report, Concern #2: "The central theoretical disconnect"
- Inutsuka & Miyama (1992): Linear theory of filament fragmentation
- Nakamura, Hanawa & Nakano (1993): MHD filament stability analysis
