# Referee Round 2 Simulation Package - Setup Guide

## Quick Setup on Your Ray Cluster

### 1. Extract the Package
```bash
cd /path/to/your/workdir
tar -xzf referee_round2_simulations.tar.gz
cd referee_round2_simulations
```

### 2. Install Athena++ (if not already installed)
```bash
# Download Athena++
wget https://github.com/PrincetonUniversity/athena-public-release/archive/v21.0.tar.gz
tar -xzf v21.0.tar.gz
cd athena-public-release-21.0

# Configure with required modules
./configure --prob=isothermal_filament_3d \
            --coord=cartesian \
            --flux=hllc \
            --integrator=vl2 \
            --pmemod=fft \
            --sink_particle \
            --omp

# Compile
make -j 8

# Set path
export ATHENA_ROOT=$(pwd)
```

### 3. Update Configuration
Edit the run scripts to set your paths:

**CT/scripts/run_ct_campaign.sh:**
```bash
ATHENA_ROOT="/your/path/to/athena++"
WORK_DIR="/your/path/to/workdir"
```

**TURB/scripts/run_turb_campaign.sh:**
```bash
ATHENA_ROOT="/your/path/to/athena++"
WORK_DIR="/your/path/to/workdir"
```

**PFE/scripts/run_pfe_campaign.sh:**
```bash
ATHENA_ROOT="/your/path/to/athena++"
WORK_DIR="/your/path/to/workdir"
```

**Analysis scripts** also need path updates:
```python
# CT/analysis/analyze_ct.py
CAMPAIGN_DIR = Path("/your/path/to/workdir/CT_critical_transition")

# TURB/analysis/analyze_turb.py
CAMPAIGN_DIR = Path("/your/path/to/workdir/TURB_turbulent_support")

# PFE/analysis/analyze_pfe.py
CAMPAIGN_DIR = Path("/your/path/to/workdir/PFE_perpendicular_extension")
```

### 4. Run Test Simulation
```bash
# Test CT
cd CT_critical_transition/scripts
bash run_ct_campaign.sh test

# Test TURB
cd ../../TURB_turbulent_support/scripts
bash run_turb_campaign.sh test

# Test PFE
cd ../../PFE_perpendicular_extension/scripts
bash run_pfe_campaign.sh test
```

### 5. Run Full Campaigns
```bash
# Campaign 1: Critical Transition (3 weeks)
cd CT_critical_transition/scripts
bash run_ct_campaign.sh run

# Campaign 2: Turbulent Support (1 week)
cd ../../TURB_turbulent_support/scripts
bash run_turb_campaign.sh run

# Campaign 3: Perpendicular Field Extension (1 week)
cd ../../PFE_perpendicular_extension/scripts
bash run_pfe_campaign.sh run
```

## Monitoring Progress

### Check simulation status
```bash
# Count completed simulations
ls -d ../runs/*/outputs 2>/dev/null | wc -l

# Check recent logs
tail -f ../logs/*.log

# Monitor cluster resources
top  # or htop if available
```

### Handle failures
```bash
# Restart failed simulations
bash run_ct_campaign.sh restart
# or
bash run_turb_campaign.sh restart
# or
bash run_pfe_campaign.sh restart
```

## Analysis

### After simulations complete:
```bash
# Analyze CT
cd CT_critical_transition/analysis
python analyze_ct.py

# Analyze TURB
cd ../../TURB_turbulent_support/analysis
python analyze_turb.py

# Analyze PFE
cd ../../PFE_perpendicular_extension/analysis
python analyze_pfe.py
```

## Expected Results

### Campaign 1 (Critical Transition) Success Metrics
- f_transition(β, M) map created
- λ/W measured across f = 1.2-1.7 range
- Transition width Δf quantified
- Publication-ready transition figure

### Campaign 2 (Turbulent Support) Success Metrics
- f_eff table provided (resolves broken reference)
- f_eff ≈ 0.7^{+0.5}_{-0.3} verified
- Turbulent support quantified
- Uncertainties propagated

### Campaign 3 (Perpendicular Field Extension) Success Metrics
- λ/W(θ, f, β) comprehensive map
- Geometry effect quantified
- Definitive test of perpendicular-field explanation
- Publication-ready geometry figure

## Troubleshooting

### Issue: Athena++ compilation fails
**Solution**: Ensure required dependencies are installed:
```bash
# On most clusters:
module load hdf5 openmpi fftw

# Or install manually:
sudo apt-get install libhdf5-dev libopenmpi-dev libfftw3-dev
```

### Issue: Simulations run slowly
**Solution**: Check MPI configuration:
```bash
# Verify MPI installation
mpirun --version

# Test parallel execution
mpirun -np 4 hostname

# Adjust NCORES in run scripts
```

### Issue: Out of memory errors
**Solution**: Reduce memory usage:
```bash
# Reduce number of parallel simulations
SIMS_PER_BATCH=5  # instead of 10

# Or reduce resolution
# Edit config files: max_level = 1 (instead of 2)
```

### Issue: Analysis scripts fail
**Solution**: Check Python dependencies:
```bash
pip install numpy pandas matplotlib scipy h5py
```

## Contact

For issues with these simulations:
- G. J. White, Open University & RAL
- Glenn's GitHub: https://github.com/gjw255/

## Citation

When using results from these campaigns, cite:
- White et al. (2026), "Fragmentation of Interstellar Filaments: HGBS Analysis and MHD Simulations", MNRAS, in press
- Supplementary simulation campaign (Round 2) addressing referee concerns on critical transition, turbulent support, and field geometry
