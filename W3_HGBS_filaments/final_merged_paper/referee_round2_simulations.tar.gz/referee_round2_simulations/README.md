# Referee Round 2 Simulation Package

**Purpose**: Address three major concerns from referee report through targeted Athena++ simulations

**Total simulations**: 360 (estimated 3-4 weeks on 220 CPU cluster)

**Campaigns**:
1. **Critical Transition Mapping Campaign** (180 simulations) - Addresses Referee Concern #2
2. **Turbulent Support Verification Campaign** (90 simulations) - Addresses Referee Concern #3
3. **Perpendicular Field Extension Campaign** (90 simulations) - Addresses Referee Concern #4

---

## Quick Start

### 1. Extract the Package
```bash
cd /path/to/your/workdir
tar -xzf referee_round2_simulations.tar.gz
cd referee_round2_simulations
```

### 2. Install Athena++ (if not already installed)
See SETUP_GUIDE.md for detailed instructions.

### 3. Update Configuration
Edit run scripts to set your paths:
```bash
# CT/scripts/run_ct_campaign.sh
TURB/scripts/run_turb_campaign.sh
PFE/scripts/run_pfe_campaign.sh

# Update these lines:
ATHENA_ROOT="/your/path/to/athena++"
WORK_DIR="/your/path/to/workdir"
```

### 4. Run Campaigns
```bash
# Campaign 1: Critical Transition (3 weeks)
cd CT_critical_transition/scripts
bash run_ct_campaign.sh

# Campaign 2: Turbulent Support (1 week)
cd ../../TURB_turbulent_support/scripts
bash run_turb_campaign.sh

# Campaign 3: Perpendicular Field Extension (1 week)
cd ../../PFE_perpendicular_extension/scripts
bash run_pfe_campaign.sh
```

### 5. Analyze Results
```bash
# Analyze each campaign
cd CT_critical_transition/analysis
python analyze_ct.py

cd ../../TURB_turbulent_support/analysis
python analyze_turb.py

cd ../../PFE_perpendicular_extension/analysis
python analyze_pfe.py
```

---

## Campaign Descriptions

### Campaign 1: Critical Transition Mapping (180 simulations)

**Referee Concern #2**: "The central theoretical disconnect — simulations and observations measure different regimes"

**Problem**: λ/W measurements come from near-critical simulations (f ≈ 1.0-1.2), but HGBS filaments are supercritical (f ≈ 1.5-3.0). The smooth λ/W(f) relationship is only demonstrated for f = 0.9-1.3, not extended to the supercritical regime.

**Objective**: Directly measure the critical transition where longitudinal beading ceases and radial collapse dominates, bridging the gap between near-critical (measurable λ/W) and supercritical (radial collapse only) regimes.

**Parameter Space**:
- f ∈ [1.2, 1.3, 1.4, 1.5, 1.6, 1.7] (6 values)
- β ∈ [0.3, 0.5, 1.0, 1.5, 2.0] (5 values)
- M ∈ [1.0, 2.0] (2 values)
- Seeds: 3 per parameter point

**Total**: 6 × 5 × 2 × 3 = 180 simulations

**Key Measurements**:
- Fragmentation classification (LONGITUDINAL vs RADIAL vs STABLE)
- Fragmentation time t_frag
- λ/W ratio (where longitudinal beading occurs)
- Radial collapse rate (where radial collapse dominates)
- Transition point identification

**Success Criteria**:
- Map the f-transition(β, M) where beading ceases
- Quantify the transition width Δf
- Determine whether the transition is abrupt or gradual
- Provide λ/W measurements across the full f = 1.2-1.7 range

---

### Campaign 2: Turbulent Support Verification (90 simulations)

**Referee Concern #3**: "The effective f problem and turbulent support"

**Problem**: Broken reference to "Table ??" for f_eff ≈ 0.7^{+0.5}_{-0.3}. This is the critical bridge between simulations and observations — if f_eff ≈ 0.7-1.2 when turbulence is included, then near-critical simulations are directly relevant to HGBS observations.

**Objective**: Provide the missing table through simulations measuring the effective line-mass fraction when turbulent pressure support is included.

**Parameter Space**:
- f_thermal ∈ [0.7, 0.8, 0.9, 1.0, 1.1, 1.2] (6 values)
- Turbulent Mach M_turb ∈ [0.5, 1.0, 1.5, 2.0, 2.5] (5 values)
- β ∈ [0.5, 1.0, 2.0] (3 values)
- Seeds: 1 per parameter point (pilot study)

**Total**: 6 × 5 × 3 × 1 = 90 simulations

**Key Measurements**:
- Effective critical line-mass: M_line,crit(eff) = M_line,crit(thermal) + M_line,crit(turbulent)
- Turbulent pressure contribution: P_turb = ρ (δv)^2
- Modified critical line-mass: f_eff = f_thermal / (1 + M_turb^2)
- Fragmentation time scaling: t_frag(f_eff, M_turb, β)
- λ/W dependence on turbulent support

**Success Criteria**:
- Generate the missing table: f_eff as function of (f_thermal, M_turb, β)
- Verify the f_eff ≈ 0.7^{+0.5}_{-0.3} claim
- Quantify uncertainties in turbulent support correction
- Determine whether turbulent support bridges the near-critical to supercritical gap

---

### Campaign 3: Perpendicular Field Extension (90 simulations)

**Referee Concern #4**: "Perpendicular field geometry: a result that transforms the problem but is underemphasized"

**Problem**: Campaign 6 shows perpendicular-field filaments fragment at λ/W ≈ 1.25 — 2-3× shorter than observed. This inverts the problem: why are observed spacings longer than perpendicular-field predictions? This result is discussed but not emphasized, and the abstract/conclusions frame the problem in terms of classical "sub-Jeans spacing" rather than this transformed question.

**Objective**: Extend perpendicular-field campaign to (a) mixed/oblique geometries, (b) broader β range, and (c) higher f values, providing a comprehensive test of whether perpendicular-field geometry can ever match observations.

**Parameter Space**:
- f ∈ [1.5, 2.0, 2.5, 3.0] (4 values)
- β ∈ [0.3, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0] (7 values)
- Field angle θ ∈ [60°, 75°, 90°] (3 values)
- Seeds: 1 per parameter point (pilot study)

**Total**: 4 × 7 × 3 × 1 = 84 simulations + 6 verification runs = 90 simulations

**Key Measurements**:
- Fragmentation time t_frag(θ, f, β)
- λ/W ratio for mixed geometries
- Transition from perpendicular-like to longitudinal-like behavior
- Optimal geometry to match HGBS observations (λ/W ≈ 2.8)

**Success Criteria**:
- Map λ/W(θ) across oblique geometries (θ = 60°-90°)
- Determine whether any geometry/β combination yields λ/W ≈ 2.8
- Quantify the geometry effect size
- Provide definitive test of perpendicular-field explanation

---

## Expected Outcomes

### Campaign 1 (Critical Transition)
- **Scientific impact**: Directly addresses the referee's "central theoretical disconnect" concern
- **Publication-ready outputs**:
  - Transition map: f_transition(β, M)
  - λ/W measurements across f = 1.2-1.7
  - Figure showing abrupt vs gradual transition
  - Table quantifying transition uncertainty

### Campaign 2 (Turbulent Support)
- **Scientific impact**: Provides the missing table linking simulations to observations
- **Publication-ready outputs**:
  - f_eff(f_thermal, M_turb, β) table
  - Verification of f_eff ≈ 0.7^{+0.5}_{-0.3} claim
  - Turbulent support quantification
  - Resolves broken reference concern

### Campaign 3 (Perpendicular Field Extension)
- **Scientific impact**: Tests whether perpendicular-field geometry can match observations
- **Publication-ready outputs**:
  - λ/W(θ, f, β) comprehensive map
  - Geometry effect quantification
  - Definitive test of perpendicular-field explanation
  - Resolves underemphasized result concern

---

## Troubleshooting

See SETUP_GUIDE.md for common issues and solutions.

## Contact

For issues with these simulations:
- G. J. White, Open University & RAL
- GitHub: https://github.com/gjw255/

## Citation

When using results from these campaigns, cite:
- White et al. (2026), "Fragmentation of Interstellar Filaments: HGBS Analysis and MHD Simulations", MNRAS, in press
- Supplementary simulation campaign (Round 2) addressing referee concerns on critical transition, turbulent support, and field geometry
