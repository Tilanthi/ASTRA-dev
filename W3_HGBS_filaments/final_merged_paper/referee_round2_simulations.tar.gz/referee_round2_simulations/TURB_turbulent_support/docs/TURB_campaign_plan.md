# Campaign TURB: Turbulent Support Verification

## Referee Concern Addressed

**Concern #3**: "The effective f problem and turbulent support"

## Problem Statement

The referee identifies a critical gap:
- Paper mentions f_eff ≈ 0.7^{+0.5}_{-0.3} as effective line-mass fraction with turbulent support
- Reference to "our Table ??" is broken — table doesn't exist
- This is the critical bridge between simulations and observations
- If f_eff ≈ 0.7-1.2 when turbulence is included, then near-critical simulations are directly relevant to HGBS observations

**Quote from referee**: "The argument that near-critical simulations are directly relevant to HGBS observations depends entirely on this effective-f correction. This is arguably the most important bridge between the simulations and observations and cannot remain as a broken reference."

## Campaign Objective

Provide the missing table through simulations measuring the effective line-mass fraction when turbulent pressure support is included, thereby resolving the broken reference and verifying the f_eff ≈ 0.7^{+0.5}_{-0.3} claim.

## Scientific Questions

1. What is the effective critical line-mass when turbulent pressure is included?
2. How does f_eff depend on (f_thermal, M_turb, β)?
3. Is the claimed f_eff ≈ 0.7^{+0.5}_{-0.3} accurate?
4. What are the uncertainties in the turbulent support correction?
5. Does turbulent support bridge the near-critical to supercritical gap?

## Physical Model

### Effective Line-Mass with Turbulent Support

The critical line-mass for a filament with turbulent pressure support is:

```
M_line,crit(eff) = M_line,crit(thermal) + M_line,crit(turbulent)

where:
M_line,crit(thermal) = 2 * c_s^2 / G
M_line,crit(turbulent) = 2 * <δv^2> / G
```

The effective line-mass fraction is:

```
f_eff = f_thermal / (1 + M_turb^2)

where:
f_thermal = M_line / M_line,crit(thermal)
M_turb = δv_rms / c_s
```

### Parameter Space

| Parameter | Values | Count |
|-----------|--------|-------|
| f_thermal | [0.7, 0.8, 0.9, 1.0, 1.1, 1.2] | 6 |
| M_turb | [0.5, 1.0, 1.5, 2.0, 2.5] | 5 |
| β | [0.5, 1.0, 2.0] | 3 |
| Random seeds | [0] (pilot study) | 1 |

**Total**: 6 × 5 × 3 × 1 = 90 simulations

## Simulation Configuration

### Domain Setup
```
Lx = 8.0 * lambda_J
Ly = 2.0 * lambda_J
Lz = 2.0 * lambda_J
Nx = 256
Ny = 64
Nz = 64
```

### Physics Modules
- Equation of state: Isothermal
- Magnetic field: Longitudinal (θ = 0°)
- Perturbations: **Physical turbulence** (Kolmogorov spectrum)
  - Amplitude: δv/c_s = M_turb
  - Power spectrum: P(k) ∝ k^(-5/3)
  - Driving: Large-scale forcing maintained throughout simulation
- AMR: Enabled, max_level = 1 (effective resolution 512^3)

### Runtime Parameters
```
tlim = 2.0 * t_J
dt_out = 0.02 * t_J
wallclock_limit = 3600 seconds (1 hour)
```

### Turbulent Driving
```python
# Kolmogorov turbulence forcing
def apply_turbulent_forcing(grid, M_turb, t):
    # Large-scale forcing at k_forcing = 2 * 2π / L
    k_forcing = 2 * 2 * np.pi / Lx

    # Forcing amplitude scaled to target Mach number
    forcing_amplitude = M_turb * c_s / sqrt(3)

    # Stochastic forcing with Kolmogorov spectrum
    velocity_perturbation = generate_kolmogorov_perturbation(
        grid, k_forcing, forcing_amplitude
    )

    return velocity_perturbation
```

## Key Measurements

### 1. Effective Critical Line-Mass
- Measure fragmentation threshold f_crit(β, M_turb)
- Fit logistic function to fragmentation probability P_frag(f)
- Define f_crit as P_frag = 50%

### 2. Turbulent Pressure Contribution
- Measure turbulent energy: E_turb = 0.5 * ρ * <δv^2>
- Compute turbulent pressure: P_turb = (2/3) * E_turb
- Compare with thermal pressure: P_thermal = ρ * c_s^2

### 3. Modified Fragmentation Time
- Measure t_frag(f_thermal, M_turb, β)
- Test scaling: t_frag ∝ (1 + M_turb^2)^α
- Determine α from fit to simulation data

### 4. λ/W Dependence on Turbulent Support
- Measure λ/W for all simulations that fragment
- Test prediction: λ/W ∝ (1 + M_turb^2)^(1/2)
- Quantify deviation from theoretical prediction

## Analysis Pipeline

### Step 1: Fragmentation Threshold Measurement
```python
def measure_critical_line_mass(thermal_f_values, M_turb, beta):
    # Run simulations across thermal_f values
    fragmentation_results = []

    for f_thermal in thermal_f_values:
        sim_id = run_simulation(f_thermal, M_turb, beta)
        fragmented = check_fragmentation(sim_id)
        fragmentation_results.append(fragmented)

    # Fit logistic function: P_frag(f) = 1 / (1 + exp(-(f - f_crit) / df))
    from scipy.optimize import curve_fit
    popt, pcov = curve_fit(logistic, thermal_f_values, fragmentation_results)

    f_crit = popt[0]  # Critical line-mass fraction
    df = popt[1]  # Transition width

    return f_crit, df
```

### Step 2: Effective Line-Mass Calculation
```python
def compute_effective_f(f_thermal, M_turb, beta, f_crit):
    # Effective f based on turbulent support model
    f_eff_model = f_thermal / (1 + M_turb**2)

    # Alternative: empirical correction from simulations
    f_eff_empirical = f_thermal * f_crit

    return f_eff_model, f_eff_empirical
```

### Step 3: Table Generation
```python
def generate_f_eff_table():
    # Create table: f_eff(f_thermal, M_turb, beta)
    table = []

    for f_thermal in [0.7, 0.8, 0.9, 1.0, 1.1, 1.2]:
        for M_turb in [0.5, 1.0, 1.5, 2.0, 2.5]:
            for beta in [0.5, 1.0, 2.0]:
                f_eff_model, f_eff_empirical = compute_effective_f(
                    f_thermal, M_turb, beta
                )

                table.append({
                    'f_thermal': f_thermal,
                    'M_turb': M_turb,
                    'beta': beta,
                    'f_eff_model': f_eff_model,
                    'f_eff_empirical': f_eff_empirical,
                    'f_eff_adopted': f_eff_empirical  # Use empirical value
                })

    return pd.DataFrame(table)
```

## Success Criteria

### Minimum Success (Required)
- **Table provided** resolving the broken reference
- f_eff table with entries for all (f_thermal, M_turb, β) combinations
- At least 3 measurements per parameter point

### Full Success
- f_eff ≈ 0.7^{+0.5}_{-0.3} claim verified or refuted
- Uncertainties in turbulent support correction quantified
- λ/W dependence on turbulent support characterized
- Publication-ready table and figure

### Exceptional Success
- Physical model for f_eff(β, M_turb) developed
- Connection to HGBS observations made explicit
- Near-critical simulations justified as relevant to HGBS

## Expected Outcomes

### Scientific Impact
- **Resolves broken reference** — the missing "Table ??" is provided
- **Verifies f_eff claim** — tests whether f_eff ≈ 0.7^{+0.5}_{-0.3} is accurate
- **Bridges sim-obs gap** — if verified, near-critical simulations are directly relevant
- **Quantifies uncertainties** — propagates errors in turbulent support correction

### Publication-Ready Outputs
1. **Table**: f_eff(f_thermal, M_turb, β) — the missing table
2. **Figure**: f_eff contour plot in (f_thermal, M_turb) plane for each β
3. **Analysis**: Verification of f_eff ≈ 0.7^{+0.5}_{-0.3} claim
4. **Uncertainty quantification**: Error bars on f_eff values

## Timeline

- **Week 1**: Run simulations (90 sims, ~1 hour each)
- **Week 2**: Analysis and table generation
- **Week 3**: Interpretation and paper integration

## Computational Requirements

- **CPU time**: 90 sims × 1 hour = 90 CPU-hours
- **Storage**: ~200 MB per simulation × 90 = 18 GB
- **Parallel execution**: 15-20 simulations at once
- **Wall-clock time**: ~1 week

## References

- Referee Report, Concern #3: "The effective f problem and turbulent support"
- Bonazzola et al. (1987): Turbulent support in filaments
- Arzoumanian et al. (2019): HGBS filament linewidths (δv/cs ~ 1-2)
