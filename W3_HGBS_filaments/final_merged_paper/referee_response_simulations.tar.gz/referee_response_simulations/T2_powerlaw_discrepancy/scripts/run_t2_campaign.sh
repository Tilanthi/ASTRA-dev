#!/bin/bash
# T2 Power-law Discrepancy Campaign - Run Script
# Hydrodynamic vs MHD comparison on 220 CPU Ray cluster

set -e  # Exit on error

# ============================================================================
# CAMPAIGN CONFIGURATION
# ============================================================================
CAMPAIGN_NAME="T2_powerlaw_discrepancy"
ATHENA_ROOT="/path/to/athena++"  # UPDATE THIS PATH
WORK_DIR="/path/to/workdir"       # UPDATE THIS PATH

# Parameter space
F_VALUES=(1.1 1.3 1.5 2.0 2.5 3.0)
BETA_MHD=(0.3 1.0 5.0)
M_VALUES=(1.0 2.0)
SEEDS=(0 1 2)

# Compute total simulations
# Hydro: 6 f × 2 M × 3 seeds = 36
# MHD: 3 β × 6 f × 2 M × 3 seeds = 108
N_HYDRO=$((${#F_VALUES[@]} * ${#M_VALUES[@]} * ${#SEEDS[@]}))
N_MHD=$((${#BETA_MHD[@]} * ${#F_VALUES[@]} * ${#M_VALUES[@]} * ${#SEEDS[@]}))
TOTAL_SIMS=$((N_HYDRO + N_MHD))

echo "=========================================="
echo "T2 Power-law Discrepancy Campaign"
echo "Hydrodynamic simulations: $N_HYDRO"
echo "MHD simulations: $N_MHD"
echo "Total simulations: $TOTAL_SIMS"
echo "=========================================="

# ============================================================================
# CLUSTER CONFIGURATION
# ============================================================================
# Ray cluster: 220 CPUs
NCORES=200  # Effective cores (91% efficiency for hydro)
SIMS_PER_BATCH=15  # Run 15 simulations at once (hydro is faster)

# MPI configuration
MPIRUN="mpirun -np $NCORES"
ATHENA_EXEC="$ATHENA_ROOT/bin/athena++"

# ============================================================================
# DIRECTORY SETUP
# ============================================================================
CAMPAIGN_DIR="$WORK_DIR/$CAMPAIGN_NAME"
CONFIG_DIR="$CAMPAIGN_DIR/configs"
RUN_DIR="$CAMPAIGN_DIR/runs"
OUTPUT_DIR="$CAMPAIGN_DIR/outputs"
LOG_DIR="$CAMPAIGN_DIR/logs"

mkdir -p "$RUN_DIR"/{hydro,mhd} "$OUTPUT_DIR"/{hydro,mhd} "$LOG_DIR"/{hydro,mhd}

# ============================================================================
# SIMULATION GENERATION
# ============================================================================

generate_config() {
    local sim_type=$1  # hydro or mhd
    local f=$2
    local beta=$3
    local M=$4
    local seed=$5

    local beta_str=$beta
    if [ "$sim_type" = "hydro" ]; then
        beta_str="inf"
    fi

    local problem_id="${sim_type}_frag_f${f}_beta${beta_str}_M${M}_seed${seed}"
    local config_file="$CONFIG_DIR/athinput_${problem_id}"

    # Copy template
    local template="$CONFIG_DIR/athinput_${sim_type}_template"
    cp "$template" "$config_file"

    # Set b_initial based on simulation type
    local b_initial="0.0"
    if [ "$sim_type" = "mhd" ]; then
        # Calculate B from β: B = sqrt(2P/β)
        # For P = 1.0 (isothermal), B = sqrt(2/β)
        b_initial=$(echo "scale=6; sqrt(2.0/$beta)" | bc)
    fi

    # Replace placeholders
    sed -i "s/{problem_type}/$sim_type/g" "$config_file"
    sed -i "s/{f}/$f/g" "$config_file"
    sed -i "s/{beta}/$beta/g" "$config_file"
    sed -i "s/{M}/$M/g" "$config_file"
    sed -i "s/{seed}/$seed/g" "$config_file"
    sed -i "s/{problem_id}/$problem_id/g" "$config_file"
    sed -i "s/{b_initial}/$b_initial/g" "$config_file"

    echo "$config_file"
}

run_simulation() {
    local sim_type=$1
    local config_file=$2
    local problem_id=$(basename "$config_file" | sed 's/athinput_//')

    local run_dir="$RUN_DIR/$sim_type/$problem_id"
    mkdir -p "$run_dir"

    local log_file="$LOG_DIR/$sim_type/${problem_id}.log"
    local err_file="$LOG_DIR/$sim_type/${problem_id}.err"

    echo "Running: $problem_id"
    echo "Config: $config_file"
    echo "Output: $run_dir"
    echo "Log: $log_file"

    cd "$run_dir"

    # Run Athena++ with MPI
    $MPIRUN $ATHENA_EXEC -i "$config_file" \
        > "$log_file" 2> "$err_file" || {
        echo "ERROR: $problem_id failed. Check $err_file"
        return 1
    }

    # Check if output exists
    if [ ! -d "$run_dir/outputs" ]; then
        echo "WARNING: No output directory for $problem_id"
        return 1
    fi

    echo "Completed: $problem_id"
    return 0
}

# ============================================================================
# BATCH EXECUTION
# ============================================================================

run_batch() {
    local sim_list=("$@")
    local batch_size=$SIMS_PER_BATCH

    for ((i=0; i<${#sim_list[@]}; i+=batch_size)); do
        local batch=("${sim_list[@]:i:batch_size}")

        echo "=========================================="
        echo "Running batch $((i/batch_size + 1))"
        echo "Simulations in this batch: ${#batch[@]}"
        echo "=========================================="

        # Run simulations in parallel
        local pids=()
        for sim_params in "${batch[@]}"; do
            IFS=',' read -r sim_type f beta M seed <<< "$sim_params"

            local config_file=$(generate_config $sim_type $f $beta $M $seed)
            local beta_str=$beta
            if [ "$sim_type" = "hydro" ]; then
                beta_str="inf"
            fi
            local problem_id="${sim_type}_frag_f${f}_beta${beta_str}_M${M}_seed${seed}"
            local run_dir="$RUN_DIR/$sim_type/$problem_id"
            mkdir -p "$run_dir"

            local log_file="$LOG_DIR/$sim_type/${problem_id}.log"
            local err_file="$LOG_DIR/$sim_type/${problem_id}.err"

            # Run in background
            (
                cd "$run_dir"
                $MPIRUN $ATHENA_EXEC -i "$config_file" \
                    > "$log_file" 2> "$err_file"
            ) &
            pids+=($!)
        done

        # Wait for all simulations in batch to complete
        for pid in "${pids[@]}"; do
            wait $pid || {
                echo "WARNING: Some simulations in batch failed"
            }
        done

        echo "Batch completed"
        sleep 5  # Brief pause between batches
    done
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

main() {
    echo "Starting T2 Power-law Discrepancy Campaign..."
    echo "Start time: $(date)"

    # Phase 1: Hydrodynamic simulations (baseline)
    echo ""
    echo "=========================================="
    echo "Phase 1: Hydrodynamic simulations ($N_HYDRO)"
    echo "=========================================="

    local hydro_sims=()
    for f in "${F_VALUES[@]}"; do
        for M in "${M_VALUES[@]}"; do
            for seed in "${SEEDS[@]}"; do
                hydro_sims+=("hydro,$f,inf,$M,$seed")
            done
        done
    done

    run_batch "${hydro_sims[@]}"

    # Phase 2: MHD comparison simulations
    echo ""
    echo "=========================================="
    echo "Phase 2: MHD comparison simulations ($N_MHD)"
    echo "=========================================="

    local mhd_sims=()
    for beta in "${BETA_MHD[@]}"; do
        for f in "${F_VALUES[@]}"; do
            for M in "${M_VALUES[@]}"; do
                for seed in "${SEEDS[@]}"; do
                    mhd_sims+=("mhd,$f,$beta,$M,$seed")
                done
            done
        done
    done

    run_batch "${mhd_sims[@]}"

    echo ""
    echo "=========================================="
    echo "T2 Campaign completed!"
    echo "End time: $(date)"
    echo "=========================================="

    # Generate summary
    local completed=0
    local failed=0

    for sim_params in "${hydro_sims[@]}" "${mhd_sims[@]}"; do
        IFS=',' read -r sim_type f beta M seed <<< "$sim_params"
        local beta_str=$beta
        if [ "$sim_type" = "hydro" ]; then
            beta_str="inf"
        fi
        local problem_id="${sim_type}_frag_f${f}_beta${beta_str}_M${M}_seed${seed}"
        local run_dir="$RUN_DIR/$sim_type/$problem_id"

        if [ -d "$run_dir/outputs" ]; then
            ((completed++))
        else
            ((failed++))
            echo "FAILED: $problem_id"
        fi
    done

    echo "Summary:"
    echo "  Completed: $completed / $TOTAL_SIMS"
    echo "  Failed: $failed / $TOTAL_SIMS"
}

# ============================================================================
# CLEANUP AND RESTART
# ============================================================================

cleanup() {
    echo "Cleaning up temporary files..."
    # Add cleanup logic here if needed
}

restart_failed() {
    echo "Restarting failed simulations..."

    local failed_sims=()

    # Check hydro simulations
    for f in "${F_VALUES[@]}"; do
        for M in "${M_VALUES[@]}"; do
            for seed in "${SEEDS[@]}"; do
                local problem_id="hydro_frag_f${f}_betaInf_M${M}_seed${seed}"
                local run_dir="$RUN_DIR/hydro/$problem_id"

                if [ ! -d "$run_dir/outputs" ]; then
                    failed_sims+=("hydro,$f,inf,$M,$seed")
                fi
            done
        done
    done

    # Check MHD simulations
    for beta in "${BETA_MHD[@]}"; do
        for f in "${F_VALUES[@]}"; do
            for M in "${M_VALUES[@]}"; do
                for seed in "${SEEDS[@]}"; do
                    local problem_id="mhd_frag_f${f}_beta${beta}_M${M}_seed${seed}"
                    local run_dir="$RUN_DIR/mhd/$problem_id"

                    if [ ! -d "$run_dir/outputs" ]; then
                        failed_sims+=("mhd,$f,$beta,$M,$seed")
                    fi
                done
            done
        done
    done

    if [ ${#failed_sims[@]} -gt 0 ]; then
        echo "Found ${#failed_sims[@]} failed simulations"
        run_batch "${failed_sims[@]}"
    else
        echo "No failed simulations found"
    fi
}

# ============================================================================
# SCRIPT ENTRY POINT
# ============================================================================

# Parse command line arguments
case "${1:-run}" in
    run)
        main
        ;;
    cleanup)
        cleanup
        ;;
    restart)
        restart_failed
        ;;
    test)
        echo "Running test simulation..."
        generate_config "hydro" 1.5 "inf" 1.0 0
        local test_config="$CONFIG_DIR/athinput_hydro_frag_f1.5_betaInf_M1.0_seed0"
        echo "Test config: $test_config"
        echo "Would run: $MPIRUN $ATHENA_EXEC -i $test_config"
        echo ""
        echo "MHD test config:"
        generate_config "mhd" 1.5 1.0 1.0 0
        local test_mhd_config="$CONFIG_DIR/athinput_mhd_frag_f1.5_beta1.0_M1.0_seed0"
        echo "Test config: $test_mhd_config"
        ;;
    *)
        echo "Usage: $0 {run|cleanup|restart|test}"
        echo ""
        echo "Commands:"
        echo "  run      - Run full campaign (default)"
        echo "  cleanup  - Clean temporary files"
        echo "  restart  - Restart failed simulations"
        echo "  test     - Test configuration generation"
        exit 1
        ;;
esac

exit 0
