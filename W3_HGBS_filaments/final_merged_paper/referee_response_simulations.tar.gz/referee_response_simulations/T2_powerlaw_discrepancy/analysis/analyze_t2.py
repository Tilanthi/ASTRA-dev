#!/usr/bin/env python3
"""
T2 Power-law Discrepancy Campaign Analysis
Analyzes hydrodynamic vs MHD simulations to isolate flux-freezing contribution

This script:
1. Measures fragmentation times for all simulations
2. Fits power-law scaling: 1/t_frag ∝ f^α
3. Compares α_hydro vs α_MHD(β)
4. Isolates flux-freezing contribution to α discrepancy
"""

import numpy as np
import h5py
import matplotlib.pyplot as plt
from pathlib import Path
import pandas as pd
from scipy.optimize import curve_fit
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

# ============================================================================
# CONFIGURATION
# ============================================================================
CAMPAIGN_DIR = Path("/path/to/workdir/T2_powerlaw_discrepancy")
OUTPUT_DIR = CAMPAIGN_DIR / "outputs"
RUN_DIR = CAMPAIGN_DIR / "runs"
ANALYSIS_DIR = CAMPAIGN_DIR / "analysis"
RESULTS_DIR = ANALYSIS_DIR / "results"
FIGURES_DIR = ANALYSIS_DIR / "figures"

# Create directories
RESULTS_DIR.mkdir(exist_ok=True, parents=True)
FIGURES_DIR.mkdir(exist_ok=True, parents=True)

# Simulation parameters
F_VALUES = [1.1, 1.3, 1.5, 2.0, 2.5, 3.0]
BETA_MHD = [0.3, 1.0, 5.0]
M_VALUES = [1.0, 2.0]
SEEDS = [0, 1, 2]

# Theoretical values
ALPHA_THEORY = 0.50  # Linear theory prediction
ALPHA_PAPER = 0.39  # From paper

# ============================================================================
# FRAGMENTATION TIME MEASUREMENT
# ============================================================================

def measure_fragmentation_time(sim_id, sim_type):
    """
    Measure fragmentation time from simulation output.

    Fragmentation defined as when longitudinal density variance
    exceeds threshold (10x initial variance).

    Parameters
    ----------
    sim_id : str
        Simulation ID
    sim_type : str
        'hydro' or 'mhd'

    Returns
    -------
    float or None
        Fragmentation time in code units, or None if not fragmented
    """
    output_path = OUTPUT_DIR / sim_type / sim_id

    # Read HDF5 outputs
    hdf5_files = sorted(output_path.glob("*.hdf5"))

    if len(hdf5_files) == 0:
        print(f"Warning: No outputs for {sim_id}")
        return None

    times = []
    variances = []

    for snapshot in hdf5_files:
        try:
            with h5py.File(snapshot, 'r') as hf:
                t = hf['Attributes'].get('Time', 0.0)
                rho = hf['dens'][:]

                # Compute longitudinal density variance
                variance = compute_longitudinal_variance(rho)

                times.append(t)
                variances.append(variance)
        except:
            continue

    times = np.array(times)
    variances = np.array(variances)

    if len(times) == 0:
        return None

    # Initial variance
    var_initial = variances[0]
    threshold = 10.0 * var_initial

    # Find when variance exceeds threshold
    frag_indices = np.where(variances > threshold)[0]

    if len(frag_indices) == 0:
        return None  # No fragmentation

    # Interpolate to get precise fragmentation time
    i_frag = frag_indices[0]

    if i_frag == 0:
        return times[0]

    # Linear interpolation
    t_frag = times[i_frag-1] + (times[i_frag] - times[i_frag-1]) * \
             (threshold - variances[i_frag-1]) / \
             (variances[i_frag] - variances[i_frag-1])

    return float(t_frag)

def compute_longitudinal_variance(rho):
    """
    Compute longitudinal density variance.

    Averages over transverse directions to get 1D profile,
    then computes variance along filament axis.
    """
    # Average over y and z directions
    rho_1d = rho.mean(axis=(1, 2))

    # Compute variance
    variance = rho_1d.var()

    return float(variance)

def verify_fragmentation(sim_id, sim_type, t_frag):
    """
    Verify fragmentation by checking for density peaks.

    Uses peak-finding algorithm to detect ≥3 longitudinal peaks.
    """
    output_path = OUTPUT_DIR / sim_type / sim_id

    # Find snapshot closest to t_frag
    hdf5_files = sorted(output_path.glob("*.hdf5"))

    snapshot = find_closest_snapshot_by_time(hdf5_files, t_frag)

    if snapshot is None:
        return False

    try:
        with h5py.File(snapshot, 'r') as hf:
            rho = hf['dens'][:]

            # Extract longitudinal profile
            rho_1d = rho.mean(axis=(1, 2))

            # Find peaks
            peaks = find_peaks(rho_1d)

            return len(peaks) >= 3
    except:
        return False

def find_closest_snapshot_by_time(hdf5_files, target_time):
    """Find HDF5 snapshot closest to target time."""
    times = []
    for f in hdf5_files:
        try:
            with h5py.File(f, 'r') as hf:
                t = hf['Attributes'].get('Time', 0.0)
                times.append((f, t))
        except:
            continue

    if not times:
        return None

    closest = min(times, key=lambda x: abs(x[1] - target_time))
    return closest[0]

def find_peaks(profile, min_distance=10, min_height=0.1):
    """Simple peak finding algorithm."""
    from scipy.signal import find_peaks

    peaks, _ = find_peaks(profile, distance=min_distance, height=min_height)

    return peaks

# ============================================================================
# POWER-LAW FITTING
# ============================================================================

def fit_power_law(f_values, t_frag_values):
    """
    Fit power-law scaling: 1/t_frag = A * f^α

    Returns
    -------
    dict
        Fit parameters: alpha, A, r_squared, etc.
    """
    # Remove any None values
    mask = np.array([t is not None for t in t_frag_values])
    f_fit = np.array(f_values)[mask]
    t_fit = np.array(t_frag_values)[mask]

    if len(f_fit) < 3:
        return None  # Need at least 3 points for fit

    # Linear regression in log-space
    log_y = np.log(1.0 / t_fit)
    log_x = np.log(f_fit)

    # Fit: log(1/t) = log(A) + α * log(f)
    slope, intercept, r_value, p_value, std_err = stats.linregress(log_x, log_y)

    alpha = slope
    A = np.exp(intercept)
    r_squared = r_value ** 2
    alpha_std = std_err

    # Compute fit quality
    y_pred = intercept + slope * log_x
    residuals = log_y - y_pred
    chi2 = np.sum(residuals**2)
    dof = len(f_fit) - 2

    return {
        'alpha': alpha,
        'A': A,
        'r_squared': r_squared,
        'alpha_std': alpha_std,
        'p_value': p_value,
        'chi2': chi2,
        'dof': dof,
        'n_points': len(f_fit),
        'f_values': f_fit,
        't_frag_values': t_fit
    }

def fit_all_scaling_relations():
    """
    Fit power-law scaling for all parameter combinations.

    Returns
    -------
    dict
        All fit results organized by (sim_type, beta, M, seed)
    """
    all_results = {}

    # Hydrodynamic simulations
    print("\nFitting hydrodynamic scaling relations...")
    for M in M_VALUES:
        for seed in SEEDS:
            # Collect data for this (M, seed)
            f_values = []
            t_frag_values = []

            for f in F_VALUES:
                sim_id = f"hydro_frag_f{f}_betaInf_M{M}_seed{seed}"
                t_frag = measure_fragmentation_time(sim_id, 'hydro')

                if verify_fragmentation(sim_id, 'hydro', t_frag):
                    f_values.append(f)
                    t_frag_values.append(t_frag)

            # Fit scaling
            fit_result = fit_power_law(f_values, t_frag_values)

            if fit_result is not None:
                key = ('hydro', 'inf', M, seed)
                all_results[key] = fit_result
                print(f"  hydro, β=∞, M={M}, seed={seed}: α = {fit_result['alpha']:.3f} ± {fit_result['alpha_std']:.3f}")

    # MHD simulations
    print("\nFitting MHD scaling relations...")
    for beta in BETA_MHD:
        for M in M_VALUES:
            for seed in SEEDS:
                # Collect data for this (beta, M, seed)
                f_values = []
                t_frag_values = []

                for f in F_VALUES:
                    sim_id = f"mhd_frag_f{f}_beta{beta}_M{M}_seed{seed}"
                    t_frag = measure_fragmentation_time(sim_id, 'mhd')

                    if verify_fragmentation(sim_id, 'mhd', t_frag):
                        f_values.append(f)
                        t_frag_values.append(t_frag)

                # Fit scaling
                fit_result = fit_power_law(f_values, t_frag_values)

                if fit_result is not None:
                    key = ('mhd', beta, M, seed)
                    all_results[key] = fit_result
                    print(f"  mhd, β={beta}, M={M}, seed={seed}: α = {fit_result['alpha']:.3f} ± {fit_result['alpha_std']:.3f}")

    return all_results

# ============================================================================
# FLUX-FREEZING ANALYSIS
# ============================================================================

def analyze_flux_freezing_contribution(all_results):
    """
    Analyze flux-freezing contribution to α discrepancy.

    Decomposes: Δα_total = Δα_flux + Δα_other

    Where:
    - Δα_total = α_theory - α_MHD(β) = 0.11
    - Δα_flux = α_hydro - α_MHD(β → ∞)
    - Δα_other = α_theory - α_hydro
    """
    # Extract hydro results
    hydro_alphas = []
    for key, result in all_results.items():
        if key[0] == 'hydro':
            hydro_alphas.append(result['alpha'])

    if len(hydro_alphas) == 0:
        print("Warning: No hydro results found")
        return None

    # Average hydro alpha
    alpha_hydro = np.mean(hydro_alphas)
    alpha_hydro_std = np.std(hydro_alphas)

    # Extract MHD results at different beta
    mhd_alphas = {}
    for beta in BETA_MHD:
        alphas = []
        for key, result in all_results.items():
            if key[0] == 'mhd' and key[1] == beta:
                alphas.append(result['alpha'])

        if len(alphas) > 0:
            mhd_alphas[beta] = {
                'mean': np.mean(alphas),
                'std': np.std(alphas),
                'n': len(alphas)
            }

    # Decompose discrepancy
    delta_alpha_total = ALPHA_THEORY - ALPHA_PAPER  # 0.11
    delta_alpha_flux = alpha_hydro - ALPHA_PAPER
    delta_alpha_other = ALPHA_THEORY - alpha_hydro

    # Fraction of discrepancy due to flux-freezing
    flux_fraction = delta_alpha_flux / delta_alpha_total if delta_alpha_total > 0 else 0

    results = {
        'alpha_hydro': alpha_hydro,
        'alpha_hydro_std': alpha_hydro_std,
        'alpha_theory': ALPHA_THEORY,
        'alpha_paper': ALPHA_PAPER,
        'mhd_alphas': mhd_alphas,
        'delta_alpha_total': delta_alpha_total,
        'delta_alpha_flux': delta_alpha_flux,
        'delta_alpha_other': delta_alpha_other,
        'flux_fraction': flux_fraction,
        'scenario': classify_scenario(alpha_hydro)
    }

    return results

def classify_scenario(alpha_hydro):
    """
    Classify which scenario best fits the data.

    Scenario A: α_hydro ≈ 0.50 (flux-freezing dominates)
    Scenario B: α_hydro ≈ 0.45 (mixed contribution)
    Scenario C: α_hydro ≈ 0.39 (non-hydro causes)
    """
    if abs(alpha_hydro - 0.50) < 0.03:
        return "A: Flux-freezing dominates"
    elif abs(alpha_hydro - 0.45) < 0.03:
        return "B: Mixed contribution"
    elif abs(alpha_hydro - 0.39) < 0.03:
        return "C: Non-hydro causes"
    else:
        return f"Intermediate: α_hydro = {alpha_hydro:.3f}"

# ============================================================================
# FIGURE GENERATION
# ============================================================================

def generate_figures(all_results, flux_analysis):
    """Generate publication-ready figures."""

    # Figure T2-1: Hydrodynamic scaling baseline
    fig, ax = plt.subplots(figsize=(8, 6))

    # Plot 1/t_frag vs f for hydro
    for M in M_VALUES:
        for seed in [0]:  # Plot one seed for clarity
            key = ('hydro', 'inf', M, seed)
            if key in all_results:
                result = all_results[key]
                f_vals = result['f_values']
                t_vals = result['t_frag_values']

                ax.plot(f_vals, 1.0/t_vals, 'o-',
                       label=f'M = {M}', markersize=8)

                # Plot fit
                f_fine = np.linspace(min(f_vals), max(f_vals), 50)
                t_fit = result['A'] * f_fine ** result['alpha']
                ax.plot(f_fine, t_fit, '--',
                       label=f'Fit: α = {result["alpha"]:.3f}')

    ax.set_xlabel('Line-mass fraction f')
    ax.set_ylabel('1/t$_{frag}$ (code units)')
    ax.set_title('Hydrodynamic Scaling Baseline')
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.savefig(FIGURES_DIR / 'T2-1_hydro_scaling.png',
                dpi=300, bbox_inches='tight')
    plt.close()

    # Figure T2-2: α(β) dependence with hydro point
    if flux_analysis is not None:
        fig, ax = plt.subplots(figsize=(8, 6))

        # Plot MHD points
        betas = sorted(flux_analysis['mhd_alphas'].keys())
        alpha_means = [flux_analysis['mhd_alphas'][b]['mean'] for b in betas]
        alpha_stds = [flux_analysis['mhd_alphas'][b]['std'] for b in betas]

        ax.errorbar(betas, alpha_means, yerr=alpha_stds,
                   fmt='s-', color='blue', markersize=10,
                   capsize=5, label='MHD')

        # Plot hydro point at β = ∞
        beta_plot = [100]  # Large value for plot
        ax.errorbar(beta_plot, [flux_analysis['alpha_hydro']],
                   yerr=[flux_analysis['alpha_hydro_std']],
                   fmt='ro', markersize=12, capsize=5,
                   label='Hydrodynamic (β = ∞)')

        # Plot theoretical value
        ax.axhline(y=ALPHA_THEORY, color='green', linestyle='--',
                  label=f'Theory (α = {ALPHA_THEORY})')

        # Plot paper value
        ax.axhline(y=ALPHA_PAPER, color='red', linestyle=':',
                  label=f'Paper (α = {ALPHA_PAPER})')

        ax.set_xlabel('Plasma beta β')
        ax.set_ylabel('Power-law exponent α')
        ax.set_title('α(β) Dependence: Flux-Freezing Effect')
        ax.set_xscale('log')
        ax.set_xlim(0.1, 1000)
        ax.legend()
        ax.grid(True, alpha=0.3)
        fig.savefig(FIGURES_DIR / 'T2-2_alpha_beta_dependence.png',
                    dpi=300, bbox_inches='tight')
        plt.close()

    # Figure T2-3: Mechanism decomposition
    if flux_analysis is not None:
        fig, ax = plt.subplots(figsize=(8, 6))

        categories = ['Flux-Freezing\nContribution',
                     'Other Mechanisms\nContribution']
        contributions = [flux_analysis['delta_alpha_flux'],
                        flux_analysis['delta_alpha_other']]
        colors = ['blue' if flux_analysis['delta_alpha_flux'] > 0 else 'gray',
                 'orange']

        bars = ax.bar(categories, contributions, color=colors,
                     alpha=0.7, edgecolor='black')

        ax.axhline(y=flux_analysis['delta_alpha_total'],
                  color='red', linestyle='--', linewidth=2,
                  label=f'Total discrepancy = {flux_analysis["delta_alpha_total"]:.3f}')

        ax.set_ylabel('Δα contribution')
        ax.set_title(f'Mechanism Decomposition\n'
                    f'Scenario: {flux_analysis["scenario"]}')
        ax.legend()

        # Add value labels on bars
        for bar, val in zip(bars, contributions):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{val:.3f}',
                   ha='center', va='bottom' if height > 0 else 'top',
                   fontsize=12, fontweight='bold')

        fig.savefig(FIGURES_DIR / 'T2-3_mechanism_decomposition.png',
                    dpi=300, bbox_inches='tight')
        plt.close()

    print("Figures generated successfully")

# ============================================================================
# MAIN ANALYSIS
# ============================================================================

def main():
    """Run complete T2 analysis."""
    print("=" * 60)
    print("T2 Power-law Discrepancy Campaign Analysis")
    print("=" * 60)

    # Measure fragmentation times
    print("\n1. Measuring fragmentation times...")
    print("   (This may take a while...)")

    # Fit all scaling relations
    print("\n2. Fitting power-law scaling relations...")
    all_results = fit_all_scaling_relations()

    print(f"\n   Total fits: {len(all_results)}")

    # Analyze flux-freezing contribution
    print("\n3. Analyzing flux-freezing contribution...")
    flux_analysis = analyze_flux_freezing_contribution(all_results)

    if flux_analysis is not None:
        print(f"\n   α_hydro = {flux_analysis['alpha_hydro']:.3f} ± {flux_analysis['alpha_hydro_std']:.3f}")
        print(f"   α_theory = {flux_analysis['alpha_theory']:.3f}")
        print(f"   α_paper = {flux_analysis['alpha_paper']:.3f}")
        print(f"\n   Δα_total = {flux_analysis['delta_alpha_total']:.3f}")
        print(f"   Δα_flux = {flux_analysis['delta_alpha_flux']:.3f}")
        print(f"   Δα_other = {flux_analysis['delta_alpha_other']:.3f}")
        print(f"\n   Flux-freezing fraction: {flux_analysis['flux_fraction']:.1%}")
        print(f"   Scenario: {flux_analysis['scenario']}")

        # Save results
        results_df = pd.DataFrame({
            'beta': ['inf'] + sorted(flux_analysis['mhd_alphas'].keys()),
            'type': ['hydro'] + ['mhd'] * len(flux_analysis['mhd_alphas']),
            'alpha_mean': [flux_analysis['alpha_hydro']] +
                          [flux_analysis['mhd_alphas'][b]['mean']
                           for b in sorted(flux_analysis['mhd_alphas'].keys())],
            'alpha_std': [flux_analysis['alpha_hydro_std']] +
                         [flux_analysis['mhd_alphas'][b]['std']
                          for b in sorted(flux_analysis['mhd_alphas'].keys())]
        })

        results_df.to_csv(RESULTS_DIR / 'alpha_beta_results.csv',
                         index=False)

    # Generate figures
    print("\n4. Generating figures...")
    generate_figures(all_results, flux_analysis)

    # Generate summary report
    print("\n5. Generating summary report...")
    generate_summary_report(all_results, flux_analysis)

    print("\n" + "=" * 60)
    print("Analysis complete!")
    print("=" * 60)

def generate_summary_report(all_results, flux_analysis):
    """Generate text summary report."""
    report_path = RESULTS_DIR / 'T2_analysis_report.txt'

    with open(report_path, 'w') as f:
        f.write("T2 POWER-LAW DISCREPANCY CAMPAIGN ANALYSIS REPORT\n")
        f.write("=" * 60 + "\n\n")

        f.write("FLUX-FREEZING ANALYSIS RESULTS\n")
        f.write("-" * 40 + "\n")

        if flux_analysis is not None:
            f.write(f"α_hydro = {flux_analysis['alpha_hydro']:.3f} ± {flux_analysis['alpha_hydro_std']:.3f}\n")
            f.write(f"α_theory = {flux_analysis['alpha_theory']:.3f}\n")
            f.write(f"α_paper = {flux_analysis['alpha_paper']:.3f}\n\n")

            f.write(f"Δα_total = {flux_analysis['delta_alpha_total']:.3f}\n")
            f.write(f"Δα_flux = {flux_analysis['delta_alpha_flux']:.3f}\n")
            f.write(f"Δα_other = {flux_analysis['delta_alpha_other']:.3f}\n\n")

            f.write(f"Flux-freezing contribution: {flux_analysis['flux_fraction']:.1%}\n")
            f.write(f"Scenario: {flux_analysis['scenario']}\n\n")

            f.write("MHD RESULTS\n")
            f.write("-" * 40 + "\n")
            for beta, data in sorted(flux_analysis['mhd_alphas'].items()):
                f.write(f"β = {beta}: α = {data['mean']:.3f} ± {data['std']:.3f} (n={data['n']})\n")

        f.write("\n\nCONCLUSIONS\n")
        f.write("-" * 40 + "\n")

        if flux_analysis is None:
            f.write("Insufficient data for analysis.\n")
        elif flux_analysis['scenario'].startswith("A"):
            f.write("SCENARIO A: Flux-freezing dominates\n\n")
            f.write("The discrepancy is primarily due to magnetic field effects.\n")
            f.write("Linear theory is correct for hydrodynamics.\n")
            f.write("MHD correction is well-understood.\n")
        elif flux_analysis['scenario'].startswith("B"):
            f.write("SCENARIO B: Mixed contribution\n\n")
            f.write("Both flux-freezing and other mechanisms contribute.\n")
            f.write("Further investigation needed for non-hydro effects.\n")
        elif flux_analysis['scenario'].startswith("C"):
            f.write("SCENARIO C: Non-hydro causes\n\n")
            f.write("Flux-freezing is NOT the primary cause.\n")
            f.write("Must investigate non-linear density evolution\n")
            f.write("or finite domain effects.\n")
        else:
            f.write(f"INTERMEDIATE RESULT: {flux_analysis['scenario']}\n\n")
            f.write("Further analysis needed.\n")

    print(f"Report saved to {report_path}")

if __name__ == "__main__":
    main()
