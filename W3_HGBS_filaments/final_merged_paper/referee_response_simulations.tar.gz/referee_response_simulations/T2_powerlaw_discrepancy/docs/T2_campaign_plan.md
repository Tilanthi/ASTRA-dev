# T2: Power-law Exponent Discrepancy - Hydro vs MHD Test
## Isolating Flux-Freezing Contribution to α = 0.39 vs α_theory = 0.5

### Scientific Motivation
The paper reports a power-law scaling:
```
1/t_frag ∝ f^α
with α = 0.39 ± 0.01 (r² = 0.999)
```

Linear theory predicts α = 0.5, giving an 18-22% discrepancy that remains unexplained.

**Candidate mechanisms**:
1. **Flux-freezing**: Magnetic field inhibits collapse, modifying scaling
2. **Non-linear density evolution**: ρ(t) deviates from linear theory
3. **Finite domain effects**: Discrete wavenumber spectrum affects growth

**Existing clue**: β-dependence test shows α(β=0.3) = 0.35 vs α(β=5.0) = 0.40, suggesting flux-freezing contributes but is not dominant.

**Key test**: Pure hydrodynamic simulations (β → ∞) will isolate flux-freezing contribution:
- If α_hydro ≈ 0.39: Flux-freezing NOT the primary cause (rules out mechanism #1)
- If α_hydro ≈ 0.45: Flux-freezing contributes significantly
- If α_hydro ≈ 0.50: Flux-freezing is the primary cause

### Campaign Design

#### Physics Parameters
```
Hydrodynamic Simulations (β = ∞):
├── Line-mass fraction f: [1.1, 1.3, 1.5, 2.0, 2.5, 3.0]
│   └── Full range from near-critical to highly supercritical
├── Mach number M: [1.0, 2.0]
│   └── Subsonic and transonic turbulence
└── Random seeds: [0, 1, 2]
    └── 3 seeds for statistical robustness

Total hydro simulations: 6 × 2 × 3 = 36

MHD Comparison Simulations:
├── Plasma beta β: [0.3, 1.0, 5.0]
│   ├── β = 0.3: Strong field (maximum flux-freezing effect)
│   ├── β = 1.0: Moderate field
│   └── β = 5.0: Weak field (minimum flux-freezing effect)
├── Line-mass fraction f: [1.1, 1.3, 1.5, 2.0, 2.5, 3.0]
├── Mach number M: [1.0, 2.0]
└── Random seeds: [0, 1, 2]

Total MHD simulations: 3 × 6 × 2 × 3 = 108

Campaign total: 144 simulations
Expected runtime: ~1 week on 220 CPUs
```

#### Simulation Configuration
**Hydrodynamic runs**:
```python
# athinput.hydro
<job>
problem_id = hydro_frag_f{f}_M{M}_s{seed}
```

**MHD comparison runs**:
```python
# athinput.mhd
<job>
problem_id = mhd_frag_f{f}_beta{beta}_M{M}_s{seed}
```

**Key difference**: Disable magnetic field in hydro runs
```python
# Hydro: <mesh> block
x1_min = -4.0  # Lx/2 in code units
x1_max = 4.0
x2_min = -1.0
x3_min = -1.0

# MHD: Same domain, but with magnetic field initialization
<hydro>
hsfc_eta = 0.0           # Disable magnetic diffusion for ideal MHD
```

### Key Measurements

#### 1. Fragmentation Time t_frag
For each simulation, measure:
```python
t_frag = time when longitudinal density variance exceeds threshold

Method:
1. Compute longitudinal density profile: ρ(x, y=0, z=0, t)
2. Calculate variance: σ_ρ²(t) = Var(ρ(x))
3. Identify fragmentation: σ_ρ²(t_frag) / σ_ρ²(0) > 10
4. Verify: Peak-finding algorithm detects ≥3 peaks
```

#### 2. Power-law Fit
Fit scaling relation:
```python
1/t_frag = A * f^α

Method:
1. Compute t_frag for all f at fixed (β, M, seed)
2. Perform linear regression in log-space:
   log(1/t_frag) = log(A) + α * log(f)
3. Extract α and uncertainty σ_α
4. Compute goodness-of-fit: r², χ²
```

#### 3. α(β) Dependence
Compare exponents across magnetic field strength:
```python
α(β) for:
- β = ∞ (hydro, no field)
- β = 5.0 (weak field)
- β = 1.0 (moderate field)
- β = 0.3 (strong field)

Test: Is α(β) monotonically decreasing with β?
If yes: Flux-freezing contributes
If no: Other mechanisms dominate
```

### Analysis Strategy

#### Phase 1: Hydrodynamic Baseline
```python
# Fit hydrodynamic scaling:
1. For each (M, seed), fit α_hydro(f)
2. Average across seeds: ⟨α_hydro⟩(M)
3. Compare with theoretical value: α_theory = 0.5

# Expected outcomes:
- α_hydro ≈ 0.50 ± 0.02: Rules out flux-freezing as primary cause
- α_hydro ≈ 0.45 ± 0.02: Flux-freezing contributes ~50%
- α_hydro ≈ 0.39 ± 0.02: Flux-freezing is NOT the cause
```

#### Phase 2: Magnetic Field Dependence
```python
# Fit MHD scaling:
1. For each (β, M, seed), fit α_MHD(f, β)
2. Plot α_MHD vs β
3. Fit model: α(β) = α_hydro + Δα * f_mag(β)

# Magnetic fraction model:
f_mag(β) = 1 / (1 + β/β_crit)

# Test: Does Δα ≈ 0?
If yes: Flux-freezing negligible
If no: Flux-freezing contributes
```

#### Phase 3: Mechanism Isolation
```python
# Decompose discrepancy:
Δα_total = α_theory - α_MHD = 0.50 - 0.39 = 0.11

# Partition contributions:
Δα_total = Δα_flux + Δα_other

Where:
Δα_flux = α_hydro - α_MHD(β → ∞)
Δα_other = α_theory - α_hydro

# Test scenarios:
Scenario A: α_hydro = 0.50 → Δα_flux = 0.11, Δα_other = 0.00
              → Flux-freezing is 100% of discrepancy

Scenario B: α_hydro = 0.45 → Δα_flux = 0.06, Δα_other = 0.05
              → Flux-freezing is ~55% of discrepancy

Scenario C: α_hydro = 0.39 → Δα_flux = 0.00, Δα_other = 0.11
              → Flux-freezing is 0% of discrepancy
```

### Expected Outcomes

#### Scenario A: Flux-Freezing Dominates (α_hydro ≈ 0.50)
**Physical interpretation**: Magnetic field inhibition of collapse is the primary cause of discrepancy

**Implications**:
- Discrepancy explained by well-understood MHD physics
- Linear theory correct for pure hydrodynamics
- Paper discussion: Emphasize magnetic field effects

**Additional tests**:
- Verify flux-freezing timescale: t_FF ∝ (B²/4πρ)^(-1/2)
- Check correlation: α(β) vs magnetic pressure/thermal pressure

#### Scenario B: Mixed Contribution (α_hydro ≈ 0.45)
**Physical interpretation**: Both flux-freezing and non-linear effects contribute

**Implications**:
- Partial explanation through flux-freezing
- Remaining discrepancy requires other mechanisms
- Paper discussion: Multi-cause explanation

**Additional tests**:
- Measure non-linear density evolution: ρ_central(t) vs linear theory
- Check finite domain effects: wavenumber spectrum analysis

#### Scenario C: Non-Hydro Causes (α_hydro ≈ 0.39)
**Physical interpretation**: Discrepancy persists without magnetic field

**Implications**:
- Flux-freezing ruled out as primary cause
- Must investigate non-linear density evolution or finite domain effects
- Paper discussion: Honest assessment of open question

**Additional tests**:
- Density evolution analysis: ρ_central(t) vs ρ_linear(t)
- Domain size convergence: L = [4, 8, 16] λ_J
- Higher-order effects: Beyond linear perturbation theory

### Computational Resources

#### Simulation Requirements
```
Resolution: 256^3 (sufficient for fragmentation time)
Domain: L = 8 λ_J × 2 λ_J × 2 λ_J
Duration: t = 0 to 2.0 t_ff (or fragmentation)
Output: ~5 GB per simulation (hydro simpler than MHD)

Total: 144 × 5 GB = 720 GB (raw outputs)
Compressed: ~150 GB (analysis products)
```

#### CPU Allocation
```
Parallel efficiency: 200 cores effective (91% of 220)
Walltime per simulation: ~8 hours (hydro faster than MHD)
Total: 144 × 8 = 1152 core-hours ≈ 6 days on 200 cores

Buffer for analysis: 7 days total
```

### Deliverables

#### Data Products
1. **Fragmentation catalog**: t_frag for all simulations
2. **Scaling fits**: α values and uncertainties for all (β, M) combinations
3. **Comparison database**: Hydro vs MHD results
4. **Analysis notebooks**: Jupyter notebooks for reproducible analysis

#### Publication Figures
1. **Figure T2-1**: 1/t_frag vs f for hydro (baseline scaling)
2. **Figure T2-2**: α(β) dependence showing hydro point at β = ∞
3. **Figure T2-3**: Mechanism decomposition (Δα_flux vs Δα_other)
4. **Figure T2-4**: Fragmentation time comparison: hydro vs MHD

#### Paper Revision Content
- New section: "Power-law scaling: Hydrodynamic baseline and magnetic effects"
- Updated discussion: Flux-freezing contribution quantified
- Revised open question: Remaining discrepancy after flux-freezing removal
- Supplementary material: Detailed hydrodynamic comparison

### Timeline
```
Week 1: Setup hydro configuration, test runs (5 simulations)
Week 2: Hydro production runs (36 simulations)
Week 3: MHD comparison runs (108 simulations)
Week 4: Analysis and figure generation
Week 5: Paper revision and supplementary material
```

### Risk Mitigation

#### Technical Risks
- **Risk**: Hydro simulations fragment differently than MHD
- **Mitigation**: Use identical IC generation, only disable B-field

- **Risk**: Fragmentation detection algorithm tuned for MHD
- **Mitigation**: Test detection threshold on hydro runs

- **Risk**: Insufficient statistics for α measurement
- **Mitigation**: 3 seeds per point gives robust uncertainty

#### Scientific Risks
- **Risk**: α_hydro = 0.39 (no improvement in understanding)
- **Mitigation**: This is still valuable (rules out flux-freezing)

- **Risk**: α_hydro shows large scatter (inconclusive)
- **Mitigation**: Increase parameter space, test additional mechanisms

- **Risk**: Hydro runs fail to fragment in some regimes
- **Mitigation**: Extend simulation duration, check IC robustness

### Success Criteria
1. **Primary**: α_hydro measured with ≤0.03 uncertainty (distinguishes scenarios)
2. **Secondary**: Clear understanding of flux-freezing contribution
3. **Tertiary**: Publication-ready results for referee response

### Expected Impact

#### If α_hydro ≈ 0.50 (Scenario A)
- **Major result**: Flux-freezing identified as primary cause
- **Theory impact**: Confirms linear theory for hydro, MHD correction well-understood
- **Paper impact**: Resolves "open question" cleanly
- **Publication potential**: High-impact follow-up paper on magnetic effects

#### If α_hydro ≈ 0.45 (Scenario B)
- **Important result**: Quantifies flux-freezing contribution
- **Theory impact**: Partial explanation, identifies need for additional mechanisms
- **Paper impact**: Improves discussion with concrete numbers
- **Publication potential**: Solid contribution to understanding

#### If α_hydro ≈ 0.39 (Scenario C)
- **Negative result**: Rules out flux-freezing as primary cause
- **Theory impact**: Identifies genuine gap in understanding
- **Paper impact**: Honest assessment of open question (valuable!)
- **Publication potential**: "What doesn't work" is still science

### Follow-up Studies

Depending on outcome, next steps:

**If Scenario A (flux-freezing dominates)**:
- Extend to wider β range: β ∈ [0.1, 10]
- Analytical model: α(β) from flux-freezing timescale
- Application: Predict α for different field strengths

**If Scenario B (mixed contribution)**:
- Investigate non-linear density evolution
- Test finite domain effects systematically
- Higher-order perturbation theory

**If Scenario C (non-hydro causes)**:
- Detailed density evolution analysis
- Domain size convergence study
- Beyond-linear-theory calculations

### Connection to Existing Results

This campaign directly extends the paper's existing analysis:

**Existing result**: α(β=0.3) = 0.35 vs α(β=5.0) = 0.40
**New test**: α(β=∞) = ?
**Question**: Does the trend continue to hydro limit?

**Existing result**: α = 0.39 ± 0.01 (r² = 0.999)
**New test**: Is this deviation from 0.50 due to flux-freezing?
**Question**: What is α without flux-freezing?

By answering these questions, we provide the referee with concrete progress on the "open question" rather than just acknowledging it.
