# Referee Response Simulation Package - Setup Guide

## Quick Setup on Your Ray Cluster

### 1. Extract the Package
```bash
cd /path/to/your/workdir
tar -xzf referee_response_simulations.tar.gz
cd referee_response_simulations
```

### 2. Install Athena++ (if not already installed)
```bash
# Download Athena++
wget https://github.com/PrincetonUniversity/athena-public-release/archive/v21.0.tar.gz
tar -xzf v21.0.tar.gz
cd athena-public-release-21.0

# Configure with required modules
./configure --prob=isothermal_filament_3d \
            --coord=cartesian \
            --flux=hllc \
            --integrator=vl2 \
            --pmemod=fft \
            --sink_particle \
            --omp

# Compile
make -j 8

# Set path
export ATHENA_ROOT=$(pwd)
```

### 3. Update Configuration
Edit the run scripts to set your paths:

**T1/scripts/run_t1_campaign.sh:**
```bash
ATHENA_ROOT="/your/path/to/athena++"
WORK_DIR="/your/path/to/workdir"
```

**T2/scripts/run_t2_campaign.sh:**
```bash
ATHENA_ROOT="/your/path/to/athena++"
WORK_DIR="/your/path/to/workdir"
```

**T1/analysis/analyze_t1.py and T2/analysis/analyze_t2.py:**
```python
CAMPAIGN_DIR = Path("/your/path/to/workdir/T1_width_normalisation")
# or
CAMPAIGN_DIR = Path("/your/path/to/workdir/T2_powerlaw_discrepancy")
```

### 4. Run Test Simulation
```bash
# Test T1
cd T1_width_normalisation/scripts
bash run_t1_campaign.sh test

# Test T2
cd ../../T2_powerlaw_discrepancy/scripts
bash run_t2_campaign.sh test
```

### 5. Run Full Campaigns
```bash
# Run T1 (2-3 weeks)
cd T1_width_normalisation/scripts
bash run_t1_campaign.sh run

# Run T2 (1 week)
cd ../../T2_powerlaw_discrepancy/scripts
bash run_t2_campaign.sh run
```

## Monitoring Progress

### Check simulation status
```bash
# Count completed simulations
ls -d ../runs/*/outputs 2>/dev/null | wc -l

# Check recent logs
tail -f ../logs/*.log

# Monitor cluster resources
top  # or htop if available
```

### Handle failures
```bash
# Restart failed simulations
bash run_t1_campaign.sh restart
# or
bash run_t2_campaign.sh restart
```

## Analysis

### After simulations complete:
```bash
# Analyze T1
cd T1_width_normalisation/analysis
python analyze_t1.py

# Analyze T2
cd ../../T2_powerlaw_discrepancy/analysis
python analyze_t2.py
```

## Expected Results

### T1 Success Metrics
- W_form/W_fil measured with ≤30% uncertainty (target: ≤20%)
- Clear width evolution timeline
- Publication-ready figures

### T2 Success Metrics
- α_hydro measured with ≤0.03 uncertainty
- Clear understanding of flux-freezing contribution
- Publication-ready α(β) plot

## Troubleshooting

### Issue: Athena++ compilation fails
**Solution**: Ensure required dependencies are installed:
```bash
# On most clusters:
module load hdf5 openmpi fftw

# Or install manually:
sudo apt-get install libhdf5-dev libopenmpi-dev libfftw3-dev
```

### Issue: Simulations run slowly
**Solution**: Check MPI configuration:
```bash
# Verify MPI installation
mpirun --version

# Test parallel execution
mpirun -np 4 hostname

# Adjust NCORES in run scripts
```

### Issue: Out of memory errors
**Solution**: Reduce memory usage:
```bash
# Reduce number of parallel simulations
SIMS_PER_BATCH=5  # instead of 10

# Or reduce resolution
# Edit config files: max_level = 1 (instead of 2)
```

### Issue: Analysis scripts fail
**Solution**: Check Python dependencies:
```bash
pip install numpy pandas matplotlib scipy h5py
```

## Contact

For issues with these simulations:
- G. J. White, Open University & RAL
- Glenn's GitHub: https://github.com/gjw255/

## Citation

When using results from these campaigns, cite:
- White et al. (2026), "Fragmentation of Interstellar Filaments: HGBS Analysis and MHD Simulations", MNRAS, in press
- Supplementary simulation campaign addressing referee concerns on width normalisation and power-law scaling
