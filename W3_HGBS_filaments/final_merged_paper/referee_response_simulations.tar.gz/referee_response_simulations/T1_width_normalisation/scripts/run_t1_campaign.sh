#!/bin/bash
# T1 Width Normalisation Campaign - Run Script
# 220 CPU Ray cluster execution script

set -e  # Exit on error

# ============================================================================
# CAMPAIGN CONFIGURATION
# ============================================================================
CAMPAIGN_NAME="T1_width_normalisation"
ATHENA_ROOT="/path/to/athena++"  # UPDATE THIS PATH
WORK_DIR="/path/to/workdir"       # UPDATE THIS PATH

# Parameter space
F_VALUES=(1.0 1.2 1.5 2.0)
BETA_VALUES=(0.5 1.0 2.0)
M_VALUES=(1.0 2.0)
SEEDS=(0 1 2)

# Compute total simulations
TOTAL_SIMS=$((${#F_VALUES[@]} * ${#BETA_VALUES[@]} * ${#M_VALUES[@]} * ${#SEEDS[@]}))
echo "=========================================="
echo "T1 Width Normalisation Campaign"
echo "Total simulations: $TOTAL_SIMS"
echo "=========================================="

# ============================================================================
# CLUSTER CONFIGURATION
# ============================================================================
# Ray cluster: 220 CPUs
# Configure for parallel execution
NCORES=180  # Effective cores (82% efficiency)
SIMS_PER_BATCH=10  # Run 10 simulations at once

# MPI configuration
MPIRUN="mpirun -np $NCORES"
ATHENA_EXEC="$ATHENA_ROOT/bin/athena++"

# ============================================================================
# DIRECTORY SETUP
# ============================================================================
CAMPAIGN_DIR="$WORK_DIR/$CAMPAIGN_NAME"
CONFIG_DIR="$CAMPAIGN_DIR/configs"
RUN_DIR="$CAMPAIGN_DIR/runs"
OUTPUT_DIR="$CAMPAIGN_DIR/outputs"
LOG_DIR="$CAMPAIGN_DIR/logs"

mkdir -p "$RUN_DIR" "$OUTPUT_DIR" "$LOG_DIR"

# ============================================================================
# SIMULATION GENERATION
# ============================================================================

generate_config() {
    local f=$1
    local beta=$2
    local M=$3
    local seed=$4

    local problem_id="filament_sink_f${f}_beta${beta}_M${M}_seed${seed}"
    local config_file="$CONFIG_DIR/athinput_${problem_id}"

    # Copy template
    cp "$CONFIG_DIR/athinput_sink_template" "$config_file"

    # Replace placeholders
    sed -i "s/{f}/$f/g" "$config_file"
    sed -i "s/{beta}/$beta/g" "$config_file"
    sed -i "s/{M}/$M/g" "$config_file"
    sed -i "s/{seed}/$seed/g" "$config_file"
    sed -i "s/{problem_id}/$problem_id/g" "$config_file"

    echo "$config_file"
}

run_simulation() {
    local config_file=$1
    local problem_id=$(basename "$config_file" | sed 's/athinput_//')

    local run_dir="$RUN_DIR/$problem_id"
    mkdir -p "$run_dir"

    local log_file="$LOG_DIR/${problem_id}.log"
    local err_file="$LOG_DIR/${problem_id}.err"

    echo "Running: $problem_id"
    echo "Config: $config_file"
    echo "Output: $run_dir"
    echo "Log: $log_file"

    cd "$run_dir"

    # Run Athena++ with MPI
    $MPIRUN $ATHENA_EXEC -i "$config_file" \
        > "$log_file" 2> "$err_file" || {
        echo "ERROR: $problem_id failed. Check $err_file"
        return 1
    }

    # Check if output exists
    if [ ! -d "$run_dir/outputs" ]; then
        echo "WARNING: No output directory for $problem_id"
        return 1
    fi

    echo "Completed: $problem_id"
    return 0
}

# ============================================================================
# BATCH EXECUTION
# ============================================================================

run_batch() {
    local sim_list=("$@")
    local batch_size=$SIMS_PER_BATCH

    for ((i=0; i<${#sim_list[@]}; i+=batch_size)); do
        local batch=("${sim_list[@]:i:batch_size}")

        echo "=========================================="
        echo "Running batch $((i/batch_size + 1))/${#sim_list[@]}"
        echo "Simulations in this batch: ${batch[*]}"
        echo "=========================================="

        # Run simulations in parallel
        local pids=()
        for sim_params in "${batch[@]}"; do
            IFS=',' read -r f beta M seed <<< "$sim_params"

            local config_file=$(generate_config $f $beta $M $seed)
            local problem_id="filament_sink_f${f}_beta${beta}_M${M}_seed${seed}"
            local run_dir="$RUN_DIR/$problem_id"
            mkdir -p "$run_dir"

            local log_file="$LOG_DIR/${problem_id}.log"
            local err_file="$LOG_DIR/${problem_id}.err"

            # Run in background
            (
                cd "$run_dir"
                $MPIRUN $ATHENA_EXEC -i "$config_file" \
                    > "$log_file" 2> "$err_file"
            ) &
            pids+=($!)
        done

        # Wait for all simulations in batch to complete
        for pid in "${pids[@]}"; do
            wait $pid || {
                echo "WARNING: Some simulations in batch failed"
            }
        done

        echo "Batch completed"
        sleep 5  # Brief pause between batches
    done
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

main() {
    echo "Starting T1 Width Normalisation Campaign..."
    echo "Start time: $(date)"

    # Generate simulation list
    local sim_list=()
    for f in "${F_VALUES[@]}"; do
        for beta in "${BETA_VALUES[@]}"; do
            for M in "${M_VALUES[@]}"; do
                for seed in "${SEEDS[@]}"; do
                    sim_list+=("${f},${beta},${M},${seed}")
                done
            done
        done
    done

    echo "Generated ${#sim_list[@]} simulations"
    echo ""

    # Run all simulations
    run_batch "${sim_list[@]}"

    echo ""
    echo "=========================================="
    echo "T1 Campaign completed!"
    echo "End time: $(date)"
    echo "=========================================="

    # Generate summary
    local completed=0
    local failed=0

    for sim_params in "${sim_list[@]}"; do
        IFS=',' read -r f beta M seed <<< "$sim_params"
        local problem_id="filament_sink_f${f}_beta${beta}_M${M}_seed${seed}"
        local run_dir="$RUN_DIR/$problem_id"

        if [ -d "$run_dir/outputs" ]; then
            ((completed++))
        else
            ((failed++))
            echo "FAILED: $problem_id"
        fi
    done

    echo "Summary:"
    echo "  Completed: $completed / $TOTAL_SIMS"
    echo "  Failed: $failed / $TOTAL_SIMS"
}

# ============================================================================
# CLEANUP AND RESTART
# ============================================================================

cleanup() {
    echo "Cleaning up temporary files..."
    # Add cleanup logic here if needed
}

restart_failed() {
    echo "Restarting failed simulations..."

    local failed_sims=()
    for f in "${F_VALUES[@]}"; do
        for beta in "${BETA_VALUES[@]}"; do
            for M in "${M_VALUES[@]}"; do
                for seed in "${SEEDS[@]}"; do
                    local problem_id="filament_sink_f${f}_beta${beta}_M${M}_seed${seed}"
                    local run_dir="$RUN_DIR/$problem_id"

                    if [ ! -d "$run_dir/outputs" ]; then
                        failed_sims+=("${f},${beta},${M},${seed}")
                    fi
                done
            done
        done
    done

    if [ ${#failed_sims[@]} -gt 0 ]; then
        echo "Found ${#failed_sims[@]} failed simulations"
        run_batch "${failed_sims[@]}"
    else
        echo "No failed simulations found"
    fi
}

# ============================================================================
# SCRIPT ENTRY POINT
# ============================================================================

# Parse command line arguments
case "${1:-run}" in
    run)
        main
        ;;
    cleanup)
        cleanup
        ;;
    restart)
        restart_failed
        ;;
    test)
        echo "Running test simulation..."
        generate_config 1.0 1.0 1.0 0
        local test_config="$CONFIG_DIR/athinput_filament_sink_f1.0_beta1.0_M1.0_seed0"
        echo "Test config: $test_config"
        echo "Would run: $MPIRUN $ATHENA_EXEC -i $test_config"
        ;;
    *)
        echo "Usage: $0 {run|cleanup|restart|test}"
        echo ""
        echo "Commands:"
        echo "  run      - Run full campaign (default)"
        echo "  cleanup  - Clean temporary files"
        echo "  restart  - Restart failed simulations"
        echo "  test     - Test configuration generation"
        exit 1
        ;;
esac

exit 0
