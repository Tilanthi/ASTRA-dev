# T1: Width Normalisation Systematic - Sink-Particle Campaign
## Reducing W_core/W_fil Uncertainty from ±50% to ±20%

### Scientific Motivation
The paper identifies W_core/W_fil ≈ 0.5 ± 0.1 as the dominant systematic uncertainty, limiting model discrimination. This ±50% uncertainty arises from:

1. **Density evolution during collapse**: Central density increases 5-10× during collapse, reducing local Jeans length
2. **Filament radial structure**: 0.1 pc is an average, not width at core formation radius
3. **Evolutionary state mismatch**: Simulations measured at fragmentation epoch, not actual core formation

**Key Insight**: Sink-particle tracking can measure filament width at the exact moment of core formation, eliminating evolutionary mismatch.

### Campaign Design

#### Physics Parameters
```
Parameter Space:
├── Line-mass fraction f: [1.0, 1.2, 1.5, 2.0]
│   ├── f = 1.0: Near-critical (baseline)
│   ├── f = 1.2: Transition zone (HGBS range)
│   ├── f = 1.5: Supercritical onset
│   └── f = 2.0: Clearly supercritical
├── Plasma beta β: [0.5, 1.0, 2.0]
│   ├── β = 0.5: Strong magnetic field
│   ├── β = 1.0: Moderate field
│   └── β = 2.0: Weak field (HGBS typical)
├── Mach number M: [1.0, 2.0]
│   ├── M = 1.0: Subsonic turbulence
│   └── M = 2.0: Transonic turbulence
└── Random seeds: [0, 1, 2]
    └── 3 seeds for IC variation

Total simulations: 4 × 3 × 2 × 3 = 72
Expected runtime: ~2-3 weeks on 220 CPUs
```

#### Sink-Particle Implementation
Athena++ sink-particle parameters:
```python
# Sink creation criteria
dens_threshold = 1e4 * n0          # 10^4 cm^-3 (typical core density)
vol_threshold = 8 * dx^3           # Minimum volume
m_threshold = 0.1 * M_jeans        # Fraction of Jeans mass

# Sink merger
merger_radius = 2 * dx             # Merger distance
merger_dens = dens_threshold       # Density threshold

# Output tracking
sink_output_dt = 0.01 * t_ff       # Frequent output during formation
```

### Key Measurements

#### 1. Width at Sink Formation
For each sink particle, record:
- Formation time t_form
- Filament width W_form (measured at formation radius)
- Central density ρ_central(t_form)
- Background density ρ_background(t_form)
- Sink mass M_sink(t_form)

**Critical Metric**: W_form / W_fil (ratio at formation epoch)

#### 2. Width Evolution Timeline
Track width evolution from t = 0 to t = t_form:
- W(t) measured at fixed radial intervals
- ρ_central(t) evolution
- M_sink(t) growth rate
- Fragmentation pattern emergence

**Critical Metric**: dW/dt during collapse phase

#### 3. Core-Filament Connection
For each sink, measure:
- Distance to filament center
- Local filament width at sink position
- Sink mass vs local Jeans mass
- Spacing between sinks along filament

**Critical Metric**: Correlation between W_form and final core properties

### Analysis Strategy

#### Phase 1: Width Evolution Characterization
```python
# For each simulation:
1. Extract sink formation events
2. Measure W_form at each formation event
3. Plot W(t) evolution timeline
4. Fit exponential decay model: W(t) = W_0 * exp(-t/τ)
5. Extract characteristic collapse timescale τ

# Aggregate across parameter space:
6. Plot τ(f, β, M) dependence
7. Identify parameter regimes with fastest collapse
8. Compare fragmentation vs radial collapse timescales
```

#### Phase 2: Systematic Uncertainty Quantification
```python
# Current method uncertainty:
W_ frag / W_fil = 0.5 ± 0.1  (±50%)

# Sink-particle method uncertainty:
W_form / W_fil = measured ± σ_W

# Target: Reduce to ±20%
σ_W / W_form ≤ 0.20

# Analysis:
1. Calculate W_form/W_fil for all simulations
2. Compute mean and standard deviation
3. Quantify dependence on f, β, M
4. Propagate uncertainties to λ/W predictions
```

#### Phase 3: Model Discrimination Improvement
```python
# With reduced uncertainty, test:
1. Longitudinal B-field: λ/W_pred = 2.8-4.4 (W_core) → 1.4-2.2 (W_fil)
2. Perpendicular B-field: λ/W_pred = 2.5 (W_core) → 0.6-1.3 (W_fil)
3. Sub-isothermal: λ/W_pred = 2.8-3.2 (W_core) → 5.4-6.3 (W_fil)

# HGBS constraint: λ/W = [2.08, 2.65]

# Question: Can we distinguish mechanisms with ±20% uncertainty?
# If yes: Model discrimination restored
# If no: Honest assessment of fundamental limitation
```

### Expected Outcomes

#### Success Scenario
- W_form/W_fil = 0.45 ± 0.09 (±20% systematic)
- Clear trend: W_form decreases with increasing f
- Model discrimination possible at 2-σ level
- Publication: "Width evolution during filament core formation"

#### Null Result
- W_form/W_fil = 0.5 ± 0.25 (±50% systematic, no improvement)
- Large scatter across parameter space
- Model discrimination still impossible
- Publication: "Fundamental limit on width normalisation accuracy"

#### Intermediate Result
- W_form/W_fil = 0.5 ± 0.15 (±30% systematic)
- Some parameter dependence (e.g., correlation with f)
- Partial model discrimination possible
- Publication: "Reduced width uncertainty through sink tracking"

### Computational Resources

#### Simulation Requirements
```
Resolution: 256^3 (baseline), 512^3 (convergence test)
Domain: L = 8 λ_J × 2 λ_J × 2 λ_J
Duration: t = 0 to 2.0 t_ff
Output: ~10 GB per simulation

Total: 72 × 10 GB = 720 GB (raw outputs)
Compressed: ~200 GB (analysis products)
```

#### CPU Allocation
```
Parallel efficiency: 180 cores effective (82% of 220)
Walltime per simulation: ~12 hours
Total: 72 × 12 = 864 core-hours ≈ 5.3 days on 180 cores

Buffer for analysis: 7 days total
```

### Deliverables

#### Data Products
1. **Sink catalog**: Formation times, positions, masses for all sinks
2. **Width evolution database**: W(t) for all simulations
3. **Analysis notebooks**: Jupyter notebooks for reproducible analysis
4. **Figures**: Publication-ready figures for paper revision

#### Publication Figures
1. **Figure T1-1**: Width evolution timeline W(t) for representative cases
2. **Figure T1-2**: W_form/W_fil vs f, β, M (parameter dependence)
3. **Figure T1-3**: Systematic uncertainty comparison (old vs new method)
4. **Figure T1-4**: Model discrimination improvement with reduced uncertainty

#### Paper Revision Content
- New section: "Width normalisation through sink-particle tracking"
- Updated systematic uncertainty: ±50% → ±20%
- Revised model discrimination statements
- Supplementary material: Sink-particle methodology details

### Timeline
```
Week 1: Setup and test runs (3 simulations)
Week 2-3: Production runs (36 simulations)
Week 4: Complete production (36 simulations)
Week 5: Analysis and figure generation
Week 6: Paper revision and supplementary material
```

### Risk Mitigation

#### Technical Risks
- **Risk**: Sink particles form too early/late
- **Mitigation**: Test dens_threshold values [1e3, 1e4, 1e5] cm^-3

- **Risk**: Sink merger removes genuine fragments
- **Mitigation**: Compare with/without merger, tune merger_radius

- **Risk**: Insufficient resolution for sink accretion
- **Mitigation**: Convergence test at 512^3 for subset of runs

#### Scientific Risks
- **Risk**: No improvement in uncertainty (±50% persists)
- **Mitigation**: This is still a valid result (fundamental limit)

- **Risk**: Width depends strongly on IC geometry
- **Mitigation**: Test multiple IC profiles (King, uniform, core-halo)

- **Risk**: Sink formation too rare in some regimes
- **Mitigation**: Extend simulation duration, adjust threshold

### Success Criteria
1. **Primary**: W_form/W_fil measured with ≤30% uncertainty
2. **Secondary**: Clear physical understanding of width evolution
3. **Tertiary**: Publication-ready results for referee response

If all criteria met: Major advance in filament fragmentation modeling
If partial: Important constraint on systematic uncertainty
If none: Honest assessment of fundamental limitation (still valuable)
