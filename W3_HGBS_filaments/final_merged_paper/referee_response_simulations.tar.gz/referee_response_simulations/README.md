# Referee Response Simulation Campaign
# Addressing Two Critical Concerns from HGBS Filaments Paper Referee

## Overview
This package contains two targeted simulation campaigns designed to address specific referee concerns about the HGBS filaments paper.

### Campaign Summary
- **T1: Width Normalisation Systematic** - Sink-particle simulations to reduce W_core/W_fil uncertainty
- **T2: Power-law Exponent Discrepancy** - Hydrodynamic vs MHD comparison to isolate flux-freezing effects

## Computational Requirements
- **Cluster**: 220 CPU Ray cluster
- **Expected Runtime**: T1: ~2-3 weeks, T2: ~1 week
- **Storage**: ~500 GB for outputs
- **Software**: Athena++ (included), Python 3.8+, HDF5 tools

## Quick Start
```bash
# Extract and navigate
tar -xzf referee_response_simulations.tar.gz
cd referee_response_simulations

# Run T1 (width normalisation)
cd T1_width_normalisation
bash scripts/run_t1_campaign.sh

# Run T2 (power-law discrepancy)
cd ../T2_powerlaw_discrepancy
bash scripts/run_t2_campaign.sh

# Analyze results
cd ../analysis
python analyze_all.py
```

## Directory Structure
```
referee_response_simulations/
├── README.md                    # This file
├── T1_width_normalisation/      # Sink-particle campaign
│   ├── configs/                 # Athena++ input files
│   ├── scripts/                 # Run scripts and job submission
│   ├── analysis/                # Analysis scripts
│   └── docs/                    # Detailed documentation
├── T2_powerlaw_discrepancy/     # Hydro vs MHD campaign
│   ├── configs/                 # Athena++ input files
│   ├── scripts/                 # Run scripts and job submission
│   ├── analysis/                # Analysis scripts
│   └── docs/                    # Detailed documentation
└── shared/                      # Shared utilities
    ├── python/                  # Python analysis modules
    └── templates/               # Template files
```

## Campaign Details

### T1: Width Normalisation Systematic
**Goal**: Reduce ±50% uncertainty in W_core/W_fil ratio through sink-particle tracking

**Physics Question**: At what exact width do cores form? Current method measures at fragmentation epoch, but sink-particle tracking can measure at actual core formation.

**Parameter Space**:
- Line-mass fractions: f = [1.0, 1.2, 1.5, 2.0]
- Plasma beta: β = [0.5, 1.0, 2.0]
- Mach numbers: M = [1.0, 2.0]
- Seeds: 3 random seeds per point
- Total: 72 simulations

**Key Innovation**: First sink-particle filament fragmentation campaign in this parameter regime

### T2: Power-law Exponent Discrepancy
**Goal**: Isolate flux-freezing contribution to α discrepancy (0.39 vs 0.5)

**Physics Question**: Does the 18% discrepancy persist in pure hydrodynamics?

**Parameter Space**:
- Hydrodynamic simulations: β = ∞ (no magnetic field)
- MHD comparison: β = [0.3, 1.0, 5.0]
- Line-mass fractions: f = [1.1, 1.3, 1.5, 2.0, 2.5, 3.0]
- Seeds: 3 per point
- Total: 54 simulations (27 hydro + 27 MHD comparison)

**Key Test**: If α_hydro ≈ 0.39, flux-freezing is ruled out as primary cause

## Expected Outcomes

### T1 Success Metrics
- Measure W_core at sink formation vs fragmentation epoch
- Quantify width evolution during collapse
- Reduce systematic uncertainty from ±50% to ±20%
- Publication-quality Figure: Width evolution timeline

### T2 Success Metrics
- Measure α_hydro from pure hydrodynamic simulations
- Compare with α_MHD = 0.39
- Isolate flux-freezing contribution
- Publication-quality Figure: α(β) dependence with hydro point

## Timeline
- Week 1: Setup and test runs
- Weeks 2-4: T1 production runs
- Weeks 5-6: T2 production runs
- Week 7: Analysis and figure generation
- Week 8: Paper revision and supplementary material

## Contact
For questions about these simulations, contact:
- G. J. White, Open University & RAL
- Glenn's GitHub: https://github.com/gjw255/

## Citation
When using these results, cite:
- White et al. (2026), "Fragmentation of Interstellar Filaments: HGBS Analysis and MHD Simulations", MNRAS, in press
- Supplementary simulation campaign addressing referee concerns on width normalisation and power-law scaling
