#!/usr/bin/env python3
"""
Unified Analyzer for Referee Response Campaigns
Processes all 4 campaigns and generates combined analysis
"""

import json
import os
import argparse
from pathlib import Path
from typing import Dict, List
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class UnifiedAnalyzer:
    """Analyze results from all referee response campaigns"""

    def __init__(self, campaigns: List[str] = None):
        self.campaigns = campaigns or ['P1', 'P2', 'P3', 'P4']
        self.results = {}
        self.campaign_dirs = {
            'P1': 'P1_hgbs_statistical_validation',
            'P2': 'P2_eos_impact_assessment',
            'P3': 'P3_dtc_stable_ridge_completion',
            'P4': 'P4_width_correction_campaign'
        }

    def load_results(self, campaign: str) -> Dict:
        """Load results JSON for a campaign"""
        campaign_dir = self.campaign_dirs[campaign]
        result_file = f"{campaign_dir}_results.json"

        if os.path.exists(result_file):
            with open(result_file, 'r') as f:
                return json.load(f)
        else:
            logger.warning(f"Results not found for {campaign}: {result_file}")
            return None

    def analyze_p1_hgbs(self, results: Dict) -> Dict:
        """Analyze P1-HGBS statistical validation results"""
        if not results:
            return {"status": "NO_DATA"}

        matches_by_seed = {}
        for sim in results.get('results', []):
            sim_id = sim['sim_id']
            # Extract seed from sim_id
            seed = sim_id.split('_s')[-1] if '_s' in sim_id else 'unknown'
            if sim.get('status') == 'success':
                matches_by_seed[seed] = matches_by_seed.get(seed, 0) + 1

        # Determine robustness
        n_seeds_with_matches = len([s for s, n in matches_by_seed.items() if n > 0])
        if n_seeds_with_matches >= 3:
            verdict = "ROBUST"
        elif n_seeds_with_matches == 1 and '6' in matches_by_seed:
            verdict = "FRAGILE"
        else:
            verdict = "NULL"

        return {
            "campaign": "P1_hgbs_statistical_validation",
            "matches_by_seed": matches_by_seed,
            "n_seeds_with_matches": n_seeds_with_matches,
            "hgbs_matching_rate": len(matches_by_seed) / len(results.get('results', [])),
            "verdict": verdict
        }

    def analyze_p2_eos(self, results: Dict) -> Dict:
        """Analyze P2-EOS impact assessment results"""
        if not results:
            return {"status": "NO_DATA"}

        fragmentation_by_gamma = {}
        for sim in results.get('results', []):
            sim_id = sim['sim_id']
            gamma = sim_id.split('_g')[1].split('_')[0] if '_g' in sim_id else 'unknown'
            if sim.get('status') == 'success':
                fragmentation_by_gamma[gamma] = fragmentation_by_gamma.get(gamma, 0) + 1

        # Check if γ=0.9 preserves fragmentation
        frag_09 = fragmentation_by_gamma.get('0.9', 0)
        frag_10 = fragmentation_by_gamma.get('1.0', 0)

        if frag_09 == 0:
            verdict = "CATASTROPHIC"
        elif frag_09 < frag_10 * 0.3:
            verdict = "SEVERE"
        elif frag_09 < frag_10 * 0.7:
            verdict = "MODERATE"
        else:
            verdict = "ROBUST"

        return {
            "campaign": "P2_eos_impact_assessment",
            "fragmentation_by_gamma": fragmentation_by_gamma,
            "frag_09": frag_09,
            "frag_10": frag_10,
            "verdict": verdict
        }

    def analyze_p3_dtc(self, results: Dict) -> Dict:
        """Analyze P3-DTC stable-ridge completion results"""
        if not results:
            return {"status": "NO_DATA"}

        stable_count = sum(1 for r in results.get('results', []) if r.get('status') == 'success' and 'STABLE' in r.get('sim_id', ''))
        total_count = len(results.get('results', []))

        if stable_count == 0:
            verdict = "CONFIRMED"
        elif stable_count < total_count * 0.3:
            verdict = "MIXED"
        else:
            verdict = "RIDGE_EXISTS"

        return {
            "campaign": "P3_dtc_stable_ridge_completion",
            "stable_count": stable_count,
            "total_count": total_count,
            "verdict": verdict
        }

    def analyze_p4_width(self, results: Dict) -> Dict:
        """Analyze P4-Width correction results"""
        if not results:
            return {"status": "NO_DATA"}

        # Check if morphology is preserved
        preserved_count = sum(1 for r in results.get('results', []) if r.get('status') == 'success')
        total_count = len(results.get('results', []))

        if preserved_count == total_count:
            verdict = "VALIDATED"
        elif preserved_count > total_count * 0.5:
            verdict = "PROBLEMATIC"
        else:
            verdict = "FUNDAMENTAL"

        return {
            "campaign": "P4_width_correction_campaign",
            "preserved_count": preserved_count,
            "total_count": total_count,
            "verdict": verdict
        }

    def analyze_all(self) -> Dict:
        """Analyze all campaigns and generate combined assessment"""
        analysis = {
            "timestamp": "2026-06-04",
            "campaigns": {},
            "combined_verdict": None
        }

        for campaign in self.campaigns:
            results = self.load_results(campaign)
            if campaign == 'P1':
                analysis['campaigns']['P1'] = self.analyze_p1_hgbs(results)
            elif campaign == 'P2':
                analysis['campaigns']['P2'] = self.analyze_p2_eos(results)
            elif campaign == 'P3':
                analysis['campaigns']['P3'] = self.analyze_p3_dtc(results)
            elif campaign == 'P4':
                analysis['campaigns']['P4'] = self.analyze_p4_width(results)

        # Determine combined verdict
        p1_verdict = analysis['campaigns'].get('P1', {}).get('verdict')
        p2_verdict = analysis['campaigns'].get('P2', {}).get('verdict')

        if p1_verdict == "ROBUST" and p2_verdict in ["MODERATE", "ROBUST"]:
            analysis['combined_verdict'] = "PAPER_STANDS"
        elif p1_verdict in ["FRAGILE", "NULL"] or p2_verdict in ["SEVERE", "CATASTROPHIC"]:
            analysis['combined_verdict'] = "MAJOR_REVISION"
        else:
            analysis['combined_verdict'] = "MODERATE_REVISION"

        return analysis

    def make_table(self, output: str = "referee_response_table.tex"):
        """Generate LaTeX table for referee response"""
        analysis = self.analyze_all()

        latex = "\\begin{table}[ht]\\n"
        latex += "\\caption{Summary of Referee Response Campaign Results}\\n"
        latex += "\\begin{tabular}{lcccl}\\n"
        latex += "\\hline\\n"
        latex += "Campaign & Simulations & Status & Verdict & Impact \\\\\\n"
        latex += "\\hline\\n"

        for campaign_id, campaign_name in [
            ('P1', 'HGBS Validation'),
            ('P2', 'EOS Impact'),
            ('P3', 'DTC Completion'),
            ('P4', 'Width Correction')
        ]:
            result = analysis['campaigns'].get(campaign_id, {})
            verdict = result.get('verdict', 'NO_DATA')
            status = result.get('status', 'NO_DATA')
            latex += f"{campaign_name} & {result.get('total_count', 0)} & {status} & {verdict} & TODO\\\\\\n"

        latex += "\\hline\\n"
        latex += "\\end{tabular}\\n"
        latex += "\\end{table}\\n"

        with open(output, 'w') as f:
            f.write(latex)

        logger.info(f"Table written to {output}")


def main():
    parser = argparse.ArgumentParser(description='Unified Referee Response Analyzer')
    parser.add_argument('--campaigns', default='P1,P2,P3,P4', help='Campaigns to analyze')
    parser.add_argument('--output', default='combined_analysis.json', help='Output file')
    parser.add_argument('--make_table', action='store_true', help='Generate LaTeX table')
    parser.add_argument('--make_figures', action='store_true', help='Generate figures')
    parser.add_argument('--output_dir', default='figures/', help='Output directory for figures')

    args = parser.parse_args()

    campaigns = args.campaigns.split(',')
    analyzer = UnifiedAnalyzer(campaigns)

    analysis = analyzer.analyze_all()

    with open(args.output, 'w') as f:
        json.dump(analysis, f, indent=2)

    logger.info(f"Analysis written to {args.output}")

    if args.make_table:
        analyzer.make_table('referee_response_table.tex')

    if args.make_figures:
        os.makedirs(args.output_dir, exist_ok=True)
        logger.info(f"Figures would be generated in {args.output_dir}")


if __name__ == '__main__':
    main()
