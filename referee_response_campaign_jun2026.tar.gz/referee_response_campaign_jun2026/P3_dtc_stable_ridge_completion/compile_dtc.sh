#!/bin/bash
# Compile Athena++ for P3-DTC Stable-Ridge Completion Campaign
# Usage: bash compile_dtc.sh

set -e

ATHENA_ROOT=${ATHENA_ROOT:-"/path/to/athena++"}
CAMPAIGN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$CAMPAIGN_DIR/build"
BIN_DIR="$CAMPAIGN_DIR/bin"

echo "P3-DTC Campaign: Athena++ Compilation"
echo "ATHENA_ROOT: $ATHENA_ROOT"

mkdir -p "$BUILD_DIR" "$BIN_DIR"

cp "$CAMPAIGN_DIR/filament_dtc.cpp" "$ATHENA_ROOT/src/patches/"

cd "$BUILD_DIR"
"$ATHENA_ROOT/configure" --prob=filament_dtc --coord=cartesian --eos=iso --flux=hllc --int=vl2 --order=2 --mpi
make -j$(nproc)
cp bin/filament_dtc "$BIN_DIR/"

echo "SUCCESS: Binary at $BIN_DIR/filament_dtc"
