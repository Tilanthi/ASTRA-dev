#!/bin/bash
# Compile Athena++ for P2-EOS Impact Assessment Campaign
# Usage: bash compile_eos.sh

set -e

ATHENA_ROOT=${ATHENA_ROOT:-"/path/to/athena++"}
CAMPAIGN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$CAMPAIGN_DIR/build"
BIN_DIR="$CAMPAIGN_DIR/bin"

echo "P2-EOS Campaign: Athena++ Compilation"
echo "ATHENA_ROOT: $ATHENA_ROOT"

mkdir -p "$BUILD_DIR" "$BIN_DIR"

cp "$CAMPAIGN_DIR/filament_eos.cpp" "$ATHENA_ROOT/src/patches/"

cd "$BUILD_DIR"
"$ATHENA_ROOT/configure" --prob=filament_eos --coord=cartesian --eos=poly --flux=hllc --int=vl2 --order=2 --mpi
make -j$(nproc)
cp bin/filament_eos "$BIN_DIR/"

echo "SUCCESS: Binary at $BIN_DIR/filament_eos"
