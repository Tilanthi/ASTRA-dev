# Referee Response Campaigns - Summary Table
**Quick Reference for All 4 Campaigns**

---

## Campaign Summary Matrix

| Campaign | Priority | Simulations | CPU Hours | Wall Time (32 CPU) | Key Scientific Question | Expected Impact |
|----------|----------|-------------|-----------|-------------------|------------------------|-----------------|
| **P1-HGBS** | 🔴 CRITICAL | 60 | 1,200 | ~45 hours | Is HGBS-matching robust across random seeds? | Paper STANDS or COLLAPSES |
| **P2-EOS** | 🟠 HIGH | 35 | 560 | ~20 hours | Does realistic γ=0.9 destroy the window? | SEVERE to MODERATE revision |
| **P3-DTC** | 🟡 MEDIUM | 40 | 560 | ~20 hours | Is stable ridge truly absent? | Text revision |
| **P4-Width** | 🟢 LOW | 8 | 80 | ~5 hours | Can widths be reconciled? | Methodology fix |
| **TOTAL** | - | **143** | **2,400** | **~90 hours** | - | - |

---

## Campaign-Specific Details

### P1: HGBS Statistical Validation (CRITICAL)

**Referee Comment**: #2 - Statistical fragility of central claim

**Parameter Window**:
- f = 1.0, 1.1, 1.2
- β = 2.0
- θ = 0° (longitudinal)
- M = 2.5, 3.0, 3.5
- Seeds: 6, 12, 18, 24, 30 (plus controls)

**Total**: 60 simulations

**Key Outcomes**:
- ✅ **ROBUST**: ≥3 seeds produce matches → Paper stands
- ⚠️ **FRAGILE**: Only seed=6 works → Major revision
- ❌ **NULL**: No matches → Claim withdrawn

**Resource Requirements**:
- CPUs: 128 (4 concurrent × 32 ranks)
- Memory: 32 GB total
- Disk: 120 GB

---

### P2: EOS Impact Assessment (HIGH)

**Referee Comment**: #5 - Realistic thermodynamics may destroy conclusions

**Parameter Sweep**:
- γ = 0.7, 0.8, 0.9, 0.95, 1.0
- β = 1.0, 2.0
- θ = 0°, 90°
- f = 1.1 (fiducial point)
- Seeds: 0, 1, 2

**Total**: 35 simulations

**Key Outcomes**:
- ✅ **MODERATE**: γ=0.9 preserves some fragmentation → Revision
- ⚠️ **SEVERE**: γ=0.9 destroys HGBS window → Major revision
- ❌ **CATASTROPHIC**: No matches at any γ<1.0 → Paper reframed

**Resource Requirements**:
- CPUs: 128 (4 concurrent × 32 ranks)
- Memory: 32 GB total
- Disk: 70 GB

---

### P3: DTC Stable-Ridge Completion (MEDIUM)

**Referee Comment**: #6 - Timeout artifacts in stable-ridge region

**Parameter Regions**:
- Region 1: β = 0.5, M = 1, f = 0.4-1.6
- Region 2: β = 0.3, M = 2, f = 0.4-1.6
- Controls: Known STABLE cases

**Total**: 40 simulations

**Key Outcomes**:
- ✅ **CONFIRMED**: No stable ridge → Text revision
- ⚠️ **MIXED**: Partial stability → Soften claims
- ❌ **RIDGE_EXISTS**: True stability found → Substantial revision

**Resource Requirements**:
- CPUs: 128 (4 concurrent × 32 ranks)
- Memory: 32 GB total
- Disk: 80 GB
- **Timeout**: 12 hours (extended from 6)

---

### P4: Width-Definition Correction (LOW)

**Referee Comment**: #3 - Simulation vs observed width inconsistency

**Two Approaches**:
1. Lower density: ρ → ρ/2.56
2. Higher temperature: T → T×2.56

**Reference Cases**: NC, CG, STABLE, STOCHASTIC morphologies

**Total**: 8 simulations

**Key Outcomes**:
- ✅ **VALIDATED**: Width correction works → Methodology fix
- ⚠️ **PROBLEMATIC**: Width changes morphology → Discussion needed
- ❌ **FUNDAMENTAL**: Width changes everything → Reanalysis

**Resource Requirements**:
- CPUs: 128 (4 concurrent × 32 ranks)
- Memory: 32 GB total
- Disk: 16 GB

---

## Execution Timeline

### Sequential Execution (Recommended)

```
Day 1-2:  P1-HGBS (45 hours)         ← CRITICAL PATH
Day 3:    P2-EOS (20 hours)         ← Run in parallel with P1 if resources allow
Day 4:    P3-DTC (20 hours)         ← Can run independently
Day 4-5:  P4-Width (5 hours)        ← Lowest priority
```

### Parallel Execution (Maximum Efficiency)

```
With 128 CPUs and 4 concurrent simulations per campaign:

Day 1-2:  P1 + P2 (parallel)       → 45 hours max(P1, P2)
Day 3-4:  P3 + P4 (parallel)       → 20 hours max(P3, P4)
Total: ~4 days
```

### Adaptive Execution (Recommended for Limited Resources)

```
Day 1-2:  P1-HGBS (45 hours)
Day 2:    Analyze P1 results
Day 3-4:  P2-EOS (20 hours)        ← Only if P1 shows promise
Day 4-5:  P3+P4 (parallel)         ← Can defer if P1+P2 resolve concerns
```

---

## Scientific Impact Summary

| Campaign | If POSITIVE | If NEGATIVE | Paper Impact |
|----------|-------------|-------------|--------------|
| P1-HGBS | Seed robustness confirmed | Only seed=6 works | **CATASTROPHIC** - central claim collapses |
| P2-EOS | Realistic γ preserves matches | γ=0.9 destroys window | **SEVERE** - isothermal assumption fatal |
| P3-DTC | No stable ridge confirmed | Stable ridge exists | **MODERATE** - requires text revision |
| P4-Width | Width doesn't affect morphology | Width changes everything | **MODERATE** - requires corrections throughout |

---

## Combined Verdict Scenarios

### Scenario A: Paper STANDS (Best Case)
- P1: ROBUST (multiple seeds match)
- P2: MODERATE (some γ<1 matches)
- P3: CONFIRMED (no stable ridge)
- P4: VALIDATED (width correction works)

**Response**: Minor revisions, emphasize robustness

### Scenario B: Paper REVISED (Most Likely)
- P1: FRAGILE (only seed=6 matches)
- P2: SEVERE (γ=0.9 reduces matches)
- P3: CONFIRMED (no stable ridge)
- P4: VALIDATED (width correction works)

**Response**: Moderate revisions, reframe claims

### Scenario C: Major Revision (Worst Case)
- P1: NULL (no matches)
- P2: CATASTROPHIC (no γ<1 matches)
- P3: RIDGE_EXISTS (true stability found)
- P4: PROBLEMATIC (width changes morphology)

**Response**: Substantial rewriting, reframe as hypothesis-generating

---

## Quick Reference Commands

```bash
# Compile all binaries
for campaign in P1 P2 P3 P4; do
    bash ${campaign}_*/compile_${campaign,}.sh
done

# Run campaigns (sequentially)
python P1_*/hgbs_launcher.py
python P2_*/eos_launcher.py
python P3_*/dtc_launcher.py
python P4_*/width_launcher.py

# Analyze combined results
python unified_analyzer.py --campaigns P1,P2,P3,P4

# Generate referee response
python unified_analyzer.py --make_table --output referee_response.tex
```

---

## Contact

**Questions**: Glenn White (g.j.white@open.ac.uk)
**Repository**: https://github.com/Tilanthi/ASTRA-dev
**Package**: referee_response_campaign_jun2026.tar.gz

---

**Last Updated**: 2026-06-04
