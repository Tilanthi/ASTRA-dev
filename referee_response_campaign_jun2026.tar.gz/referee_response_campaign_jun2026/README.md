# Referee Response Simulation Campaigns — June 2026
**Date**: 2026-06-04 | **Purpose**: Address All 4 Referee Concerns Requiring Athena++ Simulations

---

## Executive Summary

This package addresses **all 4 referee concerns** that require additional Athena++ simulations. The campaigns are **prioritized by scientific importance** and designed for execution on a **Ray cluster** (not Slurm).

### Campaign Priority Order

1. **P1 - HGBS-Matching Statistical Validation** (CRITICAL - Central Claim)
2. **P2 - Equation of State Impact Assessment** (HIGH - Affects All Conclusions)  
3. **P3 - DTC Stable-Ridge Completion** (MEDIUM - Fragmentation Boundary)
4. **P4 - Width-Definition Correction Campaign** (LOW - Methodology Fix)

**Total Simulations**: 143 Athena++ runs across all campaigns

**Estimated CPU Hours**: ~2,400 CPU-hours (assuming 32 cores per simulation)

**Estimated Wall Time**: ~75 hours on 32-CPU cluster with 4 concurrent simulations

---

## Campaign Structure

```
referee_response_campaign_jun2026/
├── README.md                                    # This file
├── DEPLOYMENT_GUIDE.md                          # Ray cluster instructions
├── ANALYSIS_GUIDE.md                            # Post-processing instructions
├── SUMMARY_TABLE.md                             # Quick reference table
│
├── P1_hgbs_statistical_validation/             # CRITICAL - 60 simulations
│   ├── hgbs_params.json
│   ├── compile_hgbs.sh
│   ├── hgbs_launcher.py
│   ├── hgbs_analyze.py
│   └── filament_hgbs.cpp
│
├── P2_eos_impact_assessment/                   # HIGH - 35 simulations
│   ├── eos_params.json
│   ├── compile_eos.sh
│   ├── eos_launcher.py
│   ├── eos_analyze.py
│   └── filament_eos.cpp
│
├── P3_dtc_stable_ridge_completion/             # MEDIUM - 40 simulations
│   ├── dtc_params.json
│   ├── compile_dtc.sh
│   ├── dtc_launcher.py
│   ├── dtc_analyze.py
│   └── filament_dtc.cpp
│
├── P4_width_correction_campaign/               # LOW - 8 simulations
│   ├── width_params.json
│   ├── compile_width.sh
│   ├── width_launcher.py
│   ├── width_analyze.py
│   └── filament_width.cpp
│
└── unified_analyzer.py                          # Combined analysis tool
```

---

## Quick Reference Table

| Campaign | Priority | Simulations | CPU Hours | Key Scientific Question |
|----------|----------|-------------|-----------|-------------------------|
| P1-HGBS | **CRITICAL** | 60 | 1,200 | Is HGBS-matching robust across random seeds? |
| P2-EOS | **HIGH** | 35 | 560 | Does realistic γ=0.9 destroy the claimed parameter window? |
| P3-DTC | **MEDIUM** | 40 | 560 | Is the stable ridge truly absent or just timeout artifacts? |
| P4-Width | **LOW** | 8 | 80 | Can we reconcile width definitions for direct comparison? |
| **TOTAL** | - | **143** | **2,400** | - |

---

## Campaign 1: HGBS-Matching Statistical Validation (CRITICAL)

### Referee Concern (Comment #2)

> "The central simulation result — four HGBS-matching simulations out of 720 (0.56%) — is presented with appropriate caveats in some places, but the overall framing of the paper does not adequately convey how fragile this result is. **Three of the four matches come from a single turbulent seed (seed = 6)**. This means the effective independent evidence for the claimed parameter window consists of exactly one NC match and one CG match at a single parameter point."

**Referee's Verdict**: Either (a) run additional seed tests before publication, OR (b) completely reframe the paper as "hypothesis-generating" rather than a finding.

### Campaign Design

**Objective**: Establish statistical robustness of HGBS-matching parameter window across **diverse random seeds**

**Core Hypothesis**: If the HGBS-matching parameter window is real, then **multiple independent turbulent realizations** (different random seeds) should produce matches at the same parameter point.

**Parameter Window to Test** (from paper's claimed "HGBS-matching conditions"):
- Line-mass fraction: **f = 1.0, 1.1, 1.2** (paper's claimed window)
- Plasma beta: **β = 2.0** (weak magnetic field, as reported)
- Field geometry: **θ = 0°** (longitudinal field, as reported)
- Mach number: **M = 2.5, 3.0, 3.5** (transonic to supersonic)
- **Random seeds**: **[6, 12, 18, 24, 30]** (new seeds, testing robustness)

### Why These Seeds?

The original HGBS-matching result used **seeds [0-11]** in the base campaign. The fact that 3/4 matches came from **seed=6** is deeply suspicious. We need:
1. **More samples from the same seed family** (seeds 12, 18, 24, 30) to test reproducibility
2. **Explicit re-test of seed=6** to verify the original result (independent validation)
3. **Diverse seeds** spanning the random number generator space

### Simulation Matrix (60 simulations total)

```
For each f ∈ [1.0, 1.1, 1.2]:
  For each M ∈ [2.5, 3.0, 3.5]:
    For each seed ∈ [6, 12, 18, 24, 30]:
      Run simulation
      → 3 × 3 × 5 = 45 simulations

Plus validation runs:
  - Re-run seed=6 cases (verify original 3 matches)
  - Test seed=0 at same parameters (control case)
  → 15 additional simulations

Total: 60 simulations
```

**Expected Scientific Outcomes**:
1. **IF robust**: ≥3 seeds produce matches at same (f, M, β=2.0, θ=0°) → **PAPER STANDS**
2. **IF fragile**: Only seed=6 produces matches → **MAJOR REVISION REQUIRED**
3. **IF null**: No seeds produce matches → **RESULT NOT REPRODUCIBLE**

### Technical Specifications

- **Domain**: 16λJ × 2λJ × 2λJ (standard)
- **Resolution**: 256³ (standard)
- **EOS**: Isothermal (γ = 1.0)
- **HDF5 interval**: Δt = 0.02 tJ (standard)
- **Max snapshots**: 200 (t = 0 → 4.0 tJ)
- **Output metrics**:
  - Fragmentation: YES/NO
  - Fragmentation time: t_frag (in tJ)
  - Final morphology: NC, CG, STABLE, STOCHASTIC
  - Fragment count: N_frags
  - Mass spectrum: dM/dm

---

## Campaign 2: Equation of State Impact Assessment (HIGH)

### Referee Concern (Comment #5)

> "Section 4.6.2 and Section 6.2 demonstrate that: (a) **adiabatic simulations (γ = 5/3) show 0% fragmentation vs. 100% for isothermal**, and (b) real molecular cloud filaments have **γ ≈ 0.7–0.95**. The paper notes that **γ ≈ 0.9 gives only ~20% fragmentation**. This is a result of **major significance** that threatens the paper's own conclusions."

**Referee's Verdict**: Run a focused γ-varying campaign at the HGBS-matching point and assess whether the "two-regime framework" survives.

### Campaign Design

**Objective**: Quantify how **realistic thermodynamics** (γ = 0.7–1.0) affects:
1. The HGBS-matching rate
2. The fragmentation boundary (f vs β)
3. The "two-regime framework" (radial collapse vs longitudinal beading)

**Central Question**: If γ=0.9 reduces fragmentation from 100% to 20%, does the HGBS-matching parameter window **even exist** under realistic conditions?

### Parameter Space

| Parameter | Values | Rationale |
|-----------|--------|-----------|
| Line-mass fraction (f) | **1.1** | Fiducial HGBS-matching point |
| Plasma beta (β) | **1.0, 2.0** | Weak-to-moderate field |
| Field geometry (θ) | **0°, 90°** | Longitudinal vs Perpendicular |
| Mach number (M) | **1.0** | Subsonic (standard test) |
| **EOS gamma (γ)** | **0.7, 0.8, 0.9, 0.95, 1.0** | Realistic ISM range |
| Random seeds | **0, 1, 2** | Statistical robustness |

### Simulation Matrix (35 simulations total)

```
For each γ ∈ [0.7, 0.8, 0.9, 0.95, 1.0]:
  For each β ∈ [1.0, 2.0]:
    For each θ ∈ [0°, 90°]:
      For each seed ∈ [0, 1, 2]:
        Run simulation
        → 5 × 2 × 2 × 3 = 60 simulations

Focusing on critical points:
  - Prioritize γ=0.9 (physically realistic)
  - Prioritize β=2.0, θ=0° (HGBS-matching geometry)
  → Select 35 most critical combinations
```

**Selected Priority Combinations**:
```
Critical Path (γ = 0.9, 0.95):
  - (β=2.0, θ=0°):  γ=0.9, 0.95 × 3 seeds  → 6 sims
  - (β=2.0, θ=90°): γ=0.9, 0.95 × 3 seeds  → 6 sims
  - (β=1.0, θ=0°):  γ=0.9, 0.95 × 3 seeds  → 6 sims

Full γ sweep at fiducial (β=2.0, θ=0°):
  - All γ ∈ [0.7, 0.8, 0.9, 0.95, 1.0] × 3 seeds → 15 sims

Selected intermediate points:
  - γ=0.7, 0.8 at β=1.0, θ=0°, 90° × 2 seeds → 8 sims
  - γ=0.7, 0.8 at β=2.0, θ=90° × 2 seeds     → 4 sims

Total: 35 simulations
```

### Expected Scientific Outcomes

1. ** catastrophic outcome**: γ=0.9 produces **ZERO** HGBS matches → entire parameter window is an isothermal artifact
2. **Severe degradation**: HGBS-matching rate drops from 0.56% to <0.1% → paper's conclusions are severely weakened
3. **Moderate degradation**: HGBS-matching rate drops to 0.1–0.3% → quantitative revision needed
4. **Robust**: HGBS-matching rate unchanged → surprising result, strengthens paper

**Most Likely**: Outcomes 1-2, meaning the **isothermal assumption is致命** to the paper's conclusions.

### Technical Specifications

- **Domain**: 16λJ × 2λJ × 2λJ
- **Resolution**: 256³
- **EOS**: Polytopic with specified γ
- **HDF5 interval**: Δt = 0.02 tJ
- **Max snapshots**: 200

---

## Campaign 3: DTC Stable-Ridge Completion (MEDIUM)

### Referee Concern (Comment #6)

> "Section 4.5 acknowledges that targeted re-runs with 6-hour timeouts were performed only for **β = 0.3, M = 1** parameter combinations, and that **STABLE and stochastic classifications at β = 0.5, f ≤ 1.6, M = 1 and β = 0.3, f ≤ 1.6, M = 2 remain potentially unresolved timeout artifacts**."

**Referee's Verdict**: Complete these re-runs or provide quantitative argument that they don't affect conclusions.

### Campaign Design

**Objective**: Establish whether the **stable ridge** is truly absent from the DTC parameter space or merely hidden by **timeout artifacts**.

**Background**: The DTC (Deep Turbulence Campaign) maps the fragmentation boundary in (f, β) space for different Mach numbers. The paper claims no "stable ridge" exists (continuous fragmentation boundary). However, some STABLE classifications may be timeout artifacts rather than true stability.

### Parameter Space to Re-Run

**Unresolved Region 1**: β = 0.5, f ≤ 1.6, M = 1 (strong field, subsonic)
**Unresolved Region 2**: β = 0.3, f ≤ 1.6, M = 2 (very strong field, transonic)

### Simulation Matrix (40 simulations total)

```
Region 1 (β = 0.5, M = 1):
  For f ∈ [0.4, 0.6, 0.8, 1.0, 1.2, 1.4, 1.6]:
    For seed ∈ [0, 1]:
      Run with extended timeout (12 hours)
      → 7 × 2 = 14 simulations

Region 2 (β = 0.3, M = 2):
  For f ∈ [0.4, 0.6, 0.8, 1.0, 1.2, 1.4, 1.6]:
    For seed ∈ [0, 1]:
      Run with extended timeout (12 hours)
      → 7 × 2 = 14 simulations

Control verification (known STABLE cases):
  - β = 0.3, f = 0.4, M = 1 (known stable)
  - β = 0.5, f = 0.4, M = 2 (known stable)
  → 2 × 6 seeds each = 12 simulations

Total: 40 simulations
```

### Expected Scientific Outcomes

1. **All timeout artifacts**: All "STABLE" cases re-classify as CG/NC → stable ridge confirmed absent
2. **Mixed**: Some stable, some timeout artifacts → fragmentation boundary is complex
3. **True stability**: Some cases remain truly STABLE even with extended runtime → **stable ridge exists!**

**Impact**: If outcome 3, the paper's claim of "no stability threshold" needs major revision.

### Technical Specifications

- **Domain**: 16λJ × 2λJ × 2λJ
- **Resolution**: 256³
- **EOS**: Isothermal (γ = 1.0)
- **HDF5 interval**: Δt = 0.02 tJ
- **Max snapshots**: 200
- **Timeout**: 12 hours (extended from 6 hours)
- **Convergence criterion**: 50 timesteps without density increase in core region

---

## Campaign 4: Width-Definition Correction Campaign (LOW)

### Referee Concern (Comment #3)

> "Section 3.1 acknowledges that the **simulation half-width W_core = 0.3λ_J ≈ 0.062 pc** differs from the **observed filament width W_fil = 0.1 pc** by 38%, and that this requires a factor of ~1.6 correction to simulation λ/W values before comparing to observations."

**Referee's Verdict**: Either re-run simulations with consistent width definition, OR apply corrections to all theory-observation comparisons.

### Campaign Design

**Objective**: Resolve the width-definition inconsistency by creating **matched-width simulations** that can be directly compared to observations without correction factors.

**Approach**: Instead of applying post-hoc corrections, we'll run a small set of simulations with **adjusted domain geometry** such that the initial filament width matches the observed W_fil = 0.1 pc.

### Physical Reasoning

The simulation width is set by the initial balance between **thermal+non-thermal pressure** and **self-gravity**:
- W_core ≈ 0.3 λ_J (isothermal)
- λ_J = c_s × sqrt(π / Gρ)
- To increase W_core from 0.062 pc → 0.1 pc (factor 1.6), we need to adjust initial conditions

**Two approaches**:
1. **Lower initial density**: ρ_0 → ρ_0 / (1.6)² ≈ ρ_0 / 2.56
2. **Higher temperature**: T → T × (1.6)² ≈ T × 2.56

We'll test both approaches to see which better matches HGBS filaments.

### Simulation Matrix (8 simulations total)

```
Approach 1: Lower Density (match W=0.1 pc via density adjustment)
  For each (f, β, θ, M) in original HGBS-matching set:
    - Adjust ρ_0 to give W_fil = 0.1 pc
    - Keep other parameters unchanged
    → 4 simulations

Approach 2: Higher Temperature (match W=0.1 pc via temperature adjustment)
  For each (f, β, θ, M) in original HGBS-matching set:
    - Adjust T to give W_fil = 0.1 pc
    - Keep other parameters unchanged
    → 4 simulations

Total: 8 simulations
```

**Reference Points** (original HGBS-matching cases):
- NC: (f=1.1, β=2.0, θ=0°, M=3.0, seed=6)
- CG: (f=1.1, β=2.0, θ=0°, M=2.5, seed=6)
- STABLE: (f=0.4, β=2.0, θ=90°, M=1.0, seed=0)
- STOCHASTIC: (f=1.4, β=2.0, θ=90°, M=2.0, seed=3)

### Expected Scientific Outcomes

1. **Morphology preserved**: Width adjustment doesn't change NC/CG/STABLE classification → quantitative scaling only
2. **Morphology changed**: Width adjustment shifts morphologies → **width definition is fundamental**
3. **Parameter window shifts**: HGBS-matching (f, β) point changes → original result was width-artifact

**Impact**: If outcome 3, the paper's entire HGBS-matching claim is an artifact of the width definition.

### Technical Specifications

- **Domain**: 16λJ × 2λJ × 2λJ (standard, but λ_J recalculated)
- **Resolution**: 256³
- **EOS**: Isothermal (γ = 1.0)
- **HDF5 interval**: Δt = 0.02 tJ
- **Max snapshots**: 200

**Width adjustment formulas**:
```python
# For Approach 1 (lower density)
lambda_J_new = lambda_J * (W_target / W_current)
rho_0_new = rho_0 * (W_current / W_target)^2

# For Approach 2 (higher temperature)
c_s_new = c_s * (W_target / W_current)
T_new = T * (W_target / W_current)^2
```

---

## Scientific Impact Summary

| Campaign | If Result is POSITIVE | If Result is NEGATIVE | Impact on Paper |
|----------|---------------------|----------------------|-----------------|
| P1-HGBS | Seed robustness confirmed | Only seed=6 works | **CATASTROPHIC** - central claim collapses |
| P2-EOS | Realistic γ preserves matches | γ=0.9 destroys window | **SEVERE** - isothermal assumption致命 |
| P3-DTC | No stable ridge (confirmed) | Stable ridge exists | **MODERATE** - requires text revision |
| P4-Width | Width doesn't affect morphology | Width changes everything | **MODERATE** - requires corrections throughout |

---

## Combined Execution Strategy

### Recommended Execution Order

1. **P1-HGBS FIRST** (critical path)
   - Run on highest-priority queue
   - Monitor results in real-time
   - If seed=6 fails to reproduce, **STOP** and reassess paper strategy

2. **P2-EOS SECOND** (high priority)
   - Can run in parallel with P1
   - Focus on γ=0.9 results first

3. **P3-DTC THIRD** (medium priority)
   - Can run in parallel with P1+P2
   - Not on critical path for publication

4. **P4-Width FOURTH** (low priority)
   - Can be deferred if P1+P2 resolve the main concerns
   - Most useful for methodology discussion

### Resource Allocation

**On 32-CPU cluster with 4 concurrent simulations**:
- P1-HGBS: ~45 hours (60 sims × 18 CPU-hours per sim / 4 concurrent)
- P2-EOS: ~20 hours (35 sims × 14 CPU-hours per sim / 4 concurrent)
- P3-DTC: ~20 hours (40 sims × 14 CPU-hours per sim / 4 concurrent)
- P4-Width: ~5 hours (8 sims × 14 CPU-hours per sim / 4 concurrent)
- **Total**: ~90 hours of wall time (~4 days)

---

## Post-Simulation Analysis Pipeline

See `ANALYSIS_GUIDE.md` for detailed analysis protocols for each campaign.

---

## Quick Start Commands

```bash
# 1. Extract package
tar -xzf referee_response_campaign_jun2026.tar.gz
cd referee_response_campaign_jun2026

# 2. Set up Athena++ source paths
export ATHENA_ROOT=/path/to/athena++
nano P1_hgbs_statistical_validation/compile_hgbs.sh
# Edit ATHENA_ROOT variable

# 3. Compile all binaries
bash P1_hgbs_statistical_validation/compile_hgbs.sh
bash P2_eos_impact_assessment/compile_eos.sh
bash P3_dtc_stable_ridge_completion/compile_dtc.sh
bash P4_width_correction_campaign/compile_width.sh

# 4. Run campaigns (sequentially)
python P1_hgbs_statistical_validation/hgbs_launcher.py
python P2_eos_impact_assessment/eos_launcher.py
python P3_dtc_stable_ridge_completion/dtc_launcher.py
python P4_width_correction_campaign/width_launcher.py

# 5. Analyze combined results
python unified_analyzer.py --campaigns P1,P2,P3,P4 --output combined_analysis.json

# 6. Generate referee response figures
python unified_analyzer.py --make_figures --output_dir figures/
```

---

## Contact & Repository

**Questions**: Glenn White (g.j.white@open.ac.uk)
**ASTRA Repository**: https://github.com/Tilanthi/ASTRA-dev
**Campaign Package**: referee_response_campaign_jun2026.tar.gz

**Status**: READY FOR DEPLOYMENT
