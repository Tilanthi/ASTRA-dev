#!/usr/bin/env python3
"""
P1-HGBS Statistical Validation Campaign Launcher
Ray-based distributed execution for Athena++ simulations
"""

import ray
import json
import os
import subprocess
import time
from pathlib import Path
from typing import Dict, List
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/hgbs_launch.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@ray.remote
class AthenaSimulation:
    """Ray actor for running individual Athena++ simulations"""

    def __init__(self, sim_config: Dict, athena_bin: str):
        self.sim_config = sim_config
        self.athena_bin = athena_bin
        self.output_dir = sim_config['output_dir']

    def run(self) -> Dict:
        """Execute a single Athena++ simulation"""
        start_time = time.time()

        try:
            # Create output directory
            os.makedirs(self.output_dir, exist_ok=True)

            # Generate Athena++ input file
            input_file = self._generate_input_file()

            # Run simulation
            mpi_cmd = [
                'mpirun', '-np', '32',
                self.athena_bin,
                '-i', input_file
            ]

            logger.info(f"Starting simulation: {self.sim_config['sim_id']}")
            process = subprocess.Popen(
                mpi_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=self.output_dir
            )

            stdout, stderr = process.communicate()

            elapsed_time = time.time() - start_time

            if process.returncode == 0:
                logger.info(f"Completed: {self.sim_config['sim_id']} in {elapsed_time:.1f}s")
                return {
                    'sim_id': self.sim_config['sim_id'],
                    'status': 'success',
                    'elapsed_time_sec': elapsed_time,
                    'output_dir': self.output_dir
                }
            else:
                logger.error(f"Failed: {self.sim_config['sim_id']}")
                return {
                    'sim_id': self.sim_config['sim_id'],
                    'status': 'failed',
                    'error': stderr.decode('utf-8'),
                    'elapsed_time_sec': elapsed_time
                }

        except Exception as e:
            logger.error(f"Exception in {self.sim_config['sim_id']}: {str(e)}")
            return {
                'sim_id': self.sim_config['sim_id'],
                'status': 'error',
                'error': str(e),
                'elapsed_time_sec': time.time() - start_time
            }

    def _generate_input_file(self) -> str:
        """Generate Athena++ .athinput file from simulation config"""
        input_file = os.path.join(self.output_dir, f"{self.sim_config['sim_id']}.athinput")

        params = self.sim_config

        input_content = f"""<job>
simulations = 1
problem_id = {params['sim_id']}

<output>
outdir = {self.output_dir}
file_type = hdf5
variable = prim,density,velocity,magnetic_field
dt = {params.get('hdf5_interval', 0.02)}
tlim = 4.0

<mesher>
nx1 = 256
nx2 = 256
nx3 = 256

<meshblock>
nx1 = 64
nx2 = 64
nx3 = 64

<mesh>
x1min = 0.0
x1max = 16.0
x2min = 0.0
x2max = 2.0
x3min = 0.0
x3max = 2.0
boundary = periodic

<time>
cfl_number = 0.3
integrator = vl2
xorder = 2

<hydro>
eos = iso
iso_sound_speed = 1.0

<field>
b_initial = 1.0
b_angle = 0.0
beta = {params['beta']}

<problem>
problem = filament
line_mass_fraction = {params['f']}
mach_number = {params['mach']}
theta_degrees = {params['theta']}
random_seed = {params['seed']}
gamma_eos = {params.get('gamma', 1.0)}
"""

        with open(input_file, 'w') as f:
            f.write(input_content)

        return input_file


def load_campaign_config(params_file: str) -> Dict:
    """Load campaign configuration from JSON file"""
    with open(params_file, 'r') as f:
        return json.load(f)


def run_campaign(
    params_file: str = 'hgbs_params.json',
    ray_address: str = 'auto',
    concurrent_sims: int = 4
):
    """Main campaign execution function"""

    # Load configuration
    config = load_campaign_config(params_file)
    simulations = config['simulations']

    logger.info(f"Starting campaign: {config['campaign']}")
    logger.info(f"Total simulations: {len(simulations)}")
    logger.info(f"Concurrent simulations: {concurrent_sims}")

    # Initialize Ray
    if ray_address == 'auto':
        ray.init()
    else:
        ray.init(address=ray_address)

    logger.info(f"Ray dashboard: {ray.cluster_resources()}")

    # Create simulation actors
    athena_bin = os.path.join(
        os.path.dirname(__file__),
        'bin',
        'filament_hgbs'
    )

    actors = []
    for sim_config in simulations:
        actor = AthenaSimulation.remote(sim_config, athena_bin)
        actors.append(actor)

    # Execute simulations in batches
    results = []
    total_sims = len(actors)
    completed = 0

    for i in range(0, total_sims, concurrent_sims):
        batch = actors[i:i+concurrent_sims]
        batch_results = ray.get([actor.run.remote() for actor in batch])
        results.extend(batch_results)

        completed += len(batch)
        logger.info(f"Progress: {completed}/{total_sims} simulations")

    # Save results
    results_file = 'P1_hgbs_results.json'
    with open(results_file, 'w') as f:
        json.dump({
            'campaign': config['campaign'],
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'total_simulations': total_sims,
            'results': results
        }, f, indent=2)

    logger.info(f"Results saved to {results_file}")

    # Print summary
    success_count = sum(1 for r in results if r['status'] == 'success')
    logger.info(f"Campaign complete: {success_count}/{total_sims} successful")

    ray.shutdown()

    return results


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='P1-HGBS Campaign Launcher')
    parser.add_argument('--params', default='hgbs_params.json', help='Parameters file')
    parser.add_argument('--ray_address', default='auto', help='Ray cluster address')
    parser.add_argument('--concurrent_sims', type=int, default=4, help='Concurrent simulations')

    args = parser.parse_args()

    # Create logs directory
    os.makedirs('logs', exist_ok=True)

    # Run campaign
    run_campaign(
        params_file=args.params,
        ray_address=args.ray_address,
        concurrent_sims=args.concurrent_sims
    )
