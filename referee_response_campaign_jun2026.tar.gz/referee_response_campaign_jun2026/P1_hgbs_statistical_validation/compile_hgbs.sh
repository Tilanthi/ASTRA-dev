#!/bin/bash
# Compile Athena++ for P1-HGBS Statistical Validation Campaign
# Usage: bash compile_hgbs.sh

set -e  # Exit on error

# Configuration
ATHENA_ROOT=${ATHENA_ROOT:-"/path/to/athena++"}
CAMPAIGN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$CAMPAIGN_DIR/build"
BIN_DIR="$CAMPAIGN_DIR/bin"
PROBLEM_FILE="$CAMPAIGN_DIR/filament_hgbs.cpp"

echo "=========================================="
echo "P1-HGBS Campaign: Athena++ Compilation"
echo "=========================================="
echo "ATHENA_ROOT: $ATHENA_ROOT"
echo "CAMPAIGN_DIR: $CAMPAIGN_DIR"
echo "BUILD_DIR: $BUILD_DIR"
echo "BIN_DIR: $BIN_DIR"
echo ""

# Check Athena++ source exists
if [ ! -d "$ATHENA_ROOT" ]; then
    echo "ERROR: Athena++ source not found at $ATHENA_ROOT"
    echo "Please set ATHENA_ROOT environment variable"
    exit 1
fi

# Create directories
mkdir -p "$BUILD_DIR"
mkdir -p "$BIN_DIR"

# Copy problem file to Athena++
echo "Copying problem file to Athena++..."
cp "$PROBLEM_FILE" "$ATHENA_ROOT/src/patches/filament_hgbs.cpp"

# Configure Athena++
echo "Configuring Athena++..."
cd "$BUILD_DIR"
"$ATHENA_ROOT/configure" \
    --prob=filament_hgbs \
    --coord=cartesian \
    --eos=iso \
    --flux=hllc \
    --int=vl2 \
    --order=2 \
    --mpi

# Compile
echo "Compiling Athena++..."
make -j$(nproc)

# Copy binary to campaign directory
echo "Copying binary to $BIN_DIR..."
cp bin/filament_hgbs "$BIN_DIR/"

# Verify binary exists
if [ -f "$BIN_DIR/filament_hgbs" ]; then
    echo "SUCCESS: Binary created at $BIN_DIR/filament_hgbs"
    ls -lh "$BIN_DIR/filament_hgbs"
else
    echo "ERROR: Binary not created"
    exit 1
fi

echo ""
echo "=========================================="
echo "Compilation complete!"
echo "=========================================="
echo "Binary: $BIN_DIR/filament_hgbs"
echo "Ready to run hgbs_launcher.py"
