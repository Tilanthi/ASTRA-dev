# Referee Response Campaigns - Ray Cluster Deployment Guide
**Date**: 2026-06-04 | **Platform**: Ray distributed computing (NOT Slurm)

---

## System Requirements

### Hardware
- **CPUs**: 32+ cores recommended (flexible, scales with `concurrent_sims` setting)
- **Memory**: 8–16 GB per concurrent simulation
- **Disk**: ~2 GB per simulation for HDF5 outputs
- **Network**: Low-latency interconnect recommended for Ray head-worker communication

### Software
```bash
# Core dependencies
python --version      # Python 3.9+
pip install ray==2.8.0
pip install numpy scipy h5py matplotlib pandas

# MPI (for Athena++)
mpirun --version      # OpenMPI 4.0+ or MPICH 4.0+

# HDF5 libraries
h5cc --version        # HDF5 1.12+

# Optional: For monitoring
pip install ray[default]  # Includes dashboard
```

---

## Quick Start (5-Minute Setup)

### Step 1: Extract and Configure

```bash
# Extract package
tar -xzf referee_response_campaign_jun2026.tar.gz
cd referee_response_campaign_jun2026

# Set Athena++ source path
export ATHENA_ROOT=/path/to/athena++/source

# Verify Athena++ exists
ls $ATHENA_ROOT/src/  # Should show: main.cpp, etc.
```

### Step 2: Compile Athena++ Binaries

```bash
# Compile all 4 campaign binaries
bash P1_hgbs_statistical_validation/compile_hgbs.sh
bash P2_eos_impact_assessment/compile_eos.sh
bash P3_dtc_stable_ridge_completion/compile_dtc.sh
bash P4_width_correction_campaign/compile_width.sh

# Verify binaries exist
ls -lh P*_*/bin/filament_*
# Expected: 4 executables ~5-10 MB each
```

### Step 3: Configure Ray Cluster

```bash
# Edit Ray configuration
nano ray_config.yaml

# Minimal configuration:
ray:
  init:
    redis_address: "auto"  # For single-node
    num_cpus: 32           # Adjust to your system
    object_store_memory: 2000000000  # 2GB
```

### Step 4: Launch First Campaign

```bash
# Initialize Ray head (if not auto-started)
ray start --head --num-cpus=32

# In a separate terminal (for monitoring):
ray dashboard  # Opens http://localhost:8265

# Run P1 campaign (critical path)
python P1_hgbs_statistical_validation/hgbs_launcher.py

# Monitor progress:
tail -f P1_hgbs_statistical_validation/hgbs_launch.log
```

---

## Ray Cluster Configuration

### Option A: Single-Node Cluster (Local Development)

```bash
# Start Ray head with 32 CPUs
ray start --head --num-cpus=32 --port=6379

# Verify Ray is running
ray status

# Run campaign
python P1_hgbs_statistical_validation/hgbs_launcher.py

# After completion, stop Ray
ray stop
```

### Option B: Multi-Node Cluster (Production)

**On Head Node**:
```bash
# Start head node
ray start --head --num-cpus=32 --port=6379 --redis-port=6380

# Note the connection string:
# ray://HEAD_NODE_IP:6379
```

**On Worker Nodes** (repeat for each worker):
```bash
# Connect to head node
ray start --address=ray://HEAD_NODE_IP:6379 --num-cpus=32

# Verify worker connected
ray status
```

**On Head Node** (run campaigns):
```bash
python P1_hgbs_statistical_validation/hgbs_launcher.py
```

### Option C: Cloud Ray Clusters (AWS, GCP, Azure)

```bash
# Install Ray autoscaler
pip install ray[default]

# Configure cluster
nano cluster_config.yaml

# Example AWS configuration:
cluster_name: referee-campaigns
max_workers: 10
provider:
  type: aws
  region: us-east-1
  availability_zone: us-east-1a

head_node:
  InstanceType: c5.9xlarge  # 36 CPUs, 72 GB RAM
  
worker_nodes:
  InstanceType: c5.9xlarge
  InstanceName: referee-worker

# Start cluster
ray up cluster_config.yaml

# Execute campaign
ray exec cluster_config.yaml "cd /home/ubuntu/referee_response_campaign_jun2026 && python P1_hgbs_statistical_validation/hgbs_launcher.py"

# Teardown
ray down cluster_config.yaml
```

---

## Campaign Execution Strategies

### Strategy 1: Sequential (Recommended for Debugging)

```bash
# Run campaigns one at a time
python P1_hgbs_statistical_validation/hgbs_launcher.py
python P2_eos_impact_assessment/eos_launcher.py
python P3_dtc_stable_ridge_completion/dtc_launcher.py
python P4_width_correction_campaign/width_launcher.py

# Pros: Easy to debug, clear error attribution
# Cons: Longer total wall time
```

### Strategy 2: Parallel (Recommended for Production)

```bash
# Run all campaigns simultaneously
ray start --head --num-cpus=128  # Need 128 CPUs for 4×4 concurrent

python P1_hgbs_statistical_validation/hgbs_launcher.py &
P1_PID=$!

python P2_eos_impact_assessment/eos_launcher.py &
P2_PID=$!

python P3_dtc_stable_ridge_completion/dtc_launcher.py &
P3_PID=$!

python P4_width_correction_campaign/width_launcher.py &
P4_PID=$!

wait $P1_PID $P2_PID $P3_PID $P4_PID
```

### Strategy 3: Adaptive (Recommended for Resource-Constrained)

```bash
# Run P1 + P2 first (critical path)
python P1_hgbs_statistical_validation/hgbs_launcher.py &
P1_PID=$!

python P2_eos_impact_assessment/eos_launcher.py &
P2_PID=$!

wait $P1_PID $P2_PID

# If P1 results are NEGATIVE, STOP and reassess
# If P1 results are POSITIVE, continue with P3+P4
python P3_dtc_stable_ridge_completion/dtc_launcher.py &
python P4_width_correction_campaign/width_launcher.py &
```

---

## Campaign-Specific Configuration

### P1-HGBS Configuration

**Edit**: `P1_hgbs_statistical_validation/hgbs_params.json`
```json
{
  "concurrent_sims": 4,
  "mpi_ranks_per_sim": 32,
  "timeout_sec": 72000,
  "output_dir": "output_P1_hgbs"
}
```

**Ray deployment**:
```bash
# Start Ray with sufficient resources
ray start --head --num-cpus=128 --object-store-memory=10000000000

# Run campaign
python P1_hgbs_statistical_validation/hgbs_launcher.py \
  --ray_address=auto \
  --concurrent_sims=4 \
  --output_dir=output_P1_hgbs
```

### P2-EOS Configuration

**Edit**: `P2_eos_impact_assessment/eos_params.json`
```json
{
  "concurrent_sims": 4,
  "mpi_ranks_per_sim": 32,
  "timeout_sec": 54000,
  "output_dir": "output_P2_eos"
}
```

**Ray deployment**:
```bash
python P2_eos_impact_assessment/eos_launcher.py \
  --ray_address=auto \
  --concurrent_sims=4
```

### P3-DTC Configuration

**Edit**: `P3_dtc_stable_ridge_completion/dtc_params.json`
```json
{
  "concurrent_sims": 4,
  "mpi_ranks_per_sim": 32,
  "timeout_sec": 72000,
  "output_dir": "output_P3_dtc"
}
```

**Ray deployment**:
```bash
python P3_dtc_stable_ridge_completion/dtc_launcher.py \
  --ray_address=auto \
  --concurrent_sims=4
```

### P4-Width Configuration

**Edit**: `P4_width_correction_campaign/width_params.json`
```json
{
  "concurrent_sims": 4,
  "mpi_ranks_per_sim": 32,
  "timeout_sec": 54000,
  "output_dir": "output_P4_width"
}
```

**Ray deployment**:
```bash
python P4_width_correction_campaign/width_launcher.py \
  --ray_address=auto \
  --concurrent_sims=4
```

---

## Monitoring and Debugging

### Ray Dashboard

```bash
# Start dashboard (usually auto-started with Ray)
ray dashboard

# Open in browser:
# http://localhost:8265

# What to monitor:
# - Actor utilization (should be >90%)
# - Memory usage (should be <80% of object_store_memory)
# - CPU utilization (should be >80%)
# - Task timelines (check for stragglers)
```

### Log Files

Each campaign writes logs to:
```
P*_*/logs/
├── ray_launcher.log       # Main Ray execution log
├── ray_worker_*.log       # Per-worker logs
└── simulation_*.log       # Per-simulation Athena++ logs
```

**Monitor campaign progress**:
```bash
# Real-time log monitoring
tail -f P1_hgbs_statistical_validation/logs/ray_launcher.log

# Count completed simulations
grep "SIMULATION COMPLETE" P1_hgbs_statistical_validation/logs/ray_launcher.log | wc -l

# Check for errors
grep -i "error\|fail" P1_hgbs_statistical_validation/logs/ray_launcher.log
```

### Common Issues and Fixes

**Issue 1: Ray not responding**
```bash
# Symptoms: "ray.init() timeout"
# Fix: Restart Ray cluster
ray stop
ray start --head --num-cpus=32 --port=6379
```

**Issue 2: Out of memory**
```bash
# Symptoms: "RayOutOfMemoryError"
# Fix: Increase object_store_memory
ray stop
ray start --head --num-cpus=32 --object-store-memory=20000000000  # 20GB
```

**Issue 3: Athena++ simulations hanging**
```bash
# Symptoms: Simulations not completing, no log output
# Fix: Check MPI ranks
mpirun --np 32 /path/to/filament_hgbs -i test.athinput
# Should complete in <1 second for test case
```

**Issue 4: HDF5 files missing**
```bash
# Symptoms: "HDF5 file not found" errors
# Fix: Check output directory permissions
ls -la output_P1_hgbs/
chmod -R u+rw output_P1_hgbs/
```

**Issue 5: Ray actor failures**
```bash
# Symptoms: "Actor died" or "Task failed"
# Fix: Reduce concurrent_sims
# Edit hgbs_params.json: "concurrent_sims": 2
```

---

## Performance Tuning

### Optimal Concurrent Simulation Count

**Formula**: `concurrent_sims = floor(total_cpus / mpi_ranks_per_sim)`

For common configurations:
```
32 CPUs,  32 ranks/sim  → 1 concurrent (no parallelism)
64 CPUs,  32 ranks/sim  → 2 concurrent
128 CPUs, 32 ranks/sim  → 4 concurrent (recommended)
256 CPUs, 32 ranks/sim  → 8 concurrent (maximum efficiency)
```

### Memory Tuning

**Estimate**: ~8 GB per concurrent simulation

```bash
# Calculate object_store_memory:
object_store_memory = 8GB × concurrent_sims × 1.5  # 50% buffer

# For 4 concurrent simulations:
object_store_memory = 8 × 4 × 1.5 = 48 GB
```

### CPU Affinity (Advanced)

For maximum performance on NUMA systems:
```bash
# Bind MPI ranks to specific cores
export MPIRUN_FLAGS="--bind-to core --map-by socket:PE=8"

# Start Ray with CPU isolation
ray start --head --num-cpus=128 --redis-max-memory=5000000000
```

---

## Verification and Validation

### Pre-Deployment Checklist

```bash
# 1. Verify Ray installation
python -c "import ray; print(ray.__version__)"
# Expected: 2.8.0 or higher

# 2. Verify MPI
mpirun --version | head -n 3
# Expected: OpenMPI or MPICH version

# 3. Verify HDF5
h5ls -h
# Expected: HDF5 version message

# 4. Test Athena++ compilation
bash P1_hgbs_statistical_validation/compile_hgbs.sh
ls -lh P1_hgbs_statistical_validation/bin/filament_hgbs
# Expected: Executable file, ~5-10 MB

# 5. Test Ray initialization
ray stop && ray start --head --num-cpus=4
python -c "import ray; ray.init(); print('Ray initialized')"
# Expected: "Ray initialized" with dashboard URL
```

### Post-Deployment Verification

```bash
# 1. Check all simulations completed
python -c "
import json
for campaign in ['P1', 'P2', 'P3', 'P4']:
    result_file = f'output_{campaign}_*/results.json'
    try:
        with open(result_file) as f:
            data = json.load(f)
            success = sum(1 for r in data['results'] if r['status'] == 'success')
            print(f'{campaign}: {success}/{len(data[\"results\"])} success')
    except:
        print(f'{campaign}: Results not found')
"

# 2. Check HDF5 files exist
find output_P* -name "*.hdf5" | wc -l
# Expected:
# P1: 60 simulations × 200 snapshots = 12,000 files
# P2: 35 simulations × 200 snapshots = 7,000 files
# P3: 40 simulations × 200 snapshots = 8,000 files
# P4: 8 simulations × 200 snapshots = 1,600 files
# Total: 28,600 files

# 3. Check log files for errors
grep -r "ERROR\|FAIL" P*_*/logs/ | wc -l
# Expected: 0

# 4. Verify disk usage
du -sh output_P*
# Expected:
# P1: ~120 GB
# P2: ~70 GB
# P3: ~80 GB
# P4: ~16 GB
# Total: ~286 GB
```

---

## Troubleshooting Guide

### Simulation Failures

**Symptom**: Simulation crashes with "NaN detected" or "divergence"
```
Diagnosis:
1. Check input parameters in *.athinput file
2. Check initial condition files (if any)
3. Run single simulation with mpirun for detailed error
```

**Fix**:
```bash
# Run single simulation outside Ray
cd P1_hgbs_statistical_validation/
mpirun -np 32 bin/filament_hgbs -i input/HGVS_f1.1_b2.0_M3.0_s6.athinput 2>&1 | tee debug.log
# Examine debug.log for specific error
```

### Ray Task Starvation

**Symptom**: Campaign hangs with no progress
```
Diagnosis:
1. Check Ray dashboard for stuck tasks
2. Check worker logs for errors
3. Verify sufficient CPUs available
```

**Fix**:
```bash
# Kill and restart Ray
ray stop
ray start --head --num-cpus=32 --redis-port=6379

# Restart campaign
python P1_hgbs_statistical_validation/hgbs_launcher.py
```

### Disk Space Exhaustion

**Symptom**: "No space left on device"
```
Diagnosis:
1. Check disk usage: df -h
2. Check HDF5 output size: du -sh output_*/
```

**Fix**:
```bash
# Clean up failed simulations
find output_P* -name "*.hdf5.tmp" -delete

# Move completed simulations to archival storage
mv output_P1_hgbs /mnt/archive/referee_campaigns/

# Re-run with archival output enabled
# Edit hgbs_params.json: "archive_output": true
```

---

## Production Deployment Template

For production deployment on a dedicated Ray cluster:

```bash
#!/bin/bash
# deploy_referee_campaigns.sh

# Configuration
RAY_HEAD="ray-head-node.example.com"
RAY_CPUS=128
CONCURRENT_SIMS=4
ATHENA_ROOT="/opt/athena++"

# Set up environment
export ATHENA_ROOT=$ATHENA_ROOT
export PATH=$ATHENA_ROOT/bin:$PATH
export PYTHONPATH=$PYTHONPATH:/opt/referee_campaigns

# Start Ray head
ssh $RAY_HEAD "ray stop && ray start --head --num-cpus=$RAY_CPUS"

# Compile binaries on all nodes
pdsh -w worker[0-9] "cd /opt/referee_campaigns && bash P*_*/compile_*.sh"

# Run campaigns sequentially
for campaign in P1 P2 P3 P4; do
  echo "Starting $campaign campaign..."
  ssh $RAY_HEAD "cd /opt/referee_campaigns && python ${campaign}_*/${campaign}_launcher.py"
  echo "Completed $campaign campaign"
done

# Collect results
rsync -av $RAY_HEAD:/opt/referee_campaigns/output_* /mnt/archive/referee_campaigns/

# Run analysis
python unified_analyzer.py --output_dir /mnt/archive/referee_campaigns/

echo "Deployment complete"
```

---

## Contact and Support

**Technical Issues**: Glenn White (g.j.white@open.ac.uk)
**Ray Documentation**: https://docs.ray.io/
**Athena++ Documentation**: https://github.com/PrincetonUniversity/athena-public-version

---

**Deployment Status**: READY FOR PRODUCTION
**Last Updated**: 2026-06-04
