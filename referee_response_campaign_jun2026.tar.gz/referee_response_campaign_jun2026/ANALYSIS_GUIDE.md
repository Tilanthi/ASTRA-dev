# Referee Response Campaigns - Analysis Guide
**Date**: 2026-06-04 | **Purpose**: Post-processing and interpretation protocols

---

## Overview

This guide provides detailed analysis protocols for each of the 4 referee response campaigns. All campaigns produce standardized HDF5 outputs that are processed through the **unified analysis pipeline**.

---

## Quick Start

```bash
# After all campaigns complete:
python unified_analyzer.py --campaigns P1,P2,P3,P4 --output combined_analysis.json

# Generate referee response figures:
python unified_analyzer.py --make_figures --output_dir figures/

# Generate referee response table:
python unified_analyzer.py --make_table --output referee_response_table.tex
```

---

## Unified Analysis Pipeline

### Input Data Structure

Each campaign outputs:
```
output_P*_*/
├── 0000_<campaign_label>_*/
│   ├── snapshot_*.hdf5         # Time series data
│   ├── *.athinput               # Athena++ input file
│   ├── *.log                    # Execution log
│   └── results.json             # Quick-look metrics
```

### Standardized HDF5 Structure

Each HDF5 file contains:
```python
with h5py.File('snapshot_00100.hdf5', 'r') as f:
    f['density'][:]        # Density field (Nx, Ny, Nz)
    f['velocity_x'][:]     # Velocity x-component
    f['velocity_y'][:]     # Velocity y-component
    f['velocity_z'][:]     # Velocity z-component
    f['magnetic_field_x'][:]  # Magnetic field components
    f['magnetic_field_y'][:]
    f['magnetic_field_z'][:]
    f['time'][()]          # Simulation time (in tJ)
    f['attrs']['f']        # Line-mass fraction
    f['attrs']['beta']     # Plasma beta
    f['attrs']['gamma']    # Equation of state index
    f['attrs']['theta']    # Field geometry (degrees)
    f['attrs']['mach']     # Mach number
    f['attrs']['seed']     # Random seed
```

---

## Campaign 1: HGBS Statistical Validation Analysis

### Scientific Questions

1. **Is the HGBS-matching parameter window robust across random seeds?**
2. **Does seed=6 produce consistent results when re-run?**
3. **What is the true HGBS-matching rate with proper statistical sampling?**

### Analysis Protocol

**Step 1: Morphology Classification**
```python
# For each simulation (f, β, θ, M, seed):
# - Load all 200 snapshots
# - Apply filament_identification_algorithm
# - Classify final morphology: NC, CG, STABLE, STOCHASTIC

# Classification criteria:
NC (Node-collapse):  ≥2 fragments, m_max > 0.5 M_total, radial collapse signature
CG (Core-growth):    ≥2 fragments, m_max < 0.3 M_total, longitudinal beading signature
STABLE:              0 fragments, density < 5× background, no growth trend
STOCHASTIC:          0-1 fragments, borderline signatures, high variance
```

**Step 2: HGBS-Matching Criteria**
```python
# HGBS filaments are characterized by:
# - Width: W ≈ 0.1 pc
# - Length-to-width ratio: L/W ≈ 5-20
# - Fragment separation: Δx ≈ 0.3-0.5 pc
# - Non-thermal velocity dispersion: σ_nt ≈ 0.2-0.5 km/s
# - Mass per unit length: M_L ≈ 1-3 M⊙/pc

# Matching criteria (from paper):
is_hgbs_match = (
    (morphology in ['NC', 'CG']) and
    (fragment_separation > 0.3 pc) and
    (l2w_ratio > 5) and
    (non_thermal_velocity < 0.5 km/s)
)
```

**Step 3: Statistical Analysis**
```python
# Calculate HGBS-matching rate for each (f, M, β=2.0, θ=0°):
matching_rate = n_hgbs_matches / n_seeds

# Expected outcomes:
# - IF robust: matching_rate > 0.4 for ≥2 (f, M) combinations
# - IF fragile: matching_rate > 0.4 only for seed=6
# - IF null: matching_rate < 0.2 for all (f, M) combinations
```

### Output Metrics

For each campaign, generate:
```json
{
  "campaign": "P1_hgbs_statistical_validation",
  "total_simulations": 60,
  "morphology_counts": {
    "NC": 12,
    "CG": 8,
    "STABLE": 15,
    "STOCHASTIC": 25
  },
  "hgbs_matches": {
    "by_seed": {
      "6": {"NC": 2, "CG": 1, "total": 3},
      "12": {"NC": 0, "CG": 1, "total": 1},
      "18": {"NC": 0, "CG": 0, "total": 0},
      "24": {"NC": 1, "CG": 0, "total": 1},
      "30": {"NC": 0, "CG": 0, "total": 0}
    },
    "by_parameter": {
      "f=1.0_M=2.5": 0,
      "f=1.0_M=3.0": 1,
      "f=1.0_M=3.5": 0,
      "f=1.1_M=2.5": 2,
      "f=1.1_M=3.0": 3,
      "f=1.1_M=3.5": 1,
      "f=1.2_M=2.5": 0,
      "f=1.2_M=3.0": 1,
      "f=1.2_M=3.5": 0
    }
  },
  "statistical_assessment": {
    "seed_reproducibility": "ROBUST",
    "parameter_window_confirmed": true,
    "hgbs_matching_rate": 0.083,
    "confidence_interval": [0.04, 0.15],
    "verdict": "PARAMETER_WINDOW_CONFIRMED"
  }
}
```

### Referee Response Templates

**If result is ROBUST**:
```
We acknowledge the referee's concern about the statistical fragility of our HGBS-matching
result. We have now run 60 additional simulations testing the claimed parameter window
(f = 1.0-1.2, β = 2.0, θ = 0°, M = 2.5-3.5) across 5 independent random seeds. We find
that the HGBS-matching behavior is reproduced in N/60 = X% of cases, with matches
distributed across multiple seeds. The matching rate is Y% with 95% confidence interval
[Z_low, Z_high], confirming that the parameter window represents a real physical effect
rather than a statistical fluke.
```

**If result is FRAGILE**:
```
We acknowledge the referee's concern about the statistical fragility of our HGBS-matching
result. Our additional 60 simulations reveal that the HGBS-matching behavior is indeed
highly seed-dependent, with N/60 = X% of cases showing matches. However, X% of these
matches come from a single random seed (seed=6), suggesting that the claimed parameter
window may not be robust. We have revised the paper to frame this result as a
hypothesis-generating lead rather than a definitive finding, adding explicit caveats
throughout the text.
```

**If result is NULL**:
```
We acknowledge the referee's concern about the statistical fragility of our HGBS-matching
result. Our additional 60 simulations reveal that the original HGBS-matching result is
not reproducible: N/60 = X% of cases show matches, consistent with random chance.
We have revised the paper to remove the HGBS-matching claim from the central conclusions
and reframe it as an interesting but unconfirmed suggestion for future investigation.
```

---

## Campaign 2: EOS Impact Assessment Analysis

### Scientific Questions

1. **How does the equation of state (γ) affect fragmentation rates?**
2. **Does realistic γ ≈ 0.9 destroy the HGBS-matching parameter window?**
3. **Does the two-regime framework (radial collapse vs longitudinal beading) survive under realistic thermodynamics?**

### Analysis Protocol

**Step 1: Fragmentation Rate vs γ**
```python
# For each γ ∈ [0.7, 0.8, 0.9, 0.95, 1.0]:
# - Count simulations that fragment
# - Calculate fragmentation rate: f_frag(γ) = N_fragment / N_total

# Expected trend:
# γ = 1.0 (isothermal): f_frag ≈ 1.0
# γ = 0.95: f_frag ≈ 0.6
# γ = 0.9: f_frag ≈ 0.2
# γ = 0.8: f_frag ≈ 0.1
# γ = 0.7: f_frag ≈ 0.05
```

**Step 2: HGBS-Matching Rate vs γ**
```python
# For each γ, count HGBS matches at fiducial point:
# - (f=1.1, β=2.0, θ=0°, M=1.0) × 3 seeds

# Compare to isothermal case:
hgbs_efficiency = hgbs_matches(γ) / hgbs_matches(γ=1.0)

# Expected outcomes:
# - If γ=0.9 has 0 matches: HGBS window is isothermal artifact
# - If γ=0.9 has ≥1 match: HGBS window may survive
```

**Step 3: Morphology Transition vs γ**
```python
# For each γ, classify morphologies:
# - Count NC vs CG cases
# - Calculate NC/CG ratio as function of γ

# Key question: Does γ favor one morphology over another?
nc_cg_ratio(γ) = N_NC(γ) / N_CG(γ)

# If NC/CG ratio changes dramatically with γ, morphology is EOS-dependent
```

### Output Metrics

```json
{
  "campaign": "P2_eos_impact_assessment",
  "total_simulations": 35,
  "fragmentation_by_gamma": {
    "0.7": {"fragmented": 1, "total": 7, "rate": 0.14},
    "0.8": {"fragmented": 2, "total": 7, "rate": 0.29},
    "0.9": {"fragmented": 3, "total": 7, "rate": 0.43},
    "0.95": {"fragmented": 5, "total": 7, "rate": 0.71},
    "1.0": {"fragmented": 7, "total": 7, "rate": 1.0}
  },
  "hgbs_matches_by_gamma": {
    "0.7": 0,
    "0.8": 0,
    "0.9": 0,
    "0.95": 1,
    "1.0": 3
  },
  "morphology_by_gamma": {
    "0.7": {"NC": 0, "CG": 1, "STABLE": 5, "STOCHASTIC": 1},
    "0.8": {"NC": 0, "CG": 2, "STABLE": 4, "STOCHASTIC": 1},
    "0.9": {"NC": 1, "CG": 2, "STABLE": 3, "STOCHASTIC": 1},
    "0.95": {"NC": 2, "CG": 3, "STABLE": 1, "STOCHASTIC": 1},
    "1.0": {"NC": 4, "CG": 3, "STABLE": 0, "STOCHASTIC": 0}
  },
  "two_regime_framework_test": {
    "radial_collapse_survives": true,
    "longitudinal_beading_survives": false,
    "transition_boundary_shifted": "f → f + 0.3",
    "verdict": "TWO_REGIME_FRAMEWORK_MODIFIED"
  }
}
```

### Referee Response Templates

**If result is MODERATE** (γ=0.9 preserves some fragmentation):
```
We acknowledge the referee's concern that our isothermal assumption may affect the
quantitative conclusions. We have run a dedicated campaign varying γ from 0.7-1.0 at
the HGBS-matching parameter point. We find that while the fragmentation rate decreases
from 100% (γ=1.0) to X% (γ=0.9), the HGBS-matching behavior persists at a reduced rate
of Y%, with Z matches across N seeds. The two-regime framework survives but with a
shifted transition boundary from f_transition to f_transition + 0.3. We have updated
the paper to include these realistic-γ results throughout the quantitative discussion.
```

**If result is SEVERE** (γ=0.9 destroys HGBS window):
```
We acknowledge the referee's concern that our isothermal assumption may affect the
quantitative conclusions. Our dedicated γ-campaign reveals that realistic thermodynamics
(γ≈0.9) has a profound impact: the fragmentation rate drops from 100% (isothermal) to
X% (γ=0.9), and the HGBS-matching rate drops from 0.56% to Y%. This suggests that the
HGBS-matching parameter window identified in the isothermal campaign does not survive
under realistic ISM conditions. We have revised the paper to: (1) present the isothermal
results as a limiting case rather than directly applicable to real filaments, (2) add
a dedicated section on the impact of realistic thermodynamics, and (3) frame the
HGBS-matching result as a hypothesis requiring future observational validation with
realistic-γ simulations.
```

---

## Campaign 3: DTC Stable-Ridge Completion Analysis

### Scientific Questions

1. **Is the stable ridge truly absent from the DTC parameter space?**
2. **Are the STABLE classifications true stability or timeout artifacts?**
3. **Does the fragmentation boundary change when timeout artifacts are removed?**

### Analysis Protocol

**Step 1: Re-classification with Extended Runtime**
```python
# For each unresolved (β, f, M) combination:
# - Compare original classification (6-hour timeout) to new classification (12-hour timeout)
# - Classify as:
#   - TRUE_STABLE: Both classifications are STABLE
#   - TIMEOUT_ARTIFACT: Original STABLE → new CG/NC
#   - TRUE_FRAGMENTED: Both classifications are CG/NC

# Calculate artifact rate:
artifact_rate = N_timeout_artifacts / N_total_STABLE_original
```

**Step 2: Fragmentation Boundary Recalculation**
```python
# With corrected classifications, recalculate fragmentation boundary:
# - Plot f vs β for each M
# - Fit f_frag(β) = f_0 × (1 + β/β_0)^(-α)
# - Compare to original boundary

# Key question: Does the boundary shift?
boundary_shift = f_frag_new - f_frag_original
```

**Step 3: Stable-Ridge Test**
```python
# Test for continuous stable ridge:
# - Fit f_stable(β) = f_min (constant)
# - Calculate goodness-of-fit: R²

# If R² > 0.8, stable ridge exists
# If R² < 0.5, no stable ridge (fragmentation everywhere)
```

### Output Metrics

```json
{
  "campaign": "P3_dtc_stable_ridge_completion",
  "total_simulations": 40,
  "reclassification": {
    "region_1": {
      "beta": 0.5,
      "mach": 1.0,
      "true_stable": 8,
      "timeout_artifact": 6,
      "true_fragmented": 0,
      "artifact_rate": 0.43
    },
    "region_2": {
      "beta": 0.3,
      "mach": 2.0,
      "true_stable": 10,
      "timeout_artifact": 4,
      "true_fragmented": 0,
      "artifact_rate": 0.29
    }
  },
  "fragmentation_boundary": {
    "original": {
      "beta_0.5": 0.8,
      "beta_0.3": 0.6,
      "fit_parameters": {"f_0": 0.5, "beta_0": 1.0, "alpha": 0.3}
    },
    "corrected": {
      "beta_0.5": 0.75,
      "beta_0.3": 0.55,
      "fit_parameters": {"f_0": 0.48, "beta_0": 0.95, "alpha": 0.28}
    },
    "boundary_shift": 0.05,
    "significance": "MINOR (<10% shift)"
  },
  "stable_ridge_test": {
    "exists": false,
    "r_squared": 0.35,
    "conclusion": "NO_CONTINUOUS_RIDGE"
  },
  "verdict": "FRAGMENTATION_BOUNDARY_CONFIRMED"
}
```

### Referee Response Templates

**If result is CONFIRMED** (no stable ridge):
```
We acknowledge the referee's concern about potential timeout artifacts in the DTC
stable-ridge classifications. We have completed re-runs for all unresolved (β, f, M)
combinations with extended 12-hour timeouts. We find that N/40 = X% of the original
STABLE classifications were timeout artifacts, reclassifying as CG. After correction,
the fragmentation boundary shifts by only Δf = 0.05 (<10% change), and we confirm that
no continuous stable ridge exists in the DTC parameter space. The paper's conclusions
about the absence of a stability threshold remain valid.
```

**If result is MIXED** (some true stability):
```
We acknowledge the referee's concern about potential timeout artifacts in the DTC
stable-ridge classifications. Our re-runs with extended timeouts reveal that N/40 = X%
of the original STABLE classifications were timeout artifacts. However, Y cases show
true stability even with extended runtime, suggesting the presence of a fragmented
stable ridge at low f and strong β. We have updated the paper to: (1) revise the
fragmentation boundary to include these stable islands, and (2) soften the claim
about "no stability threshold" to "no continuous stability threshold."
```

---

## Campaign 4: Width-Definition Correction Analysis

### Scientific Questions

1. **Can we reconcile the simulation width (W_core = 0.062 pc) with observed width (W_fil = 0.1 pc)?**
2. **Does width adjustment change the HGBS-matching classifications?**
3. **What is the correct factor to convert simulation λ/W to observational λ/W?**

### Analysis Protocol

**Step 1: Width Measurement from Simulations**
```python
# For each simulation, measure filament width from density profile:
# - Extract transverse density profile ρ(r) at filament center
# - Fit ρ(r) = ρ_0 × exp(-r²/W²) or ρ(r) = ρ_0 / (1 + (r/W)²)
# - Extract FWHM: W_fwhm
# - Convert to half-width: W_core = W_fwhm / 2

# Compare to target width:
width_ratio = W_core / W_target
# Should be ≈ 1.0 if width adjustment successful
```

**Step 2: HGBS-Matching Test with Matched Width**
```python
# For each adjusted-width simulation, test HGBS-matching criteria:
# - Morphology: NC or CG
# - Fragment separation: Δx ≈ 0.3-0.5 pc
# - Length-to-width ratio: L/W ≈ 5-20
# - Non-thermal velocity: σ_nt ≈ 0.2-0.5 km/s

# Compare to original (unadjusted) simulations:
classification_change = morphology_new - morphology_old
```

**Step 3: Correction Factor Validation**
```python
# Calculate the empirical correction factor:
correction_factor = (λ / W)_observed / (λ / W)_simulation

# Compare to theoretical correction:
theoretical_correction = W_target / W_simulation ≈ 1.6

# If correction_factor ≈ 1.6, width definition is the only difference
# If correction_factor ≠ 1.6, additional physics is involved
```

### Output Metrics

```json
{
  "campaign": "P4_width_correction_campaign",
  "total_simulations": 8,
  "width_adjustment": {
    "approach_1_lower_density": {
      "target_width_pc": 0.1,
      "achieved_width_pc": 0.098,
      "success_rate": 0.98,
      "density_reduction_factor": 2.5
    },
    "approach_2_higher_temperature": {
      "target_width_pc": 0.1,
      "achieved_width_pc": 0.102,
      "success_rate": 1.02,
      "temperature_increase_factor": 2.6
    }
  },
  "morphology_preservation": {
    "NC": {"preserved": 2, "changed": 0, "preservation_rate": 1.0},
    "CG": {"preserved": 1, "changed": 1, "preservation_rate": 0.5},
    "STABLE": {"preserved": 1, "changed": 0, "preservation_rate": 1.0},
    "STOCHASTIC": {"preserved": 0, "changed": 1, "preservation_rate": 0.0}
  },
  "correction_factor_validation": {
    "theoretical": 1.6,
    "empirical": 1.55,
    "agreement": "GOOD (<5% difference)",
    "lambda_over_W_shifted": "3.70 → 5.97 (longitudinal), 2.02 → 2.54 (perpendicular)"
  },
  "verdict": "WIDTH_CORRECTION_VALIDATED"
}
```

### Referee Response Templates

**If result is VALIDATED** (width correction works):
```
We acknowledge the referee's concern about the width-definition inconsistency between
simulations (W_core = 0.062 pc) and observations (W_fil = 0.1 pc). We have run a dedicated
campaign testing two approaches to match the simulation width to observations: (1) lowering
the initial density, and (2) increasing the initial temperature. We find that both
approaches successfully produce filaments with W ≈ 0.1 pc, and the morphological
classifications (NC, CG, STABLE) are preserved in X/8 cases. The empirical correction
factor for λ/W is Y, in good agreement with the theoretical factor of 1.6. We have
updated the paper to apply this correction consistently throughout all theory-observation
comparisons.
```

**If result is PROBLEMATIC** (width changes morphology):
```
We acknowledge the referee's concern about the width-definition inconsistency between
simulations and observations. Our width-adjustment campaign reveals that matching the
simulation width to observations (W_fil = 0.1 pc) changes the morphological classifications
in N/8 cases, suggesting that the width definition is not merely a scaling factor but
a fundamental parameter affecting fragmentation physics. We have updated the paper to:
(1) report all simulation results in terms of both W_core and W_fil, (2) apply the
width correction factor explicitly in all theory-observation comparisons, and (3) add
a discussion of the sensitivity of fragmentation outcomes to the width definition.
```

---

## Combined Analysis and Synthesis

### Cross-Campaign Synthesis

After analyzing all 4 campaigns, synthesize the results into a coherent referee response:

```python
# Generate combined assessment
combined_verdict = {
    "P1_hgbs_robustness": "ROBUST" | "FRAGILE" | "NULL",
    "P2_eos_impact": "MODERATE" | "SEVERE" | "CATASTROPHIC",
    "P3_dtc_completion": "CONFIRMED" | "MIXED",
    "P4_width_correction": "VALIDATED" | "PROBLEMATIC",
    "overall_paper_status": "STANDS" | "REVISED" | "MAJOR_REVISION" | "WITHDRAWN"
}
```

### Referee Response Strategy

**If overall status is STANDS**:
- Emphasize statistical robustness (P1)
- Acknowledge EOS impact but note framework survives (P2)
- Confirm DTC results (P3)
- Validate width correction (P4)
- Referee's major concerns addressed

**If overall status is REVISED**:
- Acknowledge limitations in original HGBS-matching claim (P1)
- Quantify EOS impact throughout (P2)
- Update DTC boundary if needed (P3)
- Apply width corrections consistently (P4)
- Moderate revisions to text and figures

**If overall status is MAJOR_REVISION**:
- Reframe HGBS-matching as hypothesis-generating (P1)
- Add dedicated EOS section (P2)
- Revise fragmentation boundary discussion (P3)
- Reconcile width definitions throughout (P4)
- Substantial text rewriting required

**If overall status is WITHDRAWN**:
- Original HGBS-matching claim not reproducible (P1)
- Realistic thermodynamics destroys window (P2)
- Fragmentation boundary fundamentally wrong (P3)
- Width definition changes everything (P4)
- Paper needs complete reframing

---

## Visualization Templates

### Figure 1: HGBS-Matching Rate vs Random Seed (P1)

```python
# Plot: HGBS matches as function of seed
plt.scatter(seeds, n_matches_per_seed)
plt.axhline(y=expected_null_rate, color='r', linestyle='--', label='Random expectation')
plt.xlabel('Random Seed')
plt.ylabel('Number of HGBS Matches')
plt.title('P1: Statistical Robustness of HGBS-Matching Window')
```

### Figure 2: Fragmentation Rate vs γ (P2)

```python
# Plot: Fragmentation rate vs EOS index
plt.plot(gamma_values, fragmentation_rates, 'o-')
plt.fill_between(gamma_values, frag_lower, frag_upper, alpha=0.3)
plt.xlabel('Equation of State Index (γ)')
plt.ylabel('Fragmentation Rate')
plt.title('P2: Impact of Realistic Thermodynamics on Fragmentation')
```

### Figure 3: DTC Fragmentation Boundary (P3)

```python
# Plot: f vs β showing fragmentation boundary
plt.plot(beta_values, f_frag_original, 'b--', label='Original (6-hour timeout)')
plt.plot(beta_values, f_frag_corrected, 'r-', label='Corrected (12-hour timeout)')
plt.xlabel('Plasma Beta (β)')
plt.ylabel('Critical Line-Mass Fraction (f_frag)')
plt.title('P3: DTC Fragmentation Boundary with Extended Runtime')
plt.legend()
```

### Figure 4: Width Correction Factor (P4)

```python
# Plot: Simulation vs Observed λ/W
plt.scatter(lambda_over_W_sim, lambda_over_W_obs)
plt.plot([0, 10], [0, 10*1.6], 'r--', label='Expected (factor 1.6)')
plt.xlabel('Simulation λ/W (W_core = 0.062 pc)')
plt.ylabel('Observational λ/W (W_fil = 0.1 pc)')
plt.title('P4: Width-Definition Correction Validation')
```

---

## Output Deliverables

After running the unified analysis pipeline, generate:

1. **combined_analysis.json**: Raw analysis results for all campaigns
2. **referee_response_table.tex**: LaTeX table for referee response
3. **figures/**: All visualization figures (PDF + PNG)
4. **referee_response_text.md**: Draft text for referee response
5. **paper_revisions.md**: Specific text revisions needed for paper

---

## Contact and Support

**Analysis Questions**: Glenn White (g.j.white@open.ac.uk)
**Pipeline Issues**: Check unified_analyzer.py logs
**Interpretation Help**: See referee response templates above

---

**Analysis Status**: READY FOR EXECUTION
**Last Updated**: 2026-06-04
